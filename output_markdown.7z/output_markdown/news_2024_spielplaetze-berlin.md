

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 30.05.2024

#### Kinderspielplätze 2023 in Berlin

Wieviel Spielflächen bietet die Stadt?
--------------------------------------

![Mädchen auf einer Schaukel im Sonnenlicht](https://download.statistik-berlin-brandenburg.de/5bd474bde5e5835e/a72ea1539dcf/v/0d94dcf8272a/istockphoto-904206258-2048x2048.jpg "Mädchen auf einer Schaukel im Sonnenlicht")

**Spielplätze sind essenzielle Orte für die kindliche Entwicklung, bieten Raum für Bewegung, Kreativität und soziales Miteinander. Nicht umsonst gibt es in Berlin seit 1995 das Kinderspielplatzgesetz, nach welchem öffentliche Spielplätze anzulegen, zu unterhalten und weiterzuentwickeln sind. Gemäß § 4 gilt ein Richtwert von einem Quadratmeter nutzbarer Spielfläche je Einwohnerin oder Einwohner. Unsere Karte zeigt, wo in Berlin dieser Wert erreicht wird.**

Die Spielplatzfläche je Einwohnerin oder Einwohner in Berlin variiert zwischen den Berliner Ortsteilen (hier [Planungsräume](/meine-region/lebensweltlich-orientierte-raeume-berlin)). Mit fünf Quadratmetern haben Personen, die in Märchenland im Nordosten Berlins wohnen, den größten Platz zum Spielen. Das Frauenviertel im Süden sowie der Pillnitzer Weg ganz im Westen folgen dicht mit 4,4 Quadratmetern. Größtenteils wird der Richtwert von einem Quadratmeter nicht erreicht, vielerorts steht jedem Einwohnenden im Schnitt nicht einmal ein halber Quadratmeter zur Verfügung.

#### Was ist eine Nettospielfläche?

Betrachtet werden immer die Nettospielflächen, das heißt direkt bespielbare Flächen ohne das Rahmengrün. Die Festlegung der anrechenbaren öffentlichen Nettospielflächen obliegt den Bezirken. Angerechnet werden alle von Berlin unterhaltenen Spielplatzflächen.

###### 31.12.2023 in Berlin am Ort der Hauptwohnung nach Planungsräumen

#### Fläche öffentlicher Kinderspielplätze je Einwohnende

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Interessant ist in diesem Zusammenhang auch ein Blick auf die Anzahl der Kinder in den jeweiligen Berliner Ortsteilen. So leben im bereits erwähnten Märchenland 122 Kinder unter 15 Jahren, im Frauenviertel dagegen 594. Die Ortsteile Brunnenstraße, Märkisches Zentrum, Maulbeerallee und Gropiusstadt Nord-West haben die meisten Kinder unter 15 Jahren. Keine dieser Gegenden erzielt den Richtwert.

###### 31.12.2023 in Berlin am Ort der Hauptwohnung nach Planungsräumen

#### Kinder im Alter unter 15 Jahren

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Sie wollen wissen, in welchem Planungsraum (LOR) Sie wohnen? Unsere Adressauskunft hilft Ihnen weiter.

[Zur Adressauskunft Berlin](/adressauskunft)
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Spielplatz](/search-results?q=tag%3ASpielplatz)
