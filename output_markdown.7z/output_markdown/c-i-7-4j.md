

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Baumschulerhebung in Brandenburg](/c-i-7-4j)

Baumschulerhebung in Brandenburg
--------------------------------

#### 2021, vierjährlich

###### Die aus der Baumschulerhebung gewonnenen Daten bieten Informationen über die Nutzung von Baumschulflächen und die Struktur der Baumschulbetriebe.

BrandenburgMethodik
### Brandenburg

**29 Hektar Fläche pro Baumschulbetrieb**

2021 bewirtschafteten die 37 Baumschulen Brandenburgs 1.073 Hektar. Bei der vorangegangenen Erhebung im Jahr 2017 waren es noch 50 Betriebe mit einer Fläche von 1.145 Hektar.

Rein rechnerisch verfügte ein Baumschulbetrieb im Jahr 2021 über 29 Hektar Baumschulfläche. Die Baumschulproduktion erfolgt fast ausschließlich im Freiland. Fast die Hälfte der brandenburgischen Baumschulfläche (518 Hektar) stand für die Anzucht von Ziersträuchern und Bäumen zur Verfügung. Forstpflanzen wurden auf 11 % der Baumschulfläche (117 Hektar) herangezogen. Des Weiteren wuchsen auf 5 % der Fläche (52 Hektar) Heckenpflanzen.

Das Tabellenprogramm im Bericht umfasst die Baumschulflächen insgesamt und nach Pflanzengruppen und Vermehrungsmerkmalen sowie die Bestände an Forstpflanzen nach Zahl und Art.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/cd931410ceab9899/7984423764cf/SB_C01-07-00_2021j04_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/8a5ff52a4fcb558e/c2d502627baf/SB_C01-07-00_2021j04_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

* [0331 8173-3054](tel:0331 8173-3054)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Baumschulerhebung ist eine dezentrale Bundesstatistik. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht. Auskunftspflichtig sind immer die Inhaberinnen und Inhaber bzw. Leiterinnen und Leiter von Betrieben mit Baumschulflächen von 0,5 ha und mehr.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Baumschulerhebung**  
Metadaten 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/5d456aa13e8eacd9/2f244aca6882/MD_41221_2021.pdf)[Archiv](https://download.statistik-berlin-brandenburg.de/5d456aa13e8eacd9/2f244aca6882/MD_41221_2021.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-7-4j)
