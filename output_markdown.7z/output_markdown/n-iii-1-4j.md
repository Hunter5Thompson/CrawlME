

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Arbeitskosten](/arbeitskosten)
* [Arbeitskosten im Produzierenden Gewerbe und im Dienstleistungsbereich in Berlin und Brandenburg](/n-iii-1-4j)

Arbeitskosten im Produzierenden Gewerbe und im Dienstleistungsbereich
---------------------------------------------------------------------

#### 2020, vierjährig

  
###### Die Erhebung der Struktur der Arbeitskosten (Arbeitskostenerhebung) bildet die Arbeitskosten und Arbeitszeiten in den Betrieben und Unternehmen ab, insbesondere die über die Bruttoverdienste hinausgehenden Kostenbestandteile wie die Sozialleistungen der Arbeitgeber.

BerlinBrandenburgMethodik
### Berlin

 **Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/bf8b50c3a1d166e2/a45138bec148/SB_N03-01-00_2020j04_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/beb3ddfa6b4ed631/e9717d4e6cc7/SB_N03-01-00_2020j04_BE.pdf)

**Arbeitskosten in Berlin**

Im Jahr 2020 betrugen die Arbeitskosten je geleistete Stunde in Berlin durchschnittlich 38,95 EUR.

2020 fielen in Berlin die Arbeitskosten im Produzierenden Gewerbe mit 39,11 EUR höher aus, als im Dienstleistungsbereich mit 38,93 EUR. Im Vergleich zu 2016 stiegen sie damit um 6,8 % bzw. 19,9 % an.

In den einzelnen Wirtschaftszweigen schwankten die Arbeitskosten erheblich. Die höchsten Arbeitskosten in Berlin wurden in den Wirtschaftszweigen Rundfunkveranstalter mit 67,44 EUR und der Luftfahrt mit 61,62 EUR ermittelt. Am wenigsten kostete eine Arbeitsstunde 2020 in der Gastronomie mit 19,25 EUR sowie im Wach- und Sicherheitsdienst mit 20,79 EUR.

### Kontakt

#### Mandy Elster

Verdienste

#### Mandy Elster

Verdienste

* [0331 8173-3044](tel:0331 8173-3044)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Katrin Skerra

Verdienste

#### Katrin Skerra

Verdienste

* [0331 8173-3454](tel:0331 8173-3454)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Arbeitskosten in Brandenburg**

Im Jahr 2020 betrugen die Arbeitskosten je geleistete Stunde in Brandenburg durchschnittlich 31,07 EUR.

In Brandenburg wurden die höchsten Arbeitskosten beim Sonstigen Fahrzeugbau mit 57,49 EUR und mit 53,69 bei Rundfunkveranstaltern beobachtet. Relativ gering waren die Kosten je Arbeitsstunde bei der Herstellung von Leder, Lederwaren und Schuhen mit 16,52 EUR sowie in der Gastronomie mit 19,30 EUR.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/15e17017321a5f0c/8cbddd9dfbce/SB_N03-01-00_2020j04_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/8ef31752cd0e4ee3/41b5290bd266/SB_N03-01-00_2020j04_BB.pdf)
### Kontakt

#### Mandy Elster

Verdienste

#### Mandy Elster

Verdienste

* [0331 8173-3044](tel:0331 8173-3044)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Katrin Skerra

Verdienste

#### Katrin Skerra

Verdienste

* [0331 8173-3454](tel:0331 8173-3454)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Arbeitskostenerhebung ermöglicht Aussagen über die Höhe und strukturelle Zusammensetzung der Arbeitskosten. Es werden Angaben zu allen Bestandteilen der Arbeitskosten und Lohnnebenkosten ermittelt. Veröffentlicht wird die durchschnittliche Höhe und Zusammensetzung der Arbeitskosten je Vollzeiteinheit oder geleistete Arbeitsstunde.

Die Befragung findet als Stichprobenerhebung in Unternehmen mit mindestens zehn Beschäftigten alle vier Jahre statt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Arbeitskosten**2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/27adfe9a080e1437/a7dd9d65ce8c/MD_62411_2020.pdf)[Archiv](/search-results?q=62411&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/n-iii-1-4j)


