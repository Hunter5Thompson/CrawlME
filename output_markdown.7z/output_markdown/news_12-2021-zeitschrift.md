

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 22.12.2021

#### Neue Ausgabe der Zeitschrift für amtliche Statistik Berlin Brandenburg

Schwerpunkt: Auswirkungen der Corona-Pandemie in der Region
-----------------------------------------------------------

![](https://download.statistik-berlin-brandenburg.de/28dce3bcf3766941/3a356d29e543/v/3c60685599c9/corona-bg.jpg)

**Im Mittelpunkt von Ausgabe 3+4/2021 der Zeitschrift für amtliche Statistik Berlin Brandenburg stehen die Corona-Pandemie und ihre Auswirkungen auf die verschiedenen Lebens- und Wirtschaftsbereiche in unserer Region.**

In der Tradition des Corona-Dossiers zeichnen wir die Entwicklungen bei Preisen und Inflation, Erwerbstätigkeit und Bruttowertschöpfung sowie Tourismuszahlen, Zuwanderung, Unfall- und Insolvenzgeschehen statistisch nach. Die monatliche Auswertung der Todesursachen ermöglicht Aussagen darüber, wie viele Menschen  
tatsächlich an dem Corona-Virus verstorben sind und bei wie vielen es eine Begleiterkrankung war.  
  
Ein weiterer Beitrag befasst sich mit den Aufgaben der Statistischen Ämter des Bundes und der Länder am Beispiel der Steuerpolitik. Ergänzend stellt Walter J. Radermacher im Fachgespräch Überlegungen für eine zukunftsfähige amtliche Statistik an und benennt die damit verbundenen Herausforderungen.  


Wie die für den Zensus 2022 relevanten Anschriften in der Hauptstadtregion identifiziert werden, beschreibt ein weiterer Bericht. Das Dauerbrennerthema „bezahlbarer Wohnraum“ in Berlin ist Gegenstand einer statistischen Untersuchung unseres Forschungsnachwuchses. Und nicht zuletzt informieren wir über die voraussichtliche Entwicklung der Bevölkerungszahl Brandenburgs bis 2030.

![](https://download.statistik-berlin-brandenburg.de/88ba36d60239642c/19c89d2d8667/v/5381abdf4279/Titel-Zeitschrift-3-4-2021.png)[Lesen Sie hier die aktuelle Ausgabe.](https://download.statistik-berlin-brandenburg.de/0e2a6bd7d6fd44ce/b43aa17fd047/Zeitschrift-20210304.pdf) 

Dies ist die letzte Ausgabe der *Zeitschrift für amtliche Statistik Berlin Brandenburg*, die Sie sowohl als Druckexemplar als auch im PDF-Format lesen können.   


Ab 2022 finden Sie unsere tiefgehenden statistischen Analysen, Fachgespräche sowie Informationen zu aktuellen Entwicklungen in der amtlichen Statistik und im Amt für Statistik Berlin-Brandenburg in gewohnter Qualität ausschließlich [online an dieser Stelle.](/news)   


Alle Ausgaben seit 2007 können Sie in der [Statistischen Bibliothek](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000025) kostenfrei herunterladen.   


  
### Kontakte

#### Nicole Dombrowski

Fachredaktion

#### Nicole Dombrowski

Fachredaktion

* [zeitschrift@statistik-bbb.de](mailto:zeitschrift@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen
