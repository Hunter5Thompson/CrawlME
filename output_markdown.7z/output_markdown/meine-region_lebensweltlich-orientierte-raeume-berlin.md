

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Was sind Berlins Raumbezüge?](/meine-region/lebensweltlich-orientierte-raeume-berlin)

Lebensweltlich
==============

orientierte Räume
=================

Die wichtigste kleinräumige Gliederung für Berlin ist die der Lebensweltlich orientierten Räume (LOR). Die kleinräumige Gliederung als Lokalisierungs- und Zuordnungssystem ist ein Organisationsmittel von Kommunalverwaltungen unter anderem zur Unterstützung des Verwaltungsvollzugs und von statistischen Erhebungen. Die gebildeten Teilräume lassen sich voneinander abgrenzen und sind vergleichbar.

[Überblick
#### Meine Region](/meine-region)[+ InfoRegionale Statistiken
#### Welche lokalen Daten bieten wir?](/meine-region/regionale-statistiken)[+ DatenBerlin-Statistik 
#### Bezirks-, Stadtteil- und Kiezdaten](/kommunalstatistik)[+ InfoLebensweltlich orientierte Räume
#### Was sind Berlins Raumbezüge?](/meine-region/lebensweltlich-orientierte-raeume-berlin)

Die räumliche Abgrenzung der LOR wurde nach fachlichen Kriterien festgelegt, während die Raumabgrenzungen der **[Regionalstatistik](/meine-region/regionale-statistiken)**auf Grenzen der administrativen Einheiten (Brandenburg: Kreis und Gemeinde, Berlin: Bezirke) basieren. Es hat das Raumbezugssystem der „Statistischen Gebiete/Verkehrszellen“ für sozialräumliche Planungszwecke abgelöst.

Die kleinste Ebene der LOR ist die der Planungsräume. Wir in der Statistik nutzen dieses System, während in der Mundart häufig der Begriff „Kiez“ verwendet wird.

Ein Adressverzeichnis für die LOR sowie eine Auflistung der Straßenumbenennungen finden Sie [**hier**](/publikationen#verzeichnisse).

![](https://download.statistik-berlin-brandenburg.de/fe0a261f79f42bad/85a0b6574984/v/038a6a7b8f63/lor-erklaergrafik.png)

542 Planungsräume
-----------------

![](https://download.statistik-berlin-brandenburg.de/c4ea712ad96e6f7e/eebcc3d1653f/v/8797ab9a8f7e/lor1.png)

**Bezirk**

![](https://download.statistik-berlin-brandenburg.de/f3050e79a2d1e10e/d7917f457a60/v/5cce70629f3a/lor2.png)

**Prognoseraum**

![](https://download.statistik-berlin-brandenburg.de/192af3e6d6f2cb4a/574eea7d7508/v/405597926c35/lor3.png)

**Bezirksregion**

![](https://download.statistik-berlin-brandenburg.de/80f312bb6ac43a4e/a579009d5789/v/8f03fac0d5d7/lor4.png)

**Planungsraum**

![](https://download.statistik-berlin-brandenburg.de/1015e65acd5e9308/ba191f7ee815/v/49cde744fb57/lor5.png)

**Block**

![](https://download.statistik-berlin-brandenburg.de/663e32f25e4dfcb8/61dc4166e9a9/v/a55911538f04/lor1neu.png)

**Adresse**

LOR-Systematik
--------------

Die erstmals 2006 festgelegten Räume wurden aufgrund der dynamischen Bevölkerungsentwicklung Berlins sowie städtebaulicher Neu- bzw. Umstrukturierungen in einem gemeinsamen Projekt der Senatsverwaltung für Stadtentwicklung und Wohnen und des Amtes für Statistik Berlin-Brandenburg überarbeitet. Zahlreiche Planungsräume wurden geteilt, zusammengelegt oder bei Entstehung neuer Stadtquartiere neu aufgenommen. Die überarbeiteten Lebensweltlich orientierten Räume sind seit dem 01.01.2021 gültig.  


Die Systematik der LOR besteht nach der Modifikation aus:

Planungsräumen (PLR) als unterste Ebene: 542 Räume

Bezirksregionen (BZR) als mittlere Ebene: 143 Räume

Prognoseräumen (PGR) als oberste Ebene: 58 Räume

![Erklärung LOR-Nummern](https://download.statistik-berlin-brandenburg.de/aced155638263813/4409a5468394/v/ccb36b2f7a7b/lor-nummer.png)

Modifikation der Planungsräume
------------------------------

![](https://download.statistik-berlin-brandenburg.de/c2f2a6b781a38489/0b17a0e1475d/v/35c88932b5ad/schmuckbild-lor2.png)

**Der LOR-Atlas dokumentiert die Änderungen, die mit Einführung der neuen LOR-Systematik am 1. Januar 2021 an der bisherigen Gliederung von 2006 vorgenommen wurden. Zahlreiche Planungsräume wurden geteilt, zusammengelegt oder bei der Entstehung neuer Stadtquartiere neu aufgenommen.**

Mithilfe der Filterfunktion können sich Nutzende diese Modifikationen der Lebensweltlich orientierten Räume anzeigen lassen und vergleichen.

[Interaktive Karte öffnen](https://web.statistik-berlin-brandenburg.de/instantatlas/interaktivekarten/planungsrauume/atlas.html)

Berlin-Statistik
----------------

**Für die kommunale Planung Berlins werden kleinräumige Daten benötigt, die von der Kommunalstatistik aufbereitet,
analysiert und zur Verfügung gestellt werden.**

Unsere Veröffentlichungen bieten
einen Überblick über die wichtigsten statistischen Informationen für die Stadt
Berlin. Dabei liegen die Schwerpunkte in der Einwohnerregisterstatistik sowie
der Arbeitslosen- und Kraftfahrzeugstatistik.

[Zu den Zahlen](/kommunalstatistik)![](https://download.statistik-berlin-brandenburg.de/e12f1f58431a4d69/7fd42169383c/v/62de57bb5513/schmuckbild-meine-region-berlin2_1.png)
