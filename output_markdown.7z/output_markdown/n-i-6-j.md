

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Verdienste](/verdienste)
* [Verdiensterhebung in Berlin und Brandenburg](/n-i-6-j)

Verdiensterhebung
-----------------

#### 2023, jährlich

###### Mit der Statistik der Verdienste werden jährlich Verdienstniveaus und Verdienstindizes über betriebliche und persönliche Eigenschaften sowie Beschäftigungsverhältnisse ermittelt.

BerlinBrandenburgMethodik
### Berlin

\*  Bruttostundenverdienste ohne Sonderzahlungen der vollzeitbeschäftigten Arbeitnehmer/-innen **Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/1f05d86b975ef492/5deadece134e/SB_N01-06-00_2023j01_BE.xlsx)

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/eba0dc2ec15e52f7/09853b6bbd9e/SB_N01-06-00_2023j01_BE.pdf)

**Verdienste in Berlin**

Arbeitnehmerinnen und Arbeitnehmer in Vollzeit verdienen in Berlin im Durchschnitt 27,29 EUR die Stunde. Je nach Anforderungsniveau, also der Komplexität bzw. Schwierigkeit der auszuübenden Tätigkeit unterscheiden sich die Bruttostundenverdienste deutlich. So verdient ein Experte (Anforderungsniveau 4) im Schnitt 18,41 EUR pro Stunde mehr als ein Helfer (Anforderungsniveau 1).

Auch zwischen den Geschlechtern zeigen sich Unterschiede. Je höher das Anforderungsniveau ist, desto höher ist der Verdienstunterschied zwischen Männern und Frauen. Während die Abweichung bei Helfern und Fachkräften (Anforderungsniveau 2) unter einem Euro liegen, verdienen Frauen im Anforderungsniveau 3 (Spezialist) 1,89 EUR die Stunde weniger, als ihre männlichen Kollegen. Bei den Experten sind es 3,87 EUR.

### Kontakt

#### Katja Kirchner

Verdienste/Preise

#### Katja Kirchner

Verdienste/Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Verena Staib

Verdienste

#### Verena Staib

Verdienste

* [0331 8173 -3049](tel:0331 8173 -3049)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Mandy Elster

Verdienste

#### Mandy Elster

Verdienste

* [0331 8173-3044](tel:0331 8173-3044)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Verdienste in Brandenburg**

Arbeitnehmerinnen und Arbeitnehmer in Vollzeit verdienen in Brandenburg im Durchschnitt 21,86 EUR die Stunde. Je nach Anforderungsniveau, also der Komplexität bzw. Schwierigkeit der auszuübenden Tätigkeit unterscheiden sich die Bruttostundenverdienste deutlich. So verdient ein Experte (Anforderungsniveau 4) im Schnitt 15,58 EUR pro Stunde mehr als ein Helfer (Anforderungsniveau 1).

Auch zwischen den Geschlechtern zeigen sich Unterschiede. Je Höher das Anforderungsniveau ist, desto Höher ist der Verdienstunterschied zwischen Männern und Frauen, außer bei der Fachkraft (Anforderungsniveau 2). Hier verdienen Frauen im Durchschnitt 0,76 EUR die Stunde mehr als die Männer. Bei den Spezialisten verdienen die Männer 0,94 EUR die Stunde mehr, bei den Experten sind es 3,53 EUR.

\*  Bruttostundenverdienste ohne Sonderzahlungen der vollzeitbeschäftigten Arbeitnehmer/-innen **Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/adff5dc35160d7e9/759c49e77a4c/SB_N01-06-00_2023j01_BB.xlsx) 

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/441f0dc5086a882e/7c5de6bef53b/SB_N01-06-00_2023j01_BB.pdf)
### Kontakt

#### Katja Kirchner

Verdienste/Preise

#### Katja Kirchner

Verdienste/Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Verena Staib

Verdienste

#### Verena Staib

Verdienste

* [0331 8173 -3049](tel:0331 8173 -3049)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Mandy Elster

Verdienste

#### Mandy Elster

Verdienste

* [0331 8173-3044](tel:0331 8173-3044)
* [verdienste@statistik-bbb.de](mailto:verdienste@statistik-bbb.de)
* [0331 817330-4011](fax:0331 817330-4011)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Jedes Jahr werden in ca. 6 000 Betriebe in Berlin und Brandenburg Daten zu den Verdiensten aller sozialversicherungspflichtig Beschäftigten des Betriebs erhoben. Die Lieferung der Daten erfolgt monatlich und beinhaltet neben den Bruttomonatsverdienste auch Angaben zu beispielsweise bezahlten Arbeitsstunden und Überstunden. Aber auch Angaben zu Geschlecht, Nationalität oder ob nach Tarif bezahlt wird, werden erhoben.

Um die Repräsentativität und Genauigkeit der Stichprobe zu verbessern und die Betriebe zu entlasten, wird jedes Jahr ein Sechstel der Stichprobe ausgetauscht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Verdiensterhebung**Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/0ef39fb0e56e9ecc/7bc8fa9cf06e/MD_62361_2024.pdf)[Archiv](/search-results?q=MD_62361&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/n-i-6-j)


