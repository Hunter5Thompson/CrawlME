

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Preise](/wirtschaft/preise)
* [Baupreise](/baupreise)
* [Preisindizes für Bauwerke in Berlin und Brandenburg](/m-i-4-vj)

Preisindizes für Bauwerke
-------------------------

#### August 2024, vierteljährlich

###### ****Hinweis:**** Mit den Ergebnissen für Mai 2024 erfolgt die Umstellung von der bisherigen Basis 2015 auf das Basisjahr 2021. In der Statistik der Bauleistungspreise werden Preise für ausgewählte Bauleistungen erhoben.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d7f5ebd75dc55c78/ee9f4fa5af13/SB_M01-04-00_2024q03_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/8a4aa3cfb638f2af/b566228e5b51/SB_M01-04-00_2024q03_BE.pdf)

**Baupreise weiterhin auf hohem Niveau**

Im August 2024 lagen die Preise für den Neubau von Wohngebäuden (Bauleistungen am Bauwerk) in Berlin im Durchschnitt um 4,1 % über denen vom August 2023.

Vom Mai bis August 2024 erhöhten sich die Bauleistungspreise um 0,8 %.

Der stärkste Preisanstieg im Bereich Rohbauarbeiten gegenüber dem Vorjahr wurde mit 9,5 % bei den Erdarbeiten verzeichnet. Im Bereich Ausbauarbeiten stiegen mit 12,2 % die Preise für Estricharbeiten am stärksten. Weitere überdurchschnittliche Preisanstiege gab es u. a. bei der Gebäudeautomation mit 9,7 %, zu der beispielsweise Brandmeldeanlagen gehören.Den stärksten Rückgang verzeichnen Gerüstbauarbeiten mit –6,0 %

### Kontakt

#### Stefanie Dobs

Preise

#### Stefanie Dobs

Preise

* [0331 8173-3523](tel:0331 8173-3523)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Baupreise weiterhin auf hohem Niveau**

Im August 2024 lagen die Preise für den Neubau von Wohngebäuden (Bauleistungen am Bauwerk) in Brandenburg im Durchschnitt um 3,9 % über denen vom August 2023.

Vom Mai bis August 2024 erhöhten sich die Bauleistungspreise um 0,7 %.

Der stärkste Preisanstieg im Bereich Rohbauarbeiten gegenüber dem Vorjahr wurde mit 7,2 % bei den Erdarbeiten verzeichnet. Im Bereich Ausbauarbeiten stiegen mit 13,2 % die Preise für Estricharbeiten am stärksten. Weitere überdurchschnittliche Preisanstiege gab es u. a. bei den Betonwerksteinarbeiten mit 9,8 %. Günstiger als vor einem Jahr waren Stahlbauarbeiten mit einem Rückgang um 3,3 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **zum aktuellen Statistischen Bericht – August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/920b302abeeefa19/a053c43fa2ae/SB_M01-04-00_2024q03_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/a72da05a202ccdb5/10ca5790384f/SB_M01-04-00_2024q03_BB.pdf)
### Kontakt

#### Stefanie Dobs

Preise

#### Stefanie Dobs

Preise

* [0331 8173-3523](tel:0331 8173-3523)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der Baupreisindex spiegelt die Entwicklung der Preise für den Neubau und die Instandhaltung von Bauwerken wieder. Es werden Preisindizes für folgende Bauwerksarten berechnet:

für den konventionellen Neubau im Hochbau (Wohngebäude, Bürogebäude und gewerbliche Betriebsgebäude),

für den Neubau von Einfamiliengebäuden in vorgefertigter Bauart aus Holz,

für den Neubau im Tiefbau (Straßen, Brücken, Ortskanäle) und

für die Instandhaltung von Wohngebäuden

Es werden 173 ausgewählte Bauleistungen bei repräsentativ ausgewählten Unternehmen erhoben, die zur Berechnung des Baupreisindizes für ausgewählte Bauwerke verwendet werden. Die Preise werden vierteljährlich – in den Monaten Februar, Mai, August und November – erhoben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Preisindizes für die Bauwirtschaft**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/80835d6fd347c904/98fd4db24d79/MD_61261_2024.pdf)[Archiv](/search-results?q=MD_61261&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/m-i-4-vj)
