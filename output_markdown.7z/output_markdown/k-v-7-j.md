

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)
* [Kinder und tätige Personen in Tageseinrichtungen und öffentlich geförderter Kindertagespflege in Berlin und Brandenburg](/k-v-7-j)

Kinder und tätige Personen in Tages­einrichtungen und öffentlich geförderter Kinder­tages­pflege
------------------------------------------------------------------------------------------------

#### 1. März 2024, jährlich

###### Die Erhebungen geben einen Überblick über die Betreuung in Tageseinrichtungen für Kinder und mit öffentlichen Mitteln geförderter Kindertagespflege, um die erforderlichen Grunddaten für die Planung von Betreuuungsmöglichkeiten für Kinder bereitzustellen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/3debd10f8ecd000e/53c05e9b9bb2/SB_K05-07-00_2024j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/0e013826b466b2f9/a0f6d2be0535/SB_K05-07-00_2024j01_BE.pdf)

**Kindertagesbetreuung in Berlin**

Am 1. März 2024 standen in Berlin 2.861 Kindertageseinrichtungen mit 195.817 genehmigten Plätzen für die Betreuung von Kindern zur Verfügung. Die Anzahl der Plätze erhöhte sich im Vergleich zum Vorjahr um 1,3 %.

174.484 Kinder besuchten ein mit öffentlichen Mitteln gefördertes Angebot der Kindertagesbetreuung. Davon waren über 169.449 Kinder (ohne Hortkinder) in Einrichtungen untergebracht. Die Eltern weiterer 5.035 Kinder nutzten die Angebote der öffentlich geförderten Kindertagespflege bei Tagesmüttern und -vätern.

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Kindertagesbetreuung in Brandenburg**

Am 1. März 2024 standen in Brandenburg 2.032 Kindertageseinrichtungen mit 228.992 genehmigten Plätzen für die Betreuung von Kindern zur Verfügung. Die Anzahl der Plätze erhöhte sich im Vergleich zum Vorjahr um 2,2 %.

202.681 Kinder besuchten ein mit öffentlichen Mitteln gefördertes Angebot der Kindertagesbetreuung. Davon waren 200.082 Kinder in Einrichtungen untergebracht. Die Eltern weiterer 2.599 Kinder nutzten die Angebote der öffentlich geförderten Kindertagespflege, indem sie ihre Kinder von Tagesmüttern und -vätern betreuen ließen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/dbeb38d5c6b5fa8d/e2fd4c8e5783/SB_K05-07-00_2024j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/3900251493a78c48/0729d95faeec/SB_K05-07-00_2024j01_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik der Kinder und tätigen Personen in Tageseinrichtungen wird jährlich als Vollerhebung bei allen örtlichen und überörtlichen Trägern der öffentlichen Jugendhilfe, den obersten Landesjugendbehörden, den kreisangehörigen Gemeinden und Gemeindeverbänden, soweit sie Aufgaben der Jugendhilfe wahrnehmen, den Trägern der freien Jugendhilfe sowie bei den Leitungen von Einrichtungen, Behörden und Geschäftsstellen in der Kinder- und Jugendhilfe durchgeführt.

Grundgesamtheit der Statistik der Kinder und tätigen Personen in Tageseinrichtungen sind Kindertageseinrichtungen, die Zahl der genehmigten Plätze sowie Angaben zu den dort betreuten Kindern und tätigen Personen.

Die Erhebung ergänzt die Statistik über Kinder und tätige Personen in öffentlich geförderter Kindertagespflege und trägt zu einem möglichst umfassenden Überblick über die Zahl der in Tagesbetreuung untergebrachten Kinder bei. Beide Erhebungen stellen zusammen die Grunddaten für die Planung von Kindertagesbetreuung auf örtlicher und überörtlicher Ebene bereit.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zu Stande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Statistik der Kinder und tätigen Personen  
in Tageseinrichtungen  
(2024)**](https://download.statistik-berlin-brandenburg.de/45aea42219ffc2bf/68437dc733ff/MD_22541_2024.pdf) | [Archiv](/search-results?q=22541&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[**Statistik der Kinder und tätigen Personen in öffentlich geförderter Kindertagespflege**  
**(2024****)**](https://download.statistik-berlin-brandenburg.de/b4c8abd163bd879d/d7db3a366f35/MD_22543_2024.pdf)| [Archiv](/search-results?q=22543&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-v-7-j)


