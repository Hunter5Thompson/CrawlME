

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Hochschulen](/hochschulen)

Hochschulen
===========

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu Studierenden, Studienkollegiaten sowie Gasthörerinnen und Gasthörern, durchgeführten Abschlussprüfungen, Promovierenden, dem Hochschulpersonal, den Habilitationen und den Hochschulfinanzen erhoben.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, vorläufige Angaben, jährlich (BIII8-j)](/b-iii-8-j)[Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Teil 1: Übersicht, jährlich (BIII2-j)](/b-iii-2-j)[Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Teil 2: ausführliche Ergebnisse, jährlich (BIII1-j)](/b-iii-1-j)[Studierende an Hochschulen in Berlin und Brandenburg – Sommersemester, jährlich (BIII6-j)](/b-iii-6-j)[Akademische und staatliche Abschlussprüfungen in Berlin und Brandenburg – Teil 1: Übersicht, jährlich (BIII5-j)](/b-iii-5-j)[Akademische und staatliche Abschlussprüfungen in Berlin und Brandenburg, Teil 2: ausführliche Ergebnisse, jährlich (BIII3-j)](/b-iii-3-j)[Personal an Hochschulen in Berlin und Brandenburg, jährlich (BIII4-j)](/b-iii-4-j)[Hochschulfinanzstatistik in Berlin und Brandenburg, jährlich (BIII7-j)](/b-iii-7-j)

Zeitreihen
----------

**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/5df8a304374edee9/9862bba41049/Bildung-Hochschulen-Zeitreihe-2023.xlsx)[Lange Reihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/81fcafd637cea502/affe584628f3/Hochschulen.xlsx)

Basisdaten
----------

StudierendeHochschulpersonalHochschulfinanzen

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=statistic&levelindex=0&levelid=1623917371929&code=21371)
#### StatIS-BBB

![](https://download.statistik-berlin-brandenburg.de/78324daa1d8c4302/8f3a5e8bad38/v/4b6c25f57664/statis-bbb-schmuckbild.jpg)

Im Statistischen Informationssystem lassen sich individuelle Auswertungen auf Basis von regional tief gegliederten Daten erstellen und exportieren.

[Zu StatIS-BBB](https://statis.statistik-berlin-brandenburg.de/webapi/opendatabase?id=BBB_STS)
#### Kommunale Bildungsdatenbank

![](https://download.statistik-berlin-brandenburg.de/3ff67ef262f0bb5a/0780120d8dcb/v/01f81be46925/kommunale-bildungsdatenbank-schmuckbild.png)

Umfassendes Datenangebot auf der Ebene der Landkreise und kreisfreien Städte. Die Ergebnisse werden in Form von Indikatoren präsentiert.

[Zur Bildungsdatenbank](https://www.bildungsmonitoring.de/bildung/online?operation=previous&levelindex=0&step=0&titel=&levelid=1613122405789&acceptscookies=false)

Haben Sie Fragen?
-----------------

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Eike Müller

Hochschulen

#### Eike Müller

Hochschulen

* [0331 8173-1144](tel:0331 8173-1144)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Andrea Götze

Hochschulfinanzen

#### Andrea Götze

Hochschulfinanzen

* [0331 8173-1250](tel:0331 8173-1250)
* [hochschulfinanzen@statistik-bbb.de](mailto:hochschulfinanzen@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)
#### Kerstin Hartung

Hochschulfinanzen

#### Kerstin Hartung

Hochschulfinanzen

* [0331 8173-1267](tel:0331 8173-1267)
* [hochschulfinanzen@statistik-bbb.de](mailto:hochschulfinanzen@statistik-bbb.de)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / Mag_Mac](https://download.statistik-berlin-brandenburg.de/87fd08d70bd6c761/8ff683cfc1de/v/34de3fb65195/gesellschaft-bildung-humboldt-university-in-berlin-germany-picture-id473452272.jpg "iStock.com / Mag_Mac")](/167-2024)**Hochschulstatistik Wintersemester 2024/25 (vorläufige Angaben)**[#### Berlin hält die Zahl der Studierenden, in Brandenburg steigt sie weiter an](/167-2024)

Im Wintersemester 2024/25 sind nach vorläufigen Angaben 200.527 Studierende in Berlin und 52.216 Studierende in Brandenburg an Hochschulen eingeschrieben.

[![iStock.com / DisobeyArt](https://download.statistik-berlin-brandenburg.de/dc81672f22a9f1f7/081341cde7be/v/b0ad30523314/gesellschaft-bildung-young-millennial-friends-having-fun-chatting-taking-photos-with-and-picture-id1194859007.jpg "iStock.com / DisobeyArt")](/b-iii-8-j)**Wintersemester 2024/2025, jährlich, B III 8 – j**[#### Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, vorläufige Angaben](/b-iii-8-j)

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden, Studienkollegiaten und Gasthörenden erhoben.

[![iStock.com / trumzz](https://download.statistik-berlin-brandenburg.de/d0a8e45e3ca8004b/5d53ced40224/v/897e56450ee6/gesellschaft-bildung-gesellschaft-bildung-audience-raising-hands-up-while-businessman-is-speaking-in-training-picture-id1041740040.jpg "iStock.com / trumzz")](/b-iii-6-j)**Sommersemester 2024, jährlich, B III 6 – j**[#### Studierende an Hochschulen in Berlin und Brandenburg – Sommersemester](/b-iii-6-j)

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden, Studienkollegiaten und Gasthörenden erhoben.

[Zu unseren News](/news)

[* Hochschulen](/search-results?q=tag%3AHochschulen)[* Studierende](/search-results?q=tag%3AStudierende)[* Prüfungen](/search-results?q=tag%3APrüfungen)[* Hochschulpersonal](/search-results?q=tag%3AHochschulpersonal)[* Promotionen](/search-results?q=tag%3APromotionen)[* Hochschulfinanzen](/search-results?q=tag%3AHochschulfinanzen)
