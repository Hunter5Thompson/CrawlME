

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Wohngeld](/wohngeld)
* [Wohngeld in Berlin und Brandenburg](/k-vii-1-j)

Wohngeld
--------

#### 2023, jährlich

###### Die Daten erlauben Rückschlüsse auf soziale und finanzielle Auswirkungen des Wohngeldgesetzes. Die Angaben werden für die weitere Planung und Fortentwicklung des Wohngeldrechts benötigt.

BerlinBrandenburgMethodik
### Berlin

1 Zu Zwecken der Geheimhaltung erfolgt ab dem Berichtsjahr 2020 die Veröffentlichung der Ergebnisse unter Anwendung der 5 er-Rundung. Der Insgesamtwert kann von der Summe der Einzelwerte abweichen. Durchschnittswerte werden nicht veröffentlicht, sofern diese auf eine geringe Fallzahl basieren.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d488850e2da9d121/51299a6644a2/SB_K07-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/3a18b5c369f2ca12/947b9aee1928/SB_K07-01-00_2023j01_BE.pdf)

**Wohngeld in Berlin**

2023 erhielten in Berlin 51.320 bedürftige Haushalte einen Zuschuss zu ihren Wohnkosten in Form von Wohngeld. Der Anteil der reinen Wohngeldhaushalte, in denen alle Haushaltsmitglieder einen Anspruch auf Wohngeld haben, betrug 98,5 %. Bei den übrigen Haushalten waren nur einzelne Personen des Haushaltes wohngeldberechtigt (wohngeldrechtliche Teilhaushalte).

Der überwiegende Teil aller reinen Wohngeldhaushalte waren mit 65,5 % Single-Haushalte, gefolgt von 2-Personen-Haushalten mit einem Anteil von 13 %.

Unter den reinen Wohngeldhaushalten bildeten Rentnerinnen und Rentner gemeinsam mit Pensionärinnen und Pensionären die größte Gruppe. Hierzu zählten mit 56,6 % über die Hälfte der Berliner Haushalte mit reinem Wohngeld.

### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Wohngeld in Brandenburg**

46.140 bedürftige Haushalte erhielten im Jahr 2023 einen Zuschuss zu ihren Wohnkosten in Form von Wohngeld. Der Anteil der reinen Wohngeldhaushalte, in denen alle Haushaltsmitglieder einen Anspruch auf Wohngeld haben, betrug in Brandenburg 98,4 %. Bei den übrigen Haushalten waren nur einzelne Personen des Haushaltes wohngeldberechtigt (wohngeldrechtliche Teilhaushalte).

66,9 % der reinen Wohngeldhaushalte waren Single-Haushalte, gefolgt von 2-Personen-Haushalten mit einem Anteil von 16,7 %.

Mit 63,5 % bildeten Rentnerinnen und Rentner gemeinsam mit Pensionärinnen und Pensionären die größte Gruppe unter den reinen Wohngeldhaushalten.

1  Zu Zwecken der Geheimhaltung erfolgt ab dem Berichtsjahr 2020 die Veröffentlichung der Ergebnisse unter Anwendung der 5 er-Rundung. Der Insgesamtwert kann von der Summe der Einzelwerte abweichen. Durchschnittswerte werden nicht veröffentlicht, sofern diese auf eine geringe Fallzahl basieren.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8100d2585adc69b9/a056541a9f6b/SB_K07-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/aa2a14ac0773ee17/24db50b73fa2/SB_K07-01-00_2023j01_BB.pdf)
### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik über die wohngeldberechtigten Personen basiert auf einer laufenden Erfassung der entsprechenden Anträge und Entscheide. Demnach werden im Rahmen dieser Statistik die Angaben zu jeder Erstbewilligung, Wiederholungsbewilligung, Änderung einer laufenden Bewilligung (Erhöhung, Verringerung, Wegfall) und jeder Ablehnung bzw. jedes sonstigen negativen Bescheides erfasst.

Die Meldungen über die Empfängerhaushalte von Wohngeld erfolgen durch die zuständigen örtlichen Wohngeldbehörden der Gemeinde-, Stadt-, Amts- oder Kreisverwaltung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Wohngeld zum 31.12.**2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/1bab9027b046f3d6/e7c70a9cc4ac/MD_22311_2023.pdf)[Archiv](/search-results?q=22311&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-vii-1-j)
