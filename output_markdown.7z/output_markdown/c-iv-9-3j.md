

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Betriebswirtschaftliche Ausrichtung der landwirtschaftlichen Betriebe in Brandenburg](/c-iv-9-3j)

Betriebswirtschaftliche Ausrichtung der landwirtschaftlichen Betriebe in Brandenburg
------------------------------------------------------------------------------------

#### 2023, drei- bis vierjährlich

###### Der Bericht informiert über betriebswirtschaftliche Ausrichtungen landwirtschaftlicher Betriebe nach Rechtsformen, Größenklassen der landwirtschaftlichen Flächen sowie Standardoutputs und nach Verwaltungsbezirken.

BrandenburgMethodik
### Brandenburg

**Ackerbau und Futterbau dominieren**

41 % aller im Rahmen der Agrarstrukturerhebung 2023 befragten Betriebe waren der betriebswirtschaftlichen Ausrichtung Ackerbau zuzuordnen. Hierbei entfielen 54 % auf die Spezialisierungsrichtungen Getreide-, Ölsaaten- und Eiweißpflanzenbetriebe. Im Mittel betrug die landwirtschaftlich genutzte Fläche der Ackerbaubetriebe 280 Hektar.

Auf Futterbau ausgerichtete Betriebe stellten mit 36 % den zweitgrößten Anteil der Betriebe dar. Diese setzten sich hauptsächlich aus den Spezialisierungsrichtungen Milchviehbetriebe, Rinderaufzucht- und Rindermastbetriebe sowie Weideviehbetrieben zusammen. Im Mittel betrug die landwirtschaftlich genutzte Fläche von Futterbaubetrieben 190 Hektar. Die hauptsächlich angebauten Futterarten waren Silomais, Gras, Klee und Futterhackfrüchte.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a57db4bfc45af89c/612b0cd70a3e/SB_C04-09-00_2023j03_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/d5a2ff302f0f6468/22ff299bce59/SB_C04-09-00_2023j03_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

**[Agrarstrukturerhebung (ASE) (2016)](https://download.statistik-berlin-brandenburg.de/98f0a5ac9f823baa/392752f4b056/MD_41121_2016.pdf)** 

**[Landwirtschaftszählung (2020)](https://download.statistik-berlin-brandenburg.de/023848dc8f72ca47/3f8123557a5c/MD_41141_2020.pdf)** 

  


[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-9-3j)
