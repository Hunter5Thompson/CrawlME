

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Zu- und Fortzüge](/bevoelkerung/demografie/zu-und-fortzuege)
* [Wanderungen in Berlin und Brandenburg](/a-iii-2-j)

Wanderungen
-----------

#### 2023, jährlich

###### Die Statistik der Wanderungen bzw. der Zu‑ und Fortzüge weist monatlich die räumliche Mobilität der Bevölkerung nach.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a2491d3f7533f4b2/2f23faa84254/SB_A03-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b3a764d38e724a03/d6685d01008e/SB_A03-02-00_2023j01_BE.pdf)

**Hohe Zuwanderung aus dem Ausland**

Im Jahr 2023 konnte Berlin insgesamt einen Wanderungsgewinn von 32.765 Personen verzeichnen. Die Zahl der Zuzüge (187.971) war der dritthöchste Wert seit 1991 für die Bundeshauptstadt.

Gegenüber dem Ausland ergab sich ein Wanderungsgewinn von 49.550 Personen (–4.470 Deutsche und +54.020 Ausländer).

Dem hohen Wanderungsgewinn aus dem Ausland stand ein Wanderungsverlust von 16.785 Personen aus dem übrigen Bundesgebiet (+1.670 alte Bundesländer und – 18.455 neue Bundesländer einschließlich Brandenburg) gegenüber.

Der Wanderungsverlust an das Nachbarland Brandenburg betrug -16.750 Personen (–15.546 Deutsche und –1.204 Ausländer).   
Es zogen aber immer noch rund doppelt so viele Berliner nach Brandenburg, wie umgekehrt. An das Berliner Umland verlor Berlin im Ergebnis 11.693 und an den weiteren Metropolenraum 5.057 Personen.

11 Bezirke partizipierten am Wanderungsgewinn Berlins: Die Außenbezirke Marzahn-Hellersdorf (6.540), Treptow‑Köpenick (5.480) erreichten mit Abstand den höchsten Wanderungsgewinn, gefolgt von Lichtenberg (3.876). Der Bezirk Friedrichshain-Kreuzberg erlangte als einziger Bezirk mit –365 Personen einen Fortzugsüberschuss.

### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Wanderungsgewinn aus dem Ausland und Berlin**

Für das Land Brandenburg konnte im Jahr 2023 ein Wanderungsgewinn in Höhe von 29.786 Personen (+13.921 Deutsche und +15.865 Ausländer) vermeldet werden.   
Dabei war der Wanderungsgewinn des Auslands (16.229) mit der Bundeshauptstadt (16.750) fast gleich. Der Wanderungsgewinn aus dem Ausland beruht größtenteils auf den Zuzügen von 34.717 Ausländern. Demgegenüber zogen 27.480 Deutsche von Berlin in die Mark.  
Aus dem übrigen Bundesgebiet verzeichnete Brandenburg einen Fortzugsüberschuss (–3.193). Zu dem größten Wanderungsverlust kam es gegenüber Mecklenburg-Vorpommern (–1.018).

Im Ergebnis vermeldeten alle kreisfreien Städte und Landkreise in Brandenburg einen Wanderungsgewinn. Die höchsten Zuzugsüberschüsse erzielten dabei die Landkreise Teltow‑Fläming (2.970), Barnim (2.631) und Potsdam-Mittelmark (2.508). Den niedrigsten Wanderungsgewinn erreichte der Landkreis Elbe-Elster (142).

Bei der Betrachtung der Strukturräume erlangte im Jahr 2023 der weitere Metropolenraum (16.642) einen höheren Wanderungsgewinn als das Berliner Umland (13.144).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e65442ed3c27d07d/8931d543cce3/SB_A03-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/745c9183e4d44dda/0eef49e7352b/SB_A03-02-00_2023j01_BB.pdf)
### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Wanderungsstatistik umfasst alle Zu‑ und Fortzüge über die Gemeindegrenze mit Verlegung der Haupt‑ oder alleinigen Wohnung im Berichtszeitraum. Sie wird monatlich und jährlich herausgegeben.

Es handelt sich um eine Totalerhebung aufgrund von Verwaltungsdaten (Sekundärdaten). Grundlage sind die An‑ und Abmeldungen, die von den Meldeämtern der Länder nach den melderechtlichen Regelungen erfasst werden. Dabei wird jeder Bezug einer alleinigen oder Hauptwohnung in einer neuen Gemeinde gleichzeitig als Fortzug aus der bisherigen Wohngemeinde gezählt.

Die Erhebung erfolgt dezentral durch Datenübermittlung der Meldebehörden an die Statistischen Ämter der Länder. Nach der hier erfolgten Prüfung und Aufbereitung der Daten erhält das Statistische Bundesamt die Datenmaterialien und stellt sie zum Bundesergebnis zusammen.

Die Daten der Wanderungsstatistik fließen in die Fortschreibung des Bevölkerungsstandes ein.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Wanderungsstatistik**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/290017d5108fc3db/9dcac94c0213/MD_12711_2023.pdf)[Archiv](/search-results?q=MD_12711&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iii-2-j)
