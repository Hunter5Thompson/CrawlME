

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Tourismus in Brandenburg nach Gemeinden](/g-iv-9-j)

Tourismus in Brandenburg nach Gemeinden
---------------------------------------

#### 2023, jährlich

###### Die Daten liefern verlässliche Aussagen über den Stand und vor allem die kurzfristige Entwicklung des Tourismus auf Gemeindeebene. Dazu zählen die Anzahl der Gäste, Übernachtungen, angebotenen Betten und deren Auslastung.

BrandenburgMethodik
### Brandenburg

**Bernau ist Spitzenreiter bei der Bettenauslastung**

Die Top fünf Gemeinden mit den meisten Übernachtungen in den Beherbergungsbetrieben im Land Brandenburg im Jahr 2023 waren Potsdam, Stadt (1.361.498), Schönefeld (649.767), Burg (Spreewald) (555.759), Rheinsberg, Stadt (484.957) und Krausnick-Groß Wasserburg (392.640).

Im Berichtsmonat Juli führt Potsdam, Stadt mit 58 geöffneten Beherbergungsbetrieben das Ranking bei der Anzahl der Betriebe an. Spitzenreiter bei der Auslastung der Betten im Jahr war die Gemeinde Bernau (84,7 %).

Das Land Brandenburg gliedert sich in 413 Gemeinden, wovon Brandenburg an der Havel, Cottbus, Frankfurt (Oder) und die Landeshauptstadt Potsdam kreisfrei sind. Die übrigen Gemeinden gehören einen der 14 Landkreise an.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/dd1a363d8952d86f/206c1f0138d3/SB_G04-09-00_2023j00_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/a056e3ec639ec2da/cd2a5bfeb130/SB_G04-09-00_2023j00_BB.pdf)
### Kontakt

#### Stefanie Chlebusch

Tourismus

#### Stefanie Chlebusch

Tourismus

* [0331 8173-3586](tel:0331 8173-3586)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de )
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Beherbergungsstätten und Campingplätze bilden zusammen die Gesamtheit der Beherbergungsbetriebe.

Zu den Beherbergungsstätten zählen die Hotellerie (Hotels, Hotels garnis, Gasthöfe, Pensionen), das Sonstige Beherbergungsgewerbe (Hütten und Jugendherbergen, Erholungs-, Ferien- und Schulungsheime, Boardinghouses, Ferienzentren, Ferienhäuser und -wohnungen) sowie Vorsorge- und Rehabilitationskliniken. Hierzu zählen auch Unterkunftsstätten, die die Gästebeherbergung nicht gewerblich und/oder nur als Nebenzweck betreiben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatserhebung im Tourismus**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/3e910e29c410222e/8f6dcc332b78/MD_45412_2023.pdf)[Archiv](/search-results?q=MD_45412&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-iv-9-j)
