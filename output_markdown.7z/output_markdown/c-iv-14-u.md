

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Ausgewählte Ergebnisse der Agrarstrukturerhebung in Berlin](/c-iv-14-u)

Ausgewählte Ergebnisse der Agrarstruktur­erhebung in Berlin
-----------------------------------------------------------

#### 2023, drei- bis vierjährlich

###### Der Bericht enthält Angaben zur Bodennutzung, zu Viehbeständen, Rechtsformen, betriebswirtschaftlicher Ausrichtung sowie landwirtschaftlicher Berufsbildung.

BerlinMethodik
### Berlin

\* seit 2010 eingeschränkte Vergleichbarkeit mit den Vorjahren aufgrund methodischer Veränderungen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/543a1389d4ae35dc/ed4956730862/SB_C04-14-00_2023u00_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f07207c40fb985e4/5a08979dd31a/SB_C04-14-00_2023u00_BE.pdf)

**46 landwirtschaftliche Betriebe in Berlin**

2023 gab es in Berlin 46 landwirtschaftliche Betriebe, die 1.908 Hektar landwirtschaftlich genutzte Fläche (LF) mit 261 Arbeitskräften bewirtschafteten, darunter 1.075 Hektar Ackerland und 824 Hektar Dauergrünland.

6 Betriebe (13,0 %) wirtschafteten nach den Prinzipien des ökologischen Landbaus. Diese Betriebe verfügten über 15,3 % der LF (292 Hektar). 75,8 % der LF waren Pachtflächen (1.447 Hektar). Im Durchschnitt zahlten die Berliner Landwirtschaftsbetriebe 155 EUR je Hektar LF.

### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Agrarstrukturerhebung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Agrarstrukturerhebung (ASE)**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/05723b6559976fb1/704419dd5b82/MD_41121_2023.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-14-u)
