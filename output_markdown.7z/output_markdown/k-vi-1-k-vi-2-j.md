

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Asylbewerberleistungen](/asylbewerberleistungen)
* [Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen nach dem Asylbewerberleistungsgesetz](/k-vi-1-k-vi-2-j)

Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen
-----------------------------------------------------------------

#### 2023, jährlich

###### Die Erhebung umfasst Daten zu Ausgaben und Einnahmen nach dem Asylbewerberleistungsgesetz sowie über den Personenkreis der Leistungsempfangenden. Die Angaben werden u. a. für die weitere Planung und Fortentwicklung des Asylbewerberleistungsgesetzes benötigt.

BerlinBrandenburgMethodik
### Berlin

1  Personen mit den Geschlechtsangaben "divers" und "ohne Angabe" (nach §22 Absatz 3 PStG) werden aus Gründen der statistischen Geheimhaltung per Zufallsprinzip dem männlichen oder weiblichen Geschlecht zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ec116a5ea087617a/1a1215db3bab/SB_K06-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/11732323dd494999/3181afae302c/SB_K06-01-00_2023j01_BE.pdf)

**Durchschnittsalter der Empfangenden bei 26 Jahren**

2023 erhielten in Berlin 35.905 Personen Regelleistungen (§§ 2 und 3 nach dem Asylbewerberleistungsgesetz – AsylbLG). 71 % der Berechtigten bezogen Grundleistungen (§ 3 AsylbLG) und 29 % empfingen Hilfe zum Lebensunterhalt (§ 2 AsylbLG). Der überwiegende Teil der Leistungsberechtigten stammte aus Asien. Mehr als die Hälfte der Schutzsuchenden erhielten den aufenthaltsrechtlichen Status Aufenthaltsgestattung. Das Durchschnittsalter lag bei 26 Jahren.

### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Aufenthaltsgestattung häufigster Status**

16.095 Personen erhielten 2023 in Brandenburg Regelleistungen (§§ 2 und 3 nach dem Asylbewerberleistungsgesetz – AsylbLG). Grundleistungen (§ 3 AsylbLG) bezogen 65 % der Berechtigten und 35 % empfingen Hilfe zum Lebensunterhalt (§ 2 AsylbLG). Der überwiegende Teil der Leistungsberechtigten stammte aus Asien. Den aufenthaltsrechtlichen Status Aufenthaltsgestattung erhielten mehr als die Hälfte der Schutzsuchenden. Das Durchschnittsalter lag bei 26 Jahren.

1  Personen mit den Geschlechtsangaben "divers" und "ohne Angabe" (nach §22 Absatz 3 PStG) werden aus Gründen der statistischen Geheimhaltung per Zufallsprinzip dem männlichen oder weiblichen Geschlecht zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/13dbbb8790e66304/fe87d274fa5e/SB_K06-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/8043440600dc7a20/b59a3989a3a6/SB_K06-01-00_2023j01_BB.pdf)
### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung erstreckt sich auf die Empfängerinnen und Empfänger von Leistungen nach dem Asylbewerberleistungsgesetz (AsylbLG). Leistungsberechtigt sind Ausländerinnen und Ausländer, die sich tatsächlich im Bundesgebiet aufhalten und eine der Voraussetzungen nach § 1 AsylbLG erfüllen. Es werden jeweils die Angaben für sämtliche Personen einer Familie bzw. eines Haushalts erhoben, die Leistungen nach dem AsylbLG erhalten.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Statistik der Ausgaben und Einnahmen nach dem Asylbewerberleistungsgesetz****(2023)**](https://download.statistik-berlin-brandenburg.de/774793cf6edae642/363660d9a9d0/MD_22211_2023.pdf) | [Archiv](/search-results?q=MD_22211&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[**Statistik der Empfänger von Leistungen nach dem Asylbewerberleistungsgesetz****(2023)**](https://download.statistik-berlin-brandenburg.de/a868ef9638a304fa/b90b8fb106f1/MD_22221_2023.pdf) | [Archiv](/search-results?q=MD_22221&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-vi-1-k-vi-2-j)
