

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentlicher Dienst](/oeffentlicher-dienst)
* [Versorgungsempfänger in Berlin und Brandenburg](/l-iii-5-j)

Versorgungsempfängerstatistik
-----------------------------

#### 1. Januar 2024, jährlich

###### Die Versorgungsempfängerstatistik liefert Daten über die Leistungsberechtigten des öffentlich-rechtlichen Alterssicherungssystems.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/0c93cfefb9f0c802/0d5057a2f1d9/SB_L03-05-00_2024j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/4f28cba2b465a1f6/91a4efcee300/SB_L03-05-00_2024j01_BE.pdf)

**Weniger Empfängerinnen und -empfänger von Waisengeld**

In Berlin erhöhte sich die Zahl der Ruhegehaltsempfängerinnen und -empfänger des öffentlichen Dienstes zum 1. Januar 2024 auf 56.205 (+1,7 %). Außerdem erhielten 11.925 Personen Witwen- bzw. Witwergeld (+1,2 %) und 600 Personen Waisengeld (–2,4 %).

Der Frauenanteil blieb gegenüber dem Vorjahreszeitpunkt relativ konstant. Bei den Ruhegehaltsempfängerinnen und -empfängern beträgt er 46,3 %, bei den Witwen bzw. Witwern 88,9 % und bei den Waisen 46,8 %.

Bei 35,1 % (24.090 Personen) aller Versorgungsempfängerinnen und -empfänger handelte es sich Anfang 2024 um ehemalige Lehrerinnen und Lehrer bzw. deren Hinterbliebene. Ihr Anteil blieb gegenüber Anfang 2023 unverändert.

2.475 vormals im Dienst des Landes Berlin stehende Personen im Beamtenstatus oder im Richteramt wechselten im Jahr 2023 in den Ruhestand. Das waren 2,2 % weniger als ein Jahr zuvor. Darunter schieden 460 Personen (2022: 460 Personen) im Verlauf des Jahres 2023 aufgrund einer amtsärztlich festgestellten Dienstunfähigkeit aus dem aktiven Dienst aus.

Das Durchschnittsalter der Neuzugänge an Versorgungsempfängerinnen und -empfängern erhöhte sich gegenüber dem Vorjahr leicht von 64,1 Jahre auf 64,5 Jahre.

### Kontakt

#### Ramona Baumert

Personalstatistiken

#### Ramona Baumert

Personalstatistiken

* [0331 8173-1251](tel:0331 8173-1251)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Mehr Ruhegehaltsempfängerinnen und -empfänger**

In Brandenburg stieg die Zahl der Ruhegehaltsempfängerinnen und -empfänger zum 1. Januar 2024 auf 17.980 (+6,8 %). Hinterbliebenenrente wurde an 2.035 Verwitwete (+9,2 %) und 265 Waise (+5,2 %) gezahlt.

Im Laufe des Jahres 2023 wurden 1.420 Bedienstete in den Ruhestand versetzt, davon 1.290 beim Land, 95 bei den Kommunen und 35 bei den Sozialversicherungsträgern. Im Vorjahr waren es 1.545 Personen. 54,3 % der im Landesbereich in den Ruhestand Versetzten waren vorher im Schuldienst, 22,7 % im Vollzugsdienst (Polizei-, Justiz-, Feuerwehrdienst) und 23,0 % in übrigen Bereichen des Landes beschäftigt.

220 Personen (2022: 205 Personen) schieden im Verlauf des Jahres 2023 aufgrund einer amtsärztlich festgestellten Dienstunfähigkeit aus dem aktiven Dienst aus. Im Vergleich zum Vorjahr sind somit 6,3 % mehr Bedienstete wegen Dienstunfähigkeit ausgeschieden.

Das Durchschnittsalter der Neuzugänge an Ruhegehaltsempfängerinnen und -empfängern lag im Jahr 2023 bei relativ konstant bei 62,6 Jahren (2022: 62,5 Jahre).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/12f2603896ea40c6/8f72e9377e0e/SB_L03-05-00_2024j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/e99afab9e776356e/217ef0f21e71/SB_L03-05-00_2024j01_BB.pdf)
### Kontakt

#### Ramona Baumert

Personalstatistiken

#### Ramona Baumert

Personalstatistiken

* [0331 8173-1251](tel:0331 8173-1251)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Versorgungsempfängerstatistik ermittelt jährlich Strukturdaten über die Empfänger von Versorgungsbezügen, die eine Versorgung nach Beamten- und Soldatenversorgungsrecht, nach dem Gesetz zu Artikel 131 Grundgesetz oder eine Versorgung nach beamtenrechtlichen Grundsätzen erhalten.

Die Daten dienen zusammen mit den Personalstandsdaten als Entscheidungsgrundlage für Maßnahmen auf dem Gebiet des Beamten- und Soldatenversorgungsrechts.

Die Ergebnisse werden des Weiteren für Berechnungen über die zukünftige Entwicklung der Versorgungsberechtigten und die daraus resultierenden finanziellen Auswirkungen auf die öffentlichen Haushalte verwendet.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Versorgungsempfängerstatistik**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/f59098e3351a46ac/32cac8941310/MD_74211_2024.pdf)[Archiv](/search-results?q=74211&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-iii-5-j)
