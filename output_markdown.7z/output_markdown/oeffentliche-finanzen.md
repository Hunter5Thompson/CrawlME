

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)

Öffentliche Finanzen
--------------------

Die Finanzstatistiken liefern nach dem [Schalenkonzept](https://www.destatis.de/DE/Themen/Staat/Oeffentliche-Finanzen/Glossar/schalenkonzept.html) Angaben der [öffentlichen Kernhaushalte, der Extrahaushalte und der sonstigen öffentlichen Fonds, Einrichtungen und Unternehmen.](https://www.destatis.de/DE/Themen/Staat/Oeffentliche-Finanzen/Fonds-Einrichtungen-Unternehmen/Methoden/_inhalt.html)

Sie umfassen u.a. die Statistik der Kassenergebnisse, der Jahresrechnungsergebnisse, der Schulden, des Finanzvermögens, der vierteljährlichen Finanzen der Fonds, Einrichtungen und Unternehmen und der Jahresabschlüsse. Dazu zählen ebenso die [Hochschulfinanzen](/hochschulen), der Realsteuervergleich und die Grundbefragung.

###### Mehr zu den Statistiken

Die Daten der **Gemeindefinanzen** werden mit der vierteljährlichen Kassenstatistik erhoben. Sie ist die aktuellste Statistik im Bereich der kommunalen Finanzen. Dargestellt werden die Einzahlungen und Auszahlungen der Gemeinden und Gemeindeverbände.

Die **Jahresrechnungsstatistik** zeigt die Struktur der Auszahlungen und Einzahlungen der kommunalen Kernhaushalte und der kommunalen Zweckverbände auf. Die Rechnungsergebnisse der Kernhaushalte der Gemeinden und Gemeindeverbände fließen in den Öffentlichen Gesamthaushalt und die Volkswirtschaftlichen Gesamtrechnungen ein.

Über die Höhe der **Realsteuerhebesätze** können die Städte und Gemeinden ihre Realsteuereinzahlungen beeinflussen. Die Festsetzung oder Änderung eines Hebesatzes beschließt die Gemeindevertretung im Rahmen ihrer Entscheidung über die Haushaltssatzung bzw. Nachtragssatzung.

Die **Statistik über die Schulden der öffentlichen Haushalte ist eine jährliche Totalerhebung** und berichtet über den Stand der Schulden, Schuldenaufnahmen, Schuldentilgungen und sonstigen Schuldenbewegungen des Berichtsjahres. Die Erhebungseinheiten sind die staatlichen und kommunalen Haushalte (Gemeinden, Gemeindeverbände), die Träger der Sozialversicherung und die Bundesagentur für Arbeit sowie Fonds, Einrichtungen und Unternehmen (FEU), die von den öffentlichen Haushalten (auch von diesen gemeinsam) bestimmt sind. Für die Kernhaushalte und die Fonds, Einrichtungen und Unternehmen des Sektors Staat erfolgt eine detaillierte Erhebung der Schuldenarten. Die sonstigen öffentlichen Fonds, Einrichtungen und Unternehmen werden mit einem verkürzten Erhebungsprogramm befragt.

Die **Statistik über das Finanzvermögen** des Öffentlichen Gesamthaushalts erhebt das Finanzvermögen des Sektors Staat. Die Erhebungseinheiten sind die staatlichen und kommunalen Haushalte (Gemeinden/Gemeindeverbände), die Träger der Sozialversicherung und die Bundesagentur für Arbeit sowie die Fonds, Einrichtungen und Unternehmen des Staatssektors, die von den öffentlichen Haushalten bestimmt sind. Die Ergebnisse der Erhebung liefern zusammen mit der Schuldenstatistik wichtige Informationen über die Finanzen der öffentlichen Haushalte. Damit erfüllen sie den Datenbedarf wirtschaftlicher und politischer Entscheidungsträger im nationalen Rahmen und auf Ebene der Europäischen Union.

Die **Statistik der Jahresabschlüsse öffentlicher Fonds, Einrichtungen und Unternehmen** erhebt für kaufmännisch buchende Einheiten die Angaben zur Gewinn- und Verlustrechnung, der Bilanz und des Anlagenvermögens. In der vierteljährlichen Erhebung der öffentlichen Fonds, Einrichtungen und Unternehmen werden nur kaufmännisch buchende Einheiten, die zum Sektor Staat im Sinne des ESVG gezählt werden, mit einem zur jährlichen Erhebung reduzierten Erhebungskatalog befragt. Beide Primärstatistiken geben Aufschluss über die Betätigung des Staates außerhalb der öffentlichen Haushalte und vervollständigen so das Gesamtbild der öffentlichen Finanzen. Zu den Hauptnutzenden zählen die Volkswirtschaftlichen Gesamtrechnungen, Bundes- und Länderministerien sowie Universitäten und Wirtschaftsforschungsinstitute.

Zweck und Ziel des **Realsteuervergleichs** ist die Berechnung von
Realsteueraufbringungs- und Steuereinnahmekraft der Gemeinden des Landes
Brandenburg bzw. für Berlin. Diese werden für den Kommunalen Finanzausgleich
und den Finanzausgleich unter den Ländern benötigt. Auf Landesebene bilden die
Realsteueraufbringungskraft und die Steuereinnahmekraft eine wichtige Grundlage
zur Beurteilung der wirtschaftlichen und finanziellen Leistungsfähigkeit der
Gemeinden.

[![iStock.com / Ralf Geithe](https://download.statistik-berlin-brandenburg.de/4ee954f5b90c0c5d/ceb6f0190487/v/4fa619ce9cbf/gesellschaft-staat-old-tab-with-the-german-word-for-taxes-picture-id945026698.jpg "iStock.com / Ralf Geithe")](/news/2023/hebesaetze)**Realsteuerhebesätze 2022 jetzt online verfügbar**[#### Schönefeld meldet niedrigsten Gewerbesteuerhebesatz](/news/2023/hebesaetze)

Die Hebesätze der Gewerbesteuer lagen im Jahr 2022 in nahezu allen Brandenburger Gemeinden (96,6 %) zwischen 300 % und 399 %.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Gemeindefinanzen in Brandenburg, jährlich (LII2-j)](/l-ii-2-j)[Rechnungsergebnisse der Kernhaushalte der Gemeinden und Gemeindeverbände in Brandenburg, jährlich (LII3-j)](/l-ii-3-j)[Realsteuerhebesätze der Städte und Gemeinden in Brandenburg, jährlich (LII6-j)](/l-ii-6-j)[Realsteuervergleich in Berlin und Brandenburg, jährlich (LII7-j)](/l-ii-7-j)[Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen in Berlin und Brandenburg, jährlich (LIII1-j)](/l-iii-1-j)[Finanzvermögen der Kern- und Extrahaushalte des öffentlichen Gesamthaushalts in Berlin und Brandenburg, jährlich (LIII6-j)](/l-iii-6-j)

Zeitreihen
----------

Jahresrechnung KassenstatistikÖffentliche FEU**Quelle:** Fachserie 14 Reihe 2 vierteljährliche Kassenergebnisse Kernhaushalte, 1.- 4. Vierteljahr einschließlich Auslaufperiode

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Kassenstatistik

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/8e705e9c65be662f/443ce2546170/oeffentliche-finanzen-zeitreihe-2022-kasse.xlsx)
#### Öffentliche Fonds, Einrichtungen und Unternehmen

[Zeitreihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/dd9615a41b8d6fae/e23fdd400ac2/OeffentlicheFinanzen_FEU_Zeitreihe_Berlin-Brandenburg.xlsx)

Basisdaten
----------

KassenstatistikJahresabschlüsse der öffentlichen FEU

Regionaldaten
-------------

###### Brandenburger Landkreise und kreisfreie Städte

#### Realsteuer 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1715943478573&code=71#abreadcrumb)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1715943158408&code=71#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Cathleen Faber

FINANZSTATISTIKEN

#### Cathleen Faber

FINANZSTATISTIKEN

* [0331 8173-1264](tel:0331 8173-1264)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Andrea Götze

ÖFFENTLICHE UNTERNEHMEN

#### Andrea Götze

ÖFFENTLICHE UNTERNEHMEN

* [0331 8173-1250](tel:0331 8173-1250)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Sandra Aßmann

REALSTEUERVERGLEICH, Kommunaler Finanzausgleich

#### Sandra Aßmann

REALSTEUERVERGLEICH, Kommunaler Finanzausgleich

* [0331 8173-1223](tel:0331 8173-1223)
* [kommunalerfinanzausgleich@statistik-bbb.de](mailto:kommunalerfinanzausgleich@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / BongkarnThanyakij](https://download.statistik-berlin-brandenburg.de/e290824131875f05/9512c6b1278e/v/2b87513e5a84/gesellschaft-soziales-man-looking-at-his-empty-leather-wallet-in-office-picture-id835036152.jpg "iStock.com / BongkarnThanyakij")](/l-iii-1-j)**jährlich, 2023, L III 1 – j**[#### Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen in Berlin und Brandenburg](/l-iii-1-j)

Stand der Schulden, Schuldenaufnahmen, Schuldentilgungen und sonstigen Schuldenbewegungen des Berichtsjahres in Berlin und Brandenburg.

[![iStock.com / Ralf Geithe](https://download.statistik-berlin-brandenburg.de/4ee954f5b90c0c5d/ceb6f0190487/v/4fa619ce9cbf/gesellschaft-staat-old-tab-with-the-german-word-for-taxes-picture-id945026698.jpg "iStock.com / Ralf Geithe")](/l-ii-6-j)**II. Quartal 2024, jährlich, L II 6 – j**[#### Realsteuerhebesätze der Städte und Gemeinden in Brandenburg](/l-ii-6-j)

Die Hebesätze sind ein Faktor, der zur Ermittlung der Steuerschuld mit dem Steuermessbetrag multipliziert wird.

[![iStock.com / Grafner](https://download.statistik-berlin-brandenburg.de/9aa00320c7d90f97/c0ca52f7f8a3/v/b12e76723d9f/gesellschaft-arbeit-finance-business-euro-stock-background-picture-id670891402.jpg "iStock.com / Grafner")](/l-iii-6-j)**31.12.2023, jährlich, L III 6 – j**[#### Finanzvermögen der Kern- und Extrahaushalte des öffentlichen Gesamthaushalts in Berlin und Brandenburg](/l-iii-6-j)

Jährliche Erhebung des Finanzvermögens der öffentlichen Haushalte und deren öffentlich bestimmten Fonds, Einrichtungen und Unternehmen.

[Zu unseren News](/news)

[* Finanzen](/search-results?q=tag%3AFinanzen)[* Einnahmen](/search-results?q=tag%3AEinnahmen)[* Kernhaushalte](/search-results?q=tag%3AKernhaushalte)[* Finanzierungssaldo](/search-results?q=tag%3AFinanzierungssaldo)[* FEU](/search-results?q=tag%3AFEU)[* Schalenkonzept](/search-results?q=tag%3ASchalenkonzept)[* Personalauszahlung](/search-results?q=tag%3APersonalauszahlung)[* Kassenkredite](/search-results?q=tag%3AKassenkredite)[* Steueraufkommen](/search-results?q=tag%3ASteueraufkommen)
