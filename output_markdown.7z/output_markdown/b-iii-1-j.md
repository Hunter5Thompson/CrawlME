

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Hochschulen](/hochschulen)
* [Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Teil 2: ausführliche Ergebnisse](/b-iii-1-j)

Studierende an Hochschulen– Wintersemester, ausführliche Ergebnisse
-------------------------------------------------------------------

#### 2023, jährlich

###### Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden, Studienkollegiaten und Gasthörenden erhoben (Studierende zu Beginn des Semesters, Gasthörer und Studienkollegiaten nur im Wintersemester).

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/307e1c3d9b33dbf0/f2def072dec4/SB_B03-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/57963808305cbee9/73d1503d2df8/SB_B03-01-00_2023j01_BE.pdf)

**Mehr Studierende****in Berlin**

Im Wintersemester 2023/24 waren 200.440 Studierende an den Hochschulen in Berlin eingeschrieben. Das waren 847 Studierende mehr als im letzten Wintersemester.

Insgesamt sind die Rechts-, Wirtschafts- und Sozialwissenschaften mit einem Anteil von 35 % weiterhin am häufigsten gefragt, gefolgt von den Ingenieurwissenschaften mit 27 % und den Geisteswissenschaften mit 12 %.

Bei den Studentinnen sind die Rechts-, Wirtschafts- und Sozialwissenschaften mit 42 % am beliebtesten, bei den Studenten liegen die Ingenieurwissenschaften mit 39 % an erster Stelle.

### Kontakt

#### Eike Müller

Hochschulen

#### Eike Müller

Hochschulen

* [0331 8173-1144](tel:0331 8173-1144)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Anstieg der Studierendenzahl in Brandenburg**

Im Wintersemester 2023/24 waren 51.468 Studierende an den Hochschulen Brandenburgs eingeschrieben. Das waren 1.041 Studierende mehr als im letzten Wintersemester. Die Frauenquote betrug unverändert 51 %.

Insgesamt sind die Rechts-, Wirtschafts- und Sozialwissenschaften mit einem Anteil von 37 % weiterhin am häufigsten gefragt, gefolgt von den Ingenieurwissenschaften mit 25 % und den Geisteswissenschaften mit 15 %.

Bei den Studentinnen sind die Rechts-, Wirtschafts- und Sozialwissenschaften mit 41 % am beliebtesten. Bei den Studenten liegt die Fächergruppe Ingenieurwissenschaften mit 36 % vor den Rechts-, Wirtschafts- und Sozialwissenschaften mit 33 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/44a9c3bc8ce00742/d53766d36f05/SB_B03-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/e4822c5985c685db/f607e8e974cd/SB_B03-01-00_2023j01_BB.pdf)
### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden und Gasthörern erhoben; Studierende zu Beginn des Semesters, Gasthörer im Wintersemester.

Auskunftspflichtig sind die Hochschulverwaltungen. In die Erhebung einbezogen sind alle staatlichen und staatlich anerkannten Hochschulen. Die Statistiken werden auf der Basis der Verwaltungs­unterlagen der Auskunftspflichtigen als Totalerhebungen durchgeführt. Die Ergebnisse der Hochschulstatistiken bilden die Datenbasis für Entscheidungen im Bund, in den Ländern und in den Hochschulen selbst. Aber auch die verschiedensten öffentlichen und privaten Einrichtungen sind an den Ergebnissen stark interessiert, unter anderem die Hochschul­rektorenkonferenz, die Ständige Konferenz der Kultusminister und der Wissenschaftsrat.

Auch wenn es sich bei den Hochschulstatistiken um Bundesstatistiken handelt, so werden die Ergebnisse doch zunehmend durch Länderspezifika und Besonderheiten der Hoch­schulen beeinflusst. Zuordnungen können in den einzelnen Bundesländern voneinander abweichen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Studenten**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/2b5d23d0611028d9/865dceac877e/MD_21311_2019.pdf)[Archiv](/search-results?q=21311&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-iii-1-j)
