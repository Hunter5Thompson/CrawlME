

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Verkehr](/gesellschaft/verkehr)
* [Personenverkehr](/personenverkehr)
* [Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg](/h-i-5-5j)

Personenverkehr mit Bussen und Bahnen
-------------------------------------

#### 2019, fünfjährlich

###### Ergänzend zur[jährlichen Erhebung](/a88cdd57b12bf112) infomieren die Strukturdaten über Linienlängen und Zahl der Linien, Schienenfahrzeuge und Omnibusse sowie Beschäftigte in Nahverkehrsunternehmen.

BerlinBrandenburgMethodik
### Berlin

1 Angaben der Unternehmen mit Sitz in Berlin**Quelle:** Amt für Statistik berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2019**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8f7804c5e9e9f351/48c4b267262e/SB_H01-05-00_2019j05_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b056d27e15526e50/324aa0025efe/SB_H01-05-00_2019j05_BE.pdf)

**30 Prozent der Fahrgäste mit S-Bahn unterwegs**

Im Jahr 2019 wurden im Berliner Schienen- und Liniennahverkehr 1 618,6 Millionen (Mill.) Fahrgäste gezählt. Der Anteil der Fahrgäste im Verkehr mit S-Bahnen machte 30,4 Prozent aus. Die Beförderungsleistung betrug 9 767,1 Mill Personenkilometer, die Fahrleistung 172,8 Mill. Fahrzeugkilometer. Für das Beförderungsangebot wurden 36 436,0 Mill. Platzkilometer ermittelt. Die Beförderungseinnahmen beliefen sich auf 2 154,9 Mill. EUR. Es waren 1 609 Omnibusse im Liniennahverkehr im Einsatz. Sie hatten eine Platzkapazität von 84 700 Sitzplätzen und 62 400 Stehplätzen.

### Kontakt

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Ein Drittel der Fahrgäste in Straßenbahnen unterwegs**

Im Land Brandenburg wurden 2019 im Schienen- und Liniennahverkehr 144,7 Millionen (Mill.) Fahrgäste gezählt. Der Anteil der Fahrgäste im Verkehr mit Straßenbahnen lag bei 32,6 Prozent. Die Beförderungsleistung betrug 1 484,4 Mill. Personenkilometer, die Fahrleistung 93,9 Mill. Fahrzeugkilometer. Für das Beförderungsangebot wurden 7 129,5 Mill. Platzkilometer ermittelt. Die Beförderungseinnahmen betrugen 137,8 Mill. EUR. Es waren 1 341 Omnibusse  mit einer Platzkapazität von 56 400 Sitzplätzen und 61 500 Stehplätzen im Liniennahverkehr im Einsatz.

1 Angaben der Unternehmen mit Sitz in Brandenburg**Quelle:** Amt für Statistik berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2019**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/20c6d88c7fd5336d/5f8431d11e0c/SB_H01-05-00_2019j05_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/15a5f05059bcc9f4/9e7fa01a3bb8/SB_H01-05-00_2019j05_BB.pdf)
### Kontakt

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Mit der jährlichen bzw. 5-jährlichen Statistik des gewerblichen Personennahverkehrs und des Omnibusfernverkehrs soll die Entwicklung und die Struktur der Verkehrsleistungen sowie die dafür erforderlichen Voraussetzungen beobachtet werden. Detaillierte Ergebnisse über das Verkehrsaufkommen sind Grundlage für eine Vielzahl von Maßnahmen im Bereich der Gesetzgebung, Verwaltung und Verkehrswirtschaft. Die Ergebnisse dieser Statistik sind Bestandteil des verkehrsstatistischen Systems zur Erfassung des Personenverkehrs und werden für die Aufstellung volkswirtschaftlicher Gesamtrechnungen verwendet.

Zur Entlastung der Verkehrsunternehmen, die Personenbeförderung im Schienennahverkehr und im gewerblichen Omnibusverkehr durchführen, werden diese auf der Grundlage des Verkehrsstatistikgesetzes (VerkStatG) nur noch alle fünf Jahre vollständig nach Verkehrsarten, Beförderungsleistungen und Unternehmensstrukturen befragt. Ergänzend gibt es eine jährliche Stichprobenerhebung sowie eine vierteljährliche Befragung von Unternehmen mit mindestens 250 000 Fahrgästen im Vollerhebungsjahr.  
Beim Nachweis von Länderergebnissen werden die von einem Unternehmen ggf. auch in anderen Bundesländern erbrachten Verkehrsleistungen dem Bundesland zugeordnet, in dem das auskunftspflichtige Unternehmen seinen Hauptsitz hat.

Erhebungsinhalte sind Fahrgäste, Beförderungsleistung, Beförderungsangebot, Fahr­leistungen und Einnahmen im Linienverkehr. Bei der 5-jährlichen Erhebung werden zusätzlich Infrastrukturangaben, Linienfahrzeuge und Beschäftigte erfragt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Jährliche/5-jährliche Statistik des   
 gewerblichen Personenverkehrs und   
 des Omnibusfernverkehrs**  
ab 2017

[Download PDF](https://download.statistik-berlin-brandenburg.de/54d2fed5a36678ce/04ce55c9125c/MD_46182_2017.pdf)[Archiv](/search-results?q=46182&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/h-i-5-5j)
