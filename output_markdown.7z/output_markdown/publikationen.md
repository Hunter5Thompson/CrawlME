

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Publikationen](/publikationen)

Publikationen
=============

Neben unserem Kernangebot, den statistischen Berichten, veröffentlichen wir Schwerpunkt-Seiten zu aktuellen Entwicklungen und Themen sowie indikatorengestützte  Berichte, u. a. zu den Themen Nachhaltigkeit oder Bildung. Hier finden Sie zudem einen Überblick über Datenbanken und Verzeichnisse.

SchwerpunkteIndikatorenberichteDatenbankenVerzeichnisse[News und Analysen](/news)

Schwerpunktthemen
-----------------

#### Anhand amtlicher Daten werden aktuelle, gesellschaftlich relevante Themen statistisch beleuchtet.

Leben in Berlin
---------------

Finden Sie mit uns heraus, wo Familien in Berlin wohnen, wie sie leben und welche Bedingungen sie in ihrem direkten Umfeld vorfinden.

[Mehr erfahren](https://www.leben-in-berlin.statistik-berlin-brandenburg.de/)[![iStock-178637753.jpg](https://download.statistik-berlin-brandenburg.de/6a255b0cd4c6f042/6748eabbd59d/v/811eb602b4a4/fahne-ukraine.jpg "iStock-178637753.jpg")](/schwerpunkte/ukraine)**Schwerpunkt**[#### Auswirkungen des Ukraine-Krieges](/schwerpunkte/ukraine)

Ausgehend vom Ist-Zustand werden die Folgen des Ukraine-Konflikts für die Hauptstadtregion in verschiedenen Bereichen beleuchtet.

[![iStock.com / Vladislav Zolotov](https://download.statistik-berlin-brandenburg.de/87f608040b23d410/f253909b08b6/v/52f2573769ca/bevoelkerung-demographie-tourismus-old-market-square-with-st-nicholas-church-and-town-hall-potsdam-picture-id1209637381.jpg "iStock.com / Vladislav Zolotov")](/tourismus-brandenburg)**Aktuelle Kennzahlen für das Urlaubsland Brandenburg**[#### Brandenburg 2018 bis 2023](/tourismus-brandenburg)

Überblick zum Tourismus in Brandenburg, die wichtigsten Kennzahlen und Statistiken – Gäste, Übernachtungen, Herkunftsländer, Umsätze, Auszubildende uvm....

[![iStock.com / jotily](https://download.statistik-berlin-brandenburg.de/bc84f523d272e119/3538d6cc5df4/v/39612975c6ec/bevoelkerung-gesellschaft-berlin-kreuzberg-oberbaumbridge-picture-id913311660.jpg "iStock.com / jotily")](/tourismus-berlin)**Touristische Entwicklungen in der Spreemetropole**[#### Berlin 2018 bis 2023](/tourismus-berlin)

Touristische Kennzahlen und Entwicklungen in der Hauptstadt – Gäste, Übernachtungen, Herkunftsländer, Umsätze, Auszubildende uvm....

[![iStock / carpinxo](https://download.statistik-berlin-brandenburg.de/08d37c8c5bf3e15e/d5047c2f885f/v/b41775ed9cb4/paris-square-empty-coronavirus-epidemy-picture-id1216594968.jpg "iStock / carpinxo")](/corona)**Schwerpunkt**[#### Corona](/corona)

Zahlen und Fakten zur Corona-Situation in der Metropolregion – Auswirkungen auf Gesundheit, Gesellschaft und Wirtschaft.

Indikatorenberichte
-------------------

#### Periodisch erscheinende Veröffentlichungen, die anhand eines Indikatorenkatalogs Entwicklungen abbilden.

#### Nachhaltigkeitsbericht

Um die Fortschritte einer nachhaltigen Entwicklung datenbasiert verfolgen zu können, sind die Gewinnung von Basisdaten und die Dokumentation ihrer Veränderungen notwendig. Mit den Nachhaltigkeitsberichten können Trends in den Zielbereichen einer nachhaltigen Entwicklung sichtbar gemacht werden.

[Berlin 2021](https://download.statistik-berlin-brandenburg.de/feb8ab55a5e5f6f1/a389e1161ead/AfS_Nachhaltigkeitsbericht_2021_BE.pdf)[Brandenburg 2016](https://download.statistik-berlin-brandenburg.de/a970a61fd499162c/47219d311ced/AfS_Nachhaltigkeitsbericht_2016_BB.pdf)[Frühere Ausgaben Berlin](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000830)
#### Regionaler Sozialbericht

Der Regionale Sozialbericht Berlin und Brandenburg untersucht soziale Sicherheit und Integration anhand von Indikatoren in den Bereichen Einkommensarmut und -verteilung, Abhängigkeit von Mindestsicherungsleistungen, Qualifikationsniveau, Erwerbsbeteiligung, Gesundheit und Wohnsituation.

[Bericht 2022 (XLSX)](https://download.statistik-berlin-brandenburg.de/e46d505407f9f2ab/665ce591962b/AfS_Tabellen_Sozialbericht_2022_BBB.xlsx)[Frühere Ausgaben](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00001126)[Interaktive Karte 2019](https://web.statistik-berlin-brandenburg.de/instantatlas/interaktivekarten/sozialbericht/atlas.html)
#### Bildungsberichte

Die regionalen Bildungsberichte enthalten amtliche Daten und Informationen aus dem Bildungsbereich – von der frühkindlichen Bildung bis zur Weiterbildung im Erwachsenenalter. Sie leisten einen Beitrag für eine sachliche Grundlage von Diskussionen und Entscheidungen im Bildungsbereich hat.

[Zu den Bildungsberichten](/bildungsberichte)

Interaktive Datenbanken
-----------------------

#### Aktuelle und historische Zahlen zu vielen amtlichen Statistiken in flexibler tabellarischer Form.

#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik für Deutschland auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten für Deutschland und die Bundesländer zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=previous&levelindex=0&step=0&titel=Statistik+%28Tabellen%29&levelid=1614263131500&acceptscookies=false#abreadcrumb)
#### StatIS-BBB

![](https://download.statistik-berlin-brandenburg.de/78324daa1d8c4302/8f3a5e8bad38/v/4b6c25f57664/statis-bbb-schmuckbild.jpg)

In StatIS-BBB lassen sich individuelle Auswertungen für Berlin und Brandenburg auf Basis regional tief gegliederter Daten erstellen und exportieren.

[Zu StatIS-BBB](https://statis.statistik-berlin-brandenburg.de/webapi/jsf/dataCatalogueExplorer.xhtml)
#### Daten & Karten

Verschiedene themenspezifische Datenbanken und Atlanten, wie beispielsweise den Unfall- oder den Tourismusatlas  finden Sie jeweils in den passenden statistischen Rubriken auf unserer Webseite.

Verzeichnisse
-------------

#### Informative Listenwerke zu verschiedenen Themen

#### Berlin

###### Straßenumbenennungen

Stand: Oktober 2024

[PDF](https://download.statistik-berlin-brandenburg.de/91d0dfabc77bc5d4/248c28c083b7/strassenumbenennungen-berlin.pdf) | [XLSX](https://download.statistik-berlin-brandenburg.de/4966c2426c883835/5625161a5076/strassenumbenennungen-berlin.xlsx)

###### Adressverzeichnis für die Lebensweltlich orientierten Räume

Stand: Juni 2024

* [Mitte, PDF](https://download.statistik-berlin-brandenburg.de/4a0cca130dc1cc38/62aaab7a74cf/VZ_Adr_VerzeichnisLOR01_2024_BE.pdf)
* [Friedrichshain-Kreuzberg, PDF](https://download.statistik-berlin-brandenburg.de/c3abd70884939095/02715a7a58bb/VZ_Adr_VerzeichnisLOR02_2024_BE.pdf)
* [Pankow, PDF](https://download.statistik-berlin-brandenburg.de/687b405e73f96f3e/85aa286c518a/VZ_Adr_VerzeichnisLOR03_2024_BE.pdf)
* [Charlottenburg-Wilmersdorf, PDF](https://download.statistik-berlin-brandenburg.de/ed440ded33bde75a/eca4a5e8c64e/VZ_Adr_VerzeichnisLOR04_2024_BE.pdf)
* [Spandau, PDF](https://download.statistik-berlin-brandenburg.de/62d42d782bfb66f5/83eacc7e7922/VZ_Adr_VerzeichnisLOR05_2024_BE.pdf)
* [Steglitz-Zehlendorf, PDF](https://download.statistik-berlin-brandenburg.de/6a735a795055bcb2/c12ee4e7ea1f/VZ_Adr_VerzeichnisLOR06_2023_BE.pdf)
* [Tempelhof-Schöneberg, PDF](https://download.statistik-berlin-brandenburg.de/4102f70b0ea54083/6f63dd0e7866/VZ_Adr_VerzeichnisLOR07_2024_BE.pdf)
* [Neukölln, PDF](https://download.statistik-berlin-brandenburg.de/45d50014cd39990c/b3607465d025/VZ_Adr_VerzeichnisLOR08_2024_BE.pdf)
* [Treptow-Köpenick, PDF](https://download.statistik-berlin-brandenburg.de/230a15574e5d5f40/7d6928f8ebca/VZ_Adr_VerzeichnisLOR09_2024_BE.pdf)
* [Marzahn-Hellersdorf, PDF](https://download.statistik-berlin-brandenburg.de/29ee9089312d60ad/1bb75368ca83/VZ_Adr_VerzeichnisLOR10_2024_BE.pdf)
* [Lichtenberg, PDF](https://download.statistik-berlin-brandenburg.de/413072b37dc0b61b/137a50af20e7/VZ_Adr_verzeichnisLOR11_2024_BE.pdf)
* [Reinickendorf, PDF](https://download.statistik-berlin-brandenburg.de/a2146d3d1f616b81/84cb817031ce/VZ_AdrVerzeichnisLOR012_2024_BE.pdf)

Bei den LOR-Adressverzeichnissen gilt seit 01.01.2021 eine neue Einteilung und Nummerierung. Eine Beschreibung der Veränderungen sind auf der Seite der Senatsverwaltung für Stadtentwicklung und Wohnen unter [Lebensweltlich orientierte Räume (LOR) (01.01.2021)](https://fbinter.stadt-berlin.de/fb/index.jsp) hinterlegt.

Stand: Juni 2020

* [Mitte, PDF](https://download.statistik-berlin-brandenburg.de/923d15aa531dd503/e9df96b0ee61/VZ_AdrVerzeichnisLOR01_2020_BE.pdf)
* [Friedrichshain-Kreuzberg, PDF](https://download.statistik-berlin-brandenburg.de/5da931392d2e3a47/b4c8396db207/VZ_AdrVerzeichnisLOR02_2020_BE.pdf)
* [Pankow, PDF](https://download.statistik-berlin-brandenburg.de/8370b1e7fa163aa8/e445be9cb5ef/VZ_AdrVerzeichnisLOR03_2020_BE.pdf)
* [Charlottenburg-Wilmersdorf, PDF](https://download.statistik-berlin-brandenburg.de/0dda64e96c89b536/72f8e475fbbe/VZ_AdrVerzeichnisLOR04_2020_BE.pdf)
* [Spandau, PDF](https://download.statistik-berlin-brandenburg.de/fc4fcf3a3e82215c/b85b0378614d/VZ_AdrVerzeichnisLOR05_2020_BE.pdf)
* [Steglitz-Zehlendorf, PDF](https://download.statistik-berlin-brandenburg.de/0794f58a1c32284a/81b7810c3ce4/VZ_AdrVerzeichnisLOR06_2020_BE.pdf)
* [Tempelhof-Schöneberg, PDF](https://download.statistik-berlin-brandenburg.de/4f70caa92f1b3cf8/9c0f65145684/VZ_AdrVerzeichnisLOR07_2020_BE.pdf)
* [Neukölln, PDF](https://download.statistik-berlin-brandenburg.de/f557972a85faa0bf/bc76eecaca09/VZ_AdrVerzeichnisLOR08_2020_BE.pdf)
* [Treptow-Köpenick, PDF](https://download.statistik-berlin-brandenburg.de/4e62547d526d2133/5e35be0d2218/VZ_AdrVerzeichnisLOR09_2020_BE.pdf)
* [Marzahn-Hellersdorf, PDF](https://download.statistik-berlin-brandenburg.de/d323239e1a274136/f609d73d3aa6/VZ_AdrVerzeichnisLOR10_2020_BE.pdf)
* [Lichtenberg, PDF](https://download.statistik-berlin-brandenburg.de/a9a6fec1025d0563/745d18bbca27/VZ_AdrVerzeichnisLOR11_2020_BE.pdf)
* [Reinickendorf, PDF](https://download.statistik-berlin-brandenburg.de/ec6d828f88f83ccd/258ea08a0bf7/VZ_AdrVerzeichnisLOR12_2020_BE.pdf)
* [Allende-Viertel, PDF](https://download.statistik-berlin-brandenburg.de/9caea1f04f462eb6/fc9f48bd8ef4/Allende-Viertel-2019_Info.pdf)
#### Brandenburg

###### Verzeichnis der Beruflichen Schulen Brandenburg

(XLSX | 20,00 EUR)  
Adressstand: 02.07.2024, Schülerzahlen: 06.11.2023 (Schuljahr 2023/24), Berufe: 06.11.2023 (Schuljahr 2023/24)  
Für Ihre Bestellung senden Sie bitte eine E-Mail an: [vertrieb@statistik-bbb.de](mailto:vertrieb@statistik-bbb.de)

###### Verzeichnis der allgemeinbildenden Schulen Brandenburg

(XLSX | 20,00 EUR)  
Adressstand: 02.07.2024, Schülerzahlen: 25.09.2023 (Schuljahr 2023/2024)  
Für Ihre Bestellung senden Sie bitte eine E-Mail an: [vertrieb@statistik-bbb.de](mailto:vertrieb@statistik-bbb.de)

###### Kommunalverzeichnis Brandenburg

Das Kommunalverzeichnis finden Sie [auf der Serviceseite des Landes Brandenburg](https://service.brandenburg.de/lis/list.php?page=kommunen_p&__ariadne=14281).

###### Gemeinde- und Ortsteilverzeichnis Brandenburg

Das Gemeinde- und Ortsteilverzeichnis der Landesvermessung und Geobasisinformation Brandenburg finden Sie [hier](https://geoportal.brandenburg.de/detailansichtdienst/render?view=gdibb&url=https://geoportal.brandenburg.de/gs-json/xml?fileid=33e424b4-972f-421b-9775-1716496f321b).

#### Deutschland

###### Gemeindeverzeichnis

Im [Gemeindeverzeichnis](https://www.statistikportal.de/de/gemeindeverzeichnis) erhalten Sie schnell und unkompliziert relevante Informationen zu jeder Gemeinde in Deutschland, wie Einwohnerzahl, Fläche, amtlichem Gemeindeschlüssel (AGS), Postleitzahl und Anschrift.

###### Regionalstatistischer Datenkatalog

Übersicht amtlicher Statistiken nach verfügbaren Berichtsjahren, Periodizität und regionaler Ebene. **→**[zum Datenkatalog](https://www.statistikportal.de/de/veroeffentlichungen/regio-stat-katalog)

###### Krankenhausverzeichnis

Das [Krankenhausverzeichnis](https://www.statistikportal.de/de/veroeffentlichungen/krankenhausverzeichnis) weist alle Einrichtungen aus, die am 31.12. des Berichtsjahres zur stationären medizinischen Versorgung der Bevölkerung vorhanden waren.

Ausgewählte Merkmale:  Anzahl der aufgestellten Betten, stationäre Notfallversorgung.

### Immer die Fakten im Blick

#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Kürzlich veröffentlicht
-----------------------

#### Aktuelle Statistiken, News rund um unsere Zahlen und Pressemitteilungen

[![iStock-1213727367.jpg](https://download.statistik-berlin-brandenburg.de/8c43b2d7bc814cc3/3e5ce1b6bb13/v/4660157d52dc/landwirtschaft-rinder.jpg "iStock-1213727367.jpg")](/c-iii-9-hj)**3. November 2024, halbjährlich, C III 9 - hj**[#### Rinder in Berlin und Brandenburg](/c-iii-9-hj)

Die Erhebung informiert über die Anzahl der Rinder (einschließlich Büffel/Bisons), gegliedert nach Alter, Geschlecht, Nutzungszweck und Rasse.

[![iStock.com / Rawf8](https://download.statistik-berlin-brandenburg.de/bb9c63d4a21d952a/78b18f7a17ff/v/85a71b6cd4c6/gesellschaft-staat-judge-gavel-and-a-laptop-wooden-background-online-auction-concept-picture-id1220820993.jpg "iStock.com / Rawf8")](/180-2024)**Strafverfolgung 2023 in Berlin und Brandenburg**[#### Abwärtstrend in Brandenburg setzt sich fort](/180-2024)

2023 nahm die Zahl der Verurteilungen in Berlin im Vergleich zum Vorjahr um 2,1 % zu, in Brandenburg ging sie um 11,1 % zurück.

[![iStock.com / Spotmatik](https://download.statistik-berlin-brandenburg.de/09fe07d2f99a71db/1fd2b255bc8f/v/d5efaa426575/gesellschaft-gesundheit-doctors-hospital-corridor-nurse-pushing-gurney-stretcher-bed-picture-id478740625.jpg "iStock.com / Spotmatik")](/179-2024)**Krankenhausdiagnosestatistik 2023 Berlin und Brandenburg**[#### Zahl der vollstationären Behandlungen steigt langsam wieder an](/179-2024)

Rund 1,25 Millionen Menschen sind 2023 in den Krankenhäusern der Metropolregion behandelt worden.

[![iStock.com / GoogolPix](https://download.statistik-berlin-brandenburg.de/1a03bedef8ab3c23/0b10aefb97c2/v/6a408397d32d/gesellschaft-verkehr-ship-on-canal-in-bavaria-picture-id666692770.jpg "iStock.com / GoogolPix")](/173-2024)**Transport auf Brandenburgs Wasserstraßen von Januar bis September 2024**[#### Mehr Güter befördert](/173-2024)

Auf den Binnenwasserstraßen Brandenburgs wurden in den ersten drei Quartalen 2024 insgesamt 1.524.600 Tonnen Güter befördert.

[![iStock.com / serts](https://download.statistik-berlin-brandenburg.de/dd6e941c8ce73a94/2daf4f79fd95/v/32cedc604422/gesellschaft-staat-statue-of-lady-justice-rmerberg-frankfurt-germany-picture-id840831682.jpg "iStock.com / serts")](/b-vi-1-j)**2023, jährlich, B VI 1 – j**[#### Abgeurteilte und Verurteilte in Berlin](/b-vi-1-j)

In dieser Statistik wird die Anzahl der Abgeurteilten und Verurteilten aus der Strafverfolgungsstatistik veröffentlicht.

[![iStock.com / Animaflora](https://download.statistik-berlin-brandenburg.de/f08f86242a9d8c45/daccc7cb7e90/v/7b54dde10b33/gesellschaft-verkehr-barges-maindanube-canal-in-bamberg-picture-id1094480316.jpg "iStock.com / Animaflora")](/172-2024)**Transport auf Berlins Wasserstraßen von Januar bis September 2024**[#### Leichter Anstieg bei der Güterbeförderung](/172-2024)

Auf den Binnenwasserstraßen Berlins wurden in den ersten drei Quartalen 2024 insgesamt 909.451 Tonnen Güter befördert.


