

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Gemüseerhebung in Brandenburg](/c-i-3-j)

Gemüseerhebung in Brandenburg
-----------------------------

#### 2023, jährlich

##### Die Daten der Gemüseerhebung geben Aufschluss über Anbau und Ernte von Gemüse und Erdbeeren, deren Jungpflanzen, die Pflanzengruppen, Pflanzenarten und Kulturformen.

BrandenburgMethodik
### Brandenburg

**Gemüseanbau rückläufig, Rekordertrag bei Einlegegurken** 

Die Anbaufläche von Gemüse im Freiland betrug 2023 in Brandenburg rund 6.100 Hektar. Das waren fast 360 Hektar weniger als im Jahr 2022. Die Erntemenge lag trotz des Flächenrückgangs mit 98.000 Tonnen um knapp 7.400 Tonnen über dem Vorjahresergebnis.

Auf einer Fläche von 3.500 Hektar wurden 22.200 Tonnen Spargel gestochen. Damit verkleinerte sich die Ertragsfläche des anbaustärksten Gemüses in Brandenburg etwa um 200 Hektar.

Als zweitstärkste Gemüsekultur wurden auf rund 470 Hektar gut 34.800 Tonnen Einlegegurken gepflückt. Gegenüber 2022 waren das 10.600 Tonnen mehr. Der Ertrag von fast 750 Dezitonnen je Hektar (dt/ha) ist der höchste Wert für Brandenburg seit 1991.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/3b595cc7ed3542db/2a26f93aad70/SB_C01-03-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/da2880464e65cbf3/60e2a885536a/SB_C01-03-00_2023j01_BB.pdf)
### Kontakt

#### Regina Kurz

Ernte- und Weinstatistiken

#### Regina Kurz

Ernte- und Weinstatistiken

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
### Methodik und weitere Informationen

In der Gemüseerhebung werden jährlich die Anbauflächen und Erntemengen von Gemüse und/oder Erdbeeren nach Pflanzengruppen, Pflanzenarten, Kulturformen und Arten der Eindeckung, bei Spargel und Erdbeeren zusätzlich der Stand der Ertragsfähigkeit erhoben. Weiterhin wird die ökologische Wirtschaftsweise erfasst. Alle vier Jahre (beginnend 2012) wird bei Gemüse zusätzlich die Grundfläche erhoben. Bei der Anzucht von Jungpflanzen wird jährlich die Grundfläche im Freiland und unter hohen begehbaren Schutzabdeckungen (einschließlich Gewächshäusern) erfragt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Gemüseerhebung**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/f2bf2ccd4b5989ef/ef3ac56916ea/MD_41215_2023.pdf)[Archiv](/search-results?q=MD_41215&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-3-j)
