

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Bruttoanlagevermögen in Berlin und Brandenburg nach Wirtschaftsbereichen](/p-i-11-j)

Bruttoanlagevermögennach Wirtschaftsbereichen
---------------------------------------------

#### 1991/1995 bis 2021, jährlich

###### Das Bruttoanlagevermögen informiert über vorhandene Vermögenswerte an Anlagen, Ausrüstungen und Bauten und deren Modernisierungsgrad. Außerdem werden Angaben zu Kapitalstock, Kapitalintensität und -produktivität auf Ebene der Bundesländer bereitgestellt.

###### 

BerlinBrandenburgMethodik
### Berlin

#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/45521fd9fa43436e/ad2b3dab41df/SB_P01-11-00_2021j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/a19abcb6086ee74b/8e622140a46f/SB_P01-11-00_2021j01_BE.pdf)

**Überdurchschnittliches Wachstum**

Der Bestand des preisbereinigten Bruttoanlagevermögens erhöhte sich zum Jahresende 2021 in Berlin um 1,2 % und damit stärker als im bundesweiten Durchschnitt (+0,8 %).  Das Anlagevermögen zu Wiederbeschaffungspreisen belief sich auf insgesamt 900.770 Mill. EUR. Die Dienstleistungsbereiche legten dabei mit einem Wachstum von 9,0 % gegenüber dem Vorjahr deutlich stärker zu als das Produzierende Gewerbe mit 4,2 %.

Der Modernitätsgrad verringerte sich um 0,1 %-Punkte auf 54,4 % und lag damit leicht unter dem Länderschnitt von 54,5 %. 1991 betrug der Modernitätsgrad noch 63,3 % in der Hauptstadt.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Modernstes Anlagevermögen Deutschlands**

Brandenburg erreichte 2021 mit einem Plus von 1,8 % den höchsten Zuwachs beim Bestand des preisbereinigten Bruttoanlagevermögens unter allen Ländern. Das Anlagevermögen zu Wiederbeschaffungspreisen belief sich auf insgesamt 587.306 Mill. EUR. Die Dienstleistungsbereiche legten um 10,2 % gegenüber dem Vorjahr zu.

Mit 60,2 % verfügte Brandenburg weiterhin über das modernste Anlagevermögen Deutschlands. Gegenüber dem Vorjahr verringerte es sich jedoch um 0,2 %-Punkte.

#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f68541a80c5b442b/bdb457cc77b7/SB_P01-11-00_2021j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/cd838e94ef7646cc/b99e3c35b0f8/SB_P01-11-00_2021j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das Anlagevermögen umfasst alle produzierten Vermögensgüter, die länger als ein Jahr wiederholt oder dauerhaft in der Produktion eingesetzt werden. Es gliedert sich in Ausrüstungen (z. B. Fahrzeuge), sonstige Anlagen (geistiges Eigentum) und Bauten (z. B. Wohnbauten und Nichtwohngebäude). Das Anlagevermögen wird brutto und netto dargestellt. Das Bruttokonzept stellt den Neuwert der Anlagen ohne Wertminderung dar, beim Nettokonzept werden die Abschreibungen berücksichtigt. Der Modernitätsgrad gibt an, wie viel Prozent des Anlagevermögens noch nicht abgeschrieben wurde und gibt somit Aufschluss über den Alterungsprozess des Vermögens.

Ergebnisse für alle Bundesländer und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/p-i-11-j)


