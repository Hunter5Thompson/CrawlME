

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Primäreinkommen und verfügbares Einkommen der privaten Haushalte in Berlin und Brandenburg](/p-i-10-j)

Primäreinkommen und verfügbares Einkommen der privaten Haushalte
----------------------------------------------------------------

#### 1991 bis 2022, jährlich

###### Die Ergebnisse geben Auskunft über die Einkommen aus Erwerbstätigkeit und Vermögen (Primäreinkommen) sowie das Einkommen, das den privaten Haushalten für Sparen und Konsum zur Verfügung steht (Verfügbares Einkommen).

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Ergebnisse des Arbeitskreises "Volkswirtschaftliche Gesamtrechnungen der Länder; Berechnungsstand: August 2023
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/fbed02635ef10851/e8f69b448c2c/SB_P01-10-00_2022j01_BE.xlsx)

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/c46ea5df74f71a74/1480d461e2c2/SB_P01-10-00_2022j01_BE.pdf)

**Verfügbares Einkommen mehr als 7 % unter Bundesdurchschnitt**

Im Jahr 2022 standen den Berliner Haushalten 23.952 EUR pro Person zur Verfügung, 5,5 % mehr als im Vorjahr. Gemessen am bundesweiten Durchschnitt von 25.830 EUR lag das verfügbare Pro-Kopf-Einkommen in Berlin bei knapp 93 %.

Das Primäreinkommen pro Person stieg um 6,6 % auf 29.821 EUR. Bundesweit betrug der Anstieg 5,9 % auf ein Primäreinkommen pro Person in Höhe von 31.462 EUR.

Größte Quelle des Primäreinkommens der privaten Haushalte war das Arbeitnehmerentgelt, dessen Anteil in Berlin mehr als 78 % betrug. Aus Betriebsüberschüssen und Selbstständigeneinkommen kamen etwa 7 % der Primäreinkommen, aus Vermögen 14 %.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Höchstes verfügbares Einkommen in Ostdeutschland**

Das verfügbare Pro-Kopf-Einkommen in Brandenburg stieg 2022 um 5,2 % auf 24.050 EUR. Das waren mehr als 93 % des in Deutschland durchschnittlich verfügbaren Einkommens in Höhe von 25.830 EUR.

Das Primäreinkommen pro Person erhöhte sich in Brandenburg um 5,8 % auf 26.331 EUR. Bundesweit betrug der Anstieg 5,9 % und das Primäreinkommen pro Person 31.462  EUR.

Der Anteil des Arbeitnehmerentgelts am Primäreinkommen betrug 81 %. Aus Betriebsüberschüssen und Selbstständigeneinkommen kamen knapp 8 % der Primäreinkommen, aus Vermögen 11 %.

**Quelle:** Ergebnisse des Arbeitskreises "Volkswirtschaftliche Gesamtrechnungen der Länder; Berechnungsstand: August 2023
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d65a8e7c02d9bcce/59e5b948577c/SB_P01-10-00_2022j01_BB.xlsx)

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/f330968703fecf08/5045a48f769c/SB_P01-10-00_2022j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das Primäreinkommen der privaten Haushalte einschließlich privater Organisationen ohne Erwerbszweck umfasst die Einkommen aus Erwerbstätigkeit und Vermögen, die den privaten Haushalten in einer Region zugeflossen sind.

Das verfügbare Einkommen ist das Einkommen, das ihnen für Konsum und Sparen zur Verfügung steht. Es ergibt sich ausgehend vom Primäreinkommen durch Abzug der im Rahmen der Umverteilung geleisteten laufenden Transfers und Hinzurechnung der empfangenen Sozial- und Transferleistungen.

Ergebnisse für alle Bundesländer und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/p-i-10-j)
