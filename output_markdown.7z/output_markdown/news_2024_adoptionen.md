

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 28.08.2024

#### Adoptionen 2023 in Berlin und Brandenburg

Eine neue Familie
-----------------

![Schmuckbild Karriere](https://download.statistik-berlin-brandenburg.de/0abb31092c440f5e/c976fbd3aa51/v/0ac0a78a7a7a/mother-at-home-trying-to-work-with-child-distracting-her-picture-id1192677586.jpg "Schmuckbild Karriere")

**Es gibt verschiedenste Gründe, die eine Adoption notwendig machen. In jedem Fall bedeutet es für das Kind den Schritt in eine neue Familie und ein neues Leben. 2023 gab es in Berlin 92 und in Brandenburg 127 Adoptionen. Die Zahlen verdeutlichen, wie vielfältig das Familienleben ist. Während zum Beispiel die Stiefelternadoption dominiert, adoptierten gleichgeschlechtliche Paare überwiegend jüngere Kinder als verschiedengeschlechtliche Paare. Mehr zu Adoptionsmustern und Verwandtschaftsverhältnissen lesen Sie hier.**

#### **Adoptionsbewerbungen steigen in Berlin und Brandenburg**

In Berlin standen den 92 Adoptionen 128 vorgemerkte Bewerbungen am Jahresende gegenüber. Damit überstiegen die Bewerbungen erstmals in zehn Jahren die Adoptionen. Mit einer Ausnahme im Jahr 2022 gab es bei den Adoptionen in den vergangenen Jahren nur geringe Schwankungen, wohingegen die Bewerbungen einen stetigen Anstieg verzeichnen.

In Brandenburg wurden 127 Adoptionen durchgeführt. 113 Bewerbungen lagen am Jahresende vor. Im Zehnjahresvergleich ist hier sowohl die Zahl der Adoptionen als auch die der Bewerbungen um ungefähr ein Drittel gestiegen.

###### **Was ist Adoptionspflege?**

In der Regel lebt das Kind vor der Adoption ein Jahr bei den künftigen Adoptiveltern in Pflege. Die Adoptionspflege wird in der Regel bei Fremdadoptionen durchgeführt, in Ausnahmefällen auch bei Stiefkind- oder Verwandtenadoptionen. In der Statistik erfasst wird die Anzahl der Kinder und Jugendlichen, die am Jahresende in Adoptionspflege leben.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Stiefelternadoption am häufigsten**

Der Adoptionsprozess in Deutschland ist komplex und kann je nach Fall mehrere Monate bis hin zu mehreren Jahren dauern. Besonders bei internationalen Adoptionen oder in Fällen, in denen kein Verwandtschaftsverhältnis besteht, kann sich der Prozess verlängern. In den häufigsten Adoptionsfällen war die Familie oder das Zuhause dem Kind jedoch bereits bekannt. Jedes zweite adoptierte Kind in Berlin wurde von Verwandten oder den eigenen Stiefmüttern oder -vätern angenommen. In Brandenburg erfolgten sogar 76 % der Adoptionen durch neue Partnerinnen oder Partner der rechtlichen Elternteile bzw. Verwandten.

Ähnliches zeigen die Zahlen zur Unterbringung vor der Adoption: In Berlin wuchs fast jedes zweite adoptierte Kind (45 %) vorher bei einem leiblichen Elternteil mit einem Stiefelternteil auf. In Brandenburg ist der Anteil mit 70 % noch höher. Weitere 20 % in Berlin und 16 % in Brandenburg wurden direkt aus dem Krankenhaus adoptiert oder kamen aus einem Heim (Berlin: 14 %, Brandenburg: 4 %). In 9 % der Fälle folgte die Adoption in Berlin auf eine anonyme Geburt oder die Abgabe über eine Babyklappe. Brandenburg weist hier keinen Fall auf.

 Stichtag: 15.05.2022**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022
#### **Stiefmütter adoptieren mehr Kleinkinder, Stiefväter eher Teenager**

Auch nach der Adoption stellen sich verschiedene Herausforderungen: Die Integration des Kindes in den Familienalltag, das Bewältigen von möglicherweise traumatischen Erfahrungen des Kindes oder bürokratische Hürden. Vor allem bei älteren Kindern kann die Schaffung einer stabilen Bindung Zeit in Anspruch nehmen.

Stiefmütter nahmen 2023 häufiger Kinder an (Berlin: 33 %, Brandenburg: 50 %) als Stiefväter (Berlin: 14 %, Brandenburg: 22 %). Dabei fällt auf: In beiden Ländern adoptierten Stiefmütter in rund sieben von zehn Fällen Säuglinge oder Kleinkinder unter 3 Jahren. Stiefväter nahmen dagegen am häufigsten Teenager an. In etwa jedem zweiten Fall waren die Kinder hier bereits über 12 Jahre.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Insgesamt lag das durchschnittliche Alter der Kinder zum Zeitpunkt der Adoption in Berlin bei 4 Jahren und in Brandenburg bei 5,2 Jahren. Unter den Altersgruppen wurden am häufigsten Kinder zwischen 1 und 3 Jahren adoptiert. Im Schnitt waren in Berlin adoptierte Jungen mit 4,3 Jahren etwas älter als Mädchen (3,6 Jahre). In Brandenburg waren Mädchen dagegen bei der Adoption mit 5,9 Jahren älter als Jungen mit 4,4 Jahren.

#### **Kinder gleichgeschlechtlicher Paare jünger als bei verschiedengeschlechtlichen** **Paaren**

Etwa jedes zweite Berliner (51 %) und jedes vierte Brandenburger (26 %) Adoptivkind wurde 2023 gemeinsam von einem Paar angenommen. 37 % aller Berliner Adoptionen erfolgte durch ein verschiedengeschlechtliches Elternpaar, in Brandenburg waren es 19 % aller Fälle. Demgegenüber stehen 14 % der Kinder in Berlin und 7 % in Brandenburg, die von gleichgeschlechtlichen Elternpaaren adoptiert wurden.

Kinder, die von Paaren eines Geschlechts adoptiert wurden, waren mit durchschnittlich 2,1 Jahren etwas jünger als die Kinder verschiedengeschlechtlicher Elternteile (Berlin: 3,5 Jahre, Brandenburg: 3,3 Jahre). Während unter gleichgeschlechtlichen Eltern in Berlin ausschließlich männlich-männliche Paare Kinder adoptierten, überwogen in Brandenburg die männlich-männlichen Paare mit einem Verhältnis von 78:22. Jungen und Mädchen wurden unter den Paaren zu gleichen Anteilen adoptiert.

#### **Wenig Auslandsadoptionen in Brandenburg**

%
-

**der adoptierten Kinder in Berlin**  
**kamen 2023****aus dem Ausland**

%
-

**der adoptierten Kinder in Brandenburg**  
**kamen 2023 aus dem Ausland**

Vor der Adoptionen besaßen in Berlin 27 % der Kinder keinen deutschen Pass. Aus dem Ausland angenommen wurden in Berlin 17 % der adoptierten Kinder, hiervon bestand bei knapp 19 % bereits ein Verwandtschaftsverhältnis. In Brandenburg lag bei 3 % der Kinder kein deutscher Pass vor. Lediglich 6 % wurden aus dem Ausland adoptiert,  wobei davon die meisten bereits mit dem Adoptivelternteil verwandt waren. Internationale Adoptionen, und hier insbesondere Fremdadoptionen, unterliegen oft strengeren und langwierigeren Prüfungen, was den gesamten Prozess zusätzlich erschwert.

###### Methodischer Hinweis

Die Statistik erfasst die Zahl der im Berichtsjahr durchgeführten Adoptionen von unter 18-jährigen Kindern oder Jugendlichen. Bei der Berechnung der potenziellen Adoptivfamilien je Kind werden internationale Adoptionen ausgeklammert. In den Jahren 2022/2023 wurde die Statistik überarbeitet und um 20 neue Merkmale erweitert, unter anderem zum familialen Hintergrund, internationalen Adoptionen, Adoptionen durch Pflegefamilien und dem Adoptionsverfahren.

###### Datenangebot

Weitere Daten zum Thema sowie Erläuterungen zur Statistik der Adoptionen und den Erhebungsmerkmalen finden Sie unter: [www.statistik-berlin-brandenburg.de/k-v-3-j](/k-v-3-j)

### Kontakte

#### Annett Kusche

Kinder- und Jugendhilfe

#### Annett Kusche

Kinder- und Jugendhilfe

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Familien](/search-results?q=tag%3AFamilien)[* Adoptionen](/search-results?q=tag%3AAdoptionen)[* Babyklappe](/search-results?q=tag%3ABabyklappe)
