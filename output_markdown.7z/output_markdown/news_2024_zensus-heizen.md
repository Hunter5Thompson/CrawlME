

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 12.09.2024

#### Zensus 2022 in Berlin und Brandenburg

Erneuerbare Energien gewinnen beim Heizen an Bedeutung
------------------------------------------------------

![Zensus Energieträger Schmuckbild](https://download.statistik-berlin-brandenburg.de/d83f8be43a79f494/ae6cb25af23a/v/d343680923e7/zensus-energietraeger.png "Zensus Energieträger Schmuckbild")

******Die Gebäude- und Wohnungszählung des Zensus 2022 liefert erstmals detaillierte Daten zur Nutzung von Energieträgern für die Beheizung von Wohngebäuden. In Berlin und Brandenburg überwiegen Fernwärme und Gas deutlich, der Anteil an Wärmepumpen steigt jedoch. Unterschiede zeigen sich vor allem, wenn das Gebäudealter in die Betrachtung einbezogen wird.******

Gas und Fernwärme dominieren sowohl in Berlin als auch in Brandenburg als Energieträger für Wohngebäude. Im gesamten Wohnungsbestand Brandenburgs werden 80 % aller Wohnungen mit diesen beiden Energieträgern beheizt. Wobei bei Fernwärme – einem Sammelbegriff für Energie, die zentral erzeugt und über ein Netz an Gebäude verteilt wird – in beiden Bundesländern ebenfalls überwiegend Erdgas als Energiequelle zum Einsatz kommt. Die Dominanz von Erdgas unterstreicht die bestehende Abhängigkeit von fossilen Brennstoffen.

**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022

Etwa jede 10. Wohnung in Brandenburg wurde zum Stichtag 15. Mai 2022 mit Heizöl versorgt. Dieser ebenfalls fossile Energieträger verliert aufgrund seines hohen CO₂-Ausstoßes während des Verarbeitungsprozesses zunehmend an Bedeutung.

Wärmepumpen oder Solar- und Geothermie, die zu den erneuerbaren Energien zählen, verzeichnen einen Anteil von 3,2 %. Dieser Wert liegt über dem bundesweiten Durchschnitt von 2,7 %. Blickt man auf das [Berliner Umland](/meine-region) steigt der Anteil nochmals auf 4,5 % der Wohnungen. In der Hauptstadt dagegen spielen Wärmepumpen, Solar- und Geothermie mit einem Anteil von weniger als 1 % eine eher untergeordnete Rolle. Die vorherrschenden Energieträger in der Bundeshauptstadt sind Gas und Fernwärme (zusammen rund 89 %).

**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022
#### 20 % der neueren Wohnungen in Brandenburg nutzen ****Wärmepumpen oder Solar- und Geothermie****

Werden die Zahlen für Brandenburg nach dem Baualter der Wohngebäude betrachtet, zeigt sich ein differenzierteres Bild: In Altbauwohnungen, die vor 1950 errichtet wurden, dominieren Gas und Heizöl. Wohnungen aus den 1950er- bis 1980er-Jahren weisen dagegen den größten Anteil bei Fernwärme auf. In den nach 1990 errichteten Wohnungen überwiegt wiederum Gas.

Von den neu gebauten Wohnungen ab 2010 wird bereits jede fünfte Wohnung (21,3 %) durch die erneuerbaren Energieträger beheizt. Damit nimmt Brandenburg ein Vorreiterrolle bei der Nutzung moderner Energien im Neubausektor ein.

 Stichtag: 15.05.2022**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022
#### **In neueren Berliner Wohnungen überwiegt Fernwärme**

In Berlin ist die Nutzung von Gas als Energieträger sehr unterschiedlich über die Baualtersklassen verteilt: In Altbauten von vor 1950 ist Gas der dominierende Energieträger, was auf die historische Infrastruktur und die geringe Verfügbarkeit anderer Energieträger in dieser Zeit zurückzuführen sein könnte. Bei den Gebäuden, die zwischen 1970 und 1989 sowie ab 2010 gebaut wurden, überwiegt die Fernwärme deutlich.

Erneuerbare Energien wie Wärmepumpen treten in den ab 1990 errichteten Gebäuden stärker in Erscheinung, auch wenn dieser Anteil in Berlin unter dem Niveau Brandenburgs liegt.

 Stichtag: 15.05.2022**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022

Der Vergleich zwischen Berlin und Brandenburg zeigt, dass die Nutzung der Energieträger stark vom Baualter der Wohngebäude abhängt. Über lange Zeit hinweg ist sie nahezu identisch verteilt. In alten Gebäude wird viel mit Gas geheizt, in der Nachkriegszeit wurde mehr Fernwärme verbaut. Während Berlin bei neuen Gebäuden weiterhin hauptsächlich auf Fernwärme setzt, ist in Brandenburg der Anteil von Gasheizungen hoch.

Falls Sie an Auswertungen des Zensus 2022 zu anderen Merkmalen oder einer anderen [räumlichen Ebene](/meine-region) interessiert sind, kontaktieren Sie uns gern unter [info@statistik-bbb.de](mailto:info@statistik-bbb.de). Eine Übersicht der Merkmale finden Sie in der Zensusdatenbank.

#### **Datenangebot**

###### Unser Zensus-Datenangebot

Mehr Daten zum Zensus 2022 in Berlin und Brandenburg gibt’s hier:  
[www.statistik-berlin-brandenburg.de/zensus22](/zensus22)

###### Zensusdatenbank

In der [Zensusdatenbank](https://ergebnisse.zensus2022.de/datenbank/online/) können Daten für Bund, Länder, Kreise, Gemeinden und Bezirke (Berlin, Hamburg) abgerufen und mit anderen Merkmalen kombiniert ausgewertet werden. Für die Weiterverarbeitung stehen verschiedene Ausgabeformate zur Verfügung. Die Zensusdatenbank enthält den **Merkmalskatalog** und kann auch mit Programmiersprachen direkt angesprochen werden.

###### Zensus-Atlas

Der [Zensus-Atlas](https://atlas.zensus2022.de/) umfasst Ergebnisse auf Basis von Gitterzellen (10 km, 1 km und 100 m). Für die ersten vier Karten stehen Begleittabellen zum Download zur Verfügung. Die Themen sind Bevölkerung, Heizungsart, Energieträger der Heizung und Nettokaltmiete je Quadratmeter. Weitere Karten und Datensätze folgen.

###### Offizielle Website Zensus 2022

Auf der [Zensus 2022 Website](http://www.zensus2022.de) werden [Regionaltabellen](https://www.zensus2022.de/DE/Ergebnisse-des-Zensus/02-veroeffentlichung.html?nn=270470 "Veröffentlichung") zum Download bereitstellt. Sie enthalten Daten für Bund, Bundesländer, Regierungsbezirke, Stadtkreise/kreisfreie Städte/Landkreise, Gemeindeverbände sowie Gemeinden. Außerdem stehen [Podcasts, Videos und Animationen](https://www.zensus2022.de/DE/Mediathek/_inhalt.html "Mediathek")mit Hintergrundinformationen zur Verfügung.

### Kontakte

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Zensus](/search-results?q=tag%3AZensus)[* Zensus 2022](/search-results?q=tag%3AZensus 2022)[* Energieträger](/search-results?q=tag%3AEnergieträger)[* Heizung](/search-results?q=tag%3AHeizung)[* Wärmepumpe](/search-results?q=tag%3AWärmepumpe)[* Gas](/search-results?q=tag%3AGas)
