

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)

Meine Region
============

Wir schreiben die Zahlen für die Bundesländer Berlin und Brandenburg. Häufig werden wir gefragt, auf welcher Ebene wir Statistiken bereitstellen. Während sich viele Ergebnisse insgesamt auf die Länder beziehen, schauen wir häufig tiefer – bis auf Landkreis-, Gemeinde- oder Bezirksebene und im Falle Berlins sogar noch kleinräumiger.

[Überblick
#### Meine Region](/meine-region)[+ InfoRegionale Statistiken
#### Welche lokalen Daten bieten wir?](/meine-region/regionale-statistiken)[+ DatenBerlin-Statistik 
#### Bezirks-, Ortsteil- und Kiezdaten](/kommunalstatistik)[+ InfoLebensweltlich orientierte Räume
#### Was sind Berlins Raumbezüge?](/meine-region/lebensweltlich-orientierte-raeume-berlin)

Statistische Regionen in Berlin
-------------------------------

**Für die Regionalstatistik werden innerhalb Berlins die Bezirksdaten herangezogen. Unterhalb dieser Ebene gibt es verschiedene Raumbezüge, die im Rahmen des Regionalen Bezugssystems Berlin – der Berliner Variante der kleinräumigen Gliederung – fortgeschrieben werden.**

Das Raumbezugssystem der Lebensweltlich orientierten Räume (LOR) hat das Raumbezugssystem der "Statistischen Gebiete/Verkehrszellen" für sozialräumliche Planungszwecke abgelöst. Für die Vergleichbarkeit über lange Zeiträume werden beide Systeme weiterhin fortgeschrieben.

Detaillierte Informationen zu den Lebensweltlich orientierten Räumen Berlins finden Sie [**hier**](/meine-region/lebensweltlich-orientierte-raeume-berlin).

###### Die wichtigsten Raumbezüge Berlins

**Bezugsraum**Bezirk  
Ortsteil  
Postleitzahlbereiche  
Ost/West

**Raumbezugssystem Lebensweltlich orientierte Räume (LOR)**LOR – Prognoseräume  
LOR – Bezirksregionen  
LOR – Planungsräume

**Raumbezugssystem Statistische Gebiete/Verkehrszellen**Statistisches Gebiet  
Verkehrszelle  
Teilverkehrszelle

**Wahlgebiete**Abgeordnetenhauswahl – Wahlkreis  
Abgeordnetenhauswahl – Stimmbezirk  
Abgeordnetenhauswahl – Briefwahlbezirk  
Bundestagswahl – Wahlkreis  
Bundestagswahl – Wahlbezirk  
Bundestagswahl – Briefwahlbezirk  
Volksentscheid – Abstimmbezirk  
Verwaltungsräume  
Finanzamtsbereiche  
Amtsgerichtsbezirke  
Arbeitsamtsbereiche  
Einschulbereiche Grundschule

**Fördergebiete**[Aktive Zentren](http://www.stadtentwicklung.berlin.de/staedtebau/foerderprogramme/)  
Stadterneuerung (Sanierungsgebiete)  
Stadtumbau Ost und West  
Städtebaulicher Denkmalschutz  
[GRW-Fördergebiete](https://www.foerderdatenbank.de/FDB/DE/Home/home.html)

**Bezirke**

**Ortsteile**

**LOR-Bezirksregionen**

**LOR-Prognoseräume**

**LOR-Planungsräume**

Statistische Regionen in Brandenburg
------------------------------------

**Brandenburg ist als Flächenstaat – im Gegensatz zu Berlin – flächendeckend nur bis zur Ebene der Gemeinden untergliedert. Aus den Gemeindeergebnissen des Landes Brandenburg werden für Vergleichszwecke größere Einheiten, wie Planungsregionen, Mittelbereiche oder Ämter gebildet.**

In einigen größeren Städten Brandenburgs gibt es auch kleinräumigere Gliederungen, welche dann für die örtlich begrenzten Planungen Bedeutung haben. Sie können jedoch nicht von der amtlichen Landesstatistik genutzt werden. Die Postleitzahlgebiete – als verwaltungsunabhängige Raumgliederung Brandenburgs – teilt einige Gemeinden auch kleinräumiger als das Gemeindegebiet selbst.

Orts-, Gemeinde- und Schulverzeichnisse für Brandenburg finden Sie[**hier**](/service#verzeichnisse).

###### Die wichtigsten Raumbezüge Brandenburgs

**Bezugsraum**Kreise und kreisfreie Städte  
Amtsangehörige Gemeinden  
Amtsfreie Gemeinden  
Nicht administrative Gebietsgliederung des Statistischen Bundesamtes  
Postleitzahlgebiete  


**Wahlgebiete**Bundestagswahlkreise  
Landtagswahlkreise

**Planungs- und Förderregionen**Bundesraumordungsregionen  
Mittelbereiche (Landesentwicklungsplan)  
Regionale Wachstumskerne  
[GRW-Fördergebiete](https://www.foerderdatenbank.de/FDB/DE/Home/home.html)

**Gebietsgliederungen EU**[NUTS/LAU](http://de.wikipedia.org/wiki/NUTS)  
[LUZ (Urban Audit)](http://www.staedtestatistik.de/urban-audit.html)

**Verwaltungsräume**  
Landgerichtsbezirk  
Amtsgerichtsbezirk  
Finanzamtsbezirk  
Arbeitsmarktregion

**Landkreise**

**Gemeinden**

**Kreisfreie Städte**

**Reisegebiete**

Statistische Regionen in Berlin
-------------------------------

**Für die Regionalstatistik werden innerhalb Berlins die Bezirksdaten herangezogen. Unterhalb dieser Ebene gibt es verschiedene Raumbezüge, die im Rahmen des Regionalen Bezugssystems Berlin – der Berliner Variante der kleinräumigen Gliederung – fortgeschrieben werden.**

Das Raumbezugssystem der Lebensweltlich orientierten Räume (LOR) hat das Raumbezugssystem der "Statistischen Gebiete/Verkehrszellen" für sozialräumliche Planungszwecke abgelöst. Für die Vergleichbarkeit über lange Zeiträume werden beide Systeme weiterhin fortgeschrieben.

Ein Adressverzeichnis für die LOR sowie eine Auflistung der Straßenumbenennungen finden Sie [**hier**](/service#verzeichnisse).

#### Berlin

12 Bezirke

96 Ortsteile

58 LOR-Prognoseräume

143 LOR-Bezirksregionen

542 LOR-Planungsräume

#### Brandenburg

14 Landkreise und 4 kreisfreie Städte

412 Gemeinden

12 Reisegebiete

###### Die wichtigsten Raumbezüge Berlins

**Bezugsraum**Bezirk  
Ortsteil  
Postleitzahlbereiche  
Ost/West

**Raumbezugssystem Lebensweltlich orientierte Räume (LOR)**LOR – Prognoseräume  
LOR – Bezirksregionen  
LOR – Planungsräume

**Raumbezugssystem Statistische Gebiete/Verkehrszellen**Statistisches Gebiet  
Verkehrszelle  
Teilverkehrszelle

**Wahlgebiete**Abgeordnetenhauswahl – Wahlkreis  
Abgeordnetenhauswahl – Stimmbezirk  
Abgeordnetenhauswahl – Briefwahlbezirk  
Bundestagswahl – Wahlkreis  
Bundestagswahl – Wahlbezirk  
Bundestagswahl – Briefwahlbezirk  
Volksentscheid – Abstimmbezirk  
Verwaltungsräume  
Finanzamtsbereiche  
Amtsgerichtsbezirke  
Arbeitsamtsbereiche  
Einschulbereiche Grundschule

**Fördergebiete**[Aktive Zentren](http://www.stadtentwicklung.berlin.de/staedtebau/foerderprogramme/)  
Stadterneuerung (Sanierungsgebiete)  
Stadtumbau Ost und West  
Städtebaulicher Denkmalschutz  
[GRW-Fördergebiete](https://www.foerderdatenbank.de/FDB/DE/Home/home.html)

Was bedeutet Hauptstadtregion?
------------------------------

**Die Hauptstadtregion Berlin-Brandenburg umfasst das gesamte Gebiet der Länder Berlin und Brandenburg. Wir sprechen hier auch von der Metropolregion Berlin Brandenburg. Für die raumbezogene Analyse und Steuerung werden in Brandenburg das „Berliner Umland“ und der „Weitere Metropolenraum“ unterschieden.**

Das Berliner Umland umfasst den stark mit der Metropole Berlin verflochtenen Raum im Land Brandenburg. Zum Berliner Umland gehören die Landeshauptstadt Potsdam und weitere 50 Städte und Gemeinden.

Der Weitere Metropolenraum schließt an das Berliner Umland an. Er weist ausgehend von den drei Oberzentren Cottbus/Chóśebuz, Brandenburg an der Havel und Frankfurt (Oder) Verdichtungsansätze auf, ist aber in weiten Teilen ländlich geprägt.

Mehr dazu erfahren Sie auf der Website der [gemeinsamen Landesplanung Berlin und Brandenburg](https://gl.berlin-brandenburg.de/landesplanung/landesentwicklungsplan-hauptstadtregion-berlin-brandenburg-lep-hr/).

![](https://download.statistik-berlin-brandenburg.de/1e8d2adeec669bf0/61d6c680e345/v/d0680ce4b057/Schmuckbild-Metropolregion.jpg)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![iStock.com / Dmytro Varavin](https://download.statistik-berlin-brandenburg.de/dafdd0edce64b1a7/f48269a57bf6/v/bdbe069a4e98/bevoelkerung-demographie-aerial-interested-crowd-of-people-in-one-place-top-view-from-drone-picture-id1190039899.jpg "iStock.com / Dmytro Varavin")](/141-2024)**Einwohnerregisterstatistik Berlin, Stand: 30.06.2024**[#### Weniger Wachstum als im 1. Halbjahr 2023](/141-2024)

Pressemitteilung Nr. 141 Am 30. Juni 2024 waren im Einwohnerregister Berlin rund 3.886.000 Einwohnerinnen und Einwohner mit Hauptwohnsitz erfasst. Damit ist die Bundeshauptstadt im 1. Halbjahr 2024...

[Zu unseren News](/news)
