

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Einbürgerungen, Ausländer](/bevoelkerung/demografie/einbuergerungen-auslaender)
* [Einbürgerungen in Berlin und Brandenburg](/a-i-9-j)
* [A I 9 - j](/archiv/a-i-9-j)

Archiv: Statistischer Bericht
=============================

#### Einbürgerungen im Land Berlin und im Land Brandenburg (A I 9 - j)

![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben dieses Statistischen Berichts jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000495)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000493)


