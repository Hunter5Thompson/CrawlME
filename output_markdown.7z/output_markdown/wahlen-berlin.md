

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Berlin](/wahlen-berlin)

Wahlen in Berlin
================

Wir unterstützen den [Landeswahlleiter für Berlin](https://www.berlin.de/wahlen/) bei der Vorbereitung, Durchführung und Nachbereitung der Wahlen in der Hauptstadt. Hier finden Sie alle Statistiken zu Europawahlen, Bundestagswahlen, Abgeordnetenhaus- und Bezirksverordnetenversammlungswahlen sowie Volksentscheiden in Berlin.

Unser Datenangebot umfasst die endgültigen Ergebnisse der  Wahlen in interaktiver Form und als Download, Informationen zur Wahlgebietseinteilung, Strukturdaten sowie repräsentative Wahlstatistiken. Neben aktuellen Zahlen liefern wir Ihnen auch historische Wahlergebnisse.

[Repräsentative Demokratie
#### Europawahlen](/europawahlen-berlin)[Repräsentative Demokratie
#### Bundestagswahlen](/bundestagswahlen-berlin)[Repräsentative Demokratie
#### Berliner Wahlen](/abgeordnetenhauswahlen-bvv-berlin)[Direkte Demokratie
#### Volksentscheide](/volksentscheide-berlin)

Termine
-------

#### Bevorstehende Wahlen in Berlin

### Überblick

| **Datum** | **Wahlart** | **Turnus** |  |
| --- | --- | --- | --- |
| Herbst 2025 | Bundestag | 4 Jahre |  |
| Herbst 2026 | AbgeordnetenhausBezirksverordnetenversammlungen | 5 Jahre |  |
|  |  |

Brauchen Sie Hilfe?
-------------------

#### Unsere Ansprechpersonen für Wahlstatistiken

#### Anja May

Wahlstatistik

#### Anja May

Wahlstatistik

* [0331 8173-3117](tel:0331 8173-3117)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)
#### Corinna Brückner

Wahlstatistik

#### Corinna Brückner

Wahlstatistik

* [0331 8173-3172](tel:0331 8173-3172)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)
#### Theresa Roscher

Wahlstatistik

#### Theresa Roscher

Wahlstatistik

* [0331 8173-3708](tel:0331 8173-3708)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)

Zuletzt veröffentlicht
----------------------

#### Neues aus dem Bereich Wahlen

![iStock.com / JARAMA](https://download.statistik-berlin-brandenburg.de/86c94bf1d6b36171/d36db17b24d2/v/6552cdca14db/bevoelkerung-wahlen-and-german-flags-fly-in-the-wind-in-front-of-the-reichstag-in-berlin-picture-id1269519877.jpg)01.11.2024Seite[#### Ergebnisse, Downloads, Infos im Überblick: Europawahlen in Berlin](/europawahlen-berlin)

 Europawahlen in Berlin Gewählt wird in Deutschland nach dem Verhältniswahlsystem. Die Wahlberechtigten haben nur eine Stimme. Neben den wahlberechtigten Deutschen sind auch die in der...

[Ansehen](/europawahlen-berlin)![iStock.com / JARAMA](https://download.statistik-berlin-brandenburg.de/86c94bf1d6b36171/d36db17b24d2/v/6552cdca14db/bevoelkerung-wahlen-and-german-flags-fly-in-the-wind-in-front-of-the-reichstag-in-berlin-picture-id1269519877.jpg)07.06.2024Artikel[#### Europawahl in Berlin und Brandenburg: Fünf Dinge, die Sie nicht über die Wahl wissen](/news/2024/europawahl)

Während die meisten Bürgerinnen und Bürger ihre Stimme abgeben und auf die Ergebnisse warten, steckt hinter den Kulissen eine herausfordernde Planung und technische Arbeit.

[Ansehen](/news/2024/europawahl)![iStock.com / neirfy](https://download.statistik-berlin-brandenburg.de/96c774c2e8e5098e/a723014007eb/v/82297b8023ca/bevoelkerung-wahlen-reichstag-building-in-berlin-germany-picture-id1037521124.jpg)01.11.2024Seite[#### Wahlergebnisse, Downloads, Infos im Überblick: Bundestagswahlen in Berlin](/bundestagswahlen-berlin)

 Bundestagswahlen in Berlin Die Bundestagswahlen finden alle vier Jahre statt. Wählende haben zwei Stimmen. Mit der Erststimme wird in den Wahlkreisen mit relativer Mehrheit je ein Direktmandat...

[Ansehen](/bundestagswahlen-berlin)[Weitere Veröffentlichungen](/search-results?q=wahlen&searchBlogPost=true&pageNumber=1&searchStaticReport=true&searchPressRelease=true&sortBy=date-desc&region=berlin&searchByButton=true#results)
### Bleiben Sie auf dem Laufenden.Der Newsletter zu diesem Thema

[Jetzt abonnieren](/newsletter)


