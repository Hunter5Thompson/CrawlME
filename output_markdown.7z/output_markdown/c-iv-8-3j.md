

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Eigentums- und Pachtverhältnisse der landwirtschaftlichen Betriebe in Brandenburg](/c-iv-8-3j)

Eigentums- und Pachtverhältnisse der landwirtschaftlichen Betriebe in Brandenburg
---------------------------------------------------------------------------------

#### 2023, drei- bis vierjährlich

###### Neben der Größe der Pachtflächen und den Pachtentgelten informieren die Daten auch über die Größe der selbstbewirtschafteten landwirtschaftlich genutzten Flächen nach Rechtformen sowie die Pachtpreisänderungen der letzten zwei Jahre.

BrandenburgMethodik
### Brandenburg

**Pachtpreise steigen weiter**

Der durchschnittliche Pachtpreis für die landwirtschaftlich genutzte Fläche lag im Jahr 2023 bei 185 EUR pro Hektar und war damit um 14 EUR höher als zur Landwirtschaftszählung 2020, wie das Amt für Statistik Berlin-Brandenburg mitteilt. Somit stieg der Pachtpreis um gut 8 %.

Das Niveau der Pachtpreise fiel je nach Nutzungsart unterschiedlich aus. So waren im Durchschnitt für Ackerland 198 EUR pro Hektar (2020: 184 EUR pro Hektar) und für Dauergrünland 137 EUR pro Hektar (2020: 125 EUR pro Hektar) zu entrichten.

Nach den Ergebnissen der Agrarstrukturerhebung 2023 waren von den rund 1,3 Millionen Hektar landwirtschaftlich genutzter Fläche 841.800 Hektar bzw. 65 % gepachtete Flächen, 441.000 Hektar bzw. 34 % selbstbewirtschaftete Eigenflächen sowie 14.800 Hektar (1 %) Flächen, die den Betrieben unentgeltlich zur Verfügung gestellt wurden. Zur Landwirtschaftszählung 2010 lag der Pachtflächenanteil noch bei 74 %.

73 % der gepachteten Flächen 2023 zählten zum Ackerland und 24 % zum Dauergrünland.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d41f3405d1609be0/2f46d36c7299/SB_C04-08-00_2023j03_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/23c91511f55215e8/02672a4d37f8/SB_C04-08-00_2023j03_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Landwirtschaftszählung**Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/023848dc8f72ca47/3f8123557a5c/MD_41141_2020.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/c-iv-8-3j-12df667607d19bf7)
