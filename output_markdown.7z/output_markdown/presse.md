

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Presse](/presse)

Presse
======

PRESSE UND KOMMUNIKATION

[****presse****@statistik-bbb.de****](mailto:presse@statistik-bbb.de)

Jana Erdmann, Pressesprecherin  
Tel. 0331 8173-1002

Claudia Metzke  
Tel. 0331 8173-1004

Willkommen im Pressebereich. Hier finden Sie neben Kontaktdaten unsere Pressemitteilungen, Fotos und Grafiken sowie die Anmeldung für den Newsletter für Veröffentlichungen. Die Übersicht über unsere Publikationen und der Publikationskalender unterstützen Sie bei Ihrer Recherche.

[#### **Presse­material**](/pressematerial)[#### **Statistische****Publi­kationen**](/statistische-publikationen)[#### Publi­kations­kalender](/publikationskalender)![iStock.com / Rawf8](https://download.statistik-berlin-brandenburg.de/bb9c63d4a21d952a/78b18f7a17ff/v/85a71b6cd4c6/gesellschaft-staat-judge-gavel-and-a-laptop-wooden-background-online-auction-concept-picture-id1220820993.jpg)20.12.2024Pressemitteilung[#### Strafverfolgung 2023 in Berlin und Brandenburg: Abwärtstrend in Brandenburg setzt sich fort](/180-2024)

2023 nahm die Zahl der Verurteilungen in Berlin im Vergleich zum Vorjahr um 2,1 % zu, in Brandenburg ging sie um 11,1 % zurück.

[Ansehen](/180-2024)![iStock.com / Spotmatik](https://download.statistik-berlin-brandenburg.de/09fe07d2f99a71db/1fd2b255bc8f/v/d5efaa426575/gesellschaft-gesundheit-doctors-hospital-corridor-nurse-pushing-gurney-stretcher-bed-picture-id478740625.jpg)20.12.2024Pressemitteilung[#### Krankenhausdiagnosestatistik 2023 Berlin und Brandenburg: Zahl der vollstationären Behandlungen steigt langsam wieder an](/179-2024)

Rund 1,25 Millionen Menschen sind 2023 in den Krankenhäusern der Metropolregion behandelt worden.

[Ansehen](/179-2024)![iStock.com / GoogolPix](https://download.statistik-berlin-brandenburg.de/1a03bedef8ab3c23/0b10aefb97c2/v/6a408397d32d/gesellschaft-verkehr-ship-on-canal-in-bavaria-picture-id666692770.jpg)20.12.2024Pressemitteilung[#### Transport auf Brandenburgs Wasserstraßen von Januar bis September 2024: Mehr Güter befördert](/173-2024)

Auf den Binnenwasserstraßen Brandenburgs wurden in den ersten drei Quartalen 2024 insgesamt 1.524.600 Tonnen Güter befördert.

[Ansehen](/173-2024)![iStock.com / Animaflora](https://download.statistik-berlin-brandenburg.de/f08f86242a9d8c45/daccc7cb7e90/v/7b54dde10b33/gesellschaft-verkehr-barges-maindanube-canal-in-bamberg-picture-id1094480316.jpg)20.12.2024Pressemitteilung[#### Transport auf Berlins Wasserstraßen von Januar bis September 2024: Leichter Anstieg bei der Güterbeförderung](/172-2024)

Auf den Binnenwasserstraßen Berlins wurden in den ersten drei Quartalen 2024 insgesamt 909.451 Tonnen Güter befördert.

[Ansehen](/172-2024)![iStock-500003996.jpg](https://download.statistik-berlin-brandenburg.de/a3673719d2d0542c/000daad3a651/v/cca1b725c6c0/wirtschaft-wirtschaftsbereiche-schweine.jpg)19.12.2024Pressemitteilung[#### Schweinebestand in Brandenburg am 3. November 2024: Leichte Erholung des Bestandes](/176-2024)

Nach dem vorläufigen Ergebnis der Erhebung der Schweinebestände zum 3. November 2024 hielten die Brandenburger Betriebe 556.400 Schweine. 

[Ansehen](/176-2024)![©Mira - stock.adobe.com](https://download.statistik-berlin-brandenburg.de/69663412bc126f18/8f20586116ad/v/4d1251f0ed9e/wirtschaft-landwirtschaft-forstwirtschaft-adobestock-324821388.jpeg)19.12.2024Pressemitteilung[#### Rinderbestand in Brandenburg am 3. November 2024: Zahl der Rinder auf historischem Tiefststand](/177-2024)

Am 3. November 2024 gab es in Brandenburg 417.500 Rinder. Das waren 3,4 % weniger als im Mai dieses Jahres. 

[Ansehen](/177-2024)Mehr anzeigen
#### Vorabinformationen externer Stellen über statistische Ergebnisse

Gemäß dem [Verhaltenskodex für europäische Statistiken](https://ec.europa.eu/eurostat/documents/4031688/9394019/KS-02-18-142-DE-N.pdf/27ca19ca-e349-45f8-bbd4-4d78a33601ae?t=1542709797000) ist es unser Bestreben, die Ergebnisse der amtlichen Statistik eigenständig zu veröffentlichen und sie allen externen Nutzenden gleichzeitig und auf gleicher Basis zur Verfügung zu stellen. Anerkannte Ausnahmen hier von sind Vorabinformationen an Landesverwaltungen, die direkte Medienanfragen zu den statistischen Veröffentlichungen erwarten dürfen.

Aus diesem Grund stellen wir der Senatskanzlei und den Senatsverwaltungen Berlin sowie der Staatskanzlei und den Ministerien Brandenburg Pressemitteilungen mit einem Sperrfristvermerk bereits am Vortag der Veröffentlichung, frühestens um 10 Uhr, zur Verfügung. Die Begrenzung von Vorabinformationen ist ein wichtiger Aspekt der „Unparteilichkeit und Objektivität“. Unser Ziel ist es, durch Transparenz und eine restriktive Praxis politischer Einflussnahme vorzubeugen und die Glaubwürdigkeit unserer statistischen Ergebnisse zu gewährleisten.

### Immer die Fakten im Blick

#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Newsletter abonnieren](/newsletter)
