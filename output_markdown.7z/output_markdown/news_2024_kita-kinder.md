

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 18.04.2024

#### Kita-Betreuung in Berlin und Brandenburg

Was sagt die Statistik?
-----------------------

![iStock-998670532.jpg](https://download.statistik-berlin-brandenburg.de/f24e0aee40185cd7/2c76bd3948e0/v/d40004720570/soziales-kita-kinder.jpg "iStock-998670532.jpg")

**1840 gründete Friedrich Fröbel in Thüringen den ersten Kindergarten. Heute sprechen wir in Berlin und Brandenburg, wenn es um Kinderbetreuung geht, eher von Kitas, meinen aber das gleiche: eine öffentliche Einrichtung zur Betreuung und Förderung der frühkindlichen Entwicklung. Doch wie steht es um unsere Kita-Betreuung? Wie viele Kinder werden in der Hauptstadtregion wie lange betreut? Und von wem? Was hat sich getan, seit 2013 der Rechtsanspruch auf einen Kita-Platz für alle Kinder ab einem Jahr in Kraft trat?**

#### Ein Drittel mehr Kitas in der Hauptstadt seit 2013

In den vergangenen zehn Jahren verzeichnete Berlin einen kontinuierlichen Anstieg an Kindertagesstätten. Mit 2.832 Einrichtungen in 2023 zeigt sich eine Zunahme um 31,5 % Dabei stieg insbesondere die Zahl der Kitas freier Träger, die gemeinnützige Vereine und andere private Einrichtungen umfassen. Lediglich 10,6 % der Kitas gehören zu einem öffentlichen Träger und stehen somit unter der Verwaltung des Landes Berlin. Im Vergleich dazu verläuft die Entwicklung in Brandenburg etwas moderater. Hier fällt die Zunahme mit 12,0 % im gleichen Zeitraum geringer aus. Die Verteilung zwischen öffentlichen und freien Trägern ist nahezu ausgewogen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
###### Zu Tageseinrichtungen für Kinder zählen Kinderkrippen und Kindergärten. In Brandenburg fließt zusätzlich die Betreuung von Hortkindern in die Statistik ein. Gerade in Flächenländern werden in vielen Einrichtungen häufig Schulkinder und Nicht-Schulkinder zusammen betreut. In Berlin ist dagegen eine Trennung üblich.

###### In diesem Artikel beziehen sich die Kinderzahlen für Berlin und Brandenburg auf Nicht-Schulkinder. Die Zahlen für Einrichtungen und tätiges Personal in Brandenburg umfassen auch die Hortbetreuung. Daher ist ein Vergleich der beiden Länder schwierig.

###### Nicht berücksichtigt sind Zahlen zur öffentlich geförderten Tagespflege mit Tagesmüttern oder -vätern.

#### Überdurchschnittlich viele Kinder in Betreuung

2023 wurden in Berlin 171.686 Kinder in Kitas betreut. Das entspricht einem Anstieg von 27,4 % in zehn Jahren. In Brandenburg beträgt der Anstieg 19,5 %. Weniger als ein Drittel der Kinder entfällt auf die Altersgruppe 0 bis unter 3 Jahre. Seit 2013 haben Eltern einen gesetzlichen Anspruch auf einen Kitaplatz für ihre Kinder, wobei die Gebühren für Kitas in der Hauptstadt seit 2018 sogar vollständig für Kinder ab einem Jahr abgeschafft wurden. Seitdem ist die Zahl der betreuten Kinder in dieser Altersgruppe in Berlin um 25,9 % gestiegen. In Brandenburg waren es 18,8 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Pankow war 2023 der Berliner Bezirk mit den meisten Kita-Kindern (22.292), während Reinickendorf mit knapp 10.000 die niedrigste Zahl aufweist (in diesen Bezirken leben jedoch auch die meisten bzw. wenigsten Familien). Die Anzahl der genehmigten Plätze übersteigt die tatsächliche Kinderzahl in allen Bezirken. Die Zahlen sagen jedoch nichts über die tatsächliche Auslastung aus, da der Personalbedarf und die entsprechende Deckung nicht erfasst ist.

Die Betreuungsquoten variieren zwischen den Bezirken. Sie geben an, welcher Anteil der Kinder einer bestimmten Altersgruppe eine Betreuungseinrichtung besucht. In Pankow besuchen je 100 Kinder im Alter von 0 bis unter 3 Jahren im Schnitt 56,3 Kinder eine Kita, während es in Reinickendorf nur 32,5 sind. Grundsätzlich werden mehr Kinder im Alter von 3 bis unter 6 Jahren betreut.

In Brandenburg werden in Potsdam und Potsdam-Mittelmark die meisten Kita-Kinder betreut. Im Schnitt sind die Betreuungsquoten hier etwas höher als in den Berliner Bezirken, mit einem besonders hohen Wert in Frankfurt (Oder), wo über 99 % der 3- bis unter 6-Jährigen eine Kita besuchen.

BerlinBrandenburg
###### am 31. März 2023 in den Berliner Bezirken

#### Kinder in Kitas

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Durchschnittlich verzeichnet Berlin Betreuungsquoten von 47,6 % bei Kindern bis unter 3 Jahren und 92,1 % bei Kindern von 3 bis unter 6 Jahren. In Brandenburg sind es 57,6 % bzw. 94,2 %. Beide Länder liegen damit deutlich über dem bundesweiten Durchschnitt von 36,4 % bzw. 90,9 %. Deutschlandweit ist die Betreuungsquote bei den unter 3-Jährigen in den letzten zehn Jahren um 24,3 % gestiegen (2013: 29,3 %), während sie bei der Gruppe der 3- bis unter 6-Jährigen um 2,9 % gesunken ist (2013: 93,6 %). Der höhere Wert bei der ersten Gruppe lässt sich ggf. mit dem Wegfall der Kitagebühren in den verschiedenen Bundesländern erklären.

#### Auf eine pädagogische Fachkraft kommen in Berlin fünf und in Brandenburg acht Kinder

Immer wieder wird ein zunehmender Personalmangel von Kita-Leitungen und Eltern beklagt. Der Personal-Kind-Schlüssel könnte diesen Umstand begünstigen. Besonders die unter 3-Jährigen, die seit 2013 einen Kitaplatz-Anspruch haben, benötigen eine weitaus intensivere und engere Betreuung als ältere Kinder. Das spiegelt sich auch in Berlin und Brandenburg wider, und das auf einem wesentlich höheren Niveau als im deutschlandweiten Schnitt. 2023 betreute sowohl in Berlin als auch in Brandenburg eine pädagogische Fachkraft durchschnittlich 5,1 Kinder unter 3 Jahren. Bei den ab 3-Jährigen waren es 7,3 bzw. 9,1 Kinder. Der Berliner Wert liegt hier sogar unter dem Bundesschnitt von 7,7 Kindern.

Die Gruppe der Kinder mit mindestens einem Elternteil ausländischer Herkunft und der Kinder, in deren Elternhaus vorrangig nicht Deutsch gesprochen wird, nimmt zu. Diese Entwicklung bringt eine zusätzliche Herausforderung für das pädagogische Personal mit sich. Auf fehlende Deutschkenntnisse einzugehen sowie verschiedene Kulturkreise und Wertevorstellungen zu berücksichtigen, bedeutet eine intensivere Arbeit mit den Kindern und auch den Eltern.

Der Anteil der Kinder mit ausländischen Wurzeln ist zwischen 2014 und 2023 in beiden Ländern gestiegen. Das ohnehin schon höhere Niveau in Berlin stieg um 6,3 % auf 38,2 %. In Brandenburg ist der Prozentsatz erwartungsgemäß niedriger, verdoppelte sich aber von 6,0 % auf 13,3 %.

Bei 36,5 % der in betreuten Kita-Kinder in Berlin und 9,5 % in Brandenburg wurde 2023 zu Hause überwiegend nicht Deutsch gesprochen. Auch hier entwickeln sich die Zahlen mit einer Verdreifachung in Brandenburg rasanter als in Berlin, aber auf vergleichsweise niedrigem Niveau.

**Quelle:** Statistisches Bundesamt**Quelle:** Statistisches Bundesamt

Fast 35.000 pädagogische Fachkräfte arbeiteten 2023 in Berliner Kitas, 82,5 % der insgesamt dort tätigen Personen. Gegenüber 2013 nahm ihre Zahl um gut die Hälfte zu (+52,5 %). Auch ihr Anteil am gesamten betreuenden Personal stieg geringfügig um +1,7 %.

In Brandenburg war die Gruppe des pädagogisch tätigen Personals 2013 ähnlich stark vertreten und legte zwischen 2013 und 2023 geringfügig um 1,9 % auf einen Anteil von 82,2 % zu. Insgesamt kümmerten sich hier im letzten Jahr 23.712 pädagogische Fachkräfte um das Wohl der Kita-Kinder – ein Zuwachs um 45,7 % binnen zehn Jahren. Zum Vergleich: Die Zahl der betreuten Kinder stieg in dem Zeitraum in Berlin um 27,4 % und in Brandenburg um 19,5 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Gleichzeitig entscheiden sich in Berlin immer mehr Erzieherinnen und Erzieher dafür, ihre Arbeitszeit zu reduzieren. 2023 arbeiteten 43,5 % von ihnen weniger als 32 Stunden. 2014 waren es 37,8 %. In Brandenburg hingegen arbeiten aktuell rund 39,4 % der Kita-Pädagoginnen und -Pädagogen in Teilzeit. Das sind 2,2 % weniger als noch vor zehn Jahren. Der Anteil der Nichtschulkinder, die mehr als 35 Stunden betreut werden müssen, stieg hingegen um 1,9 %  auf 66,7 % an und ist damit größer als in Berlin.

#### Kinderbetreuung nicht länger nur Frauensache

Eine erfreuliche Entwicklung weist die Geschlechterverteilung im pädagogischen Fachpersonal in Kitas auf. In Berlin stieg der Anteil der Männer von 8,4 % im Jahr 2013 auf 13,2 % im Jahr 2023. Ähnlich positiv entwickelt sich die Situation in Brandenburg. Hier stieg der Anteil von 5,2 % im Jahr 2013 auf 10,7 % im Jahr 2023. Diese Zunahme deutet darauf hin, dass der Beruf der Kinderbetreuung für männliche Fachkräfte attraktiver wird und eine breitere Anerkennung erfährt.

1 Ohne hauswirtschaftlichen und technischen Bereich.**Quelle:** Amt für Statistik Berlin-Brandenburg

Das zeigen auch die Zahlen nach Altersgruppen: Der Männeranteil der tätigen Personen steigt mit sinkendem Alter. In beiden Ländern finden sich 2023 mit 23,4 % in Berlin und sogar 27,0 % in Brandenburg die meisten Männer bei den unter 20-Jährigen. Eine nicht unwesentliche Entwicklung, denn ein ausgewogenes Geschlechterverhältnis in der Kinderbetreuung kann die Vielfalt und Qualität der Betreuungsangebote erhöhen.

Beim Blick auf die Altersgruppen insgesamt zeigt sich, dass die Zahl der jungen Erwerbstätigen in den Berliner Kitas die Zahl der älteren, die den Arbeitsmarkt in den kommenden zehn Jahren verlassen, übersteigt. 22,7 % sind unter 30 Jahre und 18,5 % über 55 Jahre. In Brandenburg hat das Verhältnis etwas weniger positive Zukunftsaussichten. Hier umfassen die unter 25-Jährigen 17,9 %, dem gegenüber stehen 20,5 % über 55-Jährige.

1 Ohne hauswirtschaftlichen und technischen Bereich.**Quelle:** Amt für Statistik Berlin-Brandenburg[Mehr Zahlen zu Kindern und tätigen Personen in Kitas](/k-v-7-j)
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
#### Annett Kusche

Kinder- und Jugendhilfe

#### Annett Kusche

Kinder- und Jugendhilfe

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Kinder](/search-results?q=tag%3AKinder)[* Kitapersonal](/search-results?q=tag%3AKitapersonal)[* Kinderbetreuung](/search-results?q=tag%3AKinderbetreuung)[* Träger](/search-results?q=tag%3ATräger)[* Kita](/search-results?q=tag%3AKita)[* Kindertagesstätte](/search-results?q=tag%3AKindertagesstätte)
