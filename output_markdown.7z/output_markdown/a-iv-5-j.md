

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Krankenhaus und Rehabilitation](/krankenhaus-und-rehabilitation)
* [Vorsorge- oder Rehabilitationseinrichtungen in Brandenburg](/a-iv-5-j)

Vorsorge- oder Rehabilitationseinrichtungen in Brandenburg
----------------------------------------------------------

#### 2022, jährlich

###### In dieser Statistik werden die Ergebnisse aus der Erhebung zu den Grunddaten der Vorsorge- oder Rehabilitationseinrichtungen (Teil I) sowie aus der Erhebung zu der „Diagnosestatistik der Vorsorge- oder Rehabilitationseinrichtungen“ (Teil II) für Brandenburg veröffentlicht.

BrandenburgMethodik
### Brandenburg

**Bettenauslastung gestiegen**

Im Jahr 2022 wurden in den 24 brandenburgischen Vorsorge- oder Rehabilitationseinrichtungen insgesamt 62.634 Patientinnen und Patienten vollstationär behandelt. Dies entspricht im Vergleich zum Vorjahr einer Zunahme um 7,8 %.

Die Bettenauslastung beträgt im Jahr 2022 durchschnittlich 85,4 % gegenüber einem Vorjahreswert von 83,2 %.

Insgesamt standen im Jahr 2022 in den Vorsorge- oder Rehabilitationseinrichtungen in Brandenburg 5.210 aufgestellte Betten zur Verfügung, 49 mehr als in 2021.

1 beinhaltet: Innere Medizin, Gastroenterologie, Hämatologie und internistische Onkologie, Geriatrie, Kardiologie, Rheumatologie**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/745c018e8ef8e46e/61ac82459e0b/SB_A04-05-00_2022j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/7eb55fa0cde68ff0/a876479fbe37/SB_A04-05-00_2022j01_BB.pdf)
### Kontakt

#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Für den Teil 1 der Erhebung sind alle Vorsorge- oder Rehabilitationseinrichtungen des Landes Brandenburg auskunftspflichtig, für den Teil 2 sind es alle Vorsorge- oder Rehabilitationseinrichtungen des Landes Brandenburg mit mehr als 100 Betten. Es handelt sich um eine Bundesstatistik, die jährlich dezentral in den Ländern durchgeführt wird.

Erhoben werden Angaben zur sachlichen und personellen Ausstattung der Einrichtungen, Patientenbewegungen sowie die Hauptdiagnosen der Vorsorge- oder Rehabilitationspatientinnen und -patienten nach soziodemographischen Merkmalen.

Die Ergebnisse bilden die statistische Basis für viele gesundheitspolitische Entscheidungen des Bundes und der Länder.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Diagnosen der Vorsorge- oder Rehabilitations-einrichtungspatienten**  
**(ab 2022)**](https://download.statistik-berlin-brandenburg.de/1df0652b953ce3bc/385f17338230/MD_23132_2022.pdf) | [Archiv](/search-results?q=23132&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[**Grunddaten der Vorsorge- oder Reha-bilitationseinrichtungen**  
**(ab 2022)**](https://download.statistik-berlin-brandenburg.de/2dec034afda5f68a/95a66668eee4/MD_23112_2022.pdf) | [Archiv](/search-results?q=23132&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-5-j)


