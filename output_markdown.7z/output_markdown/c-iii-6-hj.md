

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Schlachtungen und Fleischerzeugung in Brandenburg](/c-iii-6-hj)

Schlachtungen und Fleischerzeugungin Brandenburg
------------------------------------------------

#### 01.01. bis 30.06.2024, halbjährlich

###### Die Ergebnisse der Schlachtungs- und Schlachtgewichtsstatistik informieren über Anzahl und Art der Schlachtungen sowie die produzierte Schlachtmenge. Sie bilden eine zentrale Grundlage für die Beurteilung der Marktlage im Bereich der Fleischproduktion.

BrandenburgMethodik
### Brandenburg

**Mehr Rinder- und weniger Schweineschlachtungen**

Im ersten Halbjahr 2024 wurden in Brandenburg knapp 17.000 Rinder gewerblich geschlachtet. Das waren fast   
4.000 Tiere oder 29,6 % mehr als im Vorjahreszeitraum. Die Zahl der gewerblichen Schweineschlachtungen war dagegen rückläufig. So wurden in den ersten sechs Monaten des Jahres mit gut 545.000 Tieren 90.000 Schweine weniger geschlachtet als im ersten Halbjahr 2023. Der Rückgang betrug hier 14,2 %.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht –**01.01. bis 30.06.2024

[Download XLSX](https://download.statistik-berlin-brandenburg.de/fd2ee7bc8636cbde/931740ecc108/SB_C03-06-00_2024hj1_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b7318cdd940d1086/0979245aa696/SB_C03-06-00_2024hj1_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung wird als dezentrale Bundesstatistik durchgeführt. Die Daten der Schlachtungsstatistik werden sekundärstatistisch auf Basis der Zusammenstellungen der amtlichen Veterinäre erhoben. Grundlage der Erfassung bilden dabei die Aufzeichnungen (Tagebücher), die von den amtlichen Veterinären geführt werden.

Dabei werden die monatlichen Schlachtungen von Rindern, Schweinen, Schafen, Ziegen und Pferden nachgewiesen, an denen eine Schlachttier- und Fleischuntersuchung durchgeführt wurde. Die für den menschlichen Verzehr als untauglich beurteilten Tiere werden hierbei nicht berücksichtigt.

Es wird nach gewerblichen Schlachtungen und Hausschlachtungen unterschieden. Die gewerblichen Schlachtungen werden zusätzlich getrennt nach inländischer und ausländischer Herkunft der Tiere erfasst.

In der Erhebung zur monatlichen Schlachtgewichtsstatistik werden die Zahl der geschlachteten und verwogenen Rinder und Schweine in den meldenden Schlachtbetrieben und das Gesamtschlachtgewicht der Tiere erhoben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Schlachtungs- und Schlachtgewichtsstatistik**  
Metadaten 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/a5681347742cbe85/80a622d55f40/MD_41331_2021.pdf)[Archiv](/search-results?q=MD_41331&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-6-m)
