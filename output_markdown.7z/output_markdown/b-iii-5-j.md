

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Hochschulen](/hochschulen)
* [Akademische und staatliche Abschlussprüfungen in Berlin und Brandenburg – Teil 1: Übersicht](/b-iii-5-j)

Akademische und staatlicheAbschlussprüfungen – Übersicht
--------------------------------------------------------

#### Prüfungsjahr 2023, jährlich

###### Die Erhebung über die Prüfungen an Hochschulen ist Teil der bundeseinheitlichen Hochschulstatistik und bildet das aktuelle Prüfungsgeschehen ab.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/319062f2a1a9cf2a/7ce16779949d/SB_B03-05-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b727a64eb03a454d/c9330131bf1b/SB_B03-05-00_2023j01_BE.pdf)

**Weniger****bestandene Prüfungen**

Im Prüfungsjahr 2023 wurden in Berlin 34.361 Abschlussprüfungen bestanden, das sind 994 Prüfungen bzw. 2,8 % weniger als im Vorjahr. Dieser Rückgang resultiert u.a. aus der Sitzverlegung der Steinbeis Hochschule von Berlin nach Magdeburg.

Mehr als die Hälfte der erfolgreich abgeschlossenen Prüfungen wurde von Frauen bestanden.

### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Eike Müller

Hochschulen

#### Eike Müller

Hochschulen

* [0331 8173-1144](tel:0331 8173-1144)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Anstieg der bestandenen Prüfungen in Brandenburg**

Im Prüfungsjahr 2023 wurden in Brandenburg 8.366 Abschlussprüfungen bestanden, das sind 73 Prüfungen mehr bzw. ein Anstieg von 0,87 % zum Vorjahr. Dabei wurden die meisten bestandenen Prüfungen (gut 63 %) an den Universitäten abgelegt.  
Mehr als die Hälfte der erfolgreich abgeschlossenen Prüfungen wurde von Frauen bestanden.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f46b8058d2186e36/03ab31eef561/SB_B03-05-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/3a293eda470040ca/9e57c81891e3/SB_B03-05-00_2023j01_BB.pdf)
### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Eike Müller

Hochschulen

#### Eike Müller

Hochschulen

* [0331 8173-1144](tel:0331 8173-1144)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den durchgeführten Abschlussprüfungen (jeweils am Ende des Winter- bzw. Sommersemesters) erhoben.

Auskunftspflichtig sind die Hochschulverwaltungen und die externen Prüfungsämter. In die Erhebung einbezogen sind alle staatlichen und staatlich anerkannten Hochschulen. Die Statistiken werden auf der Basis der Verwaltungs­unterlagen der Auskunftspflichtigen als Totalerhebungen durchgeführt. Die Ergebnisse der Hochschulstatistiken bilden die Datenbasis für Entscheidungen im Bund, in den Ländern und in den Hochschulen selbst. Aber auch die verschiedensten öffentlichen und privaten Einrichtungen sind an den Ergebnissen stark interessiert, unter anderem die Hochschul­rektorenkonferenz, die Ständige Konferenz der Kultusminister und der Wissenschaftsrat.

Auch wenn es sich bei den Hochschulstatistiken um Bundesstatistiken handelt, so werden die Ergebnisse doch zunehmend durch Länderspezifika und Besonderheiten der Hoch­schulen beeinflusst. Zuordnungen können in den einzelnen Bundesländern voneinander abweichen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Prüfungen**  
ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/14c736bd712f1a09/90f0223489a6/MD_21321_2019.pdf)[Archiv](/search-results?q=21321&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-iii-5-j)
