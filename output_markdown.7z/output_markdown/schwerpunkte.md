

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Schwerpunkte](/schwerpunkte)
#### Übergreifende Themen

Schwerpunkte
============

**In diesem Bereich finden Sie Zahlen und Fakten zu sachgebietsübergreifenden Themen.**  


### <#ukraine>

### <#corona>

### [#großberlin](#grossberlin)

### <#30jahrebrandenburg>

![](https://download.statistik-berlin-brandenburg.de/6a255b0cd4c6f042/6748eabbd59d/v/811eb602b4a4/fahne-ukraine.jpg)

Kapitel

Grafiken

#### Online-SchwerpunktUkraine

**Der Krieg in der Ukraine trifft nicht nur das Land selbst und seine Menschen unglaublich hart, der Konflikt wirkt sich auf die wirtschaftliche und soziale Lage in Deutschland, Europa und der Welt aus. Inwieweit die Menschen in der Hauptstadtregion die Folgen des Konflikts spüren, zeigen wir Ihnen auf dieser Themenseite.**

Anhand amtlicher Zahlen beleuchten wir die Auswirkungen und Folgen in der Bevölkerung, in Bildungseinrichtungen, im Supermarkt und an der Tanktelle sowie in verschiedenen Wirtschaftsbereichen.

[Zum Online-Schwerpunkt Ukraine](/schwerpunkte/ukraine)
#### Online-Schwerpunkt

Corona in derHauptstadtregion
-----------------------------

**Die Corona-Pandemie bestimmt das tägliche Leben in Berlin und Brandenburg. Welche Auswirkungen hat die Krise auf Gesellschaft, Wirtschaft und Gesundheit? Auf unserer laufend aktualisierten Sonderseite publizieren wir für ausgewählte Indikatoren Daten und Fakten. Hier finden Sie auch aktuelle Pressemitteilungen zum Thema.**

Für eine Einschätzung der wirtschaftlichen und sozialen Lage nach der Ausbreitung des SARS-CoV-2-Virus und der dadurch verursachten Erkrankung COVID-19 ab Frühjahr 2020 sind verlässliche Zahlen unabdingbar. Das Amt für Statistik Berlin-Brandenburg stellte 2020 ein Dossier mit statistischen Daten für die drei Themenbereiche Gesundheit, Gesellschaft und Wirtschaft zusammen, die sich an konkreten Fragestellungen zur Corona-Situation orientieren.

[Zum Online-Schwerpunkt Corona](/corona)![](https://download.statistik-berlin-brandenburg.de/d9b5e98d30001b0a/bcd26cf899a8/corona-live.gif)

Seiten

Grafiken

Tabellen

![](https://download.statistik-berlin-brandenburg.de/c682fadeadb4f7fc/8e14db5ca4ce/v/9e14f58b8864/corona-schwerpunkt-grossberlin.png)

Seiten

Grafiken

#### Schwerpunkt100 Jahre Groß-Berlin

**Berlin wurde am 1. Oktober 1920 praktisch über Nacht zur drittgrößten Stadt der Welt nach London und New York. Dieses bedeutsame Ereignis feiern wir mit dem Sonderheft „100 Jahre Groß-Berlin“.**

Die Berlinerinnen und Berliner haben in den letzten 100 Jahren seit der Gründung Groß-Berlins am 1. Oktober 1920 viele Spuren in der Entwicklung der Stadt hinterlassen. Das Amt für Statistik Berlin-Brandenburg legt in dieser Publikation eine Auswertung einer Vielzahl von Statistiken vor, um die Entwicklungen und Ereignisse durch die Linse der Zahlen zu beleuchten.

[Download der Publikation "100 Jahre Groß-Berlin"](https://download.statistik-berlin-brandenburg.de/59ebfdca96ce2a04/2536b39f616c/AfS_100jahregrossberlin.pdf)
#### Deutsche Einheit

30 Jahre Brandenburg
--------------------

**Das Land Brandenburg wurde im Oktober 2020 30 Jahre alt.  Eine Doppelausgabe der Zeitschrift für amtliche Statistik Berlin Brandenburg widmet sich der Entwicklung des Landes aus statistischer Sicht.**

Ausgewählte Kennzahlen, beispielsweise zu Geburten und Sterbefällen, Zu- und Abwanderung, Kindertagesbetreuung, Erwerbstätigkeit, landwirtschaftlichen Betrieben, Straßenverkehrsunfällen oder Verbraucherpreisen, geben einen Überblick über wesentliche Lebensbereiche und deren Wandel in den vergangenen 30 Jahren, der sowohl positive Entwicklungen als auch Problemlagen erkennen hilft.

[Download PDF](https://download.statistik-berlin-brandenburg.de/20c23e7a88172608/ecda1832db50/Zeitschrift-AfS-30JahreBB.pdf)

Seiten

Grafiken

![](https://download.statistik-berlin-brandenburg.de/9cc5e8368b5fe5fc/02f921a14bb7/v/87d854f4d64f/30jbrandenburg-schwerpunkt-bildteaser.png)

Zur Ausstellung „Wir sind Brandenburg. 1990–2020–2050“ in der Brandenburgischen Landeszentrale für politische Bildung gab unser ehemaliger Referatsleiter Robert Budras ein Interview:

### Sie haben einen Themenvorschlag?Schreiben Sie uns!

[Zum Formular](/kontakt#kontaktformular)
