

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Dienstleistungen](/dienstleistungen)
* [Dienstleistungen in Berlin und Brandenburg (monatlich)](/j-i-3-m)

Dienstleistungen
----------------

#### September 2024, monatlich

###### Die Konjunkturerhebungen im Dienstleistungsbereich liefern kurzfristige Informationen zur Beurteilung der konjunkturellen Entwicklung dieses Wirtschaftsbereiches. Dazu zählen Daten zu Umsatz und tätigen Personen aufgegliedert nach einzelnen Branchen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4fc73e519b8758b3/12a6e307dcf6/SB_J01-03-00_2024m09_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/ea93cc238dbeff76/458265ccf6d8/SB_J01-03-00_2024m09_BE.pdf)

**Dienstleistungssektor verzeichnet Umsatzplus, aber Rückgang bei der Beschäftigung**

Im September 2024 verzeichneten die Berliner Dienstleistungsunternehmen ein reales (preisbereinigtes) Umsatzwachstum von 6,0 % im Vergleich zum Vorjahresmonat.

Besonders stark wuchsen die Umsätze im Bereich Information und Kommunikation mit einem Anstieg von 19,0 %, gefolgt von den sonstigen wirtschaftlichen Dienstleistungen, die um 17,8 % zulegten. Auch das Grundstücks- und Wohnungswesen verzeichnete ein Plus von 8,8 %. Demgegenüber meldeten die Bereiche Verkehr und Lagerei einen Umsatzrückgang von 5,2 % und die freiberuflichen, wissenschaftlichen und technischen Dienstleistungen einen Rückgang von 5,6 %.

Die Beschäftigtenzahl im Berliner Dienstleistungssektor sank im September 2024 im Vergleich zum Vorjahresmonat um 1,2 %.

### Kontakt

#### Robby Trinks

Dienstleistungen Konjunktur

#### Robby Trinks

Dienstleistungen Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Brandenburger Dienstleistungssektor verzeichnet Umsatzrückgang**

Im September 2024 meldeten die Brandenburger Dienstleistungsunternehmen einen realen (preisbereinigten) Umsatzrückgang von 7,8 % im Vergleich zum Vorjahresmonat.

Besonders stark von diesem allgemeinen Rückgang betroffen war der Bereich der sonstigen wirtschaftlichen Dienstleistungen, der einen Rückgang von 16,2 % hinnehmen musste. Auch das Grundstücks- und Wohnungswesen verzeichnete einen deutlichen Rückgang von 13,6 %. Der Bereich Verkehr und Lagerei meldete ein Minus von 7,6 %, während die freiberuflichen, wissenschaftlichen und technischen Dienstleistungen um 3,0 % geringere Umsätze meldeten. Der einzige Bereich, der einen Umsatzanstieg verzeichnen konnte, war Information und Kommunikation, mit einem Plus von 9,8 %.

Im September 2024 sank die Beschäftigtenzahl im Brandenburger Dienstleistungssektor um 2,4 % im Vergleich zum Vorjahresmonat.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/431d92638137a202/3fdc41029a83/SB_J01-03-00_2024m09_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/b1d718cbc35545d2/00e90f4e93e7/SB_J01-03-00_2024m09_BB.pdf)
### Kontakt

#### Robby Trinks

Dienstleistungen Konjunktur

#### Robby Trinks

Dienstleistungen Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Konjunkturerhebungen im Dienstleistungsbereich liefern kurzfristige Informationen zur Beurteilung der konjunkturellen Entwicklung dieses Wirtschaftsbereichs. Erhoben werden der Nettoumsatz (ohne Umsatzsteuer) sowie die Zahl der tätigen Personen.

Seit dem Berichtsjahr 2021 werden die Daten aufgrund von Gesetzesänderungen monatlich erhoben. Ab dem Berichtsjahr 2022 erfolgt die Veröffentlichung monatlich und löst die bisherige vierteljährliche Berichterstattung ab. Erstmals werden aufgrund der Preisbereinigung neben nominalen Ergebnissen auch reale Ergebnisse für den Umsatz im Dienstleistungsbereich ausgewiesen. Die Daten werden als Indizes und Veränderungsraten dargestellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Konjunkturstatistik im Dienstleistungsbereich**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/eb88df40b9d83bb7/90a3b8de3d5c/MD_47414_2024.pdf)[Archiv](/search-results?q=MD_47415&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/j-i-3-m)
