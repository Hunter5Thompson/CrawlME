

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 21.05.2024

#### Fakten zur Erdbeerernte

Werden heimische Früchte zum Luxusgut?
--------------------------------------

![iStock-957868276.jpg](https://download.statistik-berlin-brandenburg.de/a1dedf4ec49a4102/f94185803a92/v/d306d1a273db/wirtschaft-wirtschaftsbereich-erdbeerernte.jpg "iStock-957868276.jpg")

**Die Erdbeersaison steht vor der Tür und viele warten schon ungeduldig auf die ersten heimischen Früchte. Doch der Anbau von Erdbeeren in Brandenburg geht seit Jahren zurück. Klimakapriolen und steigende Produktionskosten machen den Bäuerinnen und Bauern zu schaffen.****Wie sich Anbau und Ernte von Erdbeeren in unserer Region seit 2012 entwickelt haben, haben wir für Sie zusammengefasst.**

#### Empfindliches Früchtchen – der Trend geht zum Dach

Erdbeeren wurden 2023 auf einer Fläche von insgesam 231,3 Hektar angebaut. Dabei nimmt der Anbau unter hohen begehbaren Schutzabdeckungen seit einigen Jahren kontinuierlich zu. Lag die Anbaufläche unter Glas 2012 bei lediglich 4,1 Hektar, erreichte sie 2021 ihren bisherigen Höhepunkt mit 57,9 Hektar. 2023 waren es noch 39,7 Hektar. Die Anbaufläche im Freiland verringerte sich in den letzten zehn Jahren um mehr als die Hälfte und lag 2023 bei 191,6 Hektar. Am größten war die Anbaufläche im ungeschützten Anbau 2017 mit insgesamt 537,2 Hektar.

Die veränderte Anbaupraxis ist eine Folge der sich häufenden Klimakapriolen. Neben Extremwetterereignissen wie Hagel oder Starkkregen machen der empfindlichen Frucht vor allem im Freiland extreme Hitze und Spätfröste zu schaffen.

###### Was sind hohe begehbare Schutzabdeckungen?

Dieser Fachausdruck mag kurios klingen, bezeichnet aber alle festen und beweglichen Systeme des geschützten Anbaus. Neben Gewächshäusern u. a. aus Glas gehören auch begehbare Folientunnel, Schutz- und Schattennetze mit einem sehr dichten Gewebe und einem Beschattungsgrad von mindestens 80 % sowie andere Schutzabdeckungen aus Glas, festem Kunststoff oder Folie dazu.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Die Erdbeerernte schrumpft, die Zahl der Betriebe auch

Die Erntemenge bei Erdbeeren lag 2023 nur noch bei 61,2 % des Wertes von 2012. Damals konnten noch 2.296,9 Tonnen Erdbeeren auf Brandenburgs Feldern gepflückt werden. Auch bei der Ernte setzt sich der Erfolg des geschützten Anbaus fort. Lag 2012 der Anteil der Erntemenge unter Glas an der gesamten Erdbeerernte nur bei 3,7 %, entfielen 2023 insgesamt 29,2 % auf diese Anbauform.

t
-

**Erdbeeren wurden 2023 in Brandenburg geerntet.**

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Dass der Anbau von Erdbeeren immer weniger rentabel ist, zeigt sich auch am Rückgang der Betriebe, die Erdbeeren anbauen. Ihre Zahl schrumpfte seit 2012 um gut ein Drittel bzw. 35 Betriebe. Den Erdbeer-Bäuerinnen und -Bauern machen neben den Ernteausfällen durch das unbeständige Wetter oder Mäusefraß auch die steigenden Kosten aufgrund des steigenden Mindestlohns für Saisonarbeitskräfte zu schaffen. Aufgrund der aufwändigen Ernte dieser anfälligen Frucht, werden viele Erntehelferinnen und -helfer gebraucht, was sich dann in den Kosten niederschlägt.

21 Brandenburger Betriebe ernteten 2023 im Freiland insgesamt 14,7 Tonnen Erdbeeren in ökologischer landwirtschaftlicher Produktion. Das ist gerade einmal 1 % der gesamten Erntemenge. 2012 pflückten 22 Öko-Betriebe noch 640 Tonnen Erdbeeren im Freiland. Das war mehr als ein Viertel der gesamten Erntemenge des Jahres.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Steigende Preise bei Erdbeeren und Co.

Der Preis für Erdbeeren, Himbeeren, Stachelbeeren und Ähnliches stieg in den letzten zehn Jahren in Berlin um 46,5 % und in Brandenburg um 43,5 %. Zum Vergleich: Der Verbraucherpreis für Nahrungsmittel insgesamt nahm im selben Zeitraum um 46,4 % (Berlin) und 50,9 % (Brandenburg) zu.

Neben  der allgemeinen Preissteigerung bei Nahrungsmitteln kommt es ganz besonders bei Erdbeeren zu starken Preisschwankungen am Markt. Vor allem während der Hochsaison, wenn viele Erdbeeren auf heimischen Feldern geerntet werden, drückt das große Angebot den Preis. Erdbeeren sind kein Lagerobst, der Verkauf kann deshalb wenig reguliert werden.

[Die endgültigen Ergebnisse zur Erdbeerernte 2024 in Form eines Statistischen Berichts erscheinen Anfang März 2025.](#)**Quelle:** Amt für Statistik Berlin-Brandenburg
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
#### Regina Kurz

Bodennutzung und Ernte

#### Regina Kurz

Bodennutzung und Ernte

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de )
#### Katrin Schoenecker

Preise

#### Katrin Schoenecker

Preise

* [0331 8173-3114](tel:0331 8173-3114)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Landwirtschaft](/search-results?q=tag%3ALandwirtschaft)[* Erdbeeren](/search-results?q=tag%3AErdbeeren)[* Erdbeersaison](/search-results?q=tag%3AErdbeersaison)[* Obstanbau](/search-results?q=tag%3AObstanbau)
