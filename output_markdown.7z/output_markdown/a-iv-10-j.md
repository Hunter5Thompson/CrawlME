

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Todesursachen](/todesursachen)
* [Sterbefälle nach Todesursachen in Berlin und Brandenburg](/a-iv-10-j)

Sterbefälle nach Todesursachen
------------------------------

#### 2023, jährlich

###### Die Statistik gibt jährlich Auskunft über die Häufigkeiten von Krankheiten und Ereignissen, die zum Tode führen. Die Sterbefälle werden nach Todesursachen, Geschlecht und Altersgruppen ausgewiesen. Die Ergebnisse informieren auch über Gestorbene aufgrund vorsätzlicher Selbstbeschädigung sowie die Säuglingssterblichkeit.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/702d5de897a7ea4c/ec59915194b4/SB_A04-10-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/45d50e8dc1f380ea/cf9babccb6e2/SB_A04-10-00_2023j01_BE.pdf)

**Krankheiten des Herz-Kreislauf-Systems als häufigste Todesursache**

Krankheiten des Herz-Kreislauf-Systems waren mit einem Anteil von 30,5 % erneut die häufigste Todesursache.

Insgesamt starben 11.720 Berlinerinnen und Berliner an einer Krankheit des Kreislaufsystems. Das durchschnittliche Sterbealter bei diesem Krankheitsbild betrug 82,1 Jahre. Es waren mehr Frauen als Männer betroffen.

Zweithäufigste Todesursache waren bösartige Neubildungen mit 9.215 Gestorbenen aus Berlin. Bei den Berlinerinnen und Berlinern waren mit einem Anteil von 22,2 % vor allem Bronchien und Lunge betroffen.

An Erkrankungen des Atmungssystems verstarben in Berlin 3.050 Menschen und damit 7,3 % mehr als im Vorjahr. Dieses Krankheitsbild war bei 7,9 % aller Gestorbenen die ausschlaggebende Todesursache.

### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Häufigste Todesursache sind Herz-Kreislauf-Erkrankungen**

Herz-Kreislauf-Erkrankungen stellen mit einem Anteil von 35,7 % erneut die häufigste Todesursache in Brandenburg dar.

Insgesamt verloren 13.063 Menschen ihr Leben infolge einer Erkrankung des Kreislaufsystems. Das durchschnittliche Alter der Verstorbenen liegt bei 82,8 Jahren. Dabei waren überwiegend Frauen betroffen.

An zweiter Stelle der Todesursachen standen bösartige Neubildungen, denen 8.435 Menschen in Brandenburg zum Opfer fielen. Diese machten 19,3 % aller Todesfälle aus.

Erkrankungen des Atmungssystems führten in Brandenburg bei 2.354 Menschen zum Tod, was einem Anstieg von 8,5 % im Vergleich zum Jahr 2022 entspricht. Insgesamt waren sie bei 6,4 % aller Verstorbenen die ausschlaggebende Ursache.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f25c2ba3f101fdf4/f7a80bd10184/SB_A04-10-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/dab7fe04f9204216/42d2a2129125/SB_A04-10-00_2023j01_BB.pdf)
### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Todesursachenstatistik bietet vielfältige Analysemöglichkeiten zur Beurteilung und Bewertung des Gesundheitszustandes der Bevölkerung. Ziel ist es, die häufigsten Todesursachen der Region übersichtlich darzustellen. Die Sterblichkeit insgesamt und die Säuglingssterblichkeit bilden Indikatoren für das Gesundheitswesen und sind für gesundheitspolitische Entscheidungen und für die Forschung notwendig.

Datengrundlage der amtlichen Todesursachenstatistik sind die Todesbescheinigungen, die im Rahmen der Leichenschau ausgestellt werden. In Berlin und Brandenburg wird seit dem 1. Januar 2017 zur Ermittlung der Todesursache ausschließlich das internationale elektronische Kodiersystem IRIS verwendet. Es wertet Todesbescheinigungen in standardisierter Weise nach den Regeln der ICD-10 (WHO) aus. Dies führt zu einer verbesserten Konsistenz und Vergleichbarkeit innerhalb der Statistik auf nationaler und internationaler Ebene.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Todesursachenstatistik**ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/f064a08028e39a0a/1f074b5f8c9a/MD_23211_2023.pdf)[Archiv](/search-results?q=23211&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-10-j)
