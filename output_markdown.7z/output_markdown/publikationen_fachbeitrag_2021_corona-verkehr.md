

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 21.03.2022

#### Auswirkungen der Corona-Pandemie in der Region

Fahrgäste im Liniennahverkehr und Unfallgeschehen
-------------------------------------------------

![iStock-523278879.jpg](https://download.statistik-berlin-brandenburg.de/d113c81c0491995a/593bb5d7cbb7/v/f04a9deb8086/gesellschaft-verkehr-innenstadtverkehr.jpg "iStock-523278879.jpg")

**Corona-Schutzmaßnahmen haben in erster Linie das Ziel, Kontakte zu beschränken. Als Folge wirkten sie sich auf die Mobilität der Bürgerinnen und Bürger und damit auch massiv auf den Straßenverkehr aus. Zudem kamen individuell getroffene Schutzmaßnahmen zum Tragen, die sich in einem veränderten Mobilitätsverhalten ausdrücken.**

**Viele Verkehrsteilnehmende wechselten vom öffentlichen Personennahverkehr (ÖPNV) zu anderen Verkehrsmitteln – wie den privaten Pkw oder das Fahrrad –, um Kontakte zu reduzieren und das Risiko einer Infektion zu verringern. Dadurch kam es in Berlin und Brandenburg seit dem 1. Quartal 2020 zu teils drastischen Rückgängen bei der Personenbeförderung mit Bussen und Bahnen. Oder die Menschen entschieden sich überwiegend im Homeoffice zu arbeiten und nahmen dadurch weniger am Straßenverkehr teil.**

**ⓘ Klicken Sie sich hier durch die Themengebiete des Artikels.**

* ###### Auswirkungen der Corona-Pandemie auf die Fahrgastzahlen im Liniennahverkehr
* ###### Auswirkungen der Corona-Pandemie auf das Unfallgeschehen im Straßenverkehr

#### Auswirkungen der Corona-Pandemie auf**die Fahrgastzahlen im Liniennahverkehr**

Die Entwicklung verlief in beiden Ländern unterschiedlich. Der Rückgang der Zahl der Fahrgäste im **Liniennahverkehr in Berlin** betrug im 1. Quartal 2020 gegenüber dem vergleichbaren Vorjahreszeitraum in 13,3 %. Nach den einzelnen Verkehrsmitteln betrachtet waren es –16,6 % bei der Berliner S-Bahn und jeweils –11,8 % bei Straßenbahnen (einschließlich U-Bahn) und Omnibussen. Diese Rückgänge verstärkten sich exorbitant im 2. Quartal 2020 mit 53,3 % insgesamt, 47,9 % bei Eisenbahnen und jeweils 55,7 % bei Straßenbahnen und Omnibussen. In Fahrgastzahlen ausgedrückt war das ein Rückgang um 214 Mill. Personen auf ein Quartals-Rekordtief der letzten zehn Jahre von nur noch 188 Mill. Fahrgästen. Grund für das geringe Aufkommen u. a. an Berufspendelnden, Schülerinnen und Schülern, Studierenden sowie touristischen Gästen und Veranstaltungsbesucherinnen und -besuchern waren die Beschränkungen zur Bekämpfung und Eindämmung des Corona-Virus.

Die Rückgänge im 3. und 4. Quartal 2020 waren nicht mehr so drastisch, aber immer noch erheblich. Mit 530 Mill. Fahrgästen im 2. Halbjahr 2020 wurden in Berlin nur knapp zwei Drittel (65,2 %) der Fahrgäste des gleichen Vorjahreszeitraums befördert. Im gesamten Jahr 2020 wurden mit 1 068 Mill. Personen rund ein Drittel weniger Fahrgäste gezählt als 2019 (–34,1 %).

Auch im 1. Quartal 2021 war die Fahrgastzahl wieder stark rückläufig. Gegenüber dem Vorjahresquartal betrug der Rückgang 44,8 % und gegenüber dem 1. Quartal 2019 sogar 52,1 %. Mit 223 Mill. Fahrgästen im 2. Quartal 2021 gab es zwar im Vergleich zum selben Quartal des Vorjahres einen Anstieg um 18,4 %, gegenüber dem 2. Quartal 2019 ist jedoch weiterhin ein starker Rückgang um 44,6 % zu verzeichnen. Vom Vor-Corona-Niveau bei den Fahrgastzahlen im öffentlichen Personennahverkehr ist Berlin noch weit entfernt.

**Quelle:** Amt für Statistik Berlin-Brandenburg

  
Zum Liniennahverkehr zählen alle Linienverkehre, in denen Fahrgäste mit Eisenbahnen (in Berlin: S-Bahn), Straßenbahnen (in Berlin: einschließlich U-Bahn) oder Omnibussen überwiegend im Stadt-, Vorort- oder Regionalverkehr befördert werden.

In **Brandenburg**fiel die Abnahme der Fahrgastzahlen 2020 gegenüber dem Vor-Corona-Jahr 2019 weniger deutlich aus als in Berlin. Im 1. Quartal 2020 betrug der Rückgang im Vorjahresvergleich insgesamt 2,9 %. Bei Straßenbahnen waren es 0,9 % und bei Omnibussen 3,9 %. Die Rückgänge verstärkten sich analog zu Berlin deutlich im 2. Quartal 2020 mit 21,2 % insgesamt, 16,2 % bei Straßenbahnen und 23,6 % bei Omnibussen. In absoluten Zahlen entspricht das einem Rückgang um 6,6 Mill. auf 24,4 Mill. Personen. Im 3. Quartal 2020 wurden 3,1 % mehr Fahrgäste gezählt als im Vorjahreszeitraum. Im gesamten 2. Halbjahr 2020 wurden 58,9 Mill. Fahrgäste befördert, das waren lediglich 1,7 % weniger als im 2. Halbjahr 2019.

Seit dem 1. Quartal 2021 steigen die Fahrgastzahlen: Nach 7,3 % im 1. Quartal erhöhte sich der Zuwachs im 2. Quartal 2021 deutlich auf 33,5 % gegenüber dem entsprechenden Vorjahreszeitraum. Maßgebend für diese positive Entwicklung war die steigende Fahrgastzahl bei der Personenbeförderung mit Omnibussen. Im 1. Halbjahr 2021 wurden hier über ein Viertel (+26,2 %) mehr Fahrgäste gezählt als im Vorjahreszeitraum, gegenüber dem 1. Halbjahr 2019 betrug der Zuwachs 9,0 %.

###### *Autoren:*

**Martin Axnick** leitet das Referat *Bauen, Wohnen, Verkehr* des Amtes für Statistik Berlin-Brandenburg.  
**Jürgen Keiser** ist Fachreferent im Referat *Bauen, Wohnen, Verkehr* des Amtes für Statistik Berlin-Brandenburg.

Die Fachbeiträge erschienen erstmals in der *Zeitschrift für amtliche Statistik Berlin Brandenburg*. Die komplette Ausgabe 3+4/2021 lesen Sie **[hier](https://download.statistik-berlin-brandenburg.de/0e2a6bd7d6fd44ce/b43aa17fd047/Zeitschrift-20210304.pdf)**.

### Kontakte

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Nicole Dombrowski

Fachredaktion

#### Nicole Dombrowski

Fachredaktion

* [zeitschrift@statistik-bbb.de](mailto:zeitschrift@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Aufsätze und Analysen](/search-results?q=tag%3AAufsätze und Analysen)[* Corona](/search-results?q=tag%3ACorona)[* Verkehrsunfälle](/search-results?q=tag%3AVerkehrsunfälle)[* Liniennahverkehr](/search-results?q=tag%3ALiniennahverkehr)[* Fahrgäste](/search-results?q=tag%3AFahrgäste)[* Unfallgeschehen](/search-results?q=tag%3AUnfallgeschehen)
