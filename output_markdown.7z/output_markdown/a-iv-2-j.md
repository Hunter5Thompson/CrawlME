

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Krankenhaus und Rehabilitation](/krankenhaus-und-rehabilitation)
* [Krankenhäuser in Berlin und Brandenburg Teil I – Grunddaten](/a-iv-2-j)

Krankenhäuser
-------------

Teil I – Grunddaten
-------------------

#### 2023, jährlich

###### In dieser Statistik werden Ergebnisse aus der Erhebung zu den Grunddaten der Krankenhäuser veröffentlicht. Sie liefert unter anderem Informationen über die sachliche und personelle Ausstattung sowie über die Bewegung der Patientinnen und Patienten.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/0fd0cb0f1e648c53/3244dd9433a6/SB_A04-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/88f0d5e5c3514cd5/31c94fa380a6/SB_A04-02-00_2023j01_BE.pdf)

**Zusammenfassung der Ergebnisse**

Im Jahr 2023 wurden in den 88 Berliner Krankenhäusern 772.778 Patientinnen und Patienten vollstationär versorgt.

In Berlin standen für die vollstationäre Behandlung 20.172 Betten bereit. Das waren 85 Betten weniger als 2022. Auch die Zahl der Intensivbetten nahm um 4,1 % auf 1.444 ab. Die durchschnittliche Bettenauslastung stieg um 2,4 Prozentpunkte auf 76,6 %. Die Verweildauer betrug wie im Vorjahr durchschnittlich 7,3 Tage.

### Kontakt

#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Zusammenfassung der Ergebnisse**

Im Jahr 2023 wurden in den 63 Brandenburger Einrichtungen 490.979 Patientinnen und Patienten vollstationär versorgt.

Die Brandenburger Krankenhäuser verfügten mit 14.970 Betten über 105 mehr als 2022, auch die Zahl der aufgestellten Intensivbetten stieg um 2,2 % auf 687 an. Die durchschnittliche Bettenauslastung nahm um 2,2 Prozentpunkte auf 70,2 % zu. Patientinnen und Patienten verweilten durchschnittlich 7,8 Tage in den Einrichtungen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7b71b5aa6e28960d/6e894a972646/SB_A04-02-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/02830a9212f2d1a6/14d3d4409df0/SB_A04-02-00_2023j01_BB.pdf)
### Kontakt

#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Bei der Krankenhausgrunddatenstatistik handelt es sich um eine jährliche Vollerhebung an Krankenhäusern einschließlich deren Ausbildungsstätten zum Erhebungsstichtag 31. Dezember. Auskunftspflichtig sind alle Krankenhäuser des Landes nach § 1 Abs. 3 Nr. 1 der Krankenhausstatistik-Verordnung (KHStatV). Ausgeschlossen sind Krankenhäuser im Straf- oder Maßregelvollzug und Polizeikrankenhäuser. Bundeswehrkrankenhäuser sind nur, soweit sie Leistungen für Zivilpatienten erbringen, einbezogen.

Die Grunddaten der Krankenhäuser fließen in die Gesundheitsberichterstattung auf regionaler, nationaler und internationaler Ebene ein.  Die Ergebnisse bilden die statistische Basis für viele gesundheitspolitische Entscheidungen des Bundes und der Länder und dienen den an der Krankenhausfinanzierung beteiligten Institutionen als Planungsgrundlage. Die Erhebung liefert wichtige Informationen über das Volumen und die Struktur des Leistungsangebots in der stationären Versorgung. Sie dient damit auch der Wissenschaft und Forschung und trägt zur Information der Bevölkerung bei.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Grunddaten der Krankenhäuser**  
2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/217c4a62c98da7f4/1508a5ec341c/MD_23111_2023.pdf)[Archiv](/search-results?q=23111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-2-j)


