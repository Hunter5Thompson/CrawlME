

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Verkehr](/gesellschaft/verkehr)
* [Straßenverkehr](/strassenverkehr)

Straßenverkehr
--------------

Ergebnisse zum Unfallgeschehen im Straßenverkehr sind Grundlage für Maßnahmen im Bereich der Gesetzgebung, der Verkehrserziehung, des Straßenbaus oder der Fahrzeugtechnik. Die Statistik hat das Ziel, Strukturen des Unfallgeschehens aufzuzeigen.

Die Erhebung wird als Vollerhebung mit Auskunftspflicht der Polizeidienststellen durchgeführt. In der Statistik sind nur die Unfälle enthalten, die polizeilich aufgenommen wurden. Unfälle, bei denen lediglich ein Sachschaden vorliegt, werden der Polizei nur zum Teil angezeigt.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Straßenverkehrsunfälle in Berlin und Brandenburg, monatlich (HI1-m)](/h-i-1-m)[Straßenverkehrsunfälle in Berlin und Brandenburg, jährlich (HI2-j)](/h-i-2-j)

Zeitreihen
----------

StraßenverkehrsunfälleVerunglückteGetöteteKfz-NeuzulassungenKfz-Bestand**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/48f08d1bebf6b3e9/0ff72eb7b1d8/strassenverkehr-lange-reihe-2023.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Berliner Bezirke

#### Straßenverkehrsunfälle 2022

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte

#### Straßenverkehrsunfälle 2022

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte - Stand: 01.01.2022

#### Kraftfahrzeugbestand

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Unfallatlas

![](https://download.statistik-berlin-brandenburg.de/37d10973bbf63cae/ea4ec5c3dfaf/v/4e2b18a45fa1/schmuckbild-verkehr-unfallatlas.png)

Mit dem Unfallatlas werden Unfälle mit Personenschaden nach Straßenabschnitten sowie nach den einzelnen Unfallstellen auf Straßenebene sichtbar.

[Zum Unfallatlas](https://unfallatlas.statistikportal.de/)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/transport-und-verkehr)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1714127572028&code=46241#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock – JTeivans](https://download.statistik-berlin-brandenburg.de/c9c96976ef6cf996/8300f9a7cdc6/v/f91b487ccb35/gesellschaft-verkehr-iStock-1292440193.jpg "iStock – JTeivans")](/h-i-1-m)**Oktober 2024, monatlich, H I 1 – m**[#### Straßenverkehrsunfälle in Berlin und Brandenburg](/h-i-1-m)

Die Statistik der Straßenverkehrsunfälle informiert monatlich über polizeilich aufgenommene Unfälle in der Region....

[![gesellschaft-verkehr-iStock-1441601254.jpg](https://download.statistik-berlin-brandenburg.de/3cc5381ad1800f11/6a382e3e9049/v/a408513df862/gesellschaft-verkehr-iStock-1441601254.jpg "gesellschaft-verkehr-iStock-1441601254.jpg")](/104-2024)**Kfz-Neuzulassungen 1. Halbjahr 2024 in Berlin**[#### Weniger Neuzulassungen von Pkw mit Elektro- und Hybridantrieb](/104-2024)

Pressemitteilung Nr. 104 In Berlin sank im 1. Halbjahr 2024 laut Kraftfahrt-Bundesamt die Zahl neu zugelassener Pkw mit alternativen Antrieben gegenüber dem 1. Halbjahr 2023 um 15,1 % auf 18.113....

[![E-Auto](https://download.statistik-berlin-brandenburg.de/104c454939aa0398/8bea30a02781/v/b8514c3a5952/iStock-1344815850.jpg "E-Auto")](/105-2024)**Kfz-Neuzulassungen 1. Halbjahr 2024 in Brandenburg**[#### Leichter Anstieg bei Neuzulassungen von Pkw mit alternativen Antrieben](/105-2024)

Pressemitteilung Nr. 105 Im Land Brandenburg stieg im 1. Halbjahr 2024 laut Kraftfahrt-Bundesamt die Zahl neu zugelassener Pkw mit alternativen Antrieben gegenüber dem 1. Halbjahr 2023 um 4,5 % auf...

[Zu unseren News](/news)

[* Unfälle](/search-results?q=tag%3AUnfälle)[* Polizei](/search-results?q=tag%3APolizei)[* Alkohol](/search-results?q=tag%3AAlkohol)[* Verunglückte](/search-results?q=tag%3AVerunglückte)[* Getötete](/search-results?q=tag%3AGetötete)[* Kfz](/search-results?q=tag%3AKfz)[* Personenschaden](/search-results?q=tag%3APersonenschaden)[* Straßenverkehrsunfall](/search-results?q=tag%3AStraßenverkehrsunfall)[* Sachschaden](/search-results?q=tag%3ASachschaden)
