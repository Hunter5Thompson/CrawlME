

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Asylbewerberleistungen](/asylbewerberleistungen)
* [Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen nach dem Asylbewerberleistungsgesetz](/k-vi-1-k-vi-2-j)
* [K VI 1 K VI 2 j](/archiv/k-vi-1-k-vi-2-j)

Archiv: Statistischer Berichte
==============================

##### Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen(K VI 1 K VI 2 j)

##### Leistungen an Asylbewerber Ausgaben und Einnahmen (K VI 1 – j)

##### Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen (K VI 2-j)

##### Leistungen an Asylbewerber im Land Berlin und im Land Brandenburg – Empfänger von besonderen Leistungen (K VI 3-j)

  


![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben der Statistischen Berichte jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

**Archiv : KVI-1-KVI 2-J - ab 2022 fortaufend**

[Ältere Berichte Berlin](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00001425)[Ältere Berichte Brandenburg](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00001424)

**Archiv : KVI-1-J**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000569)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000567)

**Archiv : KVI-2-J**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000428)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000424)

**Archiv : KVI-3-J**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000592)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000594)


