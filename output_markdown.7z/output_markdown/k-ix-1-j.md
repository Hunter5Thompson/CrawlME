

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Ausbildungsförderung](/ausbildungsfoerderung)
* [Ausbildungsförderung nach dem Bundesausbildungsförderungsgesetz (BAföG) in Berlin und Brandenburg](/k-ix-1-j)

Ausbildungsförderung nach dem Bundesausbildungsförderungsgesetz (BAföG)
-----------------------------------------------------------------------

#### 2023, jährlich

###### In der Statistik werden Angaben zum sozialen und finanziellen Hintergrund der Geförderten, ihrer Ehegatten und Eltern sowie des Förderbedarfs der Antragsteller und der errechneten Förderungsbeträge ausgewertet. Auch die tatsächlich in Anspruch genommene Förderung wird aus.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ddd7305f4d990d37/fba658adc1e5/SB_K09-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/4f322c780fbea77b/0c293d83eeae/SB_K09-01-00_2023j01_BE.pdf)

**Ausbildungsförderung in Berlin**

In Berlin wurden im Jahr 2023 insgesamt 45.201 Personen nach dem Bundesausbildungsförderungsgesetz (BAföG) gefördert. Das waren 1 % mehr als im Vorjahr. Es wurden 525 Schülerinnen und Schüler weniger und 966 Studierende mehr gefördert als im Jahr 2022.

Im Durchschnitt wurden in Berlin 32.247 Personen gefördert, davon 6.687 Schülerinnen und Schüler (mit durchschnittlich 490 EUR) und 25.560 Studierende (mit durchschnittlich 687 EUR).

Im Jahr 2023 kamen in der Hauptstadt rund 250 Millionen EUR zur Auszahlung, 14,9 % mehr als im Vorjahr. 58,9 % waren Zuschüsse und 41,1 % wurden als Darlehen ausgezahlt.

### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Ausbildungsförderung in Brandenburg**

In Brandenburg wurden im Jahr 2023 insgesamt 14.830 Personen nach dem Bundesausbildungsförderungsgesetz (BAföG) gefördert. Das waren 0,4 % mehr als im Vorjahr. Es wurden 113 Schülerinnen und Schüler weniger und 177 Studierende mehr gefördert als im Jahr 2022.

Im Durchschnitt wurden in Brandenburg 10.146 Personen gefördert, davon 2.942 Schülerinnen und Schüler (mit durchschnittlich 504 EUR) und 7.204 Studierende (mit durchschnittlich 703 EUR).

Im Jahr 2023 kamen in Brandenburg rund 78,6 Millionen EUR zur Auszahlung, 14 % mehr als im Vorjahr. 62,3 % waren Zuschüsse und 37,7 % wurden als Darlehen ausgezahlt.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8e26363cfd68607d/f577e9ca7c0c/SB_K09-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/b5d1dfea859dba7f/d294324245e2/SB_K09-01-00_2023j01_BB.pdf)
### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Zur Ausbildungsförderung werden derzeit jährlich zwei Bundesstatistiken als Sekundärstatistik durchgeführt:

* Statistik nach dem Bundesausbildungsförderungsgesetz (BAföG)
* Statistik nach dem Aufstiegsfortbildungsförderungsgesetz (AFBG)

Beide Gesetze werden im Auftrag des Bundes von den Ländern umgesetzt, die die dafür zuständigen Behörden bestimmt haben. Zuständige Behörden sind die kommunalen Ämter für Ausbildungsförderung. Für Studierende sind darüber hinaus bei den staatlichen Hochschulen oder bei den Studentenwerken Ämter für Ausbildungsförderung eingerichtet worden.

Die Ämter für Ausbildungsförderung nehmen die Anträge auf Ausbildungsförderung entgegen, entscheiden über den Antrag und erlassen den Bescheid hierüber. Mit der Berechnung der Förderbeträge sind die Landesrechenzentren beauftragt. Aus diesem Verfahren zur Zahlbarmachung werden die Angaben für die amtliche Statistik in anonymisierter Form zur Verfügung gestellt (Sekundärstatistik).

Für Schülerinnen und Schüler an Abendgymnasien und Kollegs und für Studierende wird das BAföG am Schul- bzw. Studienort, für die anderen Schülerinnen und Schüler am Wohnort der Eltern beantragt. Während Schülerinnen und Schüler die BAföG-Leistungen als Zuschuss erhalten, werden sie für Studierende in der Regel zur Hälfte als Zuschuss und zur Hälfte als unverzinsliches Darlehen ausgezahlt.

Seit dem Berichtsjahr 2011 wird außerdem die Statistik zum Stipendiumprogramm-Gesetz (Deutschlandstipendium) durchgeführt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Bundesausbildungsförderung (BAföG)**  
ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/692b397075bf8fb4/55d66f2740b2/MD_21411_2019.pdf)[Archiv](/search-results?q=21411&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-ix-1-j)


