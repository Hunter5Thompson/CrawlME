

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Gewerbeanzeigen](/gewerbeanzeigen)
* [Gewerbeanzeigen in Berlin und Brandenburg](/d-i-1-m)

Gewerbeanzeigen
---------------

#### Oktober 2024, monatlich

###### Die Gewerbeanzeigenstatistik liefert Informationen über Zahl und Art der in einer Region ansässigen Gewerbebetriebe. Gewerbean- und -abmeldungen werden u. a. nach Wirtschaftsbereich, Rechtsform, Zahl der tätigen Personen sowie Geschlecht und Staatsangehörigkeit der Gewerbetreibenden ausgewiesen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenbrug
#### Z**um aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ff02fbf7aa268365/0fa862068ee4/SB_D01-01-00_2024m10_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/e309b586e7da43a8/3994a16bb855/SB_D01-01-00_2024m10_BE.pdf)

**Zahl der Gewerbeanmeldungen leicht gestiegen**

3.563 Gewerbe wurden im Oktober 2024 in Berlin angemeldet. Das waren 106 Gewerbe bzw. 3,1 % mehr als im Vormonat. 22,9 % aller Gewerbeanmeldungen waren Betriebsgründungen mit größerer wirtschaftlicher Substanz wie Kapitalgesellschaften, Personengesellschaften und Betriebe mit Beschäftigten. Im gleichen Zeitraum stieg die Anzahl der Gewerbeabmeldungen um 19 (0,8 %) auf 2.523 Anzeigen. Hiervon waren 21,2 % Betriebsaufgaben.

Mit 582 An- und 262 Abmeldungen wurden im Bezirk Tempelhof-Schöneberg die meisten Aktivitäten registriert, gefolgt vom Bezirk Mitte mit 504 An- und 263 Abmeldungen.

### Kontakt

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

* [0331 8173-1341](tel:0331 8173-1341)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Jannette Frömling

Gewerbeanzeigen

#### Jannette Frömling

Gewerbeanzeigen

* [0331 8173-1348](tel:0331 8173-1348)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Mehr Gewerbean- und -abmeldungen**

Im Oktober 2024 wurden in Brandenburg 1.592 Gewerbeanmeldungen gezählt. Gegenüber dem Vormonat bedeutet das einen Anstieg um 143 Anmeldungen bzw. 9,9 %. Bei 18,3 % der Gewerbeanmeldungen handelte es sich um Betriebsgründungen mit größerer wirtschaftlicher Substanz wie Kapitalgesellschaften, Personengesellschaften und Betriebe mit Beschäftigten.

Im selben Zeitraum meldeten 1.328 Unternehmen ihre Betriebstätigkeit ab. Im Vergleich zum Vormonat waren das 68 Anzeigen bzw. 5,4 % mehr. Hier betrug der Anteil der Betriebsaufgaben 19,1 %.

Der Landkreis Teltow-Fläming verzeichnete mit 279 An- und 171 Abmeldungen die meisten Gewerbeanzeigen. Dahinter folgte der Landkreis Dahme-Spreewald. Dort wurden 159 Gewerbe an- und 142 Gewerbe abgemeldet.

**Quelle:** Amt für Statistik Berlin-Brandenbrug
#### Z**um aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/3899f50d1d10c984/a1809f841e31/SB_D01-01-00_2024m10_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/59cd3019e7d79e28/85b3e7e02102/SB_D01-01-00_2024m10_BB.pdf)
### Kontakt

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

* [0331 8173-1341](tel:0331 8173-1341)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Jannette Frömling

Gewerbeanzeigen

#### Jannette Frömling

Gewerbeanzeigen

* [0331 8173-1348](tel:0331 8173-1348)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Gewerbeanzeigenstatistik wird monatlich wie eine Sekundärstatistik auf der Basis der in der Verwaltung erstellten Gewerbemeldungen durchgeführt. Seit Januar 2017 werden die Daten von den Gewerbeämtern elektronisch übermittelt.

Der Eingangsdatenbestand beinhaltet neben den Gewerbean- und Gewerbeabmeldungen auch Gewerbeummeldungen, die jedoch seit Januar 2006 nicht mehr ausgewertet werden.

Bei der Interpretation der Zahlen ist zu beachten, dass Gewerbemeldungen Absichtserklärungen sind. Den Statistikern liegen keine Informationen darüber vor, ob das an- bzw. abgemeldete Gewerbe auch tatsächlich ausgeübt wird bzw. wurde.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Gewerbeanzeigenstatistik**  
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/9a2038f806f7d875/c5f1b87762d7/MD_52311_2023.pdf)[Archiv](/search-results?q=MD_52311&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/d-i-1-m)
