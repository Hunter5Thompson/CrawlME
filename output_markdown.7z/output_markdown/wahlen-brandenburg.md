

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Brandenburg](/wahlen-brandenburg)

Wahlen in Brandenburg
=====================

Wir unterstützen den [Landeswahlleiter für Brandenburg](https://wahlen.brandenburg.de/wahlen/de/) bei der Vorbereitung, Durchführung und Nachbereitung der Wahlen in Brandenburg. Hier finden Sie alle Statistiken zu Europawahlen, Bundestagswahlen, Landtagswahlen und Kommunalwahlen im Bundesland.

Unser Datenangebot umfasst die endgültigen Ergebnisse der  Wahlen in interaktiver Form und als Download, Strukturdaten sowie repräsentative Wahlstatistiken. Neben aktuellen Zahlen liefern wir Ihnen auch historische Wahlergebnisse.

[Repräsentative Demokratie
#### Europawahlen](/europawahlen-brandenburg)[Repräsentative Demokratie
#### Bundestagswahlen](/bundestagswahlen-brandenburg)[Repräsentative Demokratie
#### Landtagswahlen](/landtagswahlen-brandenburg)[Repräsentative Demokratie
#### Kommunalwahlen](/kommunalwahlen-brandenburg)

Termine
-------

#### Bevorstehende Wahlen in Brandenburg

### Überblick

| **Datum** | **Wahlart** | **Turnus** |  |
| --- | --- | --- | --- |
|  |
| Herbst 2025 | Bundestag | 4 Jahre |  |
|  |  |

Brauchen Sie Hilfe?
-------------------

#### Unsere Ansprechpersonen für Wahlstatistiken

#### Anja May

Wahlstatistik

#### Anja May

Wahlstatistik

* [0331 8173-3117](tel:0331 8173-3117)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)
#### Corinna Brückner

Wahlstatistik

#### Corinna Brückner

Wahlstatistik

* [0331 8173-3172](tel:0331 8173-3172)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)
#### Theresa Roscher

Wahlstatistik

#### Theresa Roscher

Wahlstatistik

* [0331 8173-3708](tel:0331 8173-3708)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)

Zuletzt veröffentlicht
----------------------

#### Neues aus dem Bereich Wahlen

![iStock.com / Ralf Geithe](https://download.statistik-berlin-brandenburg.de/2c6bfd8d9296f077/fc270cd7cdcd/v/43e4e12804f9/bevoelkerung-wahlen-filling-a-ballot-with-a-pen-picture-id1026485820.jpg)24.10.2024Seite[#### Alle Wahlergebnisse für Berlin: Wahlen in Berlin](/wahlen-berlin)

Die Landeswahleitung Berlin. Umfassende Informationen über Europawahlen, Bundestagswahlen, Abgeordnetenhauswahlen, BVV-Wahlen und Volksentscheide.

[Ansehen](/wahlen-berlin)![iStock.com / JARAMA](https://download.statistik-berlin-brandenburg.de/86c94bf1d6b36171/d36db17b24d2/v/6552cdca14db/bevoelkerung-wahlen-and-german-flags-fly-in-the-wind-in-front-of-the-reichstag-in-berlin-picture-id1269519877.jpg)07.06.2024Artikel[#### Europawahl in Berlin und Brandenburg: Fünf Dinge, die Sie nicht über die Wahl wissen](/news/2024/europawahl)

Während die meisten Bürgerinnen und Bürger ihre Stimme abgeben und auf die Ergebnisse warten, steckt hinter den Kulissen eine herausfordernde Planung und technische Arbeit.

[Ansehen](/news/2024/europawahl)![iStock.com / cbies](https://download.statistik-berlin-brandenburg.de/b4cb759b6ac111fc/5a0d6ce83420/v/7bcc8c5418df/bevoelkerung-wahlen-germany-politics-concept-german-flag-in-front-of-the-reichstag-picture-id1020839762.jpg)04.07.2022Artikel[#### Repräsentative Wahlstatistik zur Bundestagswahl 2021 in Brandenburg: Über 60 Prozent der Wählenden sind älter als 50 Jahre](/publikationen/fachbeitrag/2022/wahlstatistik-bundestagswahl-brandenburg)

Der Fachbeitrag analysiert anhand der repräsentativen Wahlstatistik das Wahlverhalten der Bürgerinnen und Bürger in Brandenburg zur Bundestagswahl am 26. September 2021.

[Ansehen](/publikationen/fachbeitrag/2022/wahlstatistik-bundestagswahl-brandenburg)[Weitere Veröffentlichungen](/search-results?q=wahlen&searchBlogPost=true&pageNumber=1&searchStaticReport=true&searchPressRelease=true&sortBy=date-desc&region=brandenburg&searchByButton=true#results)
### Bleiben Sie auf dem Laufenden.Der Newsletter zu diesem Thema

[Jetzt abonnieren](/newsletter)


