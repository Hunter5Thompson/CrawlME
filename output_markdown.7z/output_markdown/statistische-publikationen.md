

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Statistische Berichte](/statistische-publikationen)

Statistische Publikationen
==========================

Mit unseren Berichtsreihen bieten wir Ihnen in regelmäßigem Turnus die aktuellen statistischen Ergebnisse aus nahezu allen Lebensbereichen. Hier finden Sie alle Veröffentlichungen im thematisch sortierten Überblick.

BevölkerungGesellschaftWirtschaftMeine Region

Bevölkerung
-----------

### Demografie

**Bevölkerungsstand, **Geburten, Sterbefälle, Eheschließungen, Zu- und Fortzüge****

Bevölkerungsstand – Monatsergebnisse, monatlich →  [A I 7 – m, A II 3 – m, A III 3 – m](/a-i-7-a-ii-3-a-iii-3-m)

Bevölkerungsstand – Jahresergebnisse, jährlich → [A I 3 – j](/a-i-3-j)

Bevölkerungsstand  – Jahresergebnisse Gemeinden Brandenburg, jährlich → [A I 4 – j, A V 2 – j](/a-i-4-a-v-2-j)

Bevölkerungsstand Vorausberechnung Brandenburg, unregelmäßig → [A I 8](/a-i-8)

Geburten, Sterbefälle, Eheschließungen – Jahresergebnisse, jährlich → [A II 1 – j](/a-ii-1-j)

Wanderungen – Jahresergebnisse, jährlich → [A III 2 – j](/a-iii-2-j)

**Einbürgerungen, Ausländer**

Einbürgerungen – Jahresergebnisse, jährlich → [A I 9 – j](/a-i-9-j)

**Mikrozensus**

Ergebnisse des Mikrozensus, jährlich → [A I 10 – j, A I 11 – j, A VI 2 – j](/a-i-10-a-i-11-a-vi-2-j)

Ergebnisse des Mikrozensus: Wohnsituation, vierjährig → [F I 2 – 4j](/f-i-2-4j)

### Wahlen

**Wahlen in Berlin**

[Europawahlen](/europawahlen-berlin), fünfjährig

[Bundestagswahlen](/bundestagswahlen-berlin), vierjährig

[Berliner Wahlen](/abgeordnetenhauswahlen-bvv-berlin) (Abgeordnetenhaus und Bezirksverordnetenversammlungen), fünfjährig

[Volksentscheide](/volksentscheide-berlin), unregelmäßig

**Wahlen in Brandenburg**

[Europawahlen](/europawahlen-brandenburg), fünfjährig

[Bundestagswahlen](/bundestagswahlen-brandenburg), vierjährig

[Landtagswahlen](/landtagswahlen-brandenburg), fünfjährig

[Kommunalwahlen](/kommunalwahlen-brandenburg), fünfjährig

Gesellschaft
------------

### Arbeit

**Erwerbstätigkeit**

Erwerbstätige am Wohnort – Jahresergebnisse und Vierteljahresergebnisse, halbjährlich → [A VI 18 – hj](/a-vi-18-hj)

Erwerbstätige am Arbeitsort – Jahresergebnisse, dreimal jährlich → [A VI 9 – hj](/a-vi-9-hj)

Erwerbstätige am Arbeitsort in den kreisfreien Städten und Landkreisen Brandenburgs – Jahresergebnisse, jährlich → [A VI 10 – j](/a-vi-10-j)

Erwerbstätige am Arbeitsort in Berlin und Brandenburg – Vierteljahresergebnisse → [A VI 16 – vj](/a-vi-16-vj)

Geleistete Arbeitsstunden – Halbjahresergebnisse, halbjährlich → [A VI 17 – hj](/a-vi-17-hj)

Sozialversicherungspflichtig Beschäftigte am 30. Juni – Jahresergebnisse, jährlich → [A VI 20 – j](/a-vi-20-j)

**Verdienste**

Verdiensterhebung, jährlich → [N I 6 – j](/n-i-6-j)

**Arbeitskosten**

Arbeitskosten im Produzierenden Gewerbe und im Dienstleistungsbereich, vierjährig → [N III 1 – 4j](/n-iii-1-4j)

### Soziales

**Sozialhilfe**

Sozialhilfe Ausgaben und Einnahmen, jährlich → [K I 1 – j](/k-i-1-j)

Hilfe zum Lebensunterhalt, jährlich → [K I 2 – j](/k-i-2-j)

Empfänger von Leistungen nach dem 5. bis 9. Kapitel SGB XII, jährlich → [K I 3 – j](/k-i-3-j)

**Menschen mit Behinderung/Eingliederungshilfe**

Schwerbehinderte Menschen, halbjährlich → [K III 1 – 2j](/k-iii-1-2j)

Empfänger von Eingliederungshilfe sowie Ausgaben und Einnahmen nach dem SGB IX, jährlich → [K III 2 – j](/k-iii-2-j)

**Wohngeld**

Wohngeld, jährlich → [K VII 1 – j](/k-vii-1-j)

**Asylbewerberleistungen**

Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen nach dem Asylbewerberleistungsgesetz, jährlich → [K VI 2 – j, K VI 1 – j](/k-vi-1-k-vi-2-j)

**Kinder- und Jugendhilfe**

Erzieherische Hilfe, Eingliederungshilfe für seelisch behinderte junge Menschen, Hilfe für junge Volljährige in Berlin und Brandenburg, jährlich → [K V 2 – j](/k-v-2-j)

Adoptionen, Pflegschaften, Vormundschaften, Beistandschaften, Pflegeerlaubnis, Sorgerecht sowie Maßnahmen des Familiengerichts, jährlich → [K V 3 – j](/k-v-3-j)

Jugendhilfe in Berlin und Brandenburg – Vorläufige Schutzmaßnahmen. jährlich → [K V 4 – j](/k-v-4-j)

Jugendhilfe in Berlin und Brandenburg – Angebote der Jugendarbeit. jährlich → [K V 6 – 2j](/k-v-6-2j)

Kinder und tätige Personen in Tageseinrichtungen und öffentlich geförderter Kindertagespflege in Berlin und Brandenburg. jährlich → [K V 7 – j](/k-v-7-j)

Sonstige Einrichtungen und tätige Personen in der Kinder- und Jugendhilfe in Berlin und Brandenburg. zweijährlich → [K V 9 – 2j](/k-v-9-2j)

Gefährdungseinschätzungen nach § 8a SGB VIII, jährlich → [K V 10 – j](/k-v-10-j)

### Gesundheit

**Krankenhaus und Rehabilitation**

Krankenhäuser in Berlin und Brandenburg; Teil I: Grunddaten, jährlich → [A IV 2– j](/a-iv-2-j)

Krankenhäuser in Berlin und Brandenburg; Teil II: Diagnosen der Krankenhauspatientinnen und -patienten, jährlich → [A IV 3 – j](/a-iv-3-j)

Krankenhäuser in Berlin und Brandenburg; Teil III: Kostennachweis, jährlich → [A IV 4 – j](/a-iv-4-j)

Vorsorge- oder Rehabilitationseinrichtungen in Brandenburg, jährlich → [A IV 5 – j](/a-iv-5-j)

**Pflege**

Ambulante und stationäre Pflegeeinrichtungen sowie Empfänger von Pflegegeldleistungen in Berlin und Brandenburg → [K VIII – 2j](/k-viii-1-2j)

**Familienplanung**

In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg, jährlich → [A IV 11 – j](/a-iv-11-j)

Schwangerschaftskonflikt-, Schwangerschaftsberatung, Familienplanung und Sexualberatung in Brandenburg, jährlich → [A IV 14 – j](/a-iv-14-j)

**Todesursachen**

Sterbefälle nach Todesursachen in Berlin und Brandenburg, jährlich → [AIV 10 – j](/a-iv-10-j)

Gestorbene nach ausgewählten Todesursachen in Berlin und Brandenburg, monatlich → [A IV 12 – m](/a-iv-12-m)

### Bildung

**Schulen**

Allgemeinbildende Schulen in Brandenburg → [B I 1 – j](/b-i-1-j)

Allgemeinbildende Schulen in Brandenburg – Ergebnisse nach Verwaltungsbezirken und staatlichen Schulämtern → [B I 9 – j](/b-i-9-j)

Absolventinnen und Absolventen/Abgängerinnen und Abgänger der allgemeinbildenden Schulen in Brandenburg → [B I 5 – j](/b-i-5-j)

Ausbildungsstätten für Fachberufe des Gesundheitswesens → [B II 6 – j](/b-ii-6-j)

Berufliche Schulen in Brandenburg einschließlich Ergebnisse nach Verwaltungsbezirken → [B II 1 – j](/b-ii-1-j)

Auszubildende und Prüfungen in Berlin und Brandenburg → [B II 5 – j](/b-ii-5-j)

**Hochschulen**

Akademische und staatliche Abschlussprüfungen in Berlin und Brandenburg, Teil: 1 Übersicht → [B III 5 – j](/b-iii-5-j)

Akademische und staatliche Abschlussprüfungen in Berlin und Brandenburg, Teil 2: Ausführliche Ergebnisse → [B III 3 – j](/b-iii-3-j)

Hochschulfinanzstatistik in Berlin und Brandenburg → [B III 7 – j](/b-iii-7-j)

Personal an Hochschulen in Berlin und Brandenburg → [B III 4 – j](/b-iii-4-j)

Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Teil 1: Übersicht → [B III 2 – j](/b-iii-2-j)

Studierende an Hochschulen in Berlin und Brandenburg – Sommersemester → [B III 6 – j](/b-iii-6-j)

Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Teil 2: Ausführliche Ergebnisse → [B III 1 – j](/b-iii-1-j)

Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Vorläufige Angaben → [B III 8 – j](/b-iii-8-j)

**Ausbildungsförderung**

Förderung beruflicher Aufstiegsfortbildung nach dem Aufstiegsfortbildungsförderungsgesetz (AFBG) → [K IX 2 – j](/k-ix-2-j)

Ausbildungsförderung nach dem Bundesausbildungsförderungsgesetz (BAföG) → [K IX 1 – j](/k-ix-1-j)

### Staat

**Steuern**

Gewerbesteuerstatistik in Berlin und Brandenburg → [L IV 13 – j](/l-iv-13-j)

Lohn- und Einkommensteuerstatistik in Berlin und Brandenburg → [L IV 3 – j](/l-iv-3-j)

Umsatzsteuerstatistik (Voranmeldungen) in Berlin und Brandenburg → [L IV 1 – j](/l-iv-1-j)

**Öffentliche Finanzen**

Finanzvermögen der Kern- und Extrahaushalte des öffentlichen Gesamthaushalts → [L III 6 – j](/l-iii-6-j)

Gemeindefinanzen in Brandenburg → [L II 2 – j](/l-ii-2-j)

Realsteuerhebesätze der Städte und Gemeinden in Brandenburg → [L II 6 – j](/l-ii-6-j)

Realsteuervergleich in Berlin und Brandenburg → [L II 7 – j](/l-ii-7-j)

Rechnungsergebnisse der Kernhaushalte der Gemeinden und Gemeindeverbände in Brandenburg → [L II 3 – j](/l-ii-3-j)

Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen → [L III 1 – j](/l-iii-1-j)

**Öffentlicher Dienst**

Personal im öffentlichen Dienst in Berlin und Brandenburg → [L III 2 – j](/l-iii-2-j)

Versorgungsempfänger in Berlin und Brandenburg → [L III 5 – j](/l-iii-5-j)

**Flächennutzung**

Gebiets- und Namensänderungen in Brandenburg → [A V 1 – u](/a-v-1-u)

Flächenerhebung nach Art der tatsächlichen Nutzung in Berlin und Brandenburg → [A V 3 – j](/a-v-3-j)

### Verkehr

**Personenverkehr**

Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg → [H I 6 – j](/h-i-6-j)

Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg → [H I 5 – 5j](/h-i-5-5j)

**Straßenverkehr**

Straßenverkehrsunfälle in Berlin und Brandenburg →[H I 1 – m](/h-i-1-m)

Straßenverkehrsunfälle in Berlin und Brandenburg → [H I 2 – j](/h-i-2-j)

Wirtschaft
----------

### **Volkswirtschaft**

**Volkswirtschaftliche Gesamtrechnungen**

Bruttoinlandsprodukt und Bruttowertschöpfung in Berlin und Brandenburg nach Wirtschaftsbereichen, jährlich → [P I 1 – j](/p-i-1-j)

Bruttoinlandsprodukt und Bruttowertschöpfung in den kreisfreien Städten und Landkreisen in Brandenburg, jährlich → [P I 5 – j](/p-i-5-j)

Arbeitnehmerentgelt, Bruttolöhne und -gehälter und Arbeitnehmer in Berlin und Brandenburg nach Wirtschaftsbereichen, halbjährlich → [P I 2 – hj,](/p-i-2-hj)

Arbeitnehmerentgelt und Bruttolöhne und -gehälter in den kreisfreien Städten und Landkreisen in Brandenburg, jährlich → [P I 7 – j](/p-i-7-j)

Bruttonationaleinkommen und Volkseinkommen in Berlin und Brandenburg, jährlich → [P I 12 – j](/p-i-12-j)

Primäreinkommen und Verfügbares Einkommen der privaten Haushalte in Berlin und Brandenburg, jährlich → [P I 10 – j](/p-i-10-j)

Primäreinkommen und verfügbares Einkommen der privaten Haushalte in Brandenburg, jährlich → [P I 6 – j](/p-i-6-j)

Konsum und Sparen der privaten Haushalte in Berlin und Brandenburg, jährlich → [P I 8 – j](/p-i-8-j)

Konsumausgaben des Staates in Berlin und Brandenburg, jährlich → [P I 9 – j](/p-i-9-j)

Bruttoanlageinvestitionen in Berlin und in Brandenburg nach Wirtschaftsbereichen, jährlich → [P I 4 – j](/p-i-4-j)

Bruttoanlagevermögen in Berlin und Brandenburg nach Wirtschaftsbereichen, jährlich → [P I 11 – j](/p-i-11-j)

**Unternehmen**

Rechtliche Einheiten und Niederlassungen in Berlin und Brandenburg, jährlich → [D II 1 – j](/d-ii-1-j)

**Gewerbeanzeigen**

Gewerbeanzeigen in Berlin und Brandenburg, monatlich → [D I 1 – m](/d-i-1-m)

Gewerbeanzeigen in Berlin und Brandenburg, jährlich → [D I 2 – j](/d-i-2-j)

**Insolvenzen**

Insolvenzen in Berlin und Brandenburg, vierteljährlich →[D III 1 – vj](/d-iii-1-vj)

Insolvenzen in Berlin und Brandenburg, jährlich → [D III 2 – j](/d-iii-2-j)

Beendete Insolvenzverfahren und Restschuldbefreiung in Berlin und Brandenburg, jährlich → [D III 3 – j](/d-iii-3-j)

**Einkommen und Konsum**

Ausstattung mit ausgewählten Gebrauchsgütern und Wohnsituation privater Haushalte in Berlin und Brandenburg, fünfjährig → [O II 1 – 5j](/o-ii-1-5j)

Haus- und Grundbesitz, Geldvermögen und Schulden privater Haushalte in Berlin und Brandenburg, fünfjährig → [O II 2 – 5j](/o-ii-2-5j)

Einkommen und Einnahmen sowie Ausgaben privater Haushalte in Berlin und Brandenburg, fünfjährig → [O II 3 – 5j](/o-ii-3-5j)

Aufwendungen privater Haushalte für Nahrungsmittel, Getränke und Tabakwaren in Berlin und Brandenburg, fünfjährig → [O II 4 – 5j](/o-ii-4-5j)

### **Wirtschaftsbereiche**

**Handel**

Umsatz und Beschäftigung im Handel und Kraftfahrzeuggewerbe – Messzahlen – in Berlin und Brandenburg, jährlich → [G I 1 – j](/g-i-1-j)

Umsatz, Beschäftigung und Investitionen im Handel und Kraftfahrzeuggewerbe in Berlin und Brandenburg, jährlich → [G I 2 – j](/g-i-2-j)

Umsatz und Beschäftigung im Einzelhandel in Berlin und Brandenburg – Messzahlen, monatlich → [G I 3 – m](/g-i-3-m)

Umsatz und Beschäftigung im Kraftfahrzeughandel einschl. Instandhaltung und Reparatur und im Großhandel – Messzahlen – in Berlin und Brandenburg → [G I 5 – m](/g-i-5-m)

**Land- und Forstwirtschaft**

Bodennutzung der landwirtschaftlichen Betriebe in Brandenburg (endgültiges Ergebnis), jährlich → [C I 1 – j](/c-i-1-j)

Bodennutzung der landwirtschaftlichen Betriebe in Brandenburg (vorläufiges Ergebnis), jährlich → [C I 2 – j](/c-i-2-j)

Ernteberichterstattung über Feldfrüchte und Grünland in Brandenburg, fallweise → [C II 1 – m](/c-ii-1-m)

Ernteberichterstattung über Feldfrüchte und Grünland in Brandenburg (Endgültiges Ergebnis), jährlich → [C II 2 – j](/c-ii-2-j)

Ernteberichterstattung über Obst im Marktobstanbau in Brandenburg, jährlich → [C II 6 – j](/c-ii-6-j)

Besondere Ernte- und Qualitätsermittlung in Brandenburg, jährlich → [C II 7 – j](/c-ii-7-j)

Gemüseerhebung in Brandenburg, jährlich → [C I 3 – j](/c-i-3-j)

Strauchbeerenerhebung in Brandenburg, jährlich → [C I 4 – j](/c-i-4-j)

Anbau von Blumen und Zierpflanzen zum Verkauf in Brandenburg, vierjährlich → [C I 6 – 4j](/c-i-6-4j)

Baumschulerhebung in Brandenburg, vierjährlich → [C I 7 – 4j](/c-i-7-4j)

Baumobstanbau in Brandenburg, fünfjährlich → [C I 8 – 5j](/c-i-8-5j)

Zwischenfruchtanbau in Brandenburg, dreijährlich → [C I 9 – 3j](/c-i-9-3j)

Holzeinschlag in Brandenburg, jährlich → [C V 1 – j](/c-v-1-j)

Ausgewählte Ergebnisse der Agrarstrukturerhebung in Berlin, drei- bis vierjährlich → [C IV 14 – u](/c-iv-14-u)

Betriebe mit ökologischem Landbau in Brandenburg, drei- bis vierjährlich → [C IV 2 – 3j](/c-iv-2-3j)

Größenstruktur, sozialökonomische Betriebstypen sowie Rechtsformen der landwirtschaftlichen Betriebe in Brandenburg, drei- bis vierjährlich → [C IV 7 – 3j](/c-iv-7-3j)

Eigentums- und Pachtverhältnisse der landwirtschaftlichen Betriebe in Brandenburg, drei- bis vierjährlich → [C IV 8 – 3j](/c-iv-8-3j)

Betriebswirtschaftliche Ausrichtung der landwirtschaftlichen Betriebe in Brandenburg, drei- bis vierjählich → [C IV 9 – 3j](/c-iv-9-3j)

Landwirtschaftliche Betriebe mit Gartenbau in Brandenburg, unregelmäßig → [C IV 13 – u](/c-iv-13-u)

Ausgewählte Ergebnisse der Landwirtschaftszählung in Berlin, zehnjährlich → [C IV 10 – u](/c-iv-10-u)

Arbeitskräfte, Berufsbildung und Hofnachfolge in den landwirtschaftlichen Betrieben in Brandenburg, drei- bis vierjährlich → [C IV 1 – 3j](/c-iv-1-3j)

Viehbestände in Brandenburg – Erhebung über Rinder, Schweine, Schafe, Ziegen und Geflügel, dreijährlich → [C III 1 – 3j](/c-iii-1-3j)

Viehbestände in Brandenburg nach Größenklassen der Tierhaltung und Flächenausstattung, dreijährlich → [C III 4 – 3j](/c-iii-4-3j)

Wirtschaftsdünger, Stall- und Weidehaltung in Brandenburg, unregelmäßig → [C IV 12 – u](/c-iv-12-u)

Viehbestände in Brandenburg am 3. Mai – Schweine, jährlich → [C III 2 – j](/c-iii-2-j)

Viehbestände in Brandenburg am 3. November, Schweine – repräsentative Erhebung, jährlich → [C III 3 – j](/c-iii-3-j)

Schlachtungen und Fleischerzeugung in Brandenburg, monatlich → [C III 6 – m](/c-iii-6-hj)

Legehennenhaltung und Eiererzeugung in Brandenburg, vierteljährlich → [C III 8 – vj](/c-iii-8-vj)

Rinder in Berlin und Brandenburg, halbjährlich → [C III 9 – hj](/c-iii-9-hj)

Viehbestände in Brandenburg – Schafe, jährlich → [C III 10 – j](/c-iii-10-j)

Erzeugung in Aquakulturbetrieben in Brandenburg, jährlich → [C III 11 – j](/c-iii-11-j)

**Tourismus und Gast­gewerbe**

Gäste, Übernachtungen und Beherbergungskapazität in Berlin und Brandenburg, monatlich → [G IV 1 – m](/g-iv-1-m)

Tourismus in Berlin (vorläufige Ergebnisse), monatlich → [G IV 2 – m](/g-iv-2-m)

Umsatz und Beschäftigung im Gastgewerbe in Berlin und Brandenburg – Messzahlen, jährlich → [G IV 3 – j](/g-iv-3-j)

Umsatz, Beschäftigung und Investitionen im Gastgewerbe in Berlin und Brandenburg, jährlich →[G IV 4 – j](/g-iv-4-j)

Umsatz und Beschäftigung im Gastgewerbe in Berlin und Brandenburg – Messzahlen, monatlich → [G IV 5 – m](/g-iv-5-m)

Tourismus in Brandenburg nach Gemeinden, monatlich → [G IV 8 – m](/g-iv-8-m)

Tourismus in Brandenburg nach Gemeinden, jährlich → [G IV 9 – j](/g-iv-9-j)

**Verarbeitendes Gewerbe**

Ergebnisse des Monats- und Jahresberichts für Betriebe in Berlin und Brandenburg, jährlich → [E I 1 – j](/e-i-1-j)

Tätige Personen, Umsatz, Bezirke, Auftragseingangsindex, monatlich →[E I 2 – m](/e-i-2-m)

Produktion in Berlin und Brandenburg, vierteljährlich → [E I 4 – vj](/e-i-4-vj)

Produktion in Berlin und Brandenburg, jährlich → [E I 5 – j](/e-i-5-j)

Investitionen der Betriebe in Berlin und Brandenburg, jährlich → [E I 6 – j](/e-i-6-j)

**Dienstleistungen**

Dienstleistungen in Berlin und Brandenburg, monatlich → [J I 3 – m](/j-i-3-m)

Dienstleistungen in Berlin und Brandenburg, jährlich → [J I 2 – j](/j-i-2-j)

**Bauen und Wohnungen**

Baufertigstellungen, Bauüberhang und Bauabgang in Berlin und Brandenburg, jährlich → [F II 2 – j](/f-ii-2-j)

Baugenehmigungen in Berlin und Brandenburg, monatlich → [F II 1 – m](/f-ii-1-m)

Baugewerbe in Berlin und Brandenburg, monatlich → [E II 1, E III 1 – m](/e-ii-1-e-iii-1-m)

Baugewerbe in Berlin und Brandenburg, jährlich → [E II 2, E III 2 – j](/e-ii-2-e-iii-2-j)

Fortschreibung des Wohngebäude- und Wohnungsbestandes in Berlin und Brandenburg, jährlich → [F I 1 – j](/f-i-1-j)

**Handwerk**

Handwerkszählung in Berlin und Brandenburg, jährlich → [E V 1 – j](/e-v-1-j)

### Preise

**Verbraucherpreise**

Verbraucherpreisindex in Berlin und Brandenburg, monatlich → [M I 2 – m](/m-i-2-m)

**Bodenmarkt**

Kaufwerte für Bauland in Berlin und Brandenburg, jährlich → [M I 6 – j](/m-i-6-j)

Kaufwerte landwirtschaftlicher Grundstücke in Brandenburg, jährlich → [M I 7 – j](/m-i-7-j)

**Baupreise**

Preisindizes für Bauwerke in Berlin und Brandenburg, vierteljährlich → [M I 4 – vj](/m-i-4-vj)

### Umwelt

**Wasser**

Wasserversorgung und Abwasserbeseitigung in Berlin und Brandenburg, dreijährlich → [Q I – 3j](/q-i-1-3j)

Wasser- und Abwasserentgelte in Berlin und Brandenburg, dreijährlich → [Q I 3 – 3j](/q-i-3-3j)

Entsorgung Klärschlamm in Berlin und Brandenburg, jährlich → [Q I 9 – j](/q-i-9-j)

**Energie**

Energie-, Wasser- und Gasversorgung in Brandenburg, jährlich → [E IV 1 – j](/e-iv-1-j)

Energieverwendung der Betriebe des Verarbeitenden Gewerbes in Berlin und Brandenburg, jährlich → [E IV 3 – j](/e-iv-3-j)

Energie- und CO₂-Bilanz in Berlin und Brandenburg, jährlich → [E IV 4 – j](/e-iv-4-j)

Energie- und CO₂-Bilanz in Berlin, jährlich → [E IV 5 – j](/e-iv-5-j)

**Abfall, Luftbelastungspotenzial**

Abfallentsorgung in Berlin und Brandenburg, zweijährlich → [Q II 1 – 2j](/q-ii-1-2j)

Klimawirksame Stoffe in Berlin und Brandenburg, jährlich → [Q IV 1 – j](/q-iv-1-j)

Meine Region
------------

### Berlin-Statistik

**Einwohnerbestand**

Einwohnerbestand in Berlin – Grunddaten, halbjährlich → [A I 5 – hj](/a-i-5-hj)

Einwohnerbestand in Berlin – LOR Planungsräume, halbjährlich → [A I 16 – hj](/a-i-16-hj)

Einwohnerbestand in Berlin – Privathaushalte, jährlich → [A I 17 – j](/a-i-17-j)

**Einwohnerbewegung**

Einwohnerbewegung, jährlich → [A II 11 – j, A III 11 – j](/a-ii-11-j)

**Stadtleben**

Sportvereine in Berlin, jährlich → [B V 1 –  j](/b-v-1-j)


