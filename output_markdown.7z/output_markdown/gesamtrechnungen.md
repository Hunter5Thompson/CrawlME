

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Gesundheitsökonomische Gesamtrechnungen](/gesamtrechnungen)

Gesundheits­ökonomische Gesamt­rechnungen
=========================================

Die Gesundheitsökonomischen Gesamtrechnungen (GGR) stellen Daten zur Gesundheitswirtschaft bereit. Sie betrachten drei Hauptkomponenten: die Gesundheitsausgabenrechnung, die Gesundheitspersonalrechnung und den Wertschöpfungs-Erwerbstätigen-Ansatz, der die Bruttowertschöpfung und Erwerbstätigen auf Länderebene berechnet.

Das Amt für Statistik Berlin-Brandenburg ist Mitglied der Arbeitsgruppe „Gesundheitsökonomische Gesamtrechnungen der Länder“ und veröffentlicht die Ergebnisse der GGR für Berlin und Brandenburg.

ZeitreihenBasisdatenWeitere Datenangebote

Zeitreihen
----------

GesundheitsausgabenGesundheitspersonalGesundheitswirtschaft**Quelle:** Gesundheitsausgabenrechnung der Länder, Gesundheitsausgabenrechnung des Bundes, Berechnungsstand: April 2024

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/506acaad541a5267/9f2d927c70ae/GGR-Zeitreihe.xlsx)

Basisdaten
----------

GesundheitsausgabenGesundheitspersonalGesundheitswirtschaft

Weitere Datenangebote
---------------------

#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Im Statistikportal finden Sie weitere Informationen zur Aufgabe der AK GGRdL, zu Definitionen und Methoden sowie Ergebnisse für alle Bundesländer.

[Zum Statistikportal](https://www.statistikportal.de/de/ggrdl)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1717088015566&code=88#abreadcrumb)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1715595712769&code=23#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Christian Benda

Gesundheitsökonomische Gesamtrechnungen

#### Christian Benda

Gesundheitsökonomische Gesamtrechnungen

* [0331 8173-3734](tel: 0331 8173-3734)
* [ggr@statistik-bbb.de](mailto:ggr@statistik-bbb.de )
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![](https://download.statistik-berlin-brandenburg.de/cc13843a8f07c91c/ef602ee6be9c/v/b14ae87d3af7/Medikamente-iStock-1484099079.jpg)](/171-2024)**Gesundheitsausgaben 2022 in Berlin und Brandenburg**[#### Jeder fünfte Euro wird für Arzneimittel ausgegeben](/171-2024)

Die Gesundheitsausgaben der gesetzlichen Krankenversicherung beliefen sich 2022 in der Hauptstadtregion auf über 21 Milliarden EUR....

[![iStock.com / Spotmatik](https://download.statistik-berlin-brandenburg.de/09fe07d2f99a71db/1fd2b255bc8f/v/d5efaa426575/gesellschaft-gesundheit-doctors-hospital-corridor-nurse-pushing-gurney-stretcher-bed-picture-id478740625.jpg "iStock.com / Spotmatik")](/118-2024)**Gesundheitsausgaben 2022 in Berlin und Brandenburg**[#### Wachsende Ausgaben in der Hauptstadtregion](/118-2024)

Pressemitteilung Nr. 118 Die Gesundheitsausgaben stiegen 2022 gegenüber dem Vorjahr in Berlin um 5,7 % auf 23,2 Milliarden EUR. Wie das Amt für Statistik Berlin-Brandenburg mitteilt, war dies der...

[![iStock.com / kzenon](https://download.statistik-berlin-brandenburg.de/a9e83ab3257d42ea/a4e296a27926/v/d3bee5bfa0d7/gesellschaft-gesundheit-seniors-in-rehabilitation-learning-how-to-walk-with-crutches-picture-id1194508750.jpg "iStock.com / kzenon")](/081-2024)**Gesundheitswirtschaft 2023 in Berlin und Brandenburg**[#### Unterschiedliche Entwicklung in der Hauptstadtregion](/081-2024)

Pressemitteilung Nr. 81 Die Bruttowertschöpfung (BWS) der Gesundheitswirtschaft stieg 2023 gegenüber dem Vorjahr preisbereinigt in Brandenburg um 1,8 %. Wie das Amt für Statistik Berlin-Brandenburg...

[Zu unseren News](/news)

[* Gesundheitsbranche](/search-results?q=tag%3AGesundheitsbranche)[* Gesundheitsbereich](/search-results?q=tag%3AGesundheitsbereich)[* Gesundheitswirtschaft](/search-results?q=tag%3AGesundheitswirtschaft)[* Gesundheitsausgaben](/search-results?q=tag%3AGesundheitsausgaben)[* Gesundheitspersonal](/search-results?q=tag%3AGesundheitspersonal)
