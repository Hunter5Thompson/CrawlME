

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Preise](/wirtschaft/preise)
#### Überblick

Preise
======

Preise und deren Entwicklungen beeinflussen nahezu alle Bereiche des Lebens. Im Mittelpunkt der amtlichen Preisstatistiken steht daher die Erfassung von Preisen für Waren und Dienstleistungen auf allen Wirtschaftsstufen. Dabei werden zeitliche und räumliche Preisentwicklungen in Form von Preisindizes dargestellt.

**Wägungsanteil
am Gesamtindex**in Promille


**Quelle:** Amt für Statistik Berlin-Brandenburg[Preisentwicklungen
#### Verbraucherpreise](/verbraucherpreise)[Bauland- und Grundstücksverkäufe
#### Bodenmarkt](/bodenmarkt)[Preisentwicklungen
#### Baupreise](/baupreise)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Preise

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 im Jahresdurchschnitt **Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Neues aus dem Bereich Preise

Zuletzt veröffentlicht
----------------------

![iStock.com / JJFarquitectos](https://download.statistik-berlin-brandenburg.de/6fa6ce9b156d3d63/504c134f19e9/v/f2d4980f3df3/wirtschaft-preise-verbraucherpreise-closeup-photo-of-stylish-woman-taking-money-picture-id842875452.jpg)05.12.2024Statistischer Bericht[#### November 2024, monatlich, M I 2 – m: Verbraucherpreisindex in Berlin und Brandenburg](/m-i-2-m)

Monatliche Statistik zur durchschnittlichen Preisentwicklung aller Waren und Dienstleistungen, die von privaten Haushalten für Konsumzwecke gekauft werden.

[Ansehen](/m-i-2-m)![](https://download.statistik-berlin-brandenburg.de/a5428da79bd40607/f3301d8bdf5a/v/5f183346ceea/iStock-1216828053.jpg)28.11.2024Pressemitteilung[#### Verbraucherpreise November 2024 Berlin und Brandenburg: Teuerung in Berlin zieht wieder an, leichte Erhöhung auch in Brandenburg](/166-2024)

Im November 2024 erhöhten sich die Verbraucherpreise im Vergleich zum November 2023 in Berlin um 2,0 % und in Brandenburg um 1,9 %.

[Ansehen](/166-2024)![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)01.11.2024Pressemitteilung[#### Verbraucherpreise Oktober 2024 Berlin und Brandenburg: Teuerung zieht in beiden Ländern wieder an](/146-2024)

Im Oktober 2024 erhöhten sich die Verbraucherpreise im Vergleich zum Oktober 2023 in Berlin um 1,4 % und in Brandenburg um 1,8 %.

[Ansehen](/146-2024)Mehr anzeigen


