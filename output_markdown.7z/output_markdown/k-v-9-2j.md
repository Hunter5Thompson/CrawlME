

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)
* [Träger der Jugendhilfe, die dort tätigen Personen und deren Einrichtungen in Berlin und Brandenburg](/k-v-9-2j)

Träger der Jugendhilfe, die dort tätigen Personen und deren Einrichtungen
-------------------------------------------------------------------------

#### 15. Dezember 2022, zweijährlich

  
###### Die Daten geben einen Überblick über die institutionelle und personelle Situation in der Kinder- und Jugendhilfe und sind Grundlage für die Planung von Jugendhilfeeinrichtungen auf regionaler und überregionaler Ebene.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8550ab3700b0d999/2fb2d935ddf3/SB_K05-09-00_2022j02_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b01e8576a5c09720/3ed3a82d7e58/SB_K05-09-00_2022j02_BE.pdf)

**Träger in der Kinder- und Jugendhilfe in Berlin**

Am 15.12.2022 nahmen in Berlin 975 Träger Aufgaben der Kinder- und Jugendhilfe wahr, davon 51 öffentliche und 924 freie Träger.

11.420 genehmigte Plätze standen in 894 betriebserlaubnispflichtigen Einrichtungen zur Betreuung junger Menschen zur Verfügung, von denen 87 % belegt waren.

Ende 2022 arbeiteten insgesamt 19.264 Personen in den Einrichtungen der Kinder- und Jugendhilfe. als Pädagogisches, Leitungs- und Verwaltungspersonal, 71 % davon waren Frauen. 42 % der Personen hatte einen Beschäftigungsumfang von 38,5 und mehr Wochenstunden.

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Träger in der Kinder- und Jugendhilfe in Brandenburg**

637 Träger nahmen am 15.12.2022 Aufgaben der Kinder- und Jugendhilfe in Brandenburg wahr, davon 192 öffentliche und 445 freie Träger.

In den 752 betriebserlaubnispflichtigen Einrichtungen standen 6.746 genehmigte Plätze zur Betreuung junger Menschen zur Verfügung, von denen 89 % belegt waren.

7.538 Personen arbeiteten Ende 2022 in den Einrichtungen der Kinder- und Jugendhilfe als Pädagogisches, Leitungs- und Verwaltungspersonal, 73 % davon waren Frauen. Über die Hälfte der Personen hatte einen Beschäftigungsumfang von 38,5 und mehr Wochenstunden.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/765794c72ddd5ffc/8b08b4bde958/SB_K05-09-00_2022j02_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/552ac25f6267db87/4c34b8c39177/SB_K05-09-00_2022j02_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik liefert Angaben zu den Trägern der Jugendhilfe mit deren Betätigungsfeldern, die dort tätigen Personen sowie die betriebserlaubnispflichtigen Einrichtungen der Träger (außer Tageseinrichtungen für Kinder). Bei Einrichtungen wird auch die Zahl der Plätze ermittelt, die für die Betreuung junger Menschen zur Verfügung stehen.

Auskunftspflichtig sind die örtlichen und überörtlichen Träger der Jugendhilfe, die obersten Landesjugendbehörden, die kreisangehörigen Gemeinden und Gemeindeverbände, soweit sie Aufgaben der Jugendhilfe wahrnehmen sowie die Träger der freien Jugendhilfe.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Einrichtungen und tätigen Personen – ohne Tageseinrichtungen**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/8a38d9dd575f981b/a4e962606c5d/MD_22542_2022.pdf)[Archiv](/search-results?q=22542&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-v-9-2j)
