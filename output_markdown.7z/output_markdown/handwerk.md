

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Handwerk](/handwerk)

Handwerk
========

Mit der vierteljährlichen Handwerksberichterstattung wird die konjunkturelle Entwicklung im zulassungspflichtigen und zulassungsfreien Handwerk beobachtet.

Seit dem Berichtsjahr 2008 werden ausschließlich Verwaltungsdaten der Bundesagentur für Arbeit und der Finanzverwaltungen ausgewertet, sodass kein Unternehmen mehr mit der statistischen Auskunftspflicht zur Handwerksberichterstattung belastet wird. Erhebungsinhalte sind der Umsatz im Kalendervierteljahr, die Zahl der sozialversicherungspflichtig entlohnten Beschäftigten zum Ende des Kalendervierteljahres, die ausgeübte wirtschaftliche Tätigkeit sowie das hauptsächlich ausgeübte Gewerbe nach der Anlage A bzw. Anlage B, Abschnitt 1 der Handwerksordnung.

Handwerkszählungen liefern Strukturangaben in Form von absoluten Werten über das Handwerk. Die Ergebnisse der Handwerkszählungen ab 2008 werden durch die Auswertung des statistischen Unternehmensregisters gewonnen. Dieses enthält unter anderem Verwaltungsdaten über Umsätze und Beschäftigte der Unternehmen.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Handwerkszählung in Berlin und Brandenburg (EV1-j)](/e-v-1-j)

Zeitreihen
----------

UnternehmenBeschäftigteUmsatz1 Nur Unternehmen (einschl. der inzwischen inaktiven Unternehmen) mit steuerbarem Umsatz aus Lieferungen und Leistungen und/oder mit sozialversicherungspflichtig oder geringfügig entlohnten Beschäftigten im jeweiligen Berichtsjahr**Quelle:** Amt für Statistik Berlin-Brandenburg

**„Zeitreihen“** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von zehn Jahren wieder. Die sogenannten **„Langen Reihen“** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/4d64a3ed6837de48/8ffc5b638f5a/handwerk-handwerkszaehlung-lange-reihe.xlsx)

Basisdaten
----------

UmsatzBeschäftigte

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=find&suchanweisung_language=de&query=Handwerk#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämter des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/bauen-und-handwerk)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=find&suchanweisung_language=de&query=handwerksz%C3%A4hlung#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Jeanette Miniers

Handwerk

#### Jeanette Miniers

Handwerk

* [0331 8173-3805](tel:0331 8173-3805)
* [handwerk@statistik-bbb.de](mailto:handwerk@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-1125757086.jpg](https://download.statistik-berlin-brandenburg.de/3ac476d432a0cece/58f384ba2603/v/6bd739bd7a08/wirtschaft-wirtschaftsbereiche-brot.jpg "iStock-1125757086.jpg")](/e-v-1-j)**2022, jährlich, E V 1 - j**[#### Handwerkszählung in Berlin und Brandenburg](/e-v-1-j)

Handwerkszählungen liefern Strukturangaben in Form von absoluten Werten über das Handwerk.

[![iStock-980300158.jpg](https://download.statistik-berlin-brandenburg.de/883981356e0148f4/3341c512f6b6/v/3bb2104a6e69/wirtschaft-wirtschaftsbereiche-maler.jpg "iStock-980300158.jpg")](/003-2023)**Handwerkszählung 2020 Berlin** [#### Handwerksunternehmen trotzen der Krise](/003-2023)

Pressemitteilung Nr. 3 Das Berliner Handwerk erwirtschaftete 2020 rund 17,2 Milliarden EUR Umsatz. Im Jahresdurchschnitt waren 184 215 Personen in 17 270 zulassungspflichtigen und zulassungsfreien...

[![wirtschaft-wirtschaftsbereich-bauen](https://download.statistik-berlin-brandenburg.de/188167ba93f983be/adca8a3669be/v/47f4f7253dd3/iStock-908801574.jpg "wirtschaft-wirtschaftsbereich-bauen")](/004-2023)**Handwerkszählung 2020 Brandenburg**[#### Umsatzplus für Brandenburger Handwerksunternehmen](/004-2023)

Pressemitteilung Nr. 4 Die Brandenburger Handwerksunternehmen erwirtschafteten 2020 etwa 16,0 Milliarden EUR Umsatz. Im Jahresdurchschnitt waren 151 251 Personen in 22 566 zulassungspflichtigen und...

[Zu unseren News](/news)

[* Handwerksberichterstattung](/search-results?q=tag%3AHandwerksberichterstattung)[* Umsatz](/search-results?q=tag%3AUmsatz)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)[* zulassungsfreies Handwerk](/search-results?q=tag%3Azulassungsfreies Handwerk)[* Gewerbezweig](/search-results?q=tag%3AGewerbezweig)[* Handwerksunternehmen](/search-results?q=tag%3AHandwerksunternehmen)[* Handwerkszählung](/search-results?q=tag%3AHandwerkszählung)[* zulassungspflichtiges Handwerk](/search-results?q=tag%3Azulassungspflichtiges Handwerk)
