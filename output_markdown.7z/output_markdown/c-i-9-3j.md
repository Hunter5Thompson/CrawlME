

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Zwischenfruchtanbau in Brandenburg](/c-i-9-3j)
### Zwischenfruchtanbau in Brandenburg

#### 2022/2023, dreijährlich

###### Die Daten zum Zwischenfruchtanbau zur Gründüngung, Futtergewinnung oder Biomasseerzeugung zur Energiegewinnung werden im Rahmen der Landwirtschaftszählung erhoben.

Brandenburg
-----------

**Zwischenfruchtanbau in Brandenburg ausgeweitet**

Der Anbau von Zwischenfrüchten wurde in Brandenburg in den letzten Jahren ausgeweitet. Wurden 2009/10 auf 45.160 Hektar Zwischenfrüchte angebaut, waren es 2022/2023 schon 128.300 Hektar. Dies entsprach einem Anstieg um 83.140 Hektar.

Damit wurden rund 13 % des Brandenburger Ackerlandes für den Anbau von Zwischenfrüchten genutzt. Insbesondere der Zwischenfruchtanbau von Pflanzen zur Gründüngung (114.000 Hektar) erhöhte sich um 79.900 Hektar deutlich. Der Anbau von Zwischenfrüchten zur Futtergewinnung (11.200 Hektar) ging dagegen um 5.000 Hektar zurück. Der Zwischenfruchtanbau für die Biomasseerzeugung zur Energiegewinnung bleibt auf niedrigem Niveau.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2022/2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d9ab1ae96582c5ce/1df3c6f6a496/SB_C01-09-00_2022j03_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/bfcdda822445d46f/c7bc568cd4c3/SB_C01-09-00_2022j03_BB.pdf)
### Kontakt

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Landwirtschaftszählung findet europaweit etwa alle 10 Jahre statt. In Deutschland wird sie als dezentrale Bundesstatistik durchgeführt. Zur Grundgesamtheit zählen alle Betriebe mit einer landwirtschaftlich genutzten Fläche von mindestens 5 Hektar oder mindestens 10 Rindern oder 50 Schweinen oder 10 Zuchtsauen oder 20 Schafen oder 20 Ziegen oder 1 000 Haltungsplätzen für Geflügel oder weiteren Mindesterzeugungseinheiten. Die Betriebe melden ihre Daten online bzw. per Erhebungsbogen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Agrarstrukturerhebung (ASE)**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/05723b6559976fb1/704419dd5b82/MD_41121_2023.pdf)[Archiv](/search-results?q=MD_41121&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-9-3j)
