

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Verkehr](/gesellschaft/verkehr)
#### Überblick

Verkehr
=======

Im Bereich Verkehr werden Informationen rund um das Geschehen auf Straße und Schiene, in der Luft und zu Wasser bereitgestellt. Wie viele Fahrten mit dem ÖPNV gab es im letzten Jahr? Wie viele Straßenverkehrsunfälle wurden der Polizei gemeldet? Mit den Ergebnissen der Verkehrsstatistiken lassen sich diese und viele weitere Fragen beantworten.

  


BerlinBrandenburg

**Straßenverkehrsunfälle mit Personenschaden**2023 in Berlin nach Uhrzeit


**Quelle:** Amt für Statistik Berlin-Brandenburg[Unfälle, Kfz-Bestände und -Zulassungen
#### Straßenverkehr](/strassenverkehr)[Personenbeförderung mit Bussen und Bahnen
#### Personenverkehr](/personenverkehr)[Passagiere in der Luftfahrt und Güterverkehr
#### Luftverkehr, Binnenschifffahrt](/luftverkehr-binnenschifffahrt)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Verkehr

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Kraftfahrt-Bundesamt Flensburg **Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 Ohne Transitverkehr**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
##### 

#### Neues aus dem Bereich Verkehr

Zuletzt veröffentlicht
----------------------

![iStock.com / GoogolPix](https://download.statistik-berlin-brandenburg.de/1a03bedef8ab3c23/0b10aefb97c2/v/6a408397d32d/gesellschaft-verkehr-ship-on-canal-in-bavaria-picture-id666692770.jpg)20.12.2024Pressemitteilung[#### Transport auf Brandenburgs Wasserstraßen von Januar bis September 2024: Mehr Güter befördert](/173-2024)

Auf den Binnenwasserstraßen Brandenburgs wurden in den ersten drei Quartalen 2024 insgesamt 1.524.600 Tonnen Güter befördert.

[Ansehen](/173-2024)![iStock.com / Animaflora](https://download.statistik-berlin-brandenburg.de/f08f86242a9d8c45/daccc7cb7e90/v/7b54dde10b33/gesellschaft-verkehr-barges-maindanube-canal-in-bamberg-picture-id1094480316.jpg)20.12.2024Pressemitteilung[#### Transport auf Berlins Wasserstraßen von Januar bis September 2024: Leichter Anstieg bei der Güterbeförderung](/172-2024)

Auf den Binnenwasserstraßen Berlins wurden in den ersten drei Quartalen 2024 insgesamt 909.451 Tonnen Güter befördert.

[Ansehen](/172-2024)![iStock – JTeivans](https://download.statistik-berlin-brandenburg.de/c9c96976ef6cf996/8300f9a7cdc6/v/f91b487ccb35/gesellschaft-verkehr-iStock-1292440193.jpg)18.12.2024Statistischer Bericht[#### Oktober 2024, monatlich, H I 1 – m: Straßenverkehrsunfälle in Berlin und Brandenburg](/h-i-1-m)

Die Statistik der Straßenverkehrsunfälle informiert monatlich über polizeilich aufgenommene Unfälle in der Region. 

[Ansehen](/h-i-1-m)Mehr anzeigen


