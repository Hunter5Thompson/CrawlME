

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Einkommen und Konsum](/einkommen-und-konsum)

**Einkommen und**Konsum
=======================

Die Einkommens- und Verbrauchsstichprobe (EVS) ist die größte freiwillige Haushaltser­hebung der amtlichen Statistik. Sie wird alle fünf Jahre durchgeführt, zuletzt 2018. Durch die EVS erfährt man, wie viel Geld den Haus­halten in Deutsch­land zur Verfügung steht und wofür sie es ausgeben.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Ausstattung mit ausgewählten Gebrauchsgütern und Wohnsituation privater Haushalte, fünfjährlich (OII1-5j)](/o-ii-1-5j)[Haus- und Grundbesitz, Geldvermögen und Schulden privater Haushalte, fünfjährlich (OII2-5j)](/o-ii-2-5j)[Einkommen und Einnahmen sowie Ausgaben privater Haushalte, fünfjährlich (OII3-5j)](/o-ii-3-5j)[Aufwendungen privater Haushalte für Nahrungsmittel, Getränke und Tabakwaren, fünfjährlich (OII4-5j)](/o-ii-4-5j)

Zeitreihen
----------

HaushaltseinkommenEinkommen, Einnahmen, AusgabenSparquote1 Ergebnisse der LWR**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/79c3a9338cb7be96/164015eeb343/LWR_Zeitreihe_2020_Berlin-Brandenburg.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/4419e71751210e32/acb060b47c53/einkommen-konsum-lange-reihe-2018.xls)

Basisdaten
----------

Weitere Datenangebote
---------------------

#### Konsumvergleichstool

![](https://download.statistik-berlin-brandenburg.de/deb1b18e1646f797/80df6f4d190d/v/2edc96369a6b/Konsumvergleichstool.PNG)

Mit dieser Anwendung können Sie Ihre Ausgaben mit den Durchschnitts­werten der Haushalte vergleichen, die Ihrem am ähnlichsten sind.

[Zum Konsumvergleichstool](https://www.konsumvergleich.de/konsumvergleich/)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1715694545479&code=63#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Nicole Baier

Haushaltserhebungen

#### Nicole Baier

Haushaltserhebungen

* [0331 8173-1912](tel:0331 8173-1912)
* [evs@statistik-bbb.de](mailto:evs@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-1165069915.jpg](https://download.statistik-berlin-brandenburg.de/cd903507df7f8bea/e0ef577c293e/v/6a9825fa056b/einkommen-konsum.jpg "iStock-1165069915.jpg")](/088-2024)**Ausgaben privater Haushalte 2022 in Berlin und Brandenburg**[#### Mehr Konsum, weniger Sparen](/088-2024)

Die privaten Haushalte in Berlin und Brandenburg nutzten ihr gestiegenes verfügbares Einkommen für vermehrten Konsum....

[![iStock.com / JJFarquitectos](https://download.statistik-berlin-brandenburg.de/6fa6ce9b156d3d63/504c134f19e9/v/f2d4980f3df3/wirtschaft-preise-verbraucherpreise-closeup-photo-of-stylish-woman-taking-money-picture-id842875452.jpg "iStock.com / JJFarquitectos")](/167-2023)**Einkommens- und Verbrauchsstichprobe (EVS) 2023**[#### Haushalte in Berlin und Brandenburg gesucht](/167-2023)

Pressemitteilung Nr. 167 Die Einkommens- und Verbrauchsstichprobe (EVS) ist die größte freiwillige Erhebung der amtlichen Statistik und findet im fünfjährigen Rhythmus statt. Das Amt für Statistik...

[![iStock.com / Grafner](https://download.statistik-berlin-brandenburg.de/9aa00320c7d90f97/c0ca52f7f8a3/v/b12e76723d9f/gesellschaft-arbeit-finance-business-euro-stock-background-picture-id670891402.jpg "iStock.com / Grafner")](/101-2023)**Einkommens- und Verbrauchsstichprobe 2023 Berlin und Brandenburg**[#### Weiterhin Haushalte für Teilnahme gesucht](/101-2023)

Pressemitteilung Nr. 101 Wie viel und wofür geben die Menschen Geld aus? Wie hoch sind die Ausgaben für Lebensmittel, Wohnen, Verkehr und andere Dinge? Antworten auf diese und weitere Fragen liefert...

[Zu unseren News](/news)

[* Verbrauch](/search-results?q=tag%3AVerbrauch)[* Haushalt](/search-results?q=tag%3AHaushalt)[* Haushaltserhebung](/search-results?q=tag%3AHaushaltserhebung)[* Konsumausgaben](/search-results?q=tag%3AKonsumausgaben)[* Gebrauchsgüter](/search-results?q=tag%3AGebrauchsgüter)[* Verbraucherverhältnisse](/search-results?q=tag%3AVerbraucherverhältnisse)[* Haushaltsbücher](/search-results?q=tag%3AHaushaltsbücher)
