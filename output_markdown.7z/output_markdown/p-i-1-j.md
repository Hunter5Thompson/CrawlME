

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Bruttoinlandsprodukt und Bruttowertschöpfung in Berlin und Brandenburg nach Wirtschaftsbereichen](/p-i-1-j)

Bruttoinlandsprodukt und Bruttowertschöpfung nach Wirtschaftsbereichen
----------------------------------------------------------------------

#### 1991 bis 2023, jährlich

###### Das Bruttoinlandsprodukt (BIP) misst alle im Inland produzierten Güter und Dienstleistungen abzüglich der Vorleistungen. Dabei drückt die Veränderungsrate des preisbereinigten BIP die wirtschaftliche Entwicklung einer Region aus und wird auch als Wirtschaftswachstum bezeichnet.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg; Berechnungsstand: August 2023/Februar 2024
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f277a45deaddce41/10796ca5d664/SB_P01-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/a2eab55780fa0703/cea3df51a244/SB_P01-01-00_2023j01_BE.pdf)

**Gegen den nationalen Trend: Wirtschaft wächst**

Das preisbereinigte Bruttoinlandsprodukt (BIP) war 2023 in Berlin nach ersten Berechnungen um 1,6 % höher als im Vorjahr. Bundesweit nahm das BIP 2023 um 0,3 % ab. Im Bundesländervergleich erreichte die Hauptstadt die dritthöchste Zuwachsrate.

Wachstumstreiber der Berliner Wirtschaft waren die Dienstleistungsbereiche mit einem preisbereinigten Anstieg um 2,0 % (Deutschland: +0,5 %) gegenüber dem Vorjahr. Mit einer Steigerung der Wertschöpfung um 6,2 % steuerte der Wirtschaftsbereich Information und Kommunikation mehr als ein Drittel zum gesamten Berliner Wirtschaftswachstum bei.

Der Wert aller in Berlin 2023 produzierten Waren und Dienstleistungen betrug 193,2 Milliarden EUR. Das entsprach einem Anteil von 4,7 % am deutschen Bruttoinlandsprodukt.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Starkes Wirtschaftswachstum** 

Im Jahr 2023 verzeichnete das preisbereinigte Bruttoinlandsprodukt (BIP) von Brandenburg, nach ersten Berechnungen, einen Anstieg von 2,1 % gegenüber dem Vorjahr. Im Vergleich zu den anderen Bundesländern war dies die zweithöchste Zuwachsrate.

Mit einem preisbereinigten Anstieg um 17,5 % gegenüber 2022 sorgte vor allem das Verarbeitende Gewerbe für Wachstumsimpulse in Brandenburg. Insbesondere der im Verarbeitenden Gewerbe beschäftigten- und umsatzstärkste Industriezweig, die Herstellung von Kraftwagen und Kraftwagenteilen, trug zum Wachstum bei.

Der Wert aller 2023 in Brandenburg produzierten Waren und Dienstleistungen betrug 97,5 Milliarden EUR. Das entsprach einem Anteil von 2,4 % am deutschen Bruttoinlandsprodukt.

**Quelle:** Volkswirtschaftliche Gesamtrechnungen der Länder; Berechnungsstand: August 2023/Februar 2024
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/aa1ffb6484ae096e/5b89bd0c76f4/SB_P01-01-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/736168a206e805ea/f6459d3c97bd/SB_P01-01-00_2023j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das Bruttoinlandsprodukt umfasst den Wert aller innerhalb eines Wirtschaftsgebietes während einer bestimmten Periode produzierten Waren und Dienstleistungen. Es entspricht der Bruttowertschöpfung aller Wirtschaftsbereiche zuzüglich der Gütersteuern und abzüglich der Gütersubventionen. Die Bruttowertschöpfung ergibt sich aus der Differenz der Produktionswerte und der Vorleistungen in den einzelnen Wirtschaftsbereichen.

Ergebnisse für alle Bundesländer und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

  


#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)
