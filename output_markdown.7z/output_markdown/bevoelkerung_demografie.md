

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)

Demografie
==========

Die Demografie untersucht die Zusammensetzung und Entwicklung einer Bevölkerung mithilfe der Bevölkerungsstatistik. Sie erfasst Geburten, Sterbefälle und Wanderungen. Wichtige Kennzahlen sind der Wanderungssaldo oder die Lebenserwartung.

Die [Einwohnerregisterstatistik](/kommunalstatistik) für Berlin umfasst Daten von Personen, die offiziell in der Stadt gemeldet sind und liefert Informationen auf lokaler Ebene. Sie bildet die Grundlage für Entscheidungen in den Bereichen Gesundheit, Soziales und Stadtplanung.

Mit dem [Mikrozensus](/bevoelkerung/demografie/mikrozensus) werden jährlich 1 % aller Haushalte befragt – in Berlin rund 18.000 und in Brandenburg rund 11.000. Er stellt Informationen zur wirtschaftlichen und sozialen Lage der Bevölkerung und zum Arbeitsmarkt bereit.

BerlinBrandenburg

**Alterspyramide 2023 in Berlin,****Basis: Zensus 2022**

**Quelle:** Amt für Statistik Berlin-Brandenburg[Bevölkerung auf Gemeindeebene
#### Bevölkerungsstand](/bevoelkerung/demografie/bevoelkerungsstand)[Natürliche Bevölkerungsbewegung
#### Geburten, Sterbefälle, Eheschließungen](/bevoelkerung/demografie/geburten-sterbefaelle-eheschliessungen)[Wanderungen
#### Zu- und Fortzüge](/bevoelkerung/demografie/zu-und-fortzuege)[Ausländische Bevölkerung
#### Einbürgerungen, Ausländer](/bevoelkerung/demografie/einbuergerungen-auslaender)[Kleinräumige Einwohnerdaten für Berlin
#### Einwohnerregisterstatistik](/kommunalstatistik)[Haushalte und Familien
#### Mikrozensus](/bevoelkerung/demografie/mikrozensus)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Demografie

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Neues aus dem Bereich Demografie

Zuletzt veröffentlicht
----------------------

![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg)19.12.2024Artikel[#### Unterschiede in der amtlichen Datenaufbereitung: Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf. 

[Ansehen](/news/2024/einwohner-oder-bevoelkerung)![iStock.com / Dmytro Varavin](https://download.statistik-berlin-brandenburg.de/dafdd0edce64b1a7/f48269a57bf6/v/bdbe069a4e98/bevoelkerung-demographie-aerial-interested-crowd-of-people-in-one-place-top-view-from-drone-picture-id1190039899.jpg)19.12.2024Statistischer Bericht[#### 31.12.2023, jährlich, A I 3 – j: Bevölkerungsstand in Berlin und Brandenburg – Jahresergebnisse](/a-i-3-j)

In der Bevölkerungsfortschreibung wird der Bevölkerungsbestand einer Region rechnerisch ermittelt.

[Ansehen](/a-i-3-j)![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png)19.12.2024Artikel[#### Unterschiede in der amtlichen Datenaufbereitung: Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[Ansehen](/news/2024/zensus-melderegister)Mehr anzeigen
#### Hintergrund

Bevölkerungsentwicklung
-----------------------

Die Ver­ände­rung der Alters­struktur der Bevölkerung in Deutschland ist eines der größ­ten gesell­schafts­po­li­ti­schen Heraus­for­de­rungen. Durch Geburten­rück­gang und steigende Lebens­er­war­tung ist die Geburtenrate seit einigen Jahrzehnten geringer als die Sterberate. Der Anteil der Älteren gegenüber den Jüngeren nimmt zu. Wesentlichen Einfluss auf den demografischen Wandel nehmen ebenfalls die Zu- und Fortzüge in eine bzw. aus einer Region.

###### Welche Merkmale werden erhoben?

Grundsätzlich wird zwischen natürlicher und räumlicher Bevölkerungsbewegung unterschieden. Die natürliche Bevölkerungsbewegung erfasst Merkmale wie: Geburts-, Sterbe- und Eheschließungsdatum, Geschlecht, Staatsangehörigkeit und Wohngemeinde. Die räumliche Bevölkerungsbewegung erfasst die Merkmale: Datum des Ein- oder Auszugs, alte und neue Wohngemeinde, Geschlecht, Alter, Familienstand und Staatsangehörigkeit. Die tiefste regionale Einheit aller Statistiken ist die Gemeindeebene.

###### Was ist eine Bevölkerungsbilanz?

Die Bevölkerungsbilanz ist ein Verfahren zur Fortschreibung der Bevölkerung eines Gebietes. Die Ergebnisse der jeweils letzten Volkszählung werden auf Gemeindeebene mit den Ergebnissen der Statistiken der natürlichen Bevölkerungsbewegung (Geburten, Sterbefälle, Eheschließungen und Ehelösungen) sowie der Wanderungsstatistik (Zu- und Fortzüge) über die Gemeindegrenzen fortgeschrieben.

###### Was ist eine Bevölkerungsvorausberechnung?

Mit Bevölkerungsvorausberechnungen werden langfristige Entwicklungen der Bevölkerung aufgezeigt. Veränderungen in der Altersstruktur und in der räumlichen Verteilung werden sichtbar. Dabei kommt das Modell der Komponentenfortschreibung zur Anwendung. Mittels bestimmter Annahmen zur Geburtenhäufigkeit, Lebenserwartung und den Wanderungen zeigen sich die Veränderungen für jedes einzelne Jahr.


