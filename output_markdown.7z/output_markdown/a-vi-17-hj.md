

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Erwerbstätigkeit](/erwerbstaetigkeit)
* [Geleistete Arbeitsstunden in Berlin und Brandenburg](/a-vi-17-hj)

Geleistete Arbeitsstunden
-------------------------

#### 2014 bis 2023, halbjährlich

###### Die jährlichen Ergebnisse zum Arbeitsvolumen (Inlandskonzept) geben den Gesamtumfang der tatsächlich geleisteten Arbeitszeit aus der Erwerbstätigenrechnung des Arbeitskreises „Erwerbstätigenrechnung der Länder“ wieder, darunter Zahlen zu Erwerbstätigen, Selbstständigen sowie Arbeitnehmerinnen und Arbeitnehmern nach ausgewählten Wirtschaftsbereichen.

BerlinBrandenburgMethodik

Berlin
------

 **Quelle:**  Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: August 2024)
#### **Zum Statistischen Bericht – Berechnungsstand: August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/dbd4ecbc3441f2e0/61ea9a61dba8/SB_A06-17-00_2023hj2_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/1a48bd369fa496ad/45672c15ca5a/SB_A06-17-00_2023hj2_BE.pdf)

**Arbeitsvolumen 2023 in Berlin gestiegen**

In Berlin wurden 2023 rund 2,95 Milliarden Arbeitsstunden von den Erwerbstätigen erbracht. Damit nahm das Arbeitsvolumen in Berlin gegenüber dem Vorjahr um 0,9 % zu. Bundesweit erhöhte sich die tatsächlich geleistete Arbeitszeit durchschnittlich um 0,4 %.

Die Zunahme des gesamtwirtschaftlichen Arbeitsvolumens 2023 in Berlin ist auf einen Anstieg bei der Zahl der Erwerbstätigen zurückzuführen: Im Vergleich zum Vorjahr erhöhte sich die Erwerbstätigkeit in Berlin um 1,6 %. Das durchschnittliche Arbeitsvolumen je Erwerbstätigen 2023 in Berlin nahm hingegen um 0,7 % (–9 Stunden) ab und betrug 1.346 Stunden. Bundesweit ging die Pro-Kopf-Arbeitszeit 2023 um 0,4 % (–5 Stunden) auf 1.335 Stunden zurück.

### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Arbeitsvolumen 2023 in Brandenburg nahezu unverändert**

Im Jahr 2023 wurden von den Erwerbstätigen in Brandenburg rund 1,57 Milliarden Arbeitsstunden erbracht. Damit blieb die tatsächlich geleistete Arbeitszeit in Brandenburg im Vergleich zum Vorjahr nahezu unverändert (0,0 %). Nach Berechnungen des Arbeitskreises „Erwerbstätigenrechnung der Länder“ erhöhte sich das Arbeitsvolumen in Westdeutschland ohne Berlin um 0,4 %, in Ostdeutschland ohne Berlin ging es um 0,1 % zurück.

In Brandenburg blieb das gesamtwirtschaftliche Arbeitsvolumen 2023 trotz eines Anstiegs der Erwerbstätigenzahl um 0,3 % auf dem Vorjahresniveau. Das resultierte aus einem Rückgang bei der Pro-Kopf-Arbeitszeit: Die geleisteten Arbeitsstunden je Erwerbstätigen gingen 2023 in Brandenburg um durchschnittlich 0,4 % (–5 Stunden) auf 1.371 Stunden zurück. Dennoch lag 2023 die Arbeitszeit in Brandenburg je Erwerbstätigen noch um 36 Stunden über der durchschnittlichen Pro-Kopf-Arbeitszeit in Deutschland (1.335 Stunden).

 Der Wert im Bereich Finanz-, Versicherungs- und Unternehmensdienstleister; Grundstücks- und Wohnungswesen beträgt gerundet 0,0 %.**Quelle:** Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: August 2024)
#### **Zum Statistischen Bericht – Berechnungsstand: August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f2bb32d96826a7f5/459ca29baa02/SB_A06-17-00_2023hj2_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/fe085e2360122954/fb96323d683b/SB_A06-17-00_2023hj2_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

**Methodik und weitere Informationen**

Die Erwerbstätigenrechnung (ETR) liefert ein umfassendes Bild der wirtschaftlich aktiven Bevölkerung. Auf der Grundlage einer Vielzahl erwerbsstatistischer Datenquellen wird neben der Zahl der Erwerbstätigen am Arbeitsort (Inlandskonzept) und Wohnort (Inländerkonzept) auch das Arbeitsvolumen am Arbeitsort nach der Stellung im Beruf und der wirtschaftsfachlichen Gliederung ermittelt.

Das Arbeitsvolumen umfasst die tatsächlich geleistete Arbeitszeit (in Arbeitsstunden) aller Erwerbstätigen, die als Arbeitnehmerinnen bzw. Arbeitnehmer oder als Selbstständige bzw. mithelfende Familienangehörige eine auf wirtschaftlichen Erwerb gerichtete Tätigkeit ausüben. Hierzu zählen auch die geleisteten Arbeitsstunden von Personen, die mehreren Beschäftigungsverhältnissen gleichzeitig nachgehen. Bezahlte, aber nicht geleistete Arbeitsstunden, beispielsweise wegen Jahresurlaub, Elternzeit, Feiertagen, Kurzarbeit oder krankheitsbedingter Abwesenheit gehören hingegen nicht zum Arbeitsvolumen.

Ergebnisse für das Bundesgebiet werden vom Statistischen Bundesamt berechnet, für die Länder sowie Landkreise und kreisfreien Städte vom Arbeitskreis „Erwerbstätigenrechnung der Länder“ (AK ETR). Die hier vorliegenden Zahlen sind Ergebnisse des AK ETR, die auf den Rechenstand des Statistischen Bundesamtes vom August 2024 abgestimmt sind.

Im Jahr 2024 fand in Deutschland – wie in den meisten Mitgliedstaaten der Europäischen Union – eine umfassende Revision der Volkswirtschaftlichen Gesamtrechnungen einschließlich der Erwerbstätigenrechnung statt. In den hier vorliegenden Statistischen Berichten sind erste, noch vorläufige, revidierte Ergebnisse zu den geleisteten Arbeitsstunden am Arbeitsort in den Ländern Berlin und Brandenburg für die Jahre 2014 bis 2023 enthalten. Um den Datennutzerinnen und -nutzern weiterhin methodisch konsistente Zeitreihen zur Verfügung zu stellen, werden auch die Ergebnisse zurück bis 2000 neu berechnet. Die Neuberechnung der Ergebnisse der Jahre 2000 bis 2013 erfolgt zeitlich versetzt, die Veröffentlichung dieser revidierten Zeitreihe erfolgt voraussichtlich Ende März 2025. Weitere Informationen zur Revision 2024 in der regionalen ETR können den [Metadaten zu dieser Statistik](/646c7aa9d793fcf3 "Verknüpfung folgen") sowie der [Internetseite des AK ETR](https://www.statistikportal.de/de/etr/generalrevision-2024 "Verknüpfung folgen") entnommen werden.

Nächste Aktualisierung: März 2025

Ergebnisse zum Arbeitsvolumen aller Bundesländer Deutschlands sowie zum Arbeitsvolumen aller Landkreise und kreisfreien Städte Deutschlands stellt der AK ETR unter [www.statistikportal.de/de/etr](https://www.statistikportal.de/de/etr "Verknüpfung folgen") zur Verfügung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erwerbstätige**ab 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/d563d8e3618b0841/82b68e999058/MD_13300_2024.pdf)[Archiv](/search-results?q=MD_13300&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)
