

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Geburten, Sterbefälle, Eheschließungen](/bevoelkerung/demografie/geburten-sterbefaelle-eheschliessungen)

Geburten, Sterbefälle, Eheschließungen
======================================

Zur natürlichen Bevölkerungsbewegung gehören die Geburtenstatistik, die Sterbefallstatistik sowie die Statistik der Eheschließungen. Die auskunftspflichtige Vollerhebung liefert monatlich Grunddaten nach demografischen Merkmalen für die Berechnung der Fortschreibung des Bevölkerungsstandes, für demografische Analysen und Vorausberechnungen.

Darüber hinaus dienen die Angaben für die Abbildung der Geburtenziffern, der Sterblichkeitsverhältnisse, der Lebenserwartung in der Bevölkerung und des Eheschließungsverhaltens.

Informationen zu den Geburten- und Sterbedaten der Kommunalstatistik Berlin auf kleinräumiger Ebene finden Sie [hier](/kommunalstatistik/wanderungen-berlin).

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Geburte, Sterbefälle und Eheschließungen in Berlin und Brandenburg, jährlich (AII1-j)](/a-ii-1-j)[Bevölkerungsstand in Berlin und Brandenburg, monatlich (AI7-m, AII3-m, AIII3-m)](/a-i-7-a-ii-3-a-iii-3-m)

Zeitreihen
----------

Geburten, SterbefälleEheschließungen, HeiratsalterMonatsdaten – GeburtenMonatsdaten – Sterbefälle**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/0986debf875713cf/dcff1cccaf00/geburten-sterbefaelle-zeitreihen.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/8f6778767e81fa53/68f7b30ab421/geburten-sterbefalle-und-eheschliessungen-lange-reihe.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Berlin 2023

#### Lebendgeborene

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburg 2023

#### Lebendgeborene

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1714041722870&code=12#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/bevoelkerung)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1714041693402&code=12#abreadcrumb)
#### StatIS-BBB

![](https://download.statistik-berlin-brandenburg.de/78324daa1d8c4302/8f3a5e8bad38/v/4b6c25f57664/statis-bbb-schmuckbild.jpg)

Im Statistischen Informationssystem lassen sich individuelle Auswertungen auf Basis von regional tief gegliederten Daten erstellen und exportieren.

[Zu StatIS-BBB](https://statis.statistik-berlin-brandenburg.de/webapi/jsf/dataCatalogueExplorer.xhtml)

Haben Sie Fragen?
-----------------

#### Myga Grobert

Bevölkerungsstatistiken

#### Myga Grobert

Bevölkerungsstatistiken

* [0331 8173-3378](tel:0331 8173-3378)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Astrid Graupner

Bevölkerungsstatistiken

#### Astrid Graupner

Bevölkerungsstatistiken

* [0331 8173-3390](tel:0331 8173-3390)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Iris Hoßmann-Büttner

Bevölkerungs- und Kommunalstatistik

#### Iris Hoßmann-Büttner

Bevölkerungs- und Kommunalstatistik

* [0331 8173-3624](tel:0331 8173-3624)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / simarik](https://download.statistik-berlin-brandenburg.de/e4a218676166e7e2/7544533f353a/v/737bb29eb13f/bevoelkerung-gesellschaft-divorce-picture-id1133419016.jpg "iStock.com / simarik")](/144-2024)**Eheschließungen und Ehescheidungen in Berlin und Brandenburg 2023**[#### Rückläufige Zahlen bei Ehen und Scheidungen](/144-2024)

Pressemitteilung Nr. 144 In Berlin und Brandenburg wurden 2023 insgesamt 23.324 Ehen geschlossen und 9.190 Ehen geschieden. Sowohl für die Eheschließungen als auch für die Ehescheidungen ist in der...

[![iStock.com / Maria Korneeva](https://download.statistik-berlin-brandenburg.de/4613517aa0aca401/e29caa424659/v/3750d2a5b46e/bevoelkerung-gesellschaft-baby-feet-in-mother-hands-picture-id1162503726.jpg "iStock.com / Maria Korneeva")](/101-2024)**Geburten, Sterbefälle und Eheschließungen 2023 in Brandenburg**[#### Geburtenrückgang setzt sich fort](/101-2024)

Pressemitteilung Nr. 101 Im Land Brandenburg wurde 2023 der höchste Sterbeüberschuss seit der Wiedervereinigung erreicht. Es starben 20.737 Personen mehr als Kinder geboren wurden. Grund für den...

[![Geburt Baby mit Mutter](https://download.statistik-berlin-brandenburg.de/0528115e092ee55e/fbd2650e479b/v/f8babb02dd00/bevoelkerung-gesellschaft-geburt-baby "Geburt Baby mit Mutter")](/102-2024)**Geburten, Sterbefälle und Eheschließungen 2023 in Berlin** [#### Durchschnittliche Kinderzahl je Frau sinkt auf 1,17](/102-2024)

Pressemitteilung Nr. 102 Die Hauptstadt verzeichnete im Jahr 2023 weiterhin einen hohen Geburtenrückgang von 4,4 %. Über das Jahr verteilt wurden 34.120 Kinder geboren, 1.609 weniger als im Jahr das...

[Zu unseren News](/news)

[* Natürliche Bevölkerungsbewegung](/search-results?q=tag%3ANatürliche Bevölkerungsbewegung
)[* Lebendgeborene](/search-results?q=tag%3ALebendgeborene
)[* Totgeborene](/search-results?q=tag%3ATotgeborene
)[* Geburtenziffer](/search-results?q=tag%3AGeburtenziffer
)[* Gestorbene](/search-results?q=tag%3AGestorbene
)[* Sterblichkeit](/search-results?q=tag%3ASterblichkeit)[* Eheschließungen](/search-results?q=tag%3AEheschließungen)[* Heiratsalter](/search-results?q=tag%3AHeiratsalter)
