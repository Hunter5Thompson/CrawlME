

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Wasser](/wasser)
* [Wasser- und Abwasserentgelte in Berlin und Brandenburg](/q-i-3-3j)

Wasser- und Abwasserentgelte
----------------------------

#### 2020 bis 2022, dreijährlich

###### Die Statistik liefert dreijährlich Daten zu den durchschnittlichen Entgelten für die Trinkwasserversorgung sowie die Abwasserentsorgung privater Haushalte.

BerlinBrandenburgMethodikArchiv
### Berlin

1 Daten jeweils zum Stichtag 01.01.2 Nach Einwohnenden gewichtet, in Brutto.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/933261aab3890fde/e852f221b020/SB_Q01-03-00_2022j03_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/8996339bcfd934e5/a2bbacc456e9/SB_Q01-03-00_2022j03_BE.pdf)

**Entgelte weitgehend stabil**

Das durchschnittliche verbrauchsabhängige Entgelt für die Trinkwasserversorgung privater Haushalte in Berlin betrug von 2020 bis 2022 konstant 1,81 EUR/m³. Als Grundgebühr waren in allen drei Jahren 17, 58 EUR zu entrichten.

Auch für die Abwasserentsorgung veränderte sich im betrachteten Zeitraum die Grundgebühr nicht. Sie betrug durchweg 16,42 EUR/Jahr. Das verbrauchsabhängige Entgelt sank von 2021 zu 2022 um 6 Cent auf 2,15 EUR/m³. Das Niederschlagswasserentgelt für versiegelte oder sonstige Flächen stieg indessen um 1 Cent auf 1,81 EUR/m².

  


### Kontakt

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1282](tel:0331 8173-1282)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Ver- und Entsorgung teurer**

In Brandenburg stieg das durchschnittliche verbrauchsabhängige Entgelt für die Trinkwasserversorgung privater Haushalte zwischen 2020 bis 2022 von 1,55 EUR/m³ auf 1,57 EUR/m³. Zusätzlich erhöhte sich die durchschnittliche jährliche Grundgebühr im selben Zeitraum von 81,89 EUR auf 82,76 EUR.

Die für die Abwasserentsorgung zu entrichtende Grundgebühr nahm um 67 Cent auf 90,61 EUR zu. Das verbrauchsabhängige Entgelt erhöhte sich um 4 Cent auf 3,20 EUR/m³, während das Niederschlagswasserentgelt für versiegelte oder sonstige Flächen mit 0,95 EUR/m² zu Buche schlug. 2020 waren es 0,90 EUR/m².

1 Daten jeweils zum Stichtag 01.01.2 Nach Einwohnenden gewichtet, in Brutto.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/708331a834c36367/322d3787d58a/SB_Q01-03-00_2022j03_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/5328a531f78733fa/85b4edeebb11/SB_Q01-03-00_2022j03_BB.pdf)
### Kontakt

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1282](tel:0331 8173-1282)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung dient der regelmäßigen Darstellung der öffentlichen Wasser- und Abwasserentgelte, die der Endverbraucher aufbringen muss. Die erhobenen Daten werden benötigt, um zu aussagekräftigen Ergebnissen über die Preise und Gebühren für die öffentliche Wasserversorgung und Abwasserentsorgung zu gelangen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erhebung der Wasser- und Abwasserentgelte**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/0e80a3da35f7f130/2afbbb712530/MD_32271_2022.pdf)[Archiv](/search-results?q=MD_32271&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/q-i-3-3j)
