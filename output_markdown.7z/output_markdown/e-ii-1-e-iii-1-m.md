

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Bauen und Wohnungen](/bauen-und-wohnungen)
* [Baugewerbe in Berlin und Brandenburg](/e-ii-1-e-iii-1-m)

Baugewerbe
----------

#### monatlich, September 2024

###### Die monatlichen Daten zum Baugewerbe liefern ein zeitnahes Abbild der konjunkturellen Lage der Baubranche auf Ebene der Bundesländer und bezogen auf alle Betriebe von rechtlichen Einheiten mit mindestens 20 Beschäftigten.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/0c4596c466216aaf/13ce006a43ae/SB_E02-01-00_2024m09_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/53ef769c3d9a8f99/e9c28ed3f412/SB_E02-01-00_2024m09_BE.pdf)

**Weniger Umsatz aber höhere Aufträge**

Die Betriebe des Berliner Bauhauptgewerbes meldeten im September 2024 weniger Umsätze aber mehr Auftragseingänge als im September 2023, teilt das Amt für Statistik Berlin-Brandenburg mit.

Die Berliner Betriebe des Bauhauptgewerbes mit 20 und mehr tätigen Personen erwirtschafteten im September einen baugewerblichen Umsatz in Höhe von 356,2 Millionen EUR. Gegenüber dem Vorjahresmonat ist das ein Rückgang um 6,1 %. Der Auftragseingang betrug 251,9 Millionen EUR, 14,9 % mehr als im September 2023. Die Zahl der tätigen Personen betrug 15.539. Das ist ein Rückgang um 4,7 % gegenüber dem Vorjahreswert. Die Entgelte stiegen um 3,6 % auf insgesamt 62,7 Millionen EUR. Auf den Baustellen wurden 1,6 Millionen Arbeitsstunden geleistet. Das sind 4,9 % weniger als im September 2023.

  


### Kontakt

#### Marlies Quägwer

Bauhauptgewerbe

#### Marlies Quägwer

Bauhauptgewerbe

* [0331 8173-3831](tel:0331 8173-3831)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Birgit Wimmer

Ausbaugewerbe

#### Birgit Wimmer

Ausbaugewerbe

* [0331 8173-3057](tel:0331 8173-3057)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Rückgang bei Umsätzen und Auftragseingängen**

In Brandenburg erzielten die Betriebe des Bauhauptgewerbes mit 20 und mehr tätigen Personen im September 2024 einen baugewerblichen Umsatz in Höhe von 337,3 Millionen EUR, das waren 19,1 % weniger als im September 2023.

Der Auftragseingang betrug 230,6 Millionen EUR. Das sind 38,2 % weniger als im Vorjahresmonat. Im Hochbau wurde ein Auftragsplus von 9,3 % ermittelt, im Tiefbau ein Auftragsminus von 55,4 %.

Die Zahl der tätigen Personen stieg um 2,7 % auf 18.433 Personen. Die Entgelte betrugen 70,1 Millionen EUR und lagen somit um 8,2 % über dem Vorjahreswert. Es wurden 1,9 Millionen Arbeitsstunden auf den Baustellen geleistet. Das sind, je Arbeitstag berechnet, 1,1 % weniger als im September 2023.

  


  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/bf37fcf8a28decd2/6d98d6a4fd94/SB_E02-01-00_2024m09_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/b7e5ca8f748de4e9/531bd90d267b/SB_E02-01-00_2024m09_BB.pdf)
### Kontakt

#### Diana Geipel

Baugewerbe

#### Diana Geipel

Baugewerbe

* [0331 8173-3745](tel:0331 8173-3745)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Birgit Wimmer

Ausbaugewerbe

#### Birgit Wimmer

Ausbaugewerbe

* [0331 8173-3057](tel:0331 8173-3057)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Im Baugewerbe, einem Teil des Produzierenden Gewerbes, werden Unternehmen bzw. Betriebe des Baugewerbes befragt.

Das Baugewerbe unterscheidet zwei große Teilbereiche: das Bauhauptgewerbe und das Ausbaugewerbe. Im Bauhauptgewerbe werden Unternehmen bzw. Betriebe mit Tätigkeits­schwerpunkt im Bereich der vorbereitenden Baustellenarbeiten, dem Bau von Gebäuden und dem Tiefbau untersucht. Im Ausbaugewerbe liegt der Tätigkeitsschwerpunkt der Unternehmen bzw. Betriebe in der Bauinstallation und im sonstigen Ausbau. Mit der Umstellung auf die Klassifikation der Wirtschaftszweige (WZ 2008) wurde dem Baugewerbe noch ein weiterer Teil zugeordnet; die Bauträger.

Die Untersuchung des Baugewerbes erfolgt in unterschiedlichen zeitlichen Abständen. Die kurzfristigen Statistiken (Konjunkturstatistiken) werden monatlich und vierteljährlich und die langfristigen Statistiken (Strukturstatistiken) werden jährlich durchgeführt. Für die Konjunkturstatistiken werden im Wesentlichen Indikatoren wie Umsatz, tätige Personen, geleistete Arbeitsstunden, Entgelte, Auftragseingänge und Auftragsbestände erfasst. Die Strukturstatistiken liefern u. a. Informationen zu tätigen Personen, Umsatz und Investitionen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

**[Monatsbericht im Bauhauptgewerbe (einschl. Auftragseingangsindizes) (2018)](https://download.statistik-berlin-brandenburg.de/41c0916435265e27/b9099c4b14d3/MD_44111_2018.pdf)** | [Archiv](/search-results?q=MD_44111&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Vierteljahreserhebung im Ausbaugewerbe und bei Bauträgern (2018)](https://download.statistik-berlin-brandenburg.de/8698cfe42cc7253e/755ee98c7f95/MD_44131_2018.pdf)** | [Archiv](/search-results?q=MD_44131&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Statistik über den Auftragsbestand im Bauhauptgewerbe (einschl. Indizes)(2019)](https://download.statistik-berlin-brandenburg.de/7fe0b1dea0363e0e/a34069740773/MD_44141_2019.pdf)** | [Archiv](/search-results?q=MD_44141&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-ii-1-e-iii-1-m)
