

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Zensus](/bevoelkerung/zensus)

Zensus
======

Der Zensus ist eine Bevölkerungsbefragung. Diese ermittelt, wie viele Menschen in einem Land leben, wo sie wohnen und wie sie arbeiten. Die Ergebnisse des Zensus liefern wichtige Daten und Informationen für Politik, Wirtschaft und Gesellschaft.

BerlinBrandenburg

Einwohnerzahl am 15.05.2022

[Bevölkerungs- und Wohnungszählung 2022
#### Zensus 2022](/zensus22)[Bevölkerungs- und Wohnungszählung 2011
#### Zensus 2011](/bevoelkerung/zensus/zensus_2011)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Zensus

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg\* Die Geheimhaltung wird durch das Verfahren der stochastischen (also zufälligen) Überlagerung, der sogenannten Cell-Key-Methode, sichergestellt. Weitere Informationen zur Geheimhaltung beim Zensus erhalten Sie auf der Zensus-Seite www.zensus2022.de.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Neues aus dem Bereich Zensus

Zuletzt veröffentlicht
----------------------

![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png)19.12.2024Artikel[#### Unterschiede in der amtlichen Datenaufbereitung: Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[Ansehen](/news/2024/zensus-melderegister)![Schmuckbild Zensus 2022 Heizung und Gebäude](https://download.statistik-berlin-brandenburg.de/6566e7c034d35542/dc5b764f0d2f/v/9c28a2322780/Zensus.png)13.12.2024Pressemitteilung[#### Zensus 2022 für Berlin und Brandenburg: Zensusdaten ermöglichen Analysen unterhalb der Gemeindeebene](/168-2024)

Das Amt für Statistik Berlin-Brandenburg bietet ab sofort Auswertungen unterhalb der Gemeindeebene an.

[Ansehen](/168-2024)![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)18.11.2024Artikel[#### Zensus 2022 in Berlin und Brandenburg: So wächst die Generation Alpha auf](/news/2024/zensus-generation-alpha)

Der Zensus 2022 gibt Einblicke in die Einwanderungsgeschichte der Generation Alpha in Berlin und Brandenburg.

[Ansehen](/news/2024/zensus-generation-alpha)Mehr anzeigen
#### Eine registergestützte Erhebung

Ermittlung der Bevölkerungszahl
-------------------------------

Die Volkszählungen 1987 in der BRD bzw. 1981 in der DDR waren Vollerhebungen. Seit 2011 wird ein moderner, registergestützter Zensus durchgeführt. Hierfür werden Informationen aus dem Melderegister mit einer Stichprobe der Bevölkerung sowie mit Vollerhebungen an sensiblen Bereichen und einer Gebäude- und Wohnungszählung ergänzt. Mit dieser statistischen Erhebung wird ermittelt, wie viele Menschen in Deutschland leben, wie sie wohnen und arbeiten.

###### Wie wird bei der Bevölkerungserhebung befragt?

Zur Feststellung der amtlichen Einwohnerzahl wird auf die kommunalen Melderegister zurückgegriffen. Die Einwohnermeldeämter übermitteln zum geplanten Zensusstichtag am 15. Mai 2022 alle gemeldeten Personen an die Statistischen Landesämter. Durch die statistische Erhebung werden anschließend die in den Melderegistern vorhandenen Über- und Unterfassungen (sogenannte Karteileichen bzw. Fehlbestände) ermittelt. Darüber hinaus werden beim Zensus 2022 Daten erhoben, die nicht in den Melderegistern vorliegen.  


###### Für wen ist die Befragung relevant?

Politik, Verwaltung und Wirtschaft benötigen die Ergebnisse des Zensus als verlässliche Planungs- und Entscheidungsgrundlage, zum Beispiel für die Infrastrukturplanung von Kitas und Schulen. Dafür
liefert der Zensus Ergebnisse über aktuelle Bevölkerungszahlen, Daten zur
Demografie, u. a. Alter und Geschlecht, und Daten zur Wohn- und
Wohnungssituation wie durchschnittliche Wohnraumgröße, Leerstand oder
Eigentümerquote.

###### Wer wird befragt?

Für die Ermittlung der Einwohnerzahl wird mithilfe eines Zufallsverfahrens eine Stichprobe gezogen. Die Personen, die an diesen Anschriften wohnen, werden befragt und sind auskunftspflichtig ([ZensG 2022](https://www.gesetze-im-internet.de/zensg_2021/)). Für die Bewohnerschaft an sensiblen Bereichen (zum Beispiel Justizvollzugsanstalten) gibt die Einrichtungsleitung stellvertretend Auskunft. In der Gebäude- und Wohnungszählung ist jeder auskunftspflichtig, der Eigentümerin bzw. Eigentümer oder Verwalterin bzw. Verwalter von Wohnraum ist.

###### Was ist der Registerzensus?

Die Statistischen Ämter des Bundes und der Länder testen gegenwärtig eine neue Methode der Einwohnerzahlermittlung, um den nächsten Zensus belastungsärmer durchführen zu können. Dafür werden Daten verschiedener Register miteinander verglichen. Die gesetzliche Grundlage für diesen Datenabgleich ist das Registerzensuserprobungsgesetz aus dem Jahr 2021. Darüber hinaus haben alle statistischen Ämter der Länder und des Bundes eine Vereinbarung über die gemeinsame Verantwortlichkeit (gemäß Artikel 26 DS-GVO) für datenschutzrechtliche Fragen geschlossen. Weiterführende Informationen zum Registerzensus finden Sie auf der [Website des Statistischen Bundesamtes](https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Registerzensus/Aktuell/Vereinbarung_nach_Artikel_26_DSGVO.html).


