

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Realsteuerhebesätze der Städte und Gemeinden in Brandenburg](/l-ii-6-j)

Realsteuerhebesätze der Städte und Gemeinden in Brandenburg
-----------------------------------------------------------

#### II. Quartal 2024, jährlich

###### Die Hebesätze sind ein Faktor, der zur Ermittlung der Steuerschuld mit dem Steuermessbetrag multipliziert wird.

BrandenburgMethodik
### Brandenburg

**Hebesätze in Brandenburg**

Die Höhe der **Hebesätze** für die Grundsteuer A schwankte 2024 in den Gemeinden des Landes Brandenburg zwischen 200 % und 1.000 %.

Bei der Grundsteuer B lagen die Hebesätze zwischen 300 % und 545 %.

Die Hebesätze für die Gewerbesteuer lagen zwischen 240 % und 455 %.

Grundsteuer AGrundsteuer BGewerbesteuer
###### Grundsteuer A – Stand II. Quartal 2024 in Brandenburg

#### Realsteuerhebesätze der Städte und Gemeinden

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### **zum aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/2f60df947f53ce10/657045a8e1d4/SB_L02-06-00_2024j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/bd6381b65822d408/256f3d05b635/SB_L02-06-00_2024j01_BB.pdf)
### Kontakt

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Basis der Datenerhebung im Land Brandenburg sind Meldungen zur vierteljährlichen Kassenstatistik der Gemeindefinanzen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Realsteuervergleich**  
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/36ed545bbf7be862/d5ef55849833/MD_71231_2023.pdf)[Archiv](/search-results?q=71231&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-ii-6-j)
