

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
#### Überblick

Soziales
========

Die Sozialgesetzgebung trägt dazu bei, soziale Gerechtigkeit und soziale Sicherheit sowie ein menschenwürdiges Dasein zu sichern. Sie schafft gleiche Voraussetzungen für die freie Entfaltung der Persönlichkeit, schützt und fördert Familie und ermöglicht den Erwerb des Lebensunterhalts durch eine frei gewählte Tätigkeit.

BerlinBrandenburg

**Nettoausgaben der Sozialhilfe 2023 in Berlin in 1.000 EUR**(insgesamt 624,9 Mio. EUR)


Hinweis Berlin insgesamt = 539 859 **Quelle:** Amt für Statistik Berlin-Brandenburg[Empfänger von Sozialleistungen
#### Sozialhilfe](/gesellschaft/soziales/sozialhilfe)[Rehabilitation und Teilhabe
#### Menschen mit Behinderung/ Eingliederungshilfe](/menschen-mit-behinderung-eingliederungshilfe)[Zuschuss zu den Wohnkosten
#### Wohngeld](/wohngeld)[Förderung und Entwicklung junger Menschen
#### Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)[Leistungsberechtigte nach § 1 AsylbLG
#### Asylbewerberleistungen](/asylbewerberleistungen)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Soziales

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 Aufgrund eines Softwarewechsels kam es in der Zentralen Ausländerbehörde des Landes Brandenburg zu einer Untererfassung.**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
##### 

#### Neues aus dem Bereich Soziales

Zuletzt veröffentlicht
----------------------

![](https://download.statistik-berlin-brandenburg.de/d42214ea25c2ff44/38db7e9757e2/v/167a8129a0ec/bevoelkerung-gesellschaft-mutter-mit-kind-iStock-487157832.jpg)18.12.2024Statistischer Bericht[#### 2023, jährlich, K V 4 – j: Jugendhilfe in Berlin und Brandenburg – Vorläufige Schutzmaßnahmen](/k-v-4-j)

Grundgesamtheit der Statistik der vorläufigen Schutzmaßnahmen sind die beendeten Maßnahmen zum vorläufigen Schutz von Kindern und Jugendlichen.

[Ansehen](/k-v-4-j)![iStock.com / DMEPhotography](https://download.statistik-berlin-brandenburg.de/6679708146fed479/3ed29824da4c/v/f478b6b598ea/gesellschaft-soziales-three-caucasian-young-adults-in-discussion-picture-id882538900.jpg)05.12.2024Statistischer Bericht[#### 2023, zweijährlich, K V 6 – 2j: Jugendhilfe in Berlin und Brandenburg – Angebote der Jugendarbeit](/k-v-6-2j)

Aus der Statistik der Angebote der Jugendarbeit werden Erkenntnisse über die wichtigsten Dimensionen der Kinder- und Jugendarbeit gewonnen.

[Ansehen](/k-v-6-2j)![iStock.com / Pro-ve](https://download.statistik-berlin-brandenburg.de/a7a02b5b3de44cac/37df9a5b1f1a/v/d46843f56ea3/gesellschaft-soziales-skatebord-shadow-picture-id516232407.jpg)16.10.2024Statistischer Bericht[#### 2022, zweijährlich, K V 9 – 2j: Träger der Jugendhilfe, die dort tätigen Personen und deren Einrichtungen in Berlin und Brandenburg](/k-v-9-2j)

 Träger der Jugendhilfe, die dort tätigen Personen und deren Einrichtungen 15. Dezember 2022, zweijährlich Die Daten geben einen Überblick über die institutionelle und personelle Situation in der...

[Ansehen](/k-v-9-2j)Mehr anzeigen


