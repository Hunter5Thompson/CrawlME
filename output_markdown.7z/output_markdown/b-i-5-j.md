

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Schulen](/gesellschaft/bildung/schulen)
* [Absolventinnen und Absolventen/Abgängerinnen und Abgänger der allgemeinbildenden Schulen in Brandenburg](/b-i-5-j)

Absolventinnen und Absolventen/Abgängerinnen und Abgänger der allgemeinbildenden Schulen in Brandenburg
-------------------------------------------------------------------------------------------------------

#### 2023, jährlich

###### Der Bericht informiert über Absolventinnen und Absolventen sowie Abgängerinnen und Abgänger der allgemeinbildenden Schulen jeweils im Zeitverlauf und für das aktuell vorliegende Berichtsjahr in Brandenburg.

BrandenburgMethodik
### Brandenburg

**Mehr als jede zweite Person an allgemeinbildenden Schulen erreichte die allgemeine Hochschulreife**

In Brandenburg haben am Ende des Schuljahres 2022/23 an allgemeinbildenden Schulen 9.446 Absolventinnen und Absolventen die allgemeine Hochschulreife erreicht. Die Zahl der Absolventinnen mit diesem Abschluss beträgt 5.092, die der Absolventen 4.353.

Am Ende des Schuljahres 2022/23 verließen insgesamt 23.446 Absolventinnen und Absolventen/Abgängerinnen und Abgänger die Schulen. Das sind 998 mehr als am Ende des Schuljahres 2020/21. Dabei erreichten 4.496 Mädchen und 4.784 Jungen den Realschulabschluss/die Fachoberschulreife, 1.203 Mädchen und 1.807 Jungen den Hauptschulabschluss/die Berufsbildungsreife. Ohne Hauptschulabschluss/ohne Berufsbildungsreife verließen 649 Mädchen und 1.061 Jungen die Schulen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/68460a1094ca0e65/5a31a87d18f6/SB_B01-05-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/ae643e4ece7e0ee5/759d0815daba/SB_B01-05-00_2023j01_BB.pdf)
### Kontakt

#### Ramona Klasen

Schulen

#### Ramona Klasen

Schulen

* [0331 8173-1146](tel:0331 8173-1146)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Matthias Gebhard

Schulen

#### Matthias Gebhard

Schulen

* [0331 8173-1103](tel:0331 8173-1103)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der statistische Bericht enthält Ergebnisse über Schulen, Schülerinnen und Schüler, Absolventinnen und Absolventen, Abgängerinnen und Abgänge, und Lehrkräfte an beruflichen Schulen im Land Brandenburg im Berichtsjahr und nach Verwaltungsbezirken und staatlichen Schulämtern. Die Ergebnisse sind nach Ländersystematik aufbereitet und für Ländervergleiche nur bedingt geeignet.

Die Erhebung der Statistik der allgemeinbildenden und beruflichen Schulen (Schulstatistik) wird jährlich zu Schuljahresbeginn bzw. zum Schuljahresende, als koordinierte Länderstatistik durchgeführt. Auswertungen der erhobenen Daten werden in der regionalen Gliederung bis auf die Ebene der Verwaltungsbezirke auf der Basis des Schulstandortes vorgenommen. Diese Statistik wird als Totalerhebung mit Auskunftspflicht aller allgemeinbildenden und beruflichen Schulen des Landes Brandenburg in öffentlicher und freier Trägerschaft durchgeführt.

Zum Erhebungsprogramm der Schulstatistik gehören Angaben über Schulen, Klassen, Schülerinnen und Schüler, Absolventinnen und Absolventen, Abgänge­rinnen und Abgänger sowie Lehrkräfte. Die Schulstatistik liefert jährlich detaillierte Informationen u.a. über die Entwicklung der Schülerzahlen nach Bildungsgängen, zu Absolventinnen und Absolventen nach Abschlussarten und zu Lehrkräften.

Hauptnutzer sind das Ministerium für Bildung, Jugend und Sport, das Bundesministerium für Bildung und Forschung, die KMK, Eurostat, wissenschaftliche Einrichtungen und die interessierte Öffentlichkeit.

Im Land Brandenburg werden Individualdaten erhoben. Die Erhebungsmerkmale werden vom MBJS des Landes Brandenburg in Anlehnung an den Kerndatensatz der KMK festgelegt. Die regionale Zuordnung erfolgt nach dem Hauptstandort der Schule. Das berufliche Gymnasium wird dem allgemeinbildenden Bereich des Schulwesens zugeordnet.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der allgemeinbildenden Schulen**2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/a74a8856b4f26c8d/259fa97bcb96/MD_21111_2022.pdf)[Archiv](/search-results?q=22111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-i-5-j)


