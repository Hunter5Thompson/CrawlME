

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Verarbeitendes Gewerbe](/verarbeitendes-gewerbe)

VerarbeitendesGewerbe
=====================

Zur Grundlage amtlicher Industriestatistiken zählen im Inland gelegene Betriebe des Verarbeitenden Gewerbes, Bergbaus, Gewinnung von Steinen und Erden.

Die Konjunkturerhebungen umfassen kurzfristigen Statistiken mit unterjährigen Ergebnissen, wie dem Monatsbericht für Betriebe. Die Strukturerhebungen erscheinen dagegen in der Regel jährlich (zum Beispiel der Jahresbericht für Betriebe).

Über aktuelle Entwicklungen der Wirtschaftszweige des Produzierenden Gewerbes in Berlin und Brandenburg informieren die Statistischen Berichte.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Ergebnisse des Monats- und Jahresberichts für Betriebe in Berlin und Brandenburg, jährlich (EI1-j)](/e-i-1-j)[Monatsbericht für Betriebe im Verarbeitenden Gewerbe in Berlin und Brandenburg, monatlich (EI2-m)](/e-i-2-m)[Investitionen der Betriebe in Berlin und Brandenburg, jährlich (EI6-j)](/e-i-6-j)[Produktion in Berlin und Brandenburg, vierteljährlich (EI4-vj)](/e-i-4-vj)[Produktion in Berlin und Brandenburg, jährlich (EI5-j)](/e-i-5-j)

Zeitreihen
----------

UmsatzBetriebeExportquoteInvestitionen (Bruttozugänge)**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/f8413f5c92a9c477/d7fe627a3461/verarbeitendes-gewerbe-zeitreihe-2023.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/b7668e3a7e9dff07/6b0ca513715f/verarbeitendes-gewerbe-lange-reihe-2023.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Berliner Bezirke 2023

#### Verarbeitendes Gewerbe¹ ² in Berlin

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Landkreise und kreisfreie Städte 2023

#### Verarbeitendes Gewerbe¹ ² in Brandenburg

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1713867615659&code=42#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämter des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/industrie)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1713868141838&code=42#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Jacqueline Kupke

Verarbeitendes Gewerbe

#### Jacqueline Kupke

Verarbeitendes Gewerbe

* [0331 8173-3342](tel:0331 8173-3342)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Diana Wilde

Produktion & Investition Brandenburg

#### Diana Wilde

Produktion & Investition Brandenburg

* [0331 8173-3836](tel:0331 8173-3836)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Kati Bleck

VERARBEITENDES GEWERBE BERLIN

#### Kati Bleck

VERARBEITENDES GEWERBE BERLIN

* [0331 8173-3816](tel:0331 8173-3816 )
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Jeanette Miniers

Produktion & Investition Berlin

#### Jeanette Miniers

Produktion & Investition Berlin

* [0331 8173-3805](tel:0331 8173-3805)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Ines Neumann

VERARBEITENDES GEWERBE BRANDENBURG

#### Ines Neumann

VERARBEITENDES GEWERBE BRANDENBURG

* [0331 8173-3725](tel:0331 8173-3725)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / kzenon](https://download.statistik-berlin-brandenburg.de/23ca77d6e494af9e/53828dc4ee85/v/e46666581ae7/gesellschaft-arbeit-workers-supervising-the-manufacture-of-a-metallic-cylinder-picture-id811843552.jpg "iStock.com / kzenon")](/059-2023)**Berliner Industrie im Januar 2023**[#### Umsatzplus von 9 Prozent](/059-2023)

Pressemitteilung Nr. 59 Die Umsätze der 316 Berliner Industriebetriebe mit 50 und mehr tätigen Personen stiegen im Januar 2023 im Vergleich zum Vorjahresmonat um 9,0 Prozent auf 3,0 Mrd. EUR. Sie...

[![iStock-1134671737.jpg](https://download.statistik-berlin-brandenburg.de/c237ff5bad52c804/5b46801119ef/v/c6d1cfea4f5c/wirtschaft-wirtschaftsbereiche-logistik.jpg "iStock-1134671737.jpg")](/060-2023)**Brandenburger Industrie im Januar 2023**[#### Viel Umsatz zu Jahresbeginn](/060-2023)

Pressemitteilung Nr. 60 In Brandenburg stiegen die Umsätze der 422 Industriebetriebe mit 50 und mehr tätigen Personen im Januar 2023 im Vergleich zum Vorjahresmonat um 26,6 Prozent auf 3,0 Mrd. EUR....

[![iStock.com / Mumemories](https://download.statistik-berlin-brandenburg.de/3712ae99613918ca/8412ad4e4aab/v/1c0290516ba1/wirtschaft-wirtschaftsbvereiche-large-inkjet-printer-working-multicolor-on-vinyl-banner-picture-id869606606.jpg "iStock.com / Mumemories")](/034-2023)**Berliner Industrie im Dezember 2022**[#### Rückläufige Auftragseingänge](/034-2023)

Pressemitteilung Nr. 34 Die Umsätze der 318 Berliner Industriebetriebe mit 50 und mehr tätigen Personen stiegen im Dezember 2022 im Vergleich zum Vorjahresmonat um 38,6 Prozent auf 3,2 Mrd. EUR. Sie...

[Zu unseren News](/news)

[* Industrie](/search-results?q=tag%3AIndustrie)[* Wirtschaft](/search-results?q=tag%3AWirtschaft)[* Betrieb](/search-results?q=tag%3ABetrieb)[* Umsatz](/search-results?q=tag%3AUmsatz)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)
