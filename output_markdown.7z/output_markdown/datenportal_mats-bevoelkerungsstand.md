

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)


* [MATS | Bevölkerungsstand](/datenportal/mats-bevoelkerungsstand)

Bevölkerungsstand
=================

![](https://download.statistik-berlin-brandenburg.de/9347f106c3327b46/65c9f51ff527/v/5a2eb5b24619/Logo_MATS.png)Überblicknach RegionVergleich | KennzahlenKennzahlen auswählennach Alternach Herkunftnach FamilienstandLaden...

Nützliche Informationen
-----------------------

### Metadaten

###### **Infos zu den erhobenen Daten, dem Erhebungsbogen und mehr.**

[Zu den Metadaten](/search-results?q=MD_12411&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true&searchByButton=true#results)[### Sie haben Fragen?

###### **Schnelle Hilfe leistet unser FAQ-Bereich.**](/datenportal/mats-hilfe)[[Zur Hilfe](/datenportal/mats-hilfe)](/datenportal/mats-hilfe)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg)19.12.2024Artikel[#### Unterschiede in der amtlichen Datenaufbereitung: Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf. 

[Ansehen](/news/2024/einwohner-oder-bevoelkerung)![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png)19.12.2024Artikel[#### Unterschiede in der amtlichen Datenaufbereitung: Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[Ansehen](/news/2024/zensus-melderegister)![](https://download.statistik-berlin-brandenburg.de/33477355662ac886/509e235aa271/v/22fe5bdcfb49/iStock-691524194.jpg)10.12.2024Pressemitteilung[#### Tag der ungleichen Lebenserwartung am 10. Dezember: Unterschiede in Berlin und Brandenburg](/170-2024)

Männer leben im Schnitt deutlich kürzer als Frauen. Wie sieht es in Berlin und Brandenburg aus?

[Ansehen](/170-2024)[Zu unseren News](/news)
#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)

Metadaten
---------

Infos zu den erhobenen Daten, dem Erhebungsbogen und mehr.

[Mehr erfahren](/search-results?q=MD_45412&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[FAQ](/datenportal/mats-hilfe)


