

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Brandenburg](/wahlen-brandenburg)
* [Bundestagswahlen in Brandenburg](/bundestagswahlen-brandenburg)

Bundestagswahlen in Brandenburg
===============================

Die Bundestagswahlen finden alle vier Jahre statt. Wählende haben zwei Stimmen. Mit der Erststimme wird in den Wahlkreisen mit relativer Mehrheit je ein Direktmandat gewählt. Mit der Zweitstimme wird die Landesliste einer Partei gewählt. Sie ist maßgebend für die Verteilung der Gesamtzahl der Sitze auf die Parteien im Deutschen Bundestag. Es werden nur Parteien berücksichtigt, die mindestens 5 % der Zweitstimmen oder in drei Wahlkreisen ein Direktmandat erhalten.

Bundestagswahl 2021Bundestagswahl 2017Endgültige ErgebnisseWahlstrukturdatenRepräsentative WahlstatistikHistorie

Bundestagswahl am 26. September 2021
------------------------------------

#### Endgültige Ergebnisse für Brandenburg

#### Die endgültigen Ergebnisse

**Alle Daten zur Bundestagswahl 2021 in Brandenburg in interaktiver Form**

[Zu den Ergebnissen](https://wahlergebnisse.brandenburg.de/wahlen/BU2021/afspraes/index.html)
#### Interaktiver Wahlatlas

**Kartenansichten mit den endgültigen Ergebnissen der Bundestagswahl** 

[Zur Karte](https://wahlergebnisse.brandenburg.de/wahlen/BU2021/afspraes/wahlatlas.html)
#### **Alle Ergebnisse als Download**

[Wahlbezirksergebnisse (XLSX)](https://download.statistik-berlin-brandenburg.de/f3ea618b12c8cd90/c0d161988631/DL_BB_BU2021.xlsx)[Wahlkreisergebnisse (XLSX)](https://download.statistik-berlin-brandenburg.de/f1dc860c7ca4576d/81bb0633f03f/DL_BB_A_BU2021.xlsx)[Ergebnisbericht – Landeswahlleitung (XLSX)](https://download.statistik-berlin-brandenburg.de/1a7c9d08eeb76c2d/6c73b1ce6ea5/SB_B07-01-03_2021j04_BB.xlsx)[Ergebnisbericht – Landeswahlleitung (PDF)](https://download.statistik-berlin-brandenburg.de/96cbca3cd1ebe951/04c37fa7b708/SB_B07-01-03_2021j04_BB.pdf)[Ergebnisbericht – Gemeinden (XLSX)](https://download.statistik-berlin-brandenburg.de/648966f8563f67e5/829f0cb124fc/SB_B07-01-04_2021j04_BB.xlsx)[Ergebnisbericht – Gemeinden (PDF)](https://download.statistik-berlin-brandenburg.de/d89dfa24c07c802e/f9c051449ace/SB_B07-01-04_2021j04_BB.pdf)

Wahlstrukturdaten
-----------------

#### Demografische und politische Strukturen von Brandenburg

#### **Download**

[Vorwahldaten, Strukturdaten (XLSX)](https://download.statistik-berlin-brandenburg.de/d76f3ea8b442bb3e/bde6b236a9a3/SB_B07-01-01_2021j04_BB.xlsx)[Vorwahldaten, Strukturdaten (PDF)](https://download.statistik-berlin-brandenburg.de/5523f3fbcc942c45/8b5649e21433/SB_B07-01-01_2021j04_BB.pdf)

Repräsentative Wahlstatistik
----------------------------

#### Wer hat wie gewählt?

##### Bundestagswahl am 26. September 2021 in Brandenburg**Wahlbeteiligung nach Alter**

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Repräsentative Wahlstatistik als Download**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/bb8ed6140b9320db/8e55a11d1486/SB_B07-01-05_2021j04_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/78f2919178add617/673826b7143f/SB_B07-01-05_2021j04_BB.pdf)

Mit der repräsentativen Wahlstatistik werden die **Wahlbeteiligung** und die **Stimmabgabe** der Wahlberechtigten nach Geschlecht und Altersgruppen im Wege der Stichprobe untersucht.

Rechtsgrundlage für die Durchführung ist das Gesetz über die allgemeine und die repräsentative Wahlstatistik (Wahlstatistikgesetz - WStatG). Für die Wahrung des Wahlgeheimnisses sind unter anderem folgende Maßnahmen angeordnet:

* Die Festlegung einer Mindestzahl von 400 Wahlberechtigten je Stichprobenwahlbezirk und von 400 Wählern je Stichprobenbriefwahlbezirk.
* Zusammenfassung der Geburtsjahrgänge zu Gruppen, sodass keine Rückschlüsse auf das Wahlverhalten einzelner Wähler möglich sind.
* Trennung der für die Stimmenauszählung und für die statistische Auswertung zuständigen Stellen sowie strenge Zweckbindung für die Statistikstellen hinsichtlich der ihnen zur Auswertung überlassenen Wahlunterlagen.

Die Wahlberechtigten der repräsentativen Wahlbezirke werden durch ein Plakat und die Auslage eines [Faltblatts](https://download.statistik-berlin-brandenburg.de/98eedb7a471b0837/1e9e2fdd1d89/BTW_RWS_Faltblatt_Online.pdf) im Wahllokal, die Zusendung eines Merkblatts mit den Briefwahlunterlagen und persönliche Beantwortung von Fragen im Wahllokal informiert. Die Stimmzettel sind mit einem Unterscheidungsaufdruck [(siehe Muster)](https://download.statistik-berlin-brandenburg.de/e1b9cdd2c4017ce7/aecf43348553/btw21-rws-SZ-Muster.pdf) versehen.

Historische Daten
-----------------

**Endgültige Ergebnisse zu Bundestagswahlen in Brandenburg**

**Landes-wahlleitung**

**nach  
Gemeinden**  


[**Repräsentative Wahlstatistiken zu Bundestagswahlen in Brandenburg**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000652)

**Wahlbezirksergebnisse zu Bundestagswahlen in Brandenburg**

[**Strukturdaten, Vorwahldaten zu Bundestagswahlen in Brandenburg**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000513)
##### Bundestagswahlen in Brandenburg**Wahlbeteiligung 1990 bis 2021**

 **Quelle:** Amt für Statistik Berlin-Brandenburg
##### **Entwicklung der Wahlergebnisse im Zeitverlauf:**

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/fef2be7da8798fcf/5cf7369c25c1/bundestagswahlen-lange-reihe.xlsx)

Weiterführende Informationen
----------------------------

###### Metadaten

Unsere Metadaten liefern Informationen zu den erhobenen Daten und der angewendeten Methodik. Ergänzt werden diese durch Musterstimmzettel, Datensatzbeschreibungen und gegebenenfalls einen Qualitätsbericht.

**Allgemeine Bundestagswahlstatistik (2021)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/9e46a1137fe0138d/d6fca48713e5/MD_14111_2021.pdf)

**Allgemeine Bundestagswahlstatistik (2017)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/55a5892fb6ce5f43/b11450513684/MD_14111_2017.pdf)

**Repräsentative Bundestagswahlstatistik (2021)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/ad7a42cbbd45e8cf/cfc158471edd/MD_14121_2021.pdf)

#### Der Landeswahlleiter für Brandenburg auf [wahlen.brandenburg.de](https://wahlen.brandenburg.de/wahlen/de/)


