

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Ernteberichterstattung über Feldfrüchte und Grünland in Brandenburg](/c-ii-1-m)

Ernteberichterstattung über Feldfrüchte und Grünland in Brandenburg
-------------------------------------------------------------------

#### August 2024, fallweise

###### Die Erhebung liefert frühzeitig Schätzungen der voraussichtlichen und endgültigen Hektarerträge, für Feldfrüchte und Grünland. Dazu zählen u.a. Getreide, Kartoffeln, Ölfrüchte, Hülsenfrüchte, Zuckerrüben, Pflanzen zur Grünernte, Silomais und Dauergrünland.

BrandenburgMethodik
### Brandenburg

**Weniger Getreide und Winterraps**

Nach dem zweiten vorläufigen Ergebnis der Besonderen Ernte- und Qualitätsermittlung 2024 rechnen Brandenburgs Landwirte mit einer Getreideernte (ohne Körnermais und Corn-Cob-Mix) von 2,2 Millionen Tonnen. Der Ertrag mit 50 Dezitonnen pro Hektar (dt/ha) liegt um 3 % unter dem Ertrag des Vorjahres.

Für Winterweizen, der anbaustärksten Getreideart, wird ein Ertrag bei 63 dt/ha ermittelt, welcher dem Niveau des Vorjahres entspricht. Gleichzeitig verringerte sich die Erntemenge um 8 % auf 912.000 Tonnen.

Nach Angaben der Ernteberichterstatter wurden rund 608.900 Tonnen Wintergerste geerntet, 2023 waren es 651.800 Tonnen gewesen. Der Ertrag liegt mit 57 dt/ha um knapp 9 % unter dem Vorjahresergebnis.

Der Ertrag beim Roggen beläuft sich auf 36 dt/ha, das ist ein Rückgang im Vergleich zum Vorjahresergebnis von 10 %. Gleichzeitig sank die Erntemenge um 17 % auf 470.800 Tonnen.

Für Triticale, eine Kreuzung aus Winterweizen und Roggen, ergibt sich ein der Ertrag von 44 dt/ha. Die Erntemenge entspricht mit 120.900 Tonnen dem Niveau des Vorjahres.

Beim Winterraps, Brandenburgs bedeutendster Ölfrucht, wird von einem Ertrag von 28 dt/ha ausgegangen. Geerntet werden voraussichtlich 257.800 Tonnen, während es 2023 noch 303.100 Tonnen gewesen waren.

1  vorläufig**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c180735b9322f8ff/6f352fff8e7c/SB_C02-01-00_2024m08_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/4123cf022d0b3f26/e6c2e5019d1c/SB_C02-01-00_2024m08_BB.pdf)
### Kontakt

#### Regina Kurz

Ernte- und Weinstatistiken

#### Regina Kurz

Ernte- und Weinstatistiken

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Ernte- und Betriebsberichterstattung für Feldfrüchte und Grünland ist eine dezentrale Bundesstatistik. Die Organisation der Datengewinnung ist Aufgabe der statistischen Ämter der Länder. Die Erhebung der Angaben erfolgt durch Befragung der Ernte- und Betriebsberichterstatter. Die Berichterstattung ist nach § 93 Absatz 3 Nummer 1 AgrStatG in Verbindung mit § 15 BStatG freiwillig.

Die Auswahl der Berichterstatter/-innen erfolgt durch die statistischen Ämter der Länder systematisch in einem nichtzufälligen Verfahren, so dass über einen langen Zeitraum ein mehr oder weniger dichtes Netz an freiwilligen bzw. ehrenamtlichen Berichterstattern/-innen aufgebaut und gepflegt wird. Die Daten der Betriebe werden über einen Fragebogen in Papierform und zusätzlich über einen Online-Fragebogen (IDEV) erhoben. Die Erhebungsbögen werden den Auskunftsgebenden über die Kreiserhebungsstellen zur Verfügung gestellt und an uns zurückgeschickt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Ernte- und Betriebsberichterstattungen (EBE): Feldfrüchte und Grünland (einschließlich Anbauflächen und Vorräte)**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/0ba2b52d6c21f46f/e14aec2be9c5/MD_41241_2024.pdf)[Archiv](/search-results?q=MD_41241&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-ii-1-m)
