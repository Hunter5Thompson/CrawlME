

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Menschen mit Behinderung/Eingliederungshilfe](/menschen-mit-behinderung-eingliederungshilfe)

Menschen mit Be­hinderung/Ein­glie­derungs­hilfe
================================================

Menschen mit Behinderung oder von Behinderung bedrohte Menschen erhalten Leistungen nach Sozialgesetzbuch IX (SGB) und den für die Rehabilitationsträger geltenden Leistungsgesetzen, um ihre Selbstbestimmung und gleichberechtigte Teilhabe am Leben in der Gesellschaft zu fördern, Benachteiligungen zu vermeiden oder ihnen entgegenzuwirken.

Ab dem Berichtsjahr 2020 wird die Eingliederungshilfe (bis 2019 nach dem 6. Kapitel des SGB XII) dem Teil 2 des SGB IX zugeordnet. Aufgabe der Eingliederungshilfe ist es, Leistungsberechtigten eine individuelle Lebensführung zu ermöglichen. Die Leistung soll sie befähigen, ihre Lebensplanung und -führung möglichst selbstbestimmt und eigenverantwortlich wahrnehmen zu können.

Statistische BerichteZeitreihenBasisdatenRegionaldaten

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Schwerbehinderte Menschen in Berlin und Brandenburg, zweijährlich (KIII1-2j)](/k-iii-1-2j)[Empfänger von Eingliederungshilfe sowie Ausgaben und Einnahmen nach dem SGB IX in Berlin und Brandenburg, jährlich, (KIII2-j)](/k-iii-2-j)

Zeitreihen
----------

Schwerbehinderte MenschenEingliederungshilfe**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Schwerbehinderte Menschen

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/acf54869d5654e8c/d0de73ef64bf/Schwerbehinderte_Zeitreihe_2023_Berlin-Brandenburg.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/58b3aa42ee3634c7/c71bf5ae65c1/Schwerbehinderte-Eingliederungshilfe_Lange_Reihe_Berlin-Brandenburg.xlsx)
#### Eingliederungshilfe

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/0ee5d4c4c63ce48b/a160d6541bb6/Eingliederungshilfe_Zeitreihe_2023_Berlin-Brandenburg.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/58b3aa42ee3634c7/c71bf5ae65c1/Schwerbehinderte-Eingliederungshilfe_Lange_Reihe_Berlin-Brandenburg.xlsx)

Basisdaten
----------

Insgesamt/AltersgruppenGrad der BehinderungEingliederungshilfe

Regionaldaten
-------------

###### Berliner Bezirke am 31.12.2023

#### Schwerbehinderte je 1.000 Einwohner

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte am 31.12.2023

#### Schwerbehinderte je 1.000 Einwohner

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Berliner Bezirke am 31.12.2023

#### Empfänger von Eingliederungshilfe

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte am 31.12.2023

#### Empfänger von Eingliederungshilfe

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Haben Sie Fragen?
-----------------

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Kita-Kinder basteln mit Knete](https://download.statistik-berlin-brandenburg.de/2ee06d31b9754b87/f680347bc5a1/v/f8cef1cb6e63/Soziales-Kita-AdobeStock_109933097.jpg "Kita-Kinder basteln mit Knete")](/133-2024)**Kindertagesbetreuung 2024 Berlin und Brandenburg**[#### Weniger Kita-Kinder in Berlin](/133-2024)

Am 1. März 2024 standen in der Hauptstadtregion insgesamt 4.893 Kindertageseinrichtungen mit über 424.800 genehmigten Plätzen für die Betreuung von Kindern zur Verfügung.

[![Schmuckbild Karriere](https://download.statistik-berlin-brandenburg.de/0abb31092c440f5e/c976fbd3aa51/v/0ac0a78a7a7a/mother-at-home-trying-to-work-with-child-distracting-her-picture-id1192677586.jpg "Schmuckbild Karriere")](/news/2024/adoptionen)**Adoptionen 2023 in Berlin und Brandenburg**[#### Eine neue Familie](/news/2024/adoptionen)

Während die Stiefelternadoption dominiert, adoptieren homosexuelle Paare jüngere Kinder als heterosexuelle Paare. Mehr zu Adoptionsmustern in Berlin und Brandenburg lesen Sie hier.

[![Männer aus verschiedenen Generationen liegen sich im Arm](https://download.statistik-berlin-brandenburg.de/90acd809305ce92b/2da7e740c1a1/v/1a5a1a22748a/gesellschaft-maenner-istockphoto-1954785358.jpg "Männer aus verschiedenen Generationen liegen sich im Arm")](/news/2024/herrentag)**Zum Herrentag 2024**[#### Zehn (wenig) überraschende Statistiken](/news/2024/herrentag)

Männer bestechen durch Geld und ihre Lässigkeit – das weiß nicht nur Grönemeyer. Zum Herrentag ein paar amtliche Zahlen aus der Männerwelt.

[Zu unseren News](/news)

[* Behinderte Menschen](/search-results?q=tag%3ABehinderte Menschen
)[* schwerste Behinderung](/search-results?q=tag%3Aschwerste Behinderung
)[* Mehrfachbehinderung](/search-results?q=tag%3AMehrfachbehinderung

)[* Schwerbehinderte](/search-results?q=tag%3ASchwerbehinderte)[* Pflegebedürftige](/search-results?q=tag%3APflegebedürftige)[* Pflegegeld](/search-results?q=tag%3APflegegeld)[* Pflegeheim](/search-results?q=tag%3APflegeheim)
