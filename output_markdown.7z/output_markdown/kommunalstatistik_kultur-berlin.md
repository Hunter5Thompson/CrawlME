

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Berlin-Statistik](/kommunalstatistik)
* [Berliner Kulturdaten](/kommunalstatistik/kultur-berlin)

Berliner Kulturdaten
====================

#### Das kulturelle Angebot in Berlin trägt maßgeblich zur Lebensqualität der Hauptstädter bei. Die Kulturstatistiken geben einen Einblick in die Kulturlandschaft und zeigen Veränderungen auf. Sie liefern Grundlagen für politische Diskussionen und verdeutlichen die gesellschaftliche und wirtschaftliche Bedeutung der Kultur.Statistisch erfasst werden Daten zu Kinos, Museen, Theatern, Bibliotheken sowie Planetarien und Sternwarten.

KinosTheaterMuseenPlanetarien und SternwartenBibliotheken[Alle Daten zum Download](https://download.statistik-berlin-brandenburg.de/12fc0a99979115a4/c065a83ac4d9/Kulturstatistik.xlsx)

Kinos
-----

###### Die Kinostatistik bietet Informationen zu Kinos (Spielstätten), Leinwänden (Kinosäle) und Filmbesuchen und gibt damit einen Überblick über die vielfältige Kinolandschaft Berlins. Die gesammelten Daten werden von der Filmförderungsanstalt (FFA) erhoben und zur Verfügung gestellt.

Kinos (2023)

Kinobesuche (2023)

Die Besuchszahlen in den Berliner Kinos (Spielstätten) konnten 2023 fast das Niveau von 2018 erreichen. 8,2 Mill. Kino-Tickets wurden 2023 verkauft. Somit konnte bei den Filmbesuchen je Einwohner ein Anstieg gegenüber 2022 von 1,7 auf 2,1 verzeichnet werden. Der Ticketpreis hat sich von 2022 auf 2023 um 6,7 % auf 9,91 EUR erhöht. Obwohl 2023 vier Kinos dazugekommen sind, ging die Zahl der Sitzplätze um über 5.000 zurück. Der Umsatz lag in 2023 bei 81,6 Mill. EUR.

###### 2023 in Berlin

#### Ortsfeste Kinos nach Bezirken

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

**Quelle:** FFA Filmförderungsanstalt1 Angaben in Brutto.**Quelle:** FFA Filmförderungsanstalt**Quelle:** FFA Filmförderungsanstalt1 Angaben in Brutto.**Quelle:** FFA Filmförderungsanstalt

Theater
-------

###### Die Theaterstatistik gibt u. a. einen Überblick über Daten der öffentlichen und privaten Theater in Berlin. Sie wird vom Deutschen Bühnenverein jährlich erstellt und liefert  eine nahezu vollständige Abbildung der aktuellen Theaterszene.

### Öffentliche Theater

###### 2021/22 in Berlin

#### Öffentliche Theater nach Bezirken

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

1 Besuche und Veranstaltungen nur am Standort Berlin.**Quelle:** Theaterstatistik des Deutschen Bühnenvereins

Besuche in der Spielzeit 2021/2022  
(öffentliche Theater)

Veranstaltungen in der Spielzeit 2021/2022 (öffentliche Theater)

Nach der Corona-Pandemie konnten die öffentlichen Theaterunternehmen in der Spielzeit 2021/22 wieder über 1,2 Mill. Besuche verzeichnen. Somit entfielen 307 Besuche auf 1.000 Einwohner. Das größte Interesse wurde im Friedstadt-Palast mit 345.501 Besuchen verbucht. Gefolgt von den Opernbesuchen. Die Staatsoper Unter den Linden meldete 192.618 und die Deutsche Oper 159.292 Interessenten. In der Spielzeit 2020/21, welche stark durch die Corona-Pandemie beeinflusst war, lagen die Streaming-Produktionen bei einer Zahl von 7.008. Für die Spielzeit 2021/22 wurden nur noch 97 Streaming-Produktionen erstellt.

#### Besucheranzahl in öffentlichen Theatern – Top 3

1. Friedrichstadt-Palast
2. Staatsoper unter den Linden
3. Deutsche Oper Berlin
1 Zu sonstigen Veranstaltungen zählen u. a. Kabarett, Lesungen, Liederabende etc.. Nicht einbezogen sind Konzerte der Konzertorchester, die als selbständiges Orchester mit eigenem Etat den Theaterdienst versehen.**Quelle:** Theaterstatistik des Deutschen Bühnenvereins1 Besuche und Veranstaltungen nur am Standort Berlin.**Quelle:** Theaterstatistik des Deutschen Bühnenvereins
### Private Theater

1 Besuche und Veranstaltungen nur am Standort Berlin.**Quelle:** Theaterstatistik des Deutschen Bühnenvereins1 Besuche und Veranstaltungen nur am Standort Berlin**Quelle:** Theaterstatistik des Deutschen Bühnenvereins

Besuche in der Spielzeit 2021/2022  
(private Theater)

Veranstaltungen in der Spielzeit 2021/2022  
(private Theater)

Die privaten Theaterunternehmen konnten in der Spielzeit 2021/22 ihre Besucherzahlen im Vergleich zu 2020/21 fast verdoppeln und erreichten eine Anzahl von 401.165. Damit entfallen auf 1.000 Einwohner 106 Besucher. Die höchsten Besucherzahlen meldete das Berliner Ensemble mit 132.780 und die Komödie am Kurfürstendamm mit 97.597. In der Spielzeit 2021/22 stiegen die Veranstaltungen im Vergleich zur Vorjahresspielzeit um 67 % an und erreichten dadurch eine Zahl von 2.444. Die Streaming-Produktion ging im Vergleich zur Spielzeit 2020/21 um fast 70 % zurück.

#### Besucheranzahl in privaten Theatern – Top 3

1. Berliner Ensemble
2. Komödie am Kurfürstendamm
3. Schaubühne am Lehniner Platz

Museen
------

###### Museen bewahren, erforschen und stellen das Kulturerbe der Menschheit aus. Die Daten zur Statistik der Museen entstammen der statistischen Gesamterhebung zu den Museen der Bundesrepublik Deutschland, die vom Institut für Museumsforschung (IfM) durchgeführt wird.

**Quelle:** Institut für Museumsforschung

gemeldete Museen in Berlin (2022)

Besuche (2022)

2022 wurden 201 Museen in Berlin angeschrieben, davon haben 137 Museen Daten gemeldet (68 %). Lagen die Besuchszahlen 2020 und 2021 coronabedingt um 5,0 Mill. im Jahr, stieg die Besucherzahl 2022 auf 14,2 Mill. Das entspricht einer Zahl von 103 840 Besuche je Museum. Die höchsten Besucherzahlen 2022 konnten die Museumsarten historische und archäologische Museen mit 6,3 Mill. und Kunstmuseen mit 2,8 Mill. Besuchen verbuchen. Mit einem Anteil von 40 % gab es die meisten Sonderausstellungen in den Kunstmuseen.

1 Bis 2018 unter dem Begriff "Volkskunde- und Heimatkundemuseen" geführt.**Quelle:**  Institut für Museumsforschung**Quelle:** Institut für Museumsforschung² Bis 2018 unter dem Begriff „Volkskunde- und Heimatkundemuseen“ geführt.**Quelle:**  Institut für Museumsforschung

Planetarien und Sternwarten
---------------------------

###### Zur Kulturlandschaft Berlins zählen auch die Planetarien und Sternwarten. Die Statistik beinhaltet Informationen zu Besucherzahlen in den unterschiedlichen Einrichtungen und nach Veranstaltungsart. Diese Angaben werden jährlich von der Stiftung Planetarium Berlin erfasst und zur Verfügung gestellt.

**Quelle:** Stiftung Planetarium Berlin**Quelle:** Stiftung Planetarium Berlin

Institutionen (2023)

Besucherinnen und Besucher (2023)

Die Besucherzahl von 2022 zu 2023 stieg um 24 %. Somit konnten die Planetarien und Sternwarten in Berlin im Jahr 2023 insgesamt eine Rekordzahl von über eine halbe Million Besuche verbuchen. Damit entfallen 132 Besuche auf 1.000 Einwohner. Von den insgesamt 5.551 Veranstaltungen konnten bei denen für Kinder und Familien mit 142.088 sowie bei denen für Wissenschaft mit 132.926 die meisten Besuche verbucht werden.

Bibliotheken
------------

###### Öffentliche Bibliotheken stehen jedem offen. Erfasst werden in der Bibliotheksstatistik Daten zu den Beständen, Besuchen und Entleihungen. Sie stammen aus den Jahresberichten des Verbunds der öffentlichen Bibliotheken Berlins (VÖBB) und der Stiftung Zentral- und Landesbibliothek Berlin (ZLB) sowie aus der Verbundstatistik.

###### 2023 in Berlin

#### Öffentliche Bibliotheken nach Bezirken

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Institutionen (2023)

Besuche (2023)

Nach der Corona-Pandemie stiegen die Bibliotheksbesuche wieder kontinuierlich an. So lag die Besucherzahl 2022 bei 6,1 Mill. und 2023 bereits bei 7,7 Mill. Das ist ein Anstieg um 25 %. 2023 wurden insgesamt 22,2 Mill analoge Ausleihungen vorgenommen. Der Trend der digitalen Entleihungen stieg weiter an und lag 2023 bereits bei 4,3 Mill., ein Zuwachs um 24 % gegenüber 2022. Die öffentlichen Bibliotheken führten 2023 insgesamt 29.271 Veranstaltungen mit 585.500 Besuchern durch. Hier zeichnete sich vor allem ein hoher Zuwachs bei den Teilnehmern an der Medienkompetenz und Leseförderung von 36 % im Vergleich zu 2022 ab.

**Quelle:** Grund- und Leistungsdaten der Berliner Öffentlichen Bibliotheken, VSZ, ZLB**Quelle:** Grund- und Leistungsdaten der Berliner Öffentlichen Bibliotheken, VSZ, ZLB**Quelle:** Grund- und Leistungsdaten der Berliner Öffentlichen Bibliotheken, VSZ, ZLB
### Alle Kulturdaten zum Download:

[Download XLSX](https://download.statistik-berlin-brandenburg.de/12fc0a99979115a4/c065a83ac4d9/Kulturstatistik.xlsx)
### Bleiben Sie auf dem Laufenden.Der Newsletter zu diesem Thema

[Newsletter abonnieren](/newsletter)

Kontakte
--------

#### Ansprechpersonen für den Fachbereich Verwaltungs- und Geschäftsstatistiken

#### Heike Stiller

Kultur, Religion, Beisetzungen, Umwelt

#### Heike Stiller

Kultur, Religion, Beisetzungen, Umwelt

* [0331 8173-3658](tel:0331 8173-3658)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Katja Niemann-Ahrendt

Kommunalstatistik

#### Katja Niemann-Ahrendt

Kommunalstatistik

* [0331 8173-3868](tel:0331 8173-3868)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)

[* Kultur](/search-results?q=tag%3AKultur)[* Sternwarte](/search-results?q=tag%3ASternwarte)[* Theater](/search-results?q=tag%3ATheater)[* Kino](/search-results?q=tag%3AKino)[* Planetarium](/search-results?q=tag%3APlanetarium)[* Bibliothek](/search-results?q=tag%3ABibliothek)[* Museum](/search-results?q=tag%3AMuseum)[* Kommunalstatistik](/search-results?q=tag%3AKommunalstatistik)
