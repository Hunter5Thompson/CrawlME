

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
#### Überblick

Gesundheit
==========

Gesundheitsthemen stehen zunehmend im Fokus der Öffentlichkeit. Der Bedarf an statistischen Informationen reicht von Einrichtungen des Gesundheitswesens über den Gesundheitszustand der Bevölkerung bis hin zu den Todesursachen. Dabei spielen auch Fragen der Finanzierbarkeit der medizinischen Versorgung eine wichtige Rolle.

BerlinBrandenburg

**Krankenhäuser nach Trägern**2023 in Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg[Gesundheitsausgaben, Gesundheitspersonal, Gesundheitswirtschaft
#### Gesundheitsökonomische Gesamtrechnungen](/gesamtrechnungen)[Krankenhäuser und Vorsorge-/Rehabilitationseinrichtungen
#### Krankenhaus und Rehabilitation](/krankenhaus-und-rehabilitation)[Pflegegeld, Pflegeeinrichtungen, Pflegepersonal
#### Pflege](/pflege)[Schwangerschaftsabbrüche, Konfliktberatung
#### Familienplanung](/familienplanung)[Todesursachen, Säuglingssterblichkeit
#### Todesursachen](/todesursachen)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Gesundheit

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 Bezogen auf alle Altersgruppen von 10 bis unter 55 Jahren**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Arbeitsgruppe "Gesundheitsökonomische Gesamtrechnungen der Länder" und Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
##### 

#### Neues aus dem Bereich Gesundheit

Zuletzt veröffentlicht
----------------------

![iStock.com / Spotmatik](https://download.statistik-berlin-brandenburg.de/09fe07d2f99a71db/1fd2b255bc8f/v/d5efaa426575/gesellschaft-gesundheit-doctors-hospital-corridor-nurse-pushing-gurney-stretcher-bed-picture-id478740625.jpg)20.12.2024Pressemitteilung[#### Krankenhausdiagnosestatistik 2023 Berlin und Brandenburg: Zahl der vollstationären Behandlungen steigt langsam wieder an](/179-2024)

Rund 1,25 Millionen Menschen sind 2023 in den Krankenhäusern der Metropolregion behandelt worden.

[Ansehen](/179-2024)![iStock.com / upixa](https://download.statistik-berlin-brandenburg.de/70cad83eb120c858/1dd5af74599e/v/05ec05160379/gesellschaft-gesundheit-emergency-admission-entrance-hospital-doctor-wheelchair-picture-id1130918876.jpg)19.12.2024Statistischer Bericht[#### 2023, jährlich, A IV 3 – j: Krankenhäuser in Berlin und Brandenburg Teil II – Diagnosen der Krankenhauspatientinnen und -patienten](/a-iv-3-j)

Jährliche Ergebnisse aus der Erhebung zu den Diagnosen der Krankenhauspatientinnen und -patienten in Berlin und Brandenburg.

[Ansehen](/a-iv-3-j)![iStock.com / mammuth](https://download.statistik-berlin-brandenburg.de/2f604837425dd414/d07c62579df7/v/ec955e84bf3b/bevoelkerung-todesfaelle-autumn-sunlight-in-the-cemetery-picture-id175381576.jpg)16.12.2024Statistischer Bericht[#### 2023, jährlich, A IV 10 – j: Sterbefälle nach Todesursachen in Berlin und Brandenburg](/a-iv-10-j)

Jährliche Statistik zur Häufigkeit von Krankheiten und Ereignissen, die zum Tode führen. Sterbefälle nach Todesursachen, Geschlecht und Altersgruppen.

[Ansehen](/a-iv-10-j)Mehr anzeigen


