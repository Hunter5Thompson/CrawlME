

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Gewerbeanzeigen](/gewerbeanzeigen)
* [Gewerbeanzeigen in Berlin und Brandenburg](/d-i-2-j)

Gewerbeanzeigen
---------------

#### 2023, jährlich

###### Die Gewerbeanzeigenstatistik liefert Informationen über Zahl und Art der in einer Region ansässigen Gewerbebetriebe. Gewerbean- und -abmeldungen werden u. a. nach Wirtschaftsbereich, Rechtsform, Zahl der tätigen Personen sowie Geschlecht und Staatsangehörigkeit der Gewerbetreibenden ausgewiesen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenbrug
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/5f8b95e6af596008/04c9e5c4f7f4/SB_D01-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/9f8edade86e6576c/779ce847e15e/SB_D01-02-00_2023j01_BE.pdf)

**Mehr Gewerbean- und -abmeldungen**

Die Berliner Wirtschaftsämter haben 2023 insgesamt 41.206 Gewerbeanmeldungen entgegengenommen, 2,0 % mehr als im Vorjahreszeitraum. Die Anzahl der Gewerbeabmeldungen stieg um 2,2 % auf 32.232.

Mit 8.112 An- und 6.589 Abmeldungen wurden im Wirtschaftsabschnitt „Handel; Instandhaltung und Reparatur von Kraftfahrzeugen“ die meisten Aktivitäten erfasst, gefolgt vom Baugewerbe mit 6.096 An- und 5.638 Abmeldungen. Im Abschnitt „Erbringung von freiberuflichen, wissenschaftlichen und technischen Dienstleistungen“ wurden 5.143 Gewerbe angemeldet und 3.097 Gewerbe abgemeldet.

### Kontakt

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

* [0331 8173-1341](tel:0331 8173-1341)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Jannette Frömling

Gewerbeanzeigen

#### Jannette Frömling

Gewerbeanzeigen

* [0331 8173-1348](tel:0331 8173-1348)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Zahl der Gewerbemeldungen leicht zurückgegangen**

2023 meldeten Brandenburgs Gewerbetreibende 17.863 Gewerbe an, 1,3 % weniger als im Vorjahr. Die Zahl der Abmeldungen sank indessen um 1,9 % auf 15.823.

Mit 4.063 An- und 3.580 Abmeldungen wurden im Wirtschaftsabschnitt „Handel; Instandhaltung und Reparatur von Kraftfahrzeugen“ die meisten Meldungen registriert, gefolgt vom Abschnitt „Erbringung von sonstigen wirtschaftlichen Dienstleistungen“ mit 2.573 Anmeldungen und 2.263 Abmeldungen. Im Baugewerbe wurden 1.564 Gewerbe angemeldet und 1.993 Gewerbe abgemeldet.

**Quelle:** Amt für Statistik Berlin-Brandenbrug
#### **zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/5a5ee08631d0b9da/8e4f50ff4b6c/SB_D01-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/afa59f880e87d921/ad400f8a842e/SB_D01-02-00_2023j01_BB.pdf)
### Kontakt

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

#### Kerstin Bortz-Franzik

Gewerbeanzeigen

* [0331 8173-1341](tel:0331 8173-1341)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Jannette Frömling

Gewerbeanzeigen

#### Jannette Frömling

Gewerbeanzeigen

* [0331 8173-1348](tel:0331 8173-1348)
* [gewerbemeldungen@statistik-bbb.de](mailto:gewerbemeldungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der Jahresbericht basiert auf den monatlichen Datenlieferungen der Gewerbeämter.

Für die jährliche Tabellierung wurde das Merkmal „Staatsangehörigkeit“ um weitere Nationalitäten ergänzt und eine zusätzliche Zeitreihendarstellung mit Gliederung nach Bezirken in Berlin bzw. nach Verwaltungsbezirken in Brandenburg aufgenommen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Gewerbeanzeigenstatistik**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/9a2038f806f7d875/c5f1b87762d7/MD_52311_2023.pdf)[Archiv](/search-results?q=MD_52311&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/d-i-2-j)
