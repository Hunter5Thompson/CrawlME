

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Bevölkerungsstand](/bevoelkerung/demografie/bevoelkerungsstand)
* [Bevölkerungsstand in Berlin und Brandenburg – Monatsergebnisse](/a-i-7-a-ii-3-a-iii-3-m)
* [A I 7 – m, A II 3 - m, A III 3 - m](/archiv/a-i-7-m-a-ii-3-m-a-iii-3-m)

Archiv: Statistischer Bericht
=============================

#### Bevölkerungsentwicklung und Bevölkerungsstand in Berlin und in Brandenburg(A I 7 – m, A II 3 - m, A III 3 - m)

![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben dieses Statistischen Berichts jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000953)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000955)


