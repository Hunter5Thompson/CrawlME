

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)
* [Erzieherische Hilfe, Eingliederungshilfe für seelisch behinderte junge Menschen, Hilfe für junge Volljährige in Berlin und Brandenburg](/k-v-2-j)

Erzieherische Hilfe, Eingliederungshilfe für seelisch behinderte junge Menschen, Hilfe für junge Volljährige
------------------------------------------------------------------------------------------------------------

#### 2023, jährlich

###### Die Erhebung stellt statistische Daten über die Hilfen und über die Situation der Hilfeempfängerinnen und -empfänger sowie über die Dauer der Hilfe bereit.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/9c219e99b9f9d730/4d6d2b19de0c/SB_K05-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/3f7be5ab7a40aa6e/edef18c16317/SB_K05-02-00_2023j01_BE.pdf)

**Hilfen zur Erziehung in Berlin**

Für 37.526 junge Menschen bzw. Familien wurde 2023 eine Hilfe zur Erziehung im Rahmen der Kinder- und Jugendhilfe neu gewährt. 34.358 Hilfen wurden im Laufe des Jahres beendet und 37.304 Hilfen bestanden am Jahresende fort.

Unter den beendeten und bestehenden Hilfen bildeten Erziehungsberatungen mit 37 % den Schwerpunkt. Heimerziehung und sonstige betreute Wohnformen standen mit 15 % an zweiter Stelle. Sozialpädagogische Familienhilfe wurde in 13 % der Fälle geleistet.

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

  


**Hilfen zur Erziehung in Brandenburg**

Im Jahr 2023 wurde für 18.553 junge Menschen bzw. Familien eine Hilfe zur Erziehung im Rahmen der Kinder- und Jugendhilfe neu gewährt. 17.377 wurden im Laufe des Jahres beendet und 22.964 Hilfen bestanden am Jahresende fort.

Bei den geleisteten Hilfen bildeten Erziehungsberatungen mit 38 % den Schwerpunkt. Gefolgt von Heimerziehung und sonstige betreute Wohnformen mit 14 % und Sozialpädagogische Familienhilfe mit 13 % der Fälle.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/98c6544972560dcc/77e09590d44d/SB_K05-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/70ee846bfe6325e9/18271655f4d4/SB_K05-02-00_2023j01_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Grundgesamtheit der Statistik erstreckt sich auf alle ambulanten, teilstationären und stationären erzieherischen Hilfen sowie die Eingliederungshilfe für seelisch behinderte junge Menschen und die Hilfe für junge Volljährige nach dem Achten Buch Sozialgesetzbuch (SGB VIII). Jährlich werden alle beendeten sowie am Jahresende bestehenden Hilfen gemeldet.

Die Meldungen über die Hilfen erfolgen durch die örtlichen Träger der öffentlichen Jugendhilfe sowie die Träger der freien Jugendhilfe, soweit sie Beratungen nach §§ 28, 41 SGB VIII durchführen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der erzieherischen Hilfe, der Eingliederungshilfe für seelisch Behinderte und der Hilfe für junge Volljährige**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/98ec3a15a3887b04/57888eccd1da/MD_22517_2023.pdf)[Archiv](/search-results?q=22517&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-v-2-j)
