

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Preise](/wirtschaft/preise)
* [Baupreise](/baupreise)

Baupreise
=========

Mit der Statistik der Bauleistungspreise wird die Entwicklung der Preise unter anderem für den Neubau ausgewählter Bauwerksarten des Hoch- und Tiefbaus und die Instandhaltung von Mehrfamilienhäusern in Form von Baupreisindizes und Veränderungsraten nachgewiesen.  
  
Dazu werden in ausgewählten Berichtsfirmen die zwischen Bauherren und Bauunternehmen vertraglich vereinbarten Preise von rund 190 Bauleistungen beobachtet.

[![Zwei Hände zeigen mehrere auf Geldstapel](https://download.statistik-berlin-brandenburg.de/58fe59e64c6fdbe7/36a55dc57069/v/994e168388ea/preise-geld-inflation-iStock-1454520770-web.png "Zwei Hände zeigen mehrere auf Geldstapel")](/news/2024/konferenz-messung-der-preise)**Erfolgreich abgeschlossen**[#### 26. Konferenz „Messung der Preise“](/news/2024/konferenz-messung-der-preise)

Vertreter der Statistischen Ämter des Bundes und der Länder, der Deutschen Bundesbank, der Europäischen Zentralbank (EZB) und der Wissenschaft kamen zusammen.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Preisindizes für Bauwerke in Berlin und Brandenburg (MI4-vj)](/m-i-4-vj)

Zeitreihen
----------

**Quelle:** Amt für Statistik Berlin-Brandenburg

**„Zeitreihen“** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von zehn Jahren wieder. Die sogenannten **„Langen Reihen“** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/91aaa853fa7c3aaa/c68cb7bb227c/baupreise-lange-reihe-2024.xlsx)

Basisdaten
----------

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=find&suchanweisung_language=de&query=Baupreisindizes#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Stefanie Dobs

Baupreise

#### Stefanie Dobs

Baupreise

* [0331 8173-3523](tel:0331 8173-3523)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Katrin Schoenecker

Baupreise

#### Katrin Schoenecker

Baupreise

* [0331 8173-3114](tel:0331 8173-3114)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / schwartstock](https://download.statistik-berlin-brandenburg.de/7d4ab4407ce3fd0b/e7dff9d39491/v/3c3ae65fca33/gesellschaft-arbeit-high-angle-view-of-workers-in-construction-site-picture-id1189235635.jpg "iStock.com / schwartstock")](/139-2024)**Preisindizes für Bauwerke im August 2024 in Berlin und Brandenburg**[#### Baupreise weiterhin auf hohem Niveau](/139-2024)

Pressemitteilung Nr. 139 Im August 2024 lagen die Preise für den Neubau von Wohngebäuden (Bauleistungen am Bauwerk) in Berlin im Durchschnitt um 4,1 % und in Brandenburg um 3,9 % über denen vom...

[![iStock-1146140224.jpg](https://download.statistik-berlin-brandenburg.de/be70e0a79821dea9/10be841721f8/v/4899f1f0da9b/wirtschaft-wirtschaftsbereiche-baugewerbe.jpg "iStock-1146140224.jpg")](/089-2024)**Preisindizes für Bauwerke im Mai 2024 in Berlin und Brandenburg**[#### Teuerung schwächt sich ab](/089-2024)

Pressemitteilung Nr. 89 Im Mai 2024 lagen die Preise für den Neubau von Wohngebäuden (Bauleistungen am Bauwerk) in Berlin im Durchschnitt um 3,9 % und in Brandenburg um 3,7 % über denen vom Mai das...

[![iStock.com / WUT789](https://download.statistik-berlin-brandenburg.de/2bf91ef8d7e87e41/d8915d0aa8d2/v/2c6debffcff1/wirtschaft-preise-surveying-engineers-are-working-together-using-theodolite-on-the-picture-id1257559262.jpg "iStock.com / WUT789")](/040-2024)**Preisindizes für Bauwerke im Februar 2024 in Berlin und Brandenburg**[#### Preise steigen, Teuerung verliert an Dynamik](/040-2024)

Pressemitteilung Nr. 40 Im Februar 2024 lagen die Preise für den Neubau von Wohngebäuden (Bauleistungen am Bauwerk) in Berlin im Durchschnitt um 4,4 Prozent und in Brandenburg um 4,0 Prozent über...

[Zu unseren News](/news)

[* Baupreisindex](/search-results?q=tag%3ABaupreisindex)[* Baupreisindizes](/search-results?q=tag%3ABaupreisindizes)[* Neubau](/search-results?q=tag%3ANeubau)[* Wohngebäude](/search-results?q=tag%3AWohngebäude)[* Bürogebäude](/search-results?q=tag%3ABürogebäude)[* Straßenbau](/search-results?q=tag%3AStraßenbau)[* Außenanlagen](/search-results?q=tag%3AAußenanlagen)[* Brückenbau](/search-results?q=tag%3ABrückenbau)[* Ortskanäle](/search-results?q=tag%3AOrtskanäle)
