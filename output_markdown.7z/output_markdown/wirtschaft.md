

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)

Wirtschaft
==========

Die Rubrik Wirtschaft umfasst Ergebnisse, welche die Herstellung, den Verkauf, die Verteilung und den Verbrauch von Gütern und Dienstleistungen betreffen sowie Daten aus dem Umweltbereich. Die Wirtschaftsdaten beziehen sich auf Unternehmen und Betriebe sowie öffentliche Einrichtungen im Bereich der Urproduktion und der gewerblichen und freigewerblichen Tätigkeiten. Sie sind die Basis für die Volkswirtschaftlichen und Umweltökonomischen Gesamtrechnungen.

###### Sie benötigen einen Nachweis über den wirtschaftlichen Schwerpunkt Ihres Unternehmens entsprechend der Klassifikation der Wirtschaftszweige (WZ 2008)?

[Hier finden Sie weitere Informationen.](/wirtschaftsnachweis)BerlinBrandenburg

%
-

#### Anteil am deutschenBruttoinlandsprodukt

hat Berlin 2023    


*Stand: März 2024*

  


[#### Volkswirtschaft](/wirtschaft/volkswirtschaft)

* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Unternehmen](/unternehmen)
* [Gewerbeanzeigen](/gewerbeanzeigen)
* [Insolvenzen](/insolvenzen)
* [Außenhandel](/aussenhandel)
* [Einkommen und Konsum](/einkommen-und-konsum)
* [Zeitverwendungs- erhebung](/zeitverwendungserhebung)
[#### Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)

* [Handel](/wirtschaft/wirtschaftbereiche/handel)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Verarbeitendes Gewerbe](/verarbeitendes-gewerbe)
* [Dienstleistungen](/dienstleistungen)
* [Bauen und Wohnungen](/bauen-und-wohnungen)
* [Handwerk](/handwerk)
[#### Preise](/wirtschaft/preise)

* [Verbraucherpreise](/verbraucherpreise)
* [Bodenmarkt](/bodenmarkt)
* [Baupreise](/baupreise)
[#### Umwelt](/wirtschaft/umwelt)

* [Umweltökonomische Gesamtrechnungen](/wirtschaft/umwelt/gesamtrechnungen)
* [Wasser](/wasser)
* [Energie](/energie)
* [Abfall, Luftbelastungspotenzial](/luftverunreinigungen)
* [Umweltausgaben](/umweltausgaben)

News und Analysen
-----------------

#### Interpretation und Einordnung

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

[![Ein Windrad und weiter Blick in die Landschaft](https://download.statistik-berlin-brandenburg.de/2fe0c01ea1e3b28f/36c8abef068e/v/58c54355b18c/wirtschaft-preise-wind-turbine-in-the-sunset-seen-from-an-aerial-view-picture-id864427886.jpg "Ein Windrad und weiter Blick in die Landschaft")](/news/2024/nachhaltigkeit-biodiversitaet)**10 Diagramme zu den Deutschen Aktionstagen Nachhaltigkeit**[#### Biodiversität im Fokus](/news/2024/nachhaltigkeit-biodiversitaet)

Deutsche Aktionstage Nachhaltigkeit mit Schwerpunkt Biodiversität: Mit aktuellen Zahlen unterstreichen wir die Bedeutung der biologischen Vielfalt in unserer Region.

[![Ausschnitt Berlin Brandenburg Tourismusatlas](https://download.statistik-berlin-brandenburg.de/4bda3785af78ba7b/9a6e6e08badc/v/aeb7b16d6157/tourismusatatlas-2023.jpg "Ausschnitt Berlin Brandenburg Tourismusatlas")](/news/2024/tourismusatlas)**Tourismusatlas mit aktuellen Daten**[#### Die Tourismusbranche ist wieder im Aufwärtstrend](/news/2024/tourismusatlas)

Im Jahr 2023 liegt die Zahl der Übernachtungen in deutschen Beherbergungsbetrieben mit 487,1 Millionen um 8,1 % über dem Vorjahr und damit fast wieder auf dem Rekordniveau aus dem Jahr 2019. Die von...

Weitere News

Zuletzt veröffentlicht
----------------------

#### Neues aus der Rubrik Wirtschaft

![iStock-1213727367.jpg](https://download.statistik-berlin-brandenburg.de/8c43b2d7bc814cc3/3e5ce1b6bb13/v/4660157d52dc/landwirtschaft-rinder.jpg)20.12.2024Statistischer Bericht[#### 3. November 2024, halbjährlich, C III 9 - hj: Rinder in Berlin und Brandenburg](/c-iii-9-hj)

Die Erhebung informiert über die Anzahl der Rinder (einschließlich Büffel/Bisons), gegliedert nach Alter, Geschlecht, Nutzungszweck und Rasse.

[Ansehen](/c-iii-9-hj)![iStock.com / Ralf Geithe](https://download.statistik-berlin-brandenburg.de/18ab4ea1b78d2d3f/a968212aefd3/v/b09357439c40/wirtschaft-volkswirtschaft-insolvenzen-old-tab-with-the-german-word-for-insolvency-picture-id945026672.jpg)19.12.2024Statistischer Bericht[#### 3. Quartal 2024, vierteljährlich, D III 1 - vj: Insolvenzen in Berlin und Brandenburg](/d-iii-1-vj)

Die Insolvenzstatistik liefert Informationen über die Anzahl der eröffneten, mangels Masse oder mit gerichtlichem Schuldenbereinigungsplan beendeten Insolvenzverfahren.

[Ansehen](/d-iii-1-vj)![iStock-500003996.jpg](https://download.statistik-berlin-brandenburg.de/a3673719d2d0542c/000daad3a651/v/cca1b725c6c0/wirtschaft-wirtschaftsbereiche-schweine.jpg)19.12.2024Pressemitteilung[#### Schweinebestand in Brandenburg am 3. November 2024: Leichte Erholung des Bestandes](/176-2024)

Nach dem vorläufigen Ergebnis der Erhebung der Schweinebestände zum 3. November 2024 hielten die Brandenburger Betriebe 556.400 Schweine. 

[Ansehen](/176-2024)Mehr anzeigen

Leben in Berlin
---------------

In Berlin leben mehr als 3,7 Millionen Menschen auf vielfältige Weise zusammen. Finden Sie mit uns heraus, wo Familien in Berlin wohnen, wie sie leben und welche Bedingungen sie in ihrem direkten Umfeld vorfinden.

[Mehr erfahren](https://www.leben-in-berlin.statistik-berlin-brandenburg.de/)

Auswirkungen des Ukraine-Krieges
--------------------------------

Ausgehend vom Ist-Zustand werden die Folgen des Ukraine-Konflikts für die Hauptstadtregion in verschiedenen Bereichen beleuchtet.  


[Mehr erfahren](/schwerpunkte/ukraine)


