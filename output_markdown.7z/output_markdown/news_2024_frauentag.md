

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 07.03.2024

#### Internationaler Frauentag 2024

Ein kurzer Blick auf den Arbeitsmarkt
-------------------------------------

![Frau mit Büchern in einer Bibliothek](https://download.statistik-berlin-brandenburg.de/3d83b26860d61c9a/ca880fc309b1/v/e8a86786704e/istockphoto-1417921874-1024x1024.jpg "Frau mit Büchern in einer Bibliothek")

**Anlässlich des Internationalen Frauentags am 8. März werfen wir einen Blick auf aktuelle Arbeitsmarktzahlen. Trotz annähernd ausgeglichener Geschlechterverteilung in der Berliner (50,9 % weiblich) und Brandenburger (50,8 % weiblich) Bevölkerung im Jahr 2022 ist das Verhältnis bei Verdiensten und Arbeitszeit immer noch weniger ausgeglichen. Ein Sektor ist dennoch besonders beliebt bei Frauen.**

#### Geringerer Verdienst, dafür mehr unbezahlte Arbeit

Auf dem Arbeitsmarkt zeigten sich 2023 weiterhin deutliche Unterschiede zwischen Frauen und Männern. Der [Gender Gap Arbeitsmarkt](/030-2024), der die Verdienstungleichheit zwischen den Geschlechtern misst, betrug in Berlin 25 % und in Brandenburg 19 %. Beide Länder schnitten damit im bundesweiten Vergleich verhältnismäßig gut ab, denn durchschnittlich lag der Gender Gap Arbeitsmarkt in Deutschland bei 39 %. Der Lohnunterschied betrug für Frauen in Berlin 11 %, während er in Brandenburg nur 4 % ausmachte. Frauen verdienen nicht nur pro Stunde weniger, sie nehmen auch seltener am Erwerbsleben teil und arbeiten häufiger in Teilzeit. Das hat langfristige Auswirkungen auf finanzielle Möglichkeiten und die soziale Absicherung im Rentenalter.

![Infografik zur Gender Gap Arbeitsmarkt 2023](https://download.statistik-berlin-brandenburg.de/66198081dc722112/7b2ee0105651/v/0c9727ad80de/20240229_GenderGapArbeitsmarkt.png "Infografik zur Gender Gap Arbeitsmarkt 2023")

Während Frauen nahezu die gleiche Anzahl an Stunden in der Woche arbeiten wie Männer, werden sie für einen größeren Teil ihrer Arbeit nicht bezahlt. 2022 wendeten Männer in Berlin etwa 22 Stunden in der Woche für unbezahlte Arbeiten bzw. Tätigkeiten wie Hausarbeit, Kinderbetreuung, die Pflege Angehöriger usw. auf. Bei den Frauen waren es sieben Stunden mehr. Auch in Brandenburg waren Frauen durchschnittlich 30 Stunden mit unbezahlter Arbeit beschäftigt – acht Stunden länger als Männer. Schaut man sich ausschließlich die [Zeiten für Haushaltsarbeiten](/zeitverwendungserhebung) wie Putzen und Waschen an, ist der Unterschied noch auffälliger: Frauen waren damit in Brandenburg im Durchschnitt 12 Stunden und 54 Minuten wöchentlich beschäftigt und damit etwa doppelt so lang wie Männer mit 6 Stunden und 33 Minuten. In Berlin sah das Verhältnis ähnlich aus.

**Quelle:** Amt für Statistik Berlin-Brandenburg/Zeitverwendungserhebung**Quelle:** Amt für Statistik Berlin-Brandenburg/Zeitverwendungserhebung
#### Unterschiede auf Entscheidungsebene

Auch auf Entscheidungsebene besteht weiterhin eine Ungleichheit. 2023 verdienten [Frauen in Leitungsfunktionen](/048-2023) in Berlin rund 13 % weniger als ihre männlichen Kollegen. In Brandenburg waren es 15 % weniger. Zu den Leitungsfunktionen gehören unter anderem Geschäftsführende sowie Abteilungs- und Teamleitende. In diesen Positionen verdienten Frauen in Berlin durchschnittlich 32,68 EUR brutto pro Stunde, während Männer 37,55 EUR erhielten. In Brandenburg erhielten Frauen in solchen Positionen einen durchschnittlichen Bruttostundenverdienst von 28,77 EUR und Männer 34,02 EUR. Dieser Wert ist vor allem in Anbetracht des durchschnittlichen Verdienstunterschiedes von 4 % für alle Beschäftigten in Brandenburg beachtlich.

Bei den höheren Ämtern zeichnen sich ebenfalls traditionelle Rollenbilder ab. So war 2022 zum Beispiel nur etwa ein Drittel der hauptberuflichen Professorinnen und Professoren an Berliner und Brandenburger Hochschulen weiblich. Unter Dozentinnen bzw. Dozenten und Assistentinnen bzw. Assistenten war die Geschlechterverteilung mit 50,3 % in Berlin und 50,0 % in Brandenburg immerhin ausgeglichen.

%
-

**der hauptberuflichen Professor/-innen an Hochschulen in Berlin sind weiblich (2022)**

%
-

**der hauptberuflichen Professor/-innen an Hochschulen in Brandenburg sind weiblich (2022)**

Doch der Nachwuchs steht bereits in den Startlöchern. Es zeigt sich, dass die Studierendenzahl an Hochschulen in Berlin und Brandenburg in den letzten zwei Jahrzehnten kontinuierlich gewachsen ist. In den 1990er Jahren waren in Berlin noch mehr Männer unter den Studierenden, dieses Bild hat sich im Laufe der Jahre gewandelt. Seit 2018 studieren immer mehr Frauen als Männer in der Bundeshauptstadt. In Brandenburg ist das Verhältnis etwas ausgewogener. Seit mehr als zehn Jahren liegt der Frauenanteil hier etwas über dem Männeranteil.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Öffentlicher Sektor in Frauenhänden

Im öffentlichen Dienst zeigt sich eine langjährige Konstante: Der größere Teil der Beschäftigten der Länder Berlin und Brandenburg besteht aus Frauen. Eine Entwicklung, die sich über die Jahre gehalten hat. Jedoch ergibt sich auch hier, genau wie auf dem gesamten Arbeitsmarkt, eine Dissonanz bei der Arbeitszeit. In Berlin lag der Anteil der Teilzeitbeschäftigten 2022 bei 28,3 %, darunter waren 72,6 % Frauen. In Brandenburg arbeitete ein Drittel der Beschäftigten in Teilzeit, während der Frauenanteil hier 84,6 % betrug.

1 Die Daten der Personalstatistiken unterliegen der Geheimhaltung. Als Geheimhaltungsverfahren wurde die 5er Rundung angewendet. Personen mit den Geschlechtsangaben "divers" und "ohne Angabe (nach §22 Absatz 3 PStG)“ wurden ab der Erhebung 2021 per Zufallsprinzip den männlichen oder weiblichen Beschäftigten zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg

Interessante Einblicke gewährt auch die Altersstruktur aus dem Jahr 2022: Einerseits fällt der Personalbestand bei den Über-50-Jährigen insgesamt größer aus, anderseits schlägt auch dort die Zahl der beschäftigten Frauen aus. Dies spiegelt ihre langjährige engagierte Arbeit im öffentlichen Dienst wider und betont die altersgerechten Arbeitsbedingungen in diesem Sektor. Bei uns im [Amt für Statistik Berlin-Brandenburg](/karriere) ist das Geschlechterverhältnis übrigens ähnlich verteilt. 2023 waren von den 477 Beschäftigten 65 % Frauen. In der Alterskohorte 51 bis 60 Jahre ist die Ungleichverteilung am stärksten ausgeprägt. Hier stehen den 118 Frauen 38 Männer gegenüber.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Höhere Risiken für Männer in Arbeitsumfeld

Gleichberechtigung am Arbeitsplatz ist eine vielschichtige Herausforderung. Während Frauen mit Lohnungleichheit und einer höheren Teilzeitbeschäftigung konfrontiert sind, treten Männer vermehrt in Berufe ein, die mit erhöhten Risiken für Arbeitsunfälle und schwerwiegende Behinderungen einhergehen. Die [Statistik über schwerbehinderte Menschen](/menschen-mit-behinderung-eingliederungshilfe) verdeutlicht, dass wesentlich mehr Männer als Frauen eine Schwerbehinderung aufgrund von berufsbedingten Unfällen oder betriebsbedingten Krankheiten haben. Nur rund ein Fünftel dieser Gruppe in Berlin und Brandenburg sind Frauen.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Frauen](/search-results?q=tag%3AFrauen)[* Verdienste](/search-results?q=tag%3AVerdienste)[* Arbeitszeit](/search-results?q=tag%3AArbeitszeit)[* Teilzeit](/search-results?q=tag%3ATeilzeit)[* Öffentlicher Dienst](/search-results?q=tag%3AÖffentlicher Dienst)[* Gender Pay Gap](/search-results?q=tag%3AGender Pay Gap)[* Gender Gap Arbeitsmarkt](/search-results?q=tag%3AGender Gap Arbeitsmarkt)
