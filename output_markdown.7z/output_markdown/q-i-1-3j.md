

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Wasser](/wasser)
* [Wasserversorgung und Abwasserbeseitigung in Berlin und Brandenburg](/q-i-1-3j)

Wasserversorgung und Abwasserbeseitigung
----------------------------------------

#### 2019, dreijährlich

###### Das Umweltstatistikgesetz 2005 (UStatG) regelt im Themenbereich „Wasserwirtschaft“ verschiedenen Erhebungen. Sie umfassen die öffentliche Wasserversorgung sowie Abwasserbehandlung und -entsorgung, die Wasserversorgung der Industrie, Unfälle mit wassergefährdenden Stoffen und Wasser- und Abwasserentgelte.

BerlinBrandenburgMethodikArchiv
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2019**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/74029c18ca64f80e/17faa5a11c53/SB_Q01-01-00_2019j03_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/8aa3e90596fd5286/da0b20259db6/SB_Q01-01-00_2019j03_BE.pdf)

**Höherer Wasserverbrauch**

2019 stieg die Wasserabgabe an Letztverbraucher in Berlin auf 162,2 Liter je Einwohner und Tag. Im Jahr 2016 lag die tägliche Wasserabgabe je Einwohner und Tag bei 158,8 Litern. Der Wasserverbrauch der Haushalte je Einwohner und Tag stieg indessen von 117,2 Liter auf 119,5 Liter.

Das durchschnittliche Entgelt für die Trinkwasserversorgung blieb im Vergleich zu 2016 mit einem verbrauchsabhängigen Entgelt von 1,81 EUR/m³ und einer Grundgebühr von 17,58 EUR/Jahr konstant. Für die Wasserentsorgung sank das verbrauchsabhängige Entgelt im Vergleich zu 2016 von 2,30 EUR/m³ auf 2,21 EUR/m³, während das Niederschlagswasserentgelt je m² versiegelter oder sonstiger Fläche von 1,80 EUR/m³ auf 1,84 EUR/m³ stieg. Die Grundgebühr hingegen sank um 1 Cent auf 16,42 EUR/Jahr.

99,8 % der Einwohnerinnen und Einwohner Berlins waren an die öffentliche Wasserver- und -entsorgung angeschlossen.

### Kontakt

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1282](tel:0331 8173-1282)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Pro-Kopf-Verbrauch um beinahe 10 Liter gestiegen**

Die tägliche an die Letztverbraucher erfolgte Wasserabgabe stieg mit 139,7 Liter je Einwohner im Vergleich zu 2016 um rund 10 Liter an. Auch die täglich an Haushalte abgegebene Wassermenge nahm mit 120,1 Liter in 2019 im Vergleich zu 111,4 Liter im Jahr 2016 zu.

Für die Wasserentsorgung stieg das verbrauchsabhängige Entgelt im Vergleich zu 2016 von 1,54 EUR/m³ auf 1,55 EUR/m³, während das Niederschlagswasserentgelt je m² versiegelter oder sonstiger Fläche 0,90 EUR/m³ gleich geblieben ist. Die Grundgebühr hingegen stieg um 88 Cent auf 81,40 EUR/Jahr.

Landesweit waren 99,0 % der Einwohnerinnen und Einwohner an die öffentliche Wasserversorgung angeschlossen. Der Anteil derer, die die öffentliche Kanalisation zur Wasserentsorgung nutzten, betrug hingegen nur 88,6 %.

1 enthält auch andere Wasserarten, z.B. Niederschlagswasser**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2019**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/60c1fb4901c5a11b/885b9b4847a8/SB_Q01-01-00_2019j03_BB.xlsx)

3. korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/5712b8385f0a6757/986e1139a28f/SB_Q01-01-00_2019j03_BB.pdf)
### Kontakt

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1282](tel:0331 8173-1282)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die jährlichen oder mehrjährlichen Erhebungen stellen grundlegende Informationen für wasserwirtschaftliche Analysen und Planungen bereit. Sie dienen der politischen Entscheidungshilfe, zum Beispiel für Umwelt- und Gewässerschutzmaßnahmen oder zur Weiterentwicklung von Wasserversorgungs- und Abwassersystemen.

Die Ergebnisse werden auch benötigt, um einen regelmäßigen Überblick über die Wasserversorgung und Abwasserentsorgung sowie ihrer Preise und Gebühren im öffentlichen Bereich zu gewinnen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

**[Erhebung der öffentlichen Wasserversorgung (2019)](https://download.statistik-berlin-brandenburg.de/61c41e9b797f8ed2/456b81856f35/MD_32211_2019.pdf)** | [Archiv](/search-results?q=MD_32211&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung der öffentlichen Abwasserentsorgung (2019)](https://download.statistik-berlin-brandenburg.de/8cb8a24778c99c75/b3bbfb2bac57/MD_32212_2019.pdf)** | [Archiv](/search-results?q=MD_32212&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung der öffentlichen Abwasserbehandlung (2019)](https://download.statistik-berlin-brandenburg.de/aeb52ed1c715133f/501ee568489f/MD_32213_2019.pdf)** | [Archiv](/search-results?q=MD_32213&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung der öffentlichen Abwasserentsorgung - Klärschlamm (2021)](https://download.statistik-berlin-brandenburg.de/7410f84ba58398d1/61d3ef6437fc/MD_32214_2021.pdf)** | [Archiv](/search-results?q=MD_32214&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung über die Wassereigenversorgung und -entsorgung privater Haushalte (2019)](https://download.statistik-berlin-brandenburg.de/c15fbde68c75faaf/127ee9cd487f/MD_32251_2019.pdf)** | [Archiv](/search-results?q=MD_32251&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung der Wasser- und Abwasserentgelte (2022)](https://download.statistik-berlin-brandenburg.de/0e80a3da35f7f130/2afbbb712530/MD_32271_2022.pdf)** | [Archiv](/search-results?q=MD_32271&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung der nichtöffentlichen Wasserversorgung und Abwasserentsorgung (2019)](https://download.statistik-berlin-brandenburg.de/fa869374098218a3/399e40df4d70/MD_32221_2019.pdf)** | [Archiv](/search-results?q=MD_32221&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Erhebung der Unfälle mit wassergefährdenden Stoffen (2019)](https://download.statistik-berlin-brandenburg.de/34f7c7492155aec1/5e71d35b1a24/MD_32311_2019.pdf)** | [Archiv](/search-results?q=MD_32311&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/q-i-1-3j)
