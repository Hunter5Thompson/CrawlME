

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Service](/service)
* [Geoservice](/geoservice)

Geoservice
==========

Das Amt für Statistik Berlin-Brandenburg bietet raumbezogene Datenverarbeitung und -analyse auch über Amt und Verwaltung hinaus als Dienstleistung an. Dies umfasst die nachfolgend aufgeführten, teilweise kostenpflichtigen, Datenbereitstellungen und Tätigkeiten.

[Alle Services
#### Übersicht](/service)[Individuelle Auskünfte
#### Informationsservice](/service/informationsservice)[Karten und Geometrien
#### Geoservice](/geoservice)[Befragungen & Analysen
#### Befragungsservice](/service/befragungsservice)[Amtliche Mikrodaten
#### Forschungsdatenzentrum](https://www.forschungsdatenzentrum.de/de)[Wissenschaftliche Spezialbibliothek
#### Unsere Bibliothek](/service#bibliothek)![](https://download.statistik-berlin-brandenburg.de/fba4f3dc6c752dcb/ec4d2acdf58f/v/5e9533b2a764/schmuckbild-fis-broker.png)

Geodaten und Geo­metrien
------------------------

#### Individuelle Aggregate

Neben den tabellarischen Sachdaten zu Bezugsräumen werden auch die Geometrien in verschiedenen Geodaten-Formaten oder die Kombination Geometrie/Sachdaten angeboten. Einige dieser Geometrien stellen wir allen Interessierten zum kostenlosen Download im Geoportal der Senatsverwaltung für Stadtentwicklung und Wohnen (FIS-Broker) und dem Berlin Open Data Portal zur Verfügung. Der Dienst der Open Data Informationsstelle (ODIS) sammelt zudem besonders relevante Geobasisdatensätze und stellt diese teilweise aufbereitet zur Verfügung. Für individuelle, aktuelle Geometrien erstellen wir Ihnen gerne einen kostenlosen Kostenvoranschlag.

[Zum FIS-Broker](https://www.stadtentwicklung.berlin.de/geoinformation/fis-broker/)[Datensätze | Offene Daten Berlin](https://daten.berlin.de/datensaetze?title=&field_license_tid=All&field_publisher_tid=193&field_geo_granularity_tid=All&field_temporal_granularity_tid=All&field_geo_coverage_tid=All&state=open)[Daten | ODIS](https://daten.odis-berlin.de/index.html)

Thematische Karten
------------------

#### Zusammen­führung von Tabellen und Raum­einheiten

Zur anschaulichen Darstellung von ansonsten oft schwer zu interpretierenden statistischen Informationen werden aus den Geometrien der Raumeinheiten und den tabellarischen Statistiken thematische Karten erzeugt. Damit lassen sich auch komplexe räumliche Zusammenhänge eingängig darstellen.   


![](https://download.statistik-berlin-brandenburg.de/0d0b6d88bcf8eee9/22f5eb6bd3e4/v/3c15334cfad0/geoservice-1.jpg)![](https://download.statistik-berlin-brandenburg.de/0c0a1eb8c522c3dd/25695cd600d3/v/9cb6f32640aa/geoservice-2.jpg)![](https://download.statistik-berlin-brandenburg.de/93bc455dfedc7f99/67c8981182d2/v/263213f7787f/geoservice-4.jpg)![](https://download.statistik-berlin-brandenburg.de/bb2e02598b2ce6a9/6690e9e76841/v/9573b9597a7b/schmuckbild-verzeichnisse-berlin.jpg)

Regionalisierung
----------------

#### Zuordnung statistischer Daten und Bezugsräume

Als Regionalisierung bezeichnet man den Vorgang der Zuordnung statistischer Daten zu validierten, geokodierten Adressen und den dazugehörigen Bezugsräumen. Die Adressauskunft Berlin zeigt die "regionalisierte Adresse" mit einer Auswahl zugeordneter Bezugsräume. Mit der Regionalisierung von Einzel-Datenbeständen lassen sich die Statistiken auf einfache Art für verschiedene Raumeinheiten aggregieren.

[Zur Adressauskunft](/adressauskunft)

Verzeichnisse
-------------

#### Standardisierte oder benutzerdefinierte Adresstabellen

Über die Geodatenbank des Regionalen Bezugssystems (kurz: RBS) lassen sich in unzähligen Kombinationen Zuordnungstabellen (z.B. LOR zu Bezirk, Straße zu Planungsraum), Tabellen der Straßenumbenennungen oder verschiedene regionalisierte Adress-Tabellen generieren. Diese werden standardisiert oder benutzerdefiniert zur Verfügung gestellt.

###### Standardisierte Verzeichnisse:

###### Verzeichnisse Berlin

Bevölkerungsstand

Einbürgerungen, Ausländer

Geburten, Sterbefälle

Fort- und Zuzüge

Mikrozensus

###### Verzeichnisse Brandenburg

Bevölkerung

Gebäude und Wohnungen

Haushalte und Familien

Ihre individuelle Anfrage
-------------------------

Sie sind an spezifischen Geometrien interessiert? Sie benötigen Kartenvisualisierungen für komplexe räumliche Zusammenhänge? Dann laden Sie sich das entsprechende Anfrageformular herunter, füllen es so genau wie möglich aus und senden es per E-Mail an Geoservice@statistik-bbb.de oder hängen es dem untenstehenden Formular an.

### Schritt 1

#### Anfrageformular herunterladen

[Formular für Geodaten](https://download.statistik-berlin-brandenburg.de/0022f7a8d33c60ae/6ca89cb9fba0/Datenanfragen-Geodaten.docx)[Formular für Karten](https://download.statistik-berlin-brandenburg.de/fc53345e4716fed0/6c91a9cd9904/Kartenanfragen.docx)
### Schritt 2

#### Ausgefülltes Formular senden an:

[geoservice@statistik-bbb.de](mailto:geoservice@statistik-bbb.de)
### Schritt 3

#### Ihr individuelles Angebot

Nach Eingang Ihrer Anfrage unterbreiten wir Ihnen ein individuelles Angebot, das Kosten- und Zeitaufwände berücksichtigt. Die Erstellung des Angebots ist kostenlos. In der Regel beantworten wir Angebotsanfragen in zwei Werktagen.


