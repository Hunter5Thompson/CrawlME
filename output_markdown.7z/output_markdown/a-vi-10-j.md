

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Erwerbstätigkeit](/erwerbstaetigkeit)
* [Erwerbstätige am Arbeitsort in den kreisfreien Städten und Landkreisen des Landes Brandenburg](/a-vi-10-j)

Erwerbstätige am Arbeitsort in den Landkreisen und kreisfreien Städten Brandenburgs
-----------------------------------------------------------------------------------

#### 1991 bis 2022, jährlich

###### Hier finden Sie jährliche Ergebnisse zur Erwerbstätigkeit am Arbeitsort in den 14 Landkreisen und vier kreisfreien Städten Brandenburgs aus der Erwerbstätigenrechnung des Arbeitskreises „Erwerbstätigenrechnung der Länder“, darunter Zahlen zu den Erwerbstätigen, Selbstständigen sowie Arbeitnehmerinnen und Arbeitnehmern nach ausgewählten Wirtschaftsbereichen.

BrandenburgMethodik
### Brandenburg

**Erwerbstätigkeit 2022 in den Landkreisen stärker gestiegen als in den kreisfreien Städten**

Die Zahl der Erwerbstätigen erhöhte sich 2022 in den 14 Landkreisen Brandenburgs gegenüber dem Vorjahr um durchschnittlich 1,2 % auf insgesamt 887.300. In den vier kreisfreien Städten betrug der Anstieg durchschnittlich 0,8 %. Im Jahresdurchschnitt 2022 waren dort insgesamt 257.700 Personen erwerbstätig.

In den Dienstleistungsbereichen verzeichneten die Landkreise ein Plus von 1,3 % (+8.100 Erwerbstätige). In den kreisfreien Städten erhöhte sich hier die Erwerbstätigkeit um 1,0 % (+2.300 Erwerbstätige). Gegensätzliche Entwicklungen lagen im Produzierenden Gewerbe vor: Hier sank die Erwerbstätigkeit in den kreisfreien Städten um 300 Personen bzw. 1,2 %. Dagegen nahm sie in den Landkreisen um 2.600 Personen bzw. 1,2 % zu. Das ist insbesondere auf den Anstieg um 3.700 Erwerbstätige im Verarbeitenden Gewerbe im Landkreis Oder-Spree zurückzuführen. Mit einem Plus von 4.100 Erwerbstätigen bzw. 5,4 % verzeichnete der Landkreis Oder-Spree auch insgesamt die stärkste Zunahme unter allen Kreisen Brandenburgs. Darauf folgt Teltow-Fläming mit einer Zuwachsrate von 2,8 % (+2.300 Erwerbstätige). Hierzu trugen sowohl Zuwächse im Produzierenden Gewerbe (+800 Erwerbstätige) als auch in den Dienstleistungsbereichen (+1.500 Erwerbstätige) bei.

In den Landkreisen Prignitz und Spree-Neiße ging die Erwerbstätigkeit mit jeweils minus 1,0 % (–400 Personen) landesweit am stärksten zurück. In der Prignitz verteilte sich der Rückgang in etwa gleichmäßig auf das Produzierende Gewerbe und den Dienstleistungsbereich. In Spree-Neiße sank die Erwerbstätigkeit im Bereich „Land- und Forstwirtschaft, Fischerei“ und im Produzierenden Gewerbe, nahm jedoch in den Dienstleistungsbereichen insgesamt zu.

Erwerbstätige (Veränderung) Erwerbstätige (Anzahl)Veränderung nach WirtschaftsbereichenAnteil nach Wirtschaftssektoren
###### Veränderung gegenüber dem Vorjahr in %

#### Erwerbstätige¹ in den Kreisen Brandenburgs 2022

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### **Berechnungsstand: August 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7a93f6c477e06ffd/098a2d9c88d9/SB_A06-10-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/eb085fdef3f0f176/d4143c6f3c82/SB_A06-10-00_2022j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

  


Die Erwerbstätigenrechnung (ETR) liefert ein umfassendes Bild der wirtschaftlich aktiven Bevölkerung. Auf der Grundlage einer Vielzahl erwerbsstatistischer Datenquellen wird sowohl die Zahl der Erwerbstätigen am Arbeitsort (Inlandskonzept) und Wohnort (Inländerkonzept) als auch das Arbeitsvolumen nach der Stellung im Beruf und der wirtschaftsfachlichen Gliederung ermittelt. Ergebnisse für das Bundesgebiet werden von Destatis berechnet, für die Länder sowie Landkreise und kreisfreien Städte vom Arbeitskreis „Erwerbstätigenrechnung der Länder“ (AK ETR). Die Berechnungen erfolgen nach den konzeptionellen und definitorischen Vorgaben des Europäischen Systems Volkswirtschaftlicher Gesamtrechnungen (ESVG 2010), wodurch internationale Vergleichbarkeit gewährleistet ist.

Die hier vorliegenden Ergebnisse für die Landkreise und kreisfreien Städte Brandenburgs sind abgestimmt auf das vom AK ETR im Oktober 2023 veröffentlichte Landesergebnis für Brandenburg mit Rechenstand des Statistischen Bundesamtes vom August 2023. Neben der Erstberechnung der Ergebnisse für das Jahr 2022 wurden die der Jahre 2019 bis 2021 turnusmäßig überarbeitet.

Ergebnisse aller Landkreise und kreisfreien Städte Deutschlands stellt der AK ETR unter [www.statistikportal.de/de/etr](https://www.statistikportal.de/de/etr "Verknüpfung folgen") zur Verfügung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erwerbstätige**ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/b85a593b815ea440/a3de95641681/MD_13300_2023.pdf)[Archiv](/search-results?q=MD_13300&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)
