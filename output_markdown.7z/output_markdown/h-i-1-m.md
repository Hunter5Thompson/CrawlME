

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Verkehr](/gesellschaft/verkehr)
* [Straßenverkehr](/strassenverkehr)
* [Straßenverkehrsunfälle in Berlin und Brandenburg](/h-i-1-m)

Straßenverkehrsunfälle
----------------------

#### Oktober 2024, monatlich (vorläufige Ergebnisse)

###### Die Statistik der Straßenverkehrsunfälle informiert monatlich über polizeilich aufgenommene Unfälle in der Region. Die Zahlen sind nach der Schwere des Unfalls, den Beteiligten (beispielsweise Kinder oder Fahrradfahrende), Unfallursache und -typ differenziert.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/3f51a1578c220678/a50a7ee09fe8/SB_H01-01-00_2024m10_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/1b979e4a8f78fe81/e41d1d1c0fb9/SB_H01-01-00_2024m10_BE.pdf)

**Weniger Verkehrsunfälle und weniger Verunglückte**

Im Oktober 2024 registrierte die Polizei nach vorläufigen Ergebnissen auf Berlins Straßen 11.356 Verkehrsunfälle, 3,4 % weniger als im Oktober 2023.

Bei 1.175 Unfällen mit Personenschaden (–6,8 Prozent) verunglückten 1.385 Personen. Das waren 108 Personen bzw. 7,2 % weniger als im Vorjahresmonat. 144 Personen wurden schwer (–20,9 %) und 1.239 leicht verletzt (–5,1 %). Zwei Personen verunglückten tödlich. Im Oktober 2023 wurden fünf Verkehrsteilnehmer getötet. Die Zahl der schwerwiegenden Unfälle sank um 9,8 % auf 156. Darunter sank die Zahl der Unfälle unter dem Einfluss berauschender Mittel um 4 auf 64. Bei den übrigen Sachschadensunfällen, den sogenannten Bagatellunfällen, gab es einen Rückgang um 2,9 %.

### Kontakt

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Mehr Verkehrsunfälle, aber weniger Schwerverletzte**

Auf Brandenburgs Straßen nahm die Polizei nach vorläufigen Ergebnissen im Oktober 2024 insgesamt 6.421 Verkehrsunfälle auf. Das waren 5,8 % mehr als im Oktober 2023.

Die Zahl der Unfälle mit Personenschaden stieg um 3,4 % auf 700. Es verunglückten 883 Personen, 48 Personen bzw. 5,7 % mehr als im Vorjahresmonat. 145 Personen wurden schwer (–5,8 %) und 729 leicht verletzt (+8,8 %). Neun Personen verunglückten tödlich, zwei Person weniger als im Oktober 2023. Die Zahl der schwerwiegenden Unfälle stieg um 16,1 % auf 267. Darunter sank die Zahl der Unfälle unter dem Einfluss berauschender Mittel um zwei auf 37. Bei den übrigen Sachschadensunfällen, den sogenannten Bagatellunfällen, gab es einen Anstieg um 5,7 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/eaa575cfd43bca2c/b2af4f9e367a/SB_H01-01-00_2024m10_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/25c88c5228a6f352/7f7b70392d76/SB_H01-01-00_2024m10_BB.pdf)
### Kontakt

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die monatliche Straßenverkehrsunfallstatistik dient der Gewinnung zuverlässiger und bundesweit vergleichbarer Daten zur Verkehrssicherheitslage.

Erhebungsinhalte sind ausführliche Angaben zu Unfällen, Beteiligten, Fahrzeugen, Verunglückten und Unfallursachen sowie die Zahl der Benutzer unfallbeteiligter Fahrzeuge.

Ergebnisse zum Unfallgeschehen sind Grundlage für eine Vielzahl von Maßnahmen im Bereich der Gesetzgebung, der Verkehrserziehung, des Straßenbaus oder der Fahrzeug­technik. Die Statistik hat das Ziel, Strukturen des Unfallgeschehens und Abhängigkeiten zwischen Unfall bestimmenden Faktoren aufzuzeigen.

Die Erhebung wird als Vollerhebung mit Auskunftspflicht der Polizeidienststellen, deren Beamte einen Unfall aufgenommen haben, durchgeführt. In der Statistik sind nur die Unfälle enthalten, die sich infolge des Fahrverkehrs auf öffentlichen Straßen, Wegen und Plätzen ereignet haben und polizeilich aufgenommen wurden. Insbesondere Verkehrsunfälle, bei denen nur Sachschaden vorliegt oder Personen nur geringfügig verletzt wurden, werden der Polizei nur zum Teil angezeigt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der
Straßenverkehrsunfälle**  
ab 2017

[Download PDF](https://download.statistik-berlin-brandenburg.de/a6287a446497ff08/d749c78a7e16/MD_46241_2017.pdf)[Archiv](/search-results?q=46241&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/h-i-1-m)
