

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Schulen](/gesellschaft/bildung/schulen)
* [Berufliche Schulen in Brandenburg einschließlich Ergebnisse nach Verwaltungsbezirken](/b-ii-1-j)

Berufliche Schulen in Brandenburg einschließlich Ergebnisse nach Verwaltungsbezirken
------------------------------------------------------------------------------------

#### Schuljahr 2023/2024, jährlich

###### Der Statistische Bericht liefert jährlich detaillierte Informationen u.a. über die Entwicklung der Schülerzahlen nach Bildungsgängen, zu Absolventinnen und Absolventen nach Abschlussarten und zu Lehrkräften.

BrandenburgMethodik

Brandenburg
-----------

**Leichter Anstieg gegenüber dem Vorjahr**

Im Schuljahr 2023/24 besuchen 38.629 Schülerinnen und Schüler an Brandenburgs Beruflichen Schulen berufliche Bildungsgänge.

Von den 38.629 Schülerinnen und Schülern befinden sich 25 963 (67,2 %) im Bildungsgang Berufsschule, 4.334 (11,2 %) im Bildungsgang Berufsfachschule, 2.770 (7,2 %) im Bildungsgang Fachoberschule und 5.562 (14,4 %) im Bildungsgang Fachschule.

Der schulische Teil der dualen Berufsausbildung bildet mit einem Anteil von 63,5 % den Hauptbestandteil der beruflichen Bildung. Dieser Anteil blieb seit dem Schuljahr 2018/19 mit ca. 63 % relativ konstant (Schuljahr 2022/23 = 63,6 %, 2021/22 = 63,6 %, 2020/21 = 63,3  %, 2019/20=63,7 %). Im laufenden Schuljahr ist bei den absoluten Schülerzahlen mit 24.541 Schülerinnen und Schülern ein Anstieg gegenüber dem Vorjahr um 298 Schülerinnen und Schüler zu verzeichnen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023/24**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/09c23f6e0496314c/5d85ae18a600/SB_B02-01-00_2023j01_BB.xlsx) 

3. korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/15f8791bab6dd49c/1e36042f867c/SB_B02-01-00_2023j01_BB.pdf)
### Kontakt

#### Ramona Klasen

Schulen

#### Ramona Klasen

Schulen

* [0331 8173-1146](tel:0331 8173-1146)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Matthias Gebhard

Schulen

#### Matthias Gebhard

Schulen

* [0331 8173-1103](tel:0331 8173-1103)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der statistische Bericht enthält Ergebnisse über Schulen, Schülerinnen und Schüler, Absolventinnen und Absolventen, Abgängerinnen und Abgänge, und Lehrkräfte an beruflichen Schulen im Land Brandenburg im Berichtsjahr und nach Verwaltungsbezirken und staatlichen Schulämtern. Die Ergebnisse sind nach Ländersystematik aufbereitet und für Ländervergleiche nur bedingt geeignet.

Die Erhebung der Statistik der allgemeinbildenden und beruflichen Schulen (Schulstatistik) wird jährlich zu Schuljahresbeginn bzw. zum Schuljahresende, als koordinierte Länderstatistik durchgeführt. Auswertungen der erhobenen Daten werden in der regionalen Gliederung bis auf die Ebene der Verwaltungsbezirke auf der Basis des Schulstandortes vorgenommen. Diese Statistik wird als Totalerhebung mit Auskunftspflicht aller allgemeinbildenden und beruflichen Schulen des Landes Brandenburg in öffentlicher und freier Trägerschaft durchgeführt.

Zum Erhebungsprogramm der Schulstatistik gehören Angaben über Schulen, Klassen, Schülerinnen und Schüler, Absolventinnen und Absolventen, Abgänge­rinnen und Abgänger sowie Lehrkräfte. Die Schulstatistik liefert jährlich detaillierte Informationen u.a. über die Entwicklung der Schülerzahlen nach Bildungsgängen, zu Absolventinnen und Absolventen nach Abschlussarten und zu Lehrkräften.

Hauptnutzer sind das Ministerium für Bildung, Jugend und Sport, das Bundesministerium für Bildung und Forschung, die KMK, Eurostat, wissenschaftliche Einrichtungen und die interessierte Öffentlichkeit.

Im Land Brandenburg werden Individualdaten erhoben. Die Erhebungsmerkmale werden vom MBJS des Landes Brandenburg in Anlehnung an den Kerndatensatz der KMK festgelegt. Die regionale Zuordnung erfolgt nach dem Hauptstandort der Schule. Das berufliche Gymnasium wird dem allgemeinbildenden Bereich des Schulwesens zugeordnet.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der beruflichen Schulen**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/a74a8856b4f26c8d/259fa97bcb96/MD_21111_2022.pdf)[Archiv](/search-results?q=21111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-ii-1-j)
