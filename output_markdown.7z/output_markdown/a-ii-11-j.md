

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Berlin-Statistik](/kommunalstatistik)
* [Einwohnerbewegung Berlin](/kommunalstatistik/wanderungen-berlin)
* [Einwohnerbewegung Berlin – Wanderungen, Geburten, Sterbefälle](/a-ii-11-j)

Einwohnerbewegung – Wanderungen,
--------------------------------

Geburten, Sterbefälle
---------------------

#### 2023, jährlich

###### Die Statistik gibt einen Überblick über Geburten und Sterbefälle sowie über die Zu- und Fortzüge innerhalb und über die Grenzen Berlins auf Ebene der Bezirke, ausgewiesen nach demografischen Merkmalen wie Alter, Geschlecht und Staatsangehörigkeit sowie Herkunfts- und Zielgebiete.

BerlinMethodik
### Berlin

Geburten- und SterbeüberschussWanderungssaldo
###### 2023 in Berlin nach Bezirken

#### Geburten- und Sterbeüberschuss

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/1e8248eb37f1c31d/f3cd8c8e72bf/SB_A02-11-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/6fb7d72190e692ac/56701bedcdfa/SB_A02-11-00_2023j01_BE.pdf) 

**Wanderungsgewinn gesunken**

Berlin verzeichnete am 31.12.2023 einen Wanderungsgewinn von 33.874 Personen – ein Rückgang um 55,4 % gegenüber dem Vorjahr (2022: 76.000). Insgesamt wurden 195.705 Zuzüge und 161.831 Fortzüge gezählt (ohne Binnenumzüge).

Zu einem Großteil ging der Wanderungsüberschuss auf die Zuwanderung von Personen mit ausländischer Staatsangehörigkeit zurück. Mit 135.140 Zuzügen und 83.162 Fortzügen ergab sich im Saldo ein Zuwachs von 51.978 Personen. Demgegenüber steht ein Wanderungsverlust von 18.104 Personen mit deutscher Staatsangehörigkeit.

Asiatische Staatsangehörige bildeten mit einem Saldo von 23.469 Personen die stärkste Zuwanderungsgruppe. Zuwanderungen ukrainischer Staatsangehörigkeit sind 2023 um 87,9 % zurückgegangen. Weitere hohe Wanderungsgewinne erzielte Berlin aus dem Zuwachs europäischer Staatsangehöriger (20.891).

Innerhalb Berlins wurden 275.491 Umzüge registriert. Davon mit 32.558 und 30.060 die meisten in den Bezirken Pankow und Mitte. In der Altersgruppe der 27- bis 45-Jährigen wurde viermal so häufig umgezogen wie in der Altersgruppe der 45- bis 65-Jährigen.

Berlinweit kamen 33.425 Kinder zur Welt und 37.455 Personen sind verstorben. Damit ergab sich erneut ein Sterbeüberschuss von 4.030 Personen. Die meisten Geburten wurden in Pankow (3.558) und Mitte (3.516) registriert.

### Kontakt

#### Katja Niemann-Ahrendt

Kommunalstatistik

#### Katja Niemann-Ahrendt

Kommunalstatistik

* [0331 8173-3868](tel:0331 8173-3868)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

In der Einwohnerregisterstatistik werden neben den Bestands- auch Bewegungsdaten über melderechtlich registrierte Einwohnende aus dem Einwohnerregister des Landesamtes für Bürger- und Ordnungsangelegenheiten (LABO) jährlich zum Stand 31.12. eines Jahres aufbereitet und ausgewertet.

Als landesspezifische Statistik dient sie vor allem dem Nachweis kleinräumiger demografischer Daten. Aus den Grunddaten werden Bewegungen der Einwohnenden, wie Geburten, Sterbefälle und Wanderungen, abgeleitet. Neben den kleinräumigen Wanderungsbewegungen über die Grenze Berlins werden auch Binnenwanderungen zwischen den Bezirken abgebildet.

Die Bereitstellung kleinräumiger Einwohnerdaten und deren abgeleiteten Merkmale sind wesentliche Grundlage für eine Vielzahl von sozial-, jugend-, gesundheits- und städteplanerischen Aufgaben und sozialraumorientierten Entscheidungen im Land Berlin.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Bewegungsdaten Einwohnerregister Berlin**  
Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/04255f8125427bea/2ce278ee57d3/MD_19212_2021.pdf)[Archiv](/search-results?q=MD_19212&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true#results)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-ii-11-j)
