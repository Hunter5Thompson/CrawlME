

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)

Tourismus und Gast­gewerbe
==========================

Die Tourismusstatistik ist eine monatliche Totalerhebung bei Beherbergungsbetrieben mit mindestens zehn Betten bzw. zehn Stellplätzen. Sie bildet die saisonale und regionale Entwicklung von Angebot und Nachfrage nach Beherbergungsdienstleistungen ab.

In der Gastgewerbestatistik wird, zur Darstellung der konjunkturellen und strukturellen Entwicklung, ein repräsentativer Kreis rechtlicher Einheiten monatlich bzw. jährlich befragt. Die Ergebnisse werden hochgerechnet und monatlich als Messzahlen bzw. jährlich als absolute Werte bereitgestellt.

[![iStock.com / jotily](https://download.statistik-berlin-brandenburg.de/bc84f523d272e119/3538d6cc5df4/v/39612975c6ec/bevoelkerung-gesellschaft-berlin-kreuzberg-oberbaumbridge-picture-id913311660.jpg "iStock.com / jotily")](/tourismus-berlin)**Touristische Entwicklungen in der Spreemetropole**[#### Berlin 2018 bis 2023](/tourismus-berlin)

Touristische Kennzahlen und Entwicklungen in der Hauptstadt – Gäste, Übernachtungen, Herkunftsländer, Umsätze, Auszubildende uvm....

[![iStock.com / Vladislav Zolotov](https://download.statistik-berlin-brandenburg.de/87f608040b23d410/f253909b08b6/v/52f2573769ca/bevoelkerung-demographie-tourismus-old-market-square-with-st-nicholas-church-and-town-hall-potsdam-picture-id1209637381.jpg "iStock.com / Vladislav Zolotov")](/tourismus-brandenburg)**Aktuelle Kennzahlen für das Urlaubsland Brandenburg**[#### Brandenburg 2018 bis 2023](/tourismus-brandenburg)

Überblick zum Tourismus in Brandenburg, die wichtigsten Kennzahlen und Statistiken – Gäste, Übernachtungen, Herkunftsländer, Umsätze, Auszubildende uvm....

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

### Tourismus

[Gäste, Übernachtungen und Beherbergungskapazität in Berlin und Brandenburg, monatlich (GIV1-m)](/g-iv-1-m)[Tourismus in Berlin – vorläufige Ergebnisse, monatlich (GIV2-m)](/g-iv-2-m)[Tourismus in Brandenburg nach Gemeinden, monatlich (GIV8-m)](/g-iv-8-m)[Tourismus in Brandenburg nach Gemeinden, jährlich (GIV9-j)](/g-iv-9-j)
### Gastgewerbe

[Umsatz und Beschäftigung im Gastgewerbe in Berlin und Brandenburg – Messzahlen, jährlich (GIV3-j)](/g-iv-3-j)[Umsatz, Beschäftigung und Investitionen im Gastgewerbe in Berlin und Brandenburg, jährlich (GIV4-j)](/g-iv-4-j)[Umsatz und Beschäftigung im Gastgewerbe in Berlin und Brandenburg – Messzahlen, monatlich (GIV5-m)](/g-iv-5-m)

Zeitreihen
----------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Tourismus

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/1bdca4167b76222b/4e07d92f6cad/Zeitreihe-2023.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/377dcc8160416d1a/0017334c1b49/tourismus-gastgewerbe-lange-reihe.xlsx)2 ab 2011 verkettet3 vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg2 ab 2011 verkettet3 vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Gastgewerbe

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/5201e9b433f439a4/bdf186f4ce8e/tourismus-gastgewerbe-lange-reihen-2023-gastgewerbe.xlsx)

Basisdaten
----------

Tourismus: BeherbergungsbetriebeTourismus: GästeTourismus: ÜbernachtungenGastgewerbe: StrukturerhebungGastgewerbe: Konjunkturerhebung

Regionaldaten
-------------

###### Berliner Bezirke

#### Geöffnete Beherbergungsbetriebe¹ 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Landkreise und kreisfreie Städte in Brandenburg

#### Geöffnete Beherbergungsbetriebe¹ 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=find&suchanweisung_language=de&query=45412#abreadcrumb)
#### Tourismusatlas

![](https://download.statistik-berlin-brandenburg.de/32c0ab1d90becabc/73b1f11b6a13/v/bfc6dbf0129f/Polen-Tourismusatlas.PNG)

Der interaktive Atlas visualisiert regionale Beherbergungsdaten für die Hauptstadtregion und die Brandenburger Reisegebiete.

[Zum Tourismusatlas](https://gis-hsl.hessen.de/portal/apps/webappviewer/index.html?id=621b2739ff8f43e895a759cc0dcc2c70)

Haben Sie Fragen?
-----------------

#### Monika Buchholz

Tourismus

#### Monika Buchholz

Tourismus

* [0331 8173-3329](tel:0331 8173-3329)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de)
#### Eliza McGownd

Gastgewerbe Konjunktur

#### Eliza McGownd

Gastgewerbe Konjunktur

* [0331 8173-3534](tel:0331 8173-3534)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Ines Sawinsky

Gastgewerbe Struktur

#### Ines Sawinsky

Gastgewerbe Struktur

* [0331 8173-1235](tel:0331 8173-1235)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Bedienung mit zwei Desserttellern in Restaurantküche](https://download.statistik-berlin-brandenburg.de/d3aee91e75d08b10/db8fc675bf3d/v/c09a768605ad/AdobeStock_280942571.jpg "Bedienung mit zwei Desserttellern in Restaurantküche")](/163-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Berlin**[#### Gemischte Entwicklung im Einzelhandel und Gastgewerbe](/163-2024)

Der Berliner Einzelhandel meldete im 3. Quartal 2024 ein reales Umsatzplus von 1,3 % gegenüber dem Vorjahreszeitraum.

[![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)](/164-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Brandenburg**[#### Einzelhandel wächst, Gastgewerbe schwächelt](/164-2024)

Der Brandenburger Einzelhandel meldete im 3. Quartal 2024 eine reale Umsatzsteigerung um 1,7 % gegenüber dem Vorjahreszeitraum....

[![iStock.com / Vladislav Zolotov](https://download.statistik-berlin-brandenburg.de/87f608040b23d410/f253909b08b6/v/52f2573769ca/bevoelkerung-demographie-tourismus-old-market-square-with-st-nicholas-church-and-town-hall-potsdam-picture-id1209637381.jpg "iStock.com / Vladislav Zolotov")](/156-2024)**Tourismus Januar bis September 2024 Brandenburg**[#### Weiter auf Erfolgskurs](/156-2024)

Die Brandenburger Beherbergungsbetriebe zählten von Januar bis September 2024 insgesamt 4,3 Millionen Gäste mit 11,6 Millionen Übernachtungen.

[Zu unseren News](/news)

[* Gastronomie](/search-results?q=tag%3AGastronomie)[* Gäste](/search-results?q=tag%3AGäste)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)[* Übernachtungen](/search-results?q=tag%3AÜbernachtungen)[* Reisegebiete](/search-results?q=tag%3AReisegebiete)
