

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Holzeinschlag in Brandenburg](/c-v-1-j)

Holzeinschlag in Brandenburg
----------------------------

#### 2023, jährlich

###### Die Holzeinschlagsstatistik liefert Ergebnisse zum Rohholzaufkommen in Deutschland differenziert nach Holzartengruppen (z. B. Eiche) und Sorten (z. B. Stammholz) jeweils nach Waldeigentumsarten (Staats-, Körperschafts- und Privatwald).

BrandenburgMethodik
### Brandenburg

**4,6 Millionen Kubikmeter Holz**

Im Jahr 2023 wurden in Brandenburgs Wäldern 4,6 Millionen Kubikmeter Holz (ohne Rinde) eingeschlagen. Gegenüber 2022 verringerte sich der Einschlag um 12 % bzw. 652.00 Kubikmeter. Der Anteil, der durch Schäden verursacht wurde, lag bei 23 %. Ein Jahr zuvor waren es 39 %. Ursachen hierfür sind Wind und Sturm (23 %), Schädigungen durch Insekten (42 %) sowie eine zunehmende Trockenheit (22 %).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/35557bf0814109a4/a2212f9bf80e/SB_C05-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/e2d8753a068440e8/a3c358da4696/SB_C05-01-00_2023j01_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung ist eine dezentrale Bundesstatistik. In der Datengewinnung erfolgt eine Kombination aus Nutzung von Verwaltungsdaten, direkter Befragung und Schätzung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht. Auskunftspflichtig sind die Inhaberinnen und Inhaber bzw. Leiterinnen und Leiter der Betriebe, die Rohholz auf Waldflächen erzeugen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Holzeinschlagsstatistik (Erhebung in forstlichen Erzeugerbetrieben)**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/2629e7e255a7de81/016a47a5c913/MD_41261_2023.pdf)[Archiv](/search-results?q=41261&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-v-1-j)
