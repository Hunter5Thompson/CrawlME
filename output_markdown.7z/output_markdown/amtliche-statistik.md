

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Über uns](/ueber-uns)
* [Amtliche Statistik](/amtliche-statistik)

Amtliche Statistik
==================

#### Verlässliche Zahlen und Fakten für Verwaltung, Politik und Gesellschaft

Die amtliche Statistik ist ein Informationsangebot der Bundesrepublik Deutschland. Sie liefert regelmäßig Daten aus vielen Lebensbereichen und unterstützt die Planungssicherheit von Politik und Verwaltung. Das Amt für Statistik Berlin-Brandenburg erfüllt als Mitglied der Arbeitsgemeinschaft „Statistischer Verbund“ die Aufgabe der amtlichen Statistik für die Hauptstadtregion.

GrundsätzeGesetzesgrundlagenVerbundÜberblick

Grundsätze
----------

**Die Grundsätze der amtlichen Statistik sind im**[**Bundesstatistikgesetz**](https://www.gesetze-im-internet.de/bstatg_1987/index.html)**verankert.**

**Amtliche Statistiken sind per Gesetz objektiv, neutral und wissenschaftlich unabhängig.**

**Für jede amtliche Statistik ist eine Rechtsgrundlage erforderlich.**

  


**Das zentrale Fundament ist die statistische Geheimhaltung der erhobenen Einzeldaten.**

**Die Datenerhebung folgt nach einheitlichen Standards (EU-, Bundes- und koordinierte Länderstatistiken).**

**Die amtliche Statistik ist unabhängig von gesellschaftlichen Gruppen oder der jeweiligen Regierung.**

Gesetzliche Grundlagen
----------------------

Die ausschließliche Gesetzgebung über die Statistik für Bundeszwecke (Bundesstatistik) hat der Bund (nach Artikel 73 Nummer 11 Grundgesetz). Landesstatistikgesetze bestimmen zusätzlich die Aufgaben der Bundesländer. Auch das Recht der Europäischen Union hat Einfluss auf die Erhebungen der amtlichen Statistik in Deutschland.

[#### Europa](/#)

* [Verhaltenskodex für europäische Statistiken](https://ec.europa.eu/eurostat/documents/4031688/9394019/KS-02-18-142-DE-N.pdf/27ca19ca-e349-45f8-bbd4-4d78a33601ae?t=1542709797000)
[#### Deutschland](/#)

* [Gesetz über die Statistik für Bundeszwecke](https://www.gesetze-im-internet.de/bstatg_1987/index.html)
[#### Berlin](/#)

* [Gesetz über die Statistik im Land Berlin](https://gesetze.berlin.de/bsbe/document/jlr-StatGBErahmen)
[#### Brandenburg](/#)

* [Gesetz über die Statistik im Land Brandenburg](https://bravors.brandenburg.de/gesetze/bbgstatg)
#### Europäischer Verhaltenskodex (Code of Practice) und Vorabinformationen

Nach dem Verhaltenskodex (Code of Practice) für europäische Statistiken sollen Ergebnisse der amtlichen Statistik von den statistischen Stellen selbst veröffentlicht und allen externen Nutzenden gleichzeitig und gleichberechtigt zur Verfügung gestellt werden. Davon gibt es begründete Ausnahmen, die nach internationaler Praxis akzeptiert sind, wenn sie transparent gemacht werden. Hierunter fallen[**Vorabinformationen**](/presse#vorabinfo) an Landesverwaltungen, die mit Medienanfragen zu den Veröffentlichungen der statistischen Ämter rechnen müssen.

Statistik im Verbund
--------------------

Die Statistischen Ämter der Länder sind für die Durchführung der Erhebungen, die Aufbereitung und die Veröffentlichung zuständig. Durch die Kooperation in einem „Statistikverbund“ entstehen für alle Länder vergleichbare und zu einem Bundesergebnis zusammenführbare Erhebungsresultate.

* ###### Landesebene
  
  14 Statistische Ämter der Länder
* ###### Bundesebene
  
  Statistisches Bundesamt (Destatis)
* ###### Europäische Ebene
  
  Eurostat

### Zusammenarbeitauf Landesebene

**Hintergrund:** Die Bundesstatistik ist ein Gemeinschaftsprodukt, das im Wesentlichen von den 14 Statistischen Ämtern der Länder und vom Statistischen Bundesamt erstellt wird. Der Begriff „Statistischer Verbund“ bezeichnet diese Arbeitsgemeinschaft, der Begriff regionale Dezentralisierung das dahinterstehende Prinzip.

**Aufgaben:** Die Statistischen Ämter der Länder erfüllen die Aufgaben der amtlichen Statistik in Deutschland gemeinsam und in Zusammenarbeit mit dem Statistischen Bundesamt. Entsprechend dem föderalen Staatsaufbau in Deutschland sind die Länder in der Regel für die Erhebung der Daten und die Aufbereitung bis zum Landesergebnis zuständig. Die einzelnen Statistischen Ämter der Länder veröffentlichen demnach regionale Ergebnisse, also Daten für Gebietsgliederungen unterhalb der Länderebene.

![](https://download.statistik-berlin-brandenburg.de/07968c6797b39c80/6ee0ade6bd5e/v/c0ea52f29f32/ueber-uns-schmuckbild-laender.jpg)

Amtliche Statistik im Überblick
-------------------------------

![](https://download.statistik-berlin-brandenburg.de/3ec1fbdfa7b2bc65/c371d7dd3cce/v/d9cb50c678d7/amtliche-statistik-deutschland.png)

Weitere Themen
--------------

Aktuelles[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Zu allen Beiträgen


