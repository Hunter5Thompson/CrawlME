

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Hochschulen](/hochschulen)
* [Hochschulfinanzstatistik in Berlin und Brandenburg](/b-iii-7-j)

Finanzen der Hochschulen
------------------------

#### 2022, jährlich

###### Die Statistik über die Finanzen der Hochschulen stellt Informationen über die Lehr- und Forschungsstruktur der Hochschulen in den Ländern Berlin und Brandenburg zur Verfügung.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/94aeeb54e7a89729/0dade4e5989d/SB_B03-07-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/d970c5b1e7ca38f7/7d10d0063164/SB_B03-07-00_2022j01_BE.pdf)

**Hochschulausgaben 2022 weiter gestiegen**

Im Jahr 2022 gaben die Hochschulen in Berlin rund 4,6 Mrd. EUR für Lehre und Forschung aus. Das sind 217,2 Mill. EUR mehr als 2021. Von den gesamten Hochschulausgaben entfielen 51,8 % auf die Hochschulkliniken (2,4 Mrd. EUR) und 35,9 % auf die Universitäten (1,7 Mrd. EUR).

Die Personalausgaben waren mit 2,8 Mrd. EUR der größte Ausgabeposten bei den Hochschulen. Ihr Anteil an den Gesamtausgaben betrug wie im Vorjahr 59,5 %.

Die Hochschuleinnahmen (ohne Trägermittel) beliefen sich auf 2,9 Mrd. EUR, davon waren 27,4 % eingeworbene Drittmittel.

  


### Kontakt

#### Andrea Götze

Hochschulfinanzen

#### Andrea Götze

Hochschulfinanzen

* [0331 8173-1250](tel:0331 8173-1250)
* [hochschulfinanzen@statistik-bbb.de](mailto:hochschulfinanzen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Ausgaben für Lehre und Forschung 2022 leicht gestiegen**

Die Ausgaben für Lehre und Forschung an den Hochschulen des Landes Brandenburg beliefen sich im Jahr 2022 auf 819,8 Mill. EUR, das sind 66,7 Mill. EUR mehr als 2021. Das entspricht einer Steigerung um 8,9 %.

Die Universitäten hatten bei den Ausgaben insgesamt einen Anteil von 68,2 % (558,8 Mill. EUR). Die Personalausgaben in Höhe von 538,2 Mill. EUR erreichten einen Anteil von 65,6 % an den gesamten Hochschulausgaben.

Die Hochschulen in Brandenburg nahmen 253,9 Mill. EUR ein (ohne Trägermittel), 68,6 % davon waren Drittmittel.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4a4a2ac3c27f6536/fa5f9ebc7658/SB_B03-07-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/38b4929713391d98/f37206d79022/SB_B03-07-00_2022j01_BB.pdf)
### Kontakt

#### Andrea Götze

Hochschulfinanzen

#### Andrea Götze

Hochschulfinanzen

* [0331 8173-1250](tel:0331 8173-1250)
* [hochschulfinanzen@statistik-bbb.de](mailto:hochschulfinanzen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Hochschulfinanzstatistik ist eine jährliche Totalerhebung aller Einnahmen und Ausgaben bzw. Erträge und Aufwendungen sowie Investitionsausgaben in fachlicher und organisatorischer Gliederung, jeweils einschließlich der über Verwahrkonten vereinnahmten Drittmittel und der internen Leistungsverrechnung.

Die Erhebungseinheiten sind die staatlichen und privaten Hochschulen einschließlich der Hochschulkliniken, die in dem Bundesland ansässig sind. Hierzu zählen alle Bildungseinrichtungen, die nach Landesrecht als Hochschulen anerkannt sind.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Hochschulfinanzstatistik**2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/34d7e8970f409090/a57890a60cb1/MD_21371_2022.pdf)[Archiv](/search-results?q=21371&searchMethodik=true&pageNumber=1&sortBy=date-desc&category=%2Fabout%2Fe1ef917ad030b642&searchByButton=true#results)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-iii-7-j)
