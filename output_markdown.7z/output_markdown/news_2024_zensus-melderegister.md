

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 19.12.2024

#### Unterschiede in der amtlichen Datenaufbereitung

Melderegister, Zensus, Fortschreibung
-------------------------------------

![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")

**Die Veröffentlichung der Ergebnisse des Zensus 2022 durch das Amt für Statistik Berlin-Brandenburg bedeutet für fast alle Kommunen in Berlin und Brandenburg eine Veränderung der amtlichen Einwohnerzahl. Einerseits unterscheidet sich die neue amtliche Zahl von den Zahlen der von den Gemeinden geführten Melderegister, andererseits auch zu den existierenden Einwohnerzahlen der Bevölkerungsfortschreibung auf der Basis des Zensus 2011. Was ist der Unterschied zwischen diesen Zahlen? Wir erklären.**

Die Einwohnerregister oder **Melderegister** sind amtliche Verzeichnisse, in denen der ständige oder vorübergehende Aufenthalt von Personen erfasst wird, soweit die Personen der Meldepflicht unterliegen. In ihnen sind vor allem die demografischen und geografischen Basisdaten, wie Geburtsort und Geburtsdatum, Nationalität und Wohnanschrift zu jeder in Deutschland gemeldeten Person gespeichert. Für die Pflege der Melderegister sind die Gemeinden darauf angewiesen, zeitnah über Änderungen in der Bevölkerung informiert zu werden. Dies ist aber nicht immer der Fall. Manche Personen sind nicht an ihrem Wohnort gemeldet, andere stehen im Register, sind aber umgezogen oder bereits verstorben. Ausbleibende Abmeldungen von Studierenden im Heimatort und ausländischen Einwohnerinnen und Einwohnern bei Rückzug in ihre Herkunftsländer sind ein aus Bevölkerungsuntersuchungen bekanntes Phänomen. Somit werden die Angaben in den Melderegistern im Laufe der Zeit ungenau, falls keine Bereinigungen stattfinden.

Um dennoch eine realitätsgetreue und deutschlandweit vergleichbare amtliche Einwohnerzahl für alle Gemeinden zu erhalten, wird alle zehn Jahre eine Art Inventur der amtlichen Bevölkerungszahl, ein **Zensus,** durchgeführt. Ausgehend von den Melderegisterdaten wird mit Hilfe der Befragung von ca. 10 % der Bevölkerung in einem deutschlandweit einheitlichen Verfahren eine möglichst genaue amtliche Einwohnerzahl festgestellt.

Das [Volkszählungsurteil des Bundesverfassungsgerichtes von 1983](https://www.bverfg.de/e/rs19831215_1bvr020983) verbietet, dass Erkenntnisse der Zensuserhebung zu einzelnen Personen an die von den Gemeinden geführten Melderegister zurückgespielt und somit die Melderegister korrigiert werden dürfen. Somit ist ein Unterschied zwischen der Zahl des Zensus und der Zahl des Melderegisters immer gegeben. Ohne Registerkorrekturen steigt diese Differenz im Zeitverlauf immer weiter an.

Die im Zensus festgestellte amtliche Einwohnerzahl wird fortlaufend um die Geburten und Sterbefälle sowie Zu- und Wegzüge aus dem Melderegister aktualisiert und fortgeschrieben, sodass immer [aktuelle Einwohnerzahlen](/bevoelkerung/demografie/bevoelkerungsstand) vorliegen. Die fortgeschriebenen Zahlen des Zensus 2011 werden aktuell durch die neu berechneten Einwohnerzahlen auf Basis des Zensus 2022 abgelöst.

**Quelle:** Amt für Statistik Berlin-Brandenburg, zum 31.12. eines Jahres, wenn nicht anders angegeben.

Weitere Erläuterungen zum Zusammenspiel von Bevölkerungsfortschreibung und Einwohnerregisterstatistik sowie eine Empfehlung, für welche Zwecke welche Zahl zu verwenden ist, finden Sie unter[www.statistik-berlin-brandenburg.de/news/2024/einwohner-oder-bevoelkerung](%20www.statistik-berlin-brandenburg.de/news/2024/einwohner-oder-bevoelkerung).

### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
#### Zensus

#### Zensus

* [zensus@statistik-bbb.de](mailto:zensus@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

[![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)](/news/2024/zensus-generation-alpha)**Zensus 2022 in Berlin und Brandenburg**[#### So wächst die Generation Alpha auf](/news/2024/zensus-generation-alpha)

Der Zensus 2022 gibt Einblicke in die Einwanderungsgeschichte der Generation Alpha in Berlin und Brandenburg.

Mehr anzeigen

[* Demografie](/search-results?q=tag%3ADemografie)[* Bevölkerung](/search-results?q=tag%3ABevölkerung)[* Einwohnerregister](/search-results?q=tag%3AEinwohnerregister)[* Zensus 2022](/search-results?q=tag%3AZensus 2022)
