

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Landwirtschaftliche Betriebe mit Gartenbau in Brandenburg](/c-iv-13-u)

Landwirtschaftliche Betriebe mit Gartenbauin Brandenburg
--------------------------------------------------------

#### 2016, unregelmäßig

###### Der Bericht informiert neben der gärtnerischen Nutzfläche, der Arbeitskräfte und der landwirtschaftlichen Berufsbildung auch über die Herkunft der Betriebseinnahmen sowie über die Grundflächen unter hohen begehbaren Schutzabdeckungen (einschl. Gewächshäusern).

BrandenburgMethodik

Brandenburg
-----------

**Gemüseerzeugung dominiert in Brandenburg**

Im Jahr 2016 bauten insgesamt 543 Brandenburger Betriebe Gartenbauerzeugnisse (Obst, Gemüse, Baumschulen, Blumen, Zierpflanzen, Heilpflanzen) an. Sie bewirtschafteten eine gärtnerische Nutzfläche (GN) von 10.715 Hektar und beschäftigten rund 18.000 Arbeitskräfte. Von der GN wurden über die Hälfte (5.453 Hektar) für die Gemüseerzeugung genutzt. Dabei wird die Gemüseproduktion insbesondere vom Spargel, den Gurken, Möhren und Erdbeeren bestimmt. 2 064 Hektar werden für den Obstbau, 1.058 Hektar für Baumschulen sowie 64 Hektar für Blumen und Zierpflanzen verwendet.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2016**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/6fb3aee86ee094e3/dbffbadb96be/SB_C04-13-00_2016u00_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/001b8100007f1225/391fa59974b6/SB_C04-13-00_2016u00_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Agrarstrukturerhebung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Agrarstrukturerhebung (ASE)**  
Metadaten 2016

[Download PDF](https://download.statistik-berlin-brandenburg.de/98f0a5ac9f823baa/392752f4b056/MD_41121_2016.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-13-u)
