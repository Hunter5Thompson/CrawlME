

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Baumobstanbau in Brandenburg](/c-i-8-5j)

Baumobstanbau in Brandenburg
----------------------------

#### 2022, fünfjährlich

###### In der Baumobstanbauerhebung werden alle fünf Jahre die Betriebe und Gesamtflächen des Baumobstanbaus sowie die Baumobstarten nach der Fläche und dem Verwendungszweck des Obstes erhoben.

BrandenburgMethodik
### Brandenburg

**Baumobstanbau auf weniger Fläche**

2022 erfolgte in Brandenburg die Produktion von Baumobst auf 1 380 Hektar. Im Vergleich zur letzten Erhebung aus dem Jahr 2017 verringerte sich die Anbaufläche um 165 Hektar bzw. 15 %. Die Zahl der Baumobst anbauenden Betriebe ist mit 116 unverändert geblieben.

¹ eingeschränkte Vergleichbarkeit zur Erhebung 2007 aufgrund methodischer Änderungen (siehe Erläuterungen)² eingeschränkte Vergleichbarkeit zu den Erhebungen 2007 und 2012 aufgrund methodischer Änderungen (siehe Erläuterungen)
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/28b2b3ee62f8ceff/fb933ccfd0aa/SB_C01-08-00_2022j05_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/ea7b9afa35c21d3c/8a8c39efb283/SB_C01-08-00_2022j05_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

* [0331 8173-3054](tel:0331 8173-3054)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Baumobstanbauerhebung ist eine dezentrale Bundesstatistik. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht. Auskunftspflichtig sind immer die Inhaberinnen und Inhaber bzw. Leiterinnen und Leiter von Betrieben mit einer Baumobstfläche von mindestens 0,5 Hektar.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Baumobstanbauerhebung**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/ee46d35d1bfad2f4/a124101e9b22/MD_41231_2022.pdf)[Archiv](/search-results?q=MD_41231&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-8-5j)
