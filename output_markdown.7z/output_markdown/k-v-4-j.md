

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)
* [Jugendhilfe in Berlin und Brandenburg – Vorläufige Schutzmaßnahmen](/k-v-4-j)

Jugendhilfe– Vorläufige Schutzmaßnahmen
---------------------------------------

#### 2023, jährlich

###### Die Statistik der vorläufigen Schutzmaßnahmen gibt Auskunft über die strukturelle Zusammensetzung des Personenkreises der Kinder und Jugendlichen, denen wegen problematischer Lebensverhältnisse vom Jugendamt oder von einem kooperierenden freien Träger Obhut gewährt wird.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d02da22939913154/86bf7caa6b90/SB_K05-04-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/8201f4d80d2ae810/b8c5642a41f9/SB_K05-04-00_2023j01_BE.pdf)

**Inobhutnahmen in Berlin**

Im Jahr 2023 wurden in Berlin 4.068 Kinder und Jugendliche in Obhut genommen, darunter erfolgte die Inobhutnahme für 1.110 Kinder und Jugendliche wegen dringenderKindeswohlgefährdung. Aufgrund einer unbegleiteten Einreise aus dem Ausland wurden 2.559 Kinder und Jugendliche vorläufig in Schutz genommen.

Bei den Inobhutnahmen war die Altersgruppe der 14-bis unter 18-jährigen Jugendlichen mit 81 % am häufigsten vertreten.

Die Schutzmaßnahme für die gefährdeten Kinder und Jugendlichen veranlassten vor allem soziale Dienste und das Jugendamt (29 %). Aber auch das Kind bzw. der Jugendliche selbst regte die Maßnahme an (53 %).

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Inobhutnahmen in Brandenburg**

2.649 Kinder und Jugendliche wurden im Jahr 2023 in Obhut genommen. Für 1.001 der Brandenburger Kinder und Jugendlichen erfolgte die Inobhutnahme wegen dringender Kindeswohlgefährdung. Aufgrund einer unbegleiteten Einreise aus dem Ausland wurden 1.342 Kinder und Jugendliche vorläufig in Schutz genommen.

Die Altersgruppe der 14- bis unter 18-jährigen Jugendlichen war mit 71 % am häufigsten vertreten.

In 41 % der Fälle veranlasste die Schutzmaßnahme die Polizei, das Gericht bzw. die Staatsanwaltschaft und in 16 % der Fälle wurde das Kind bzw. der Jugendliche selbst aktiv und regte die Maßnahme.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ebf2446203a86e8f/8d0cda6a546d/SB_K05-04-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/58ade9af27cf56e4/29c17bcef9f4/SB_K05-04-00_2023j01_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Grundgesamtheit der Statistik der vorläufigen Schutzmaßnahmen sind die beendeten Maßnahmen zum vorläufigen Schutz von Kindern und Jugendlichen. Bei der Inobhutnahme ist das Jugendamt verpflichtet Kindern und Jugendlichen vorläufigen Schutz zu bieten, wenn sie darum bitten oder wenn eine dringende Gefahr für ihr Wohl besteht.

Seit dem Berichtsjahr 2017 fließen auch vorläufige Inobhutnahmen, sobald die unbegleitete Einreise eines ausländischen Kindes oder Jugendlichen in die Bundesrepublik festgestellt wurde, in das Gesamtergebnis ein.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zu Stande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der vorläufigen Schutzmaßnahmen**Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/2a0411e95b200b84/9d4248bc4216/MD_22523_2023.pdf)[Archiv](/search-results?q=MD_22523&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-v-4-j)


