

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Brandenburg](/wahlen-brandenburg)
* [Europawahlen in Brandenburg](/europawahlen-brandenburg)

Europawahlen in Brandenburg
===========================

Gewählt wird in Deutschland nach dem Verhältniswahlsystem. Die Wahlberechtigten haben nur eine Stimme. Neben den wahlberechtigten Deutschen sind auch die in der Bundesrepublik Deutschland lebenden ausländischen Unionsbürgerinnen und -bürger auf Antrag wahlberechtigt, sofern sie ihr Wahlrecht nicht in ihrem Heimatland ausüben. Die Wahlperiode beträgt fünf Jahre.

Europawahl 2024Europawahl 2019Endgültige ErgebnisseWahlstrukturdatenRepräsentative WahlstatistikHistorie

Europawahl am 09. Juni 2024
---------------------------

#### Endgültige Ergebnisse für Brandenburg

#### **Alle Ergebnisse der Europawahl 2024 in Brandenburg in interaktiver Form**

[Zu den Ergebnissen](https://wahlergebnisse.brandenburg.de/12/100/20240609/europawahl_land/)
#### **Ergebnisse****als Download**

[Wahlbezirksergebnisse (XLSX)](https://download.statistik-berlin-brandenburg.de/1585bf2fde357251/50e72e9d3a33/DL_BB_EU2024.xlsx)[Ergebnisse nach Landkreisen, kreisfreien Städten, Ämtern und Gemeinden (XLSX)](https://download.statistik-berlin-brandenburg.de/616d5edee31a02d1/80221267d68d/DL_BB_2_EU2024.xlsx)[Ergebnisbericht (XLSX)](https://download.statistik-berlin-brandenburg.de/474d07478c929acd/61a36bbfd828/SB_B07-05-03_2024j05_BB.xlsx)[Ergebnisbericht – Gemeinden (XLSX)](https://download.statistik-berlin-brandenburg.de/0ad66e45f409c01c/4103f99dff07/SB_B07-05-04_2024j05_BB.xlsx)[Ergebnisbericht (PDF)](https://download.statistik-berlin-brandenburg.de/49cc76c1ad06a10c/c7d0f3560e80/SB_B07-05-03_2024j05_BB.pdf)[Ergebnisbericht – Gemeinden (PDF)](https://download.statistik-berlin-brandenburg.de/d8aa7609f0c870f5/cad6ed3c46dd/SB_B07-05-04_2024j05_BB.pdf)
#### Die endgültigen Ergebnisse

**Alle Daten zur Europawahl 2024 in Brandenburg in interaktiver Form**

[Zu den Ergebnissen](https://www.wahlergebnisse.brandenburg.de/wahlen/EU2019/diagramUberblick.html)
#### **Alle Ergebnisse****als Download**

[Wahlbezirksergebnisse XLSX](https://download.statistik-berlin-brandenburg.de/79cc93cf98fe1b2a/03b905e7804b/DL_BB_EU2019.xlsx)[Ergebnisse nach Landkreisen, kreisfreien Städten, Ämtern und Gemeinden XLSX](https://download.statistik-berlin-brandenburg.de/ea10d85b747ecfbf/094ca8826f2d/DL_BB_2_EU2019.xlsx)[Ergebnisbericht (Landeswahlleitung) XLSX](https://download.statistik-berlin-brandenburg.de/60482db9e1d7a4fe/b35b0f99f07b/SB_B07-05-03_2019j05_BB.xlsx)[Ergebnisbericht (Gemeinden) XLSX](https://download.statistik-berlin-brandenburg.de/8d792bdfbf7e4a87/4f7782bd7744/SB_B07-05-04_2019j05_BB.xlsx)[Ergebnisbericht (Landeswahlleitung) PDF](https://download.statistik-berlin-brandenburg.de/fb2eb0379ca4eb9b/e9945edca123/SB_B07-05-03_2019j05_BB.pdf)[Ergebnisbericht (Gemeinden) PDF](https://download.statistik-berlin-brandenburg.de/cb4fa773e118221b/d04ccb7f70a6/SB_B07-05-04_2019j05_BB.pdf)

Wahlstrukturdaten
-----------------

#### Demografische und politische Strukturen von Brandenburg

#### **Download**

[Vorwahldaten, Strukturdaten (XLSX)](https://download.statistik-berlin-brandenburg.de/d2b598cde5ecc92e/b4ac8178a421/SB_B07-05-01_2024j05_BB.xlsx)[Vorwahldaten, Strukturdaten (PDF)](https://download.statistik-berlin-brandenburg.de/1429c22ca03a9ec1/01f8e4692597/SB_B07-05-01_2024j05_BB.pdf)

Repräsentative Wahlstatistik
----------------------------

#### Wer hat wie gewählt?

##### Europawahl am 09. Juni 2024 in Brandenburg**Abgegebene Stimmen nach Partei und Alter**

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Repräsentative Wahlstatistik als Download**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/75883c4876e5e8d4/32fda1cae646/SB_B07-05-05_2024j05_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/3884b4d96947f4e7/664bad50d71a/SB_B07-05-05_2024j05_BB.pdf)

Mit der repräsentativen Wahlstatistik werden die **Wahlbeteiligung** und die **Stimmabgabe** der Wahlberechtigten nach Geschlecht und Altersgruppen im Wege der Stichprobe untersucht.

Rechtsgrundlage für die Durchführung ist das Gesetz über die allgemeine und die repräsentative Wahlstatistik (Wahlstatistikgesetz - WStatG). Für die Wahrung des Wahlgeheimnisses sind unter anderem folgende Maßnahmen angeordnet:

* Die Festlegung einer Mindestzahl von 400 Wahlberechtigten je Stichprobenwahlbezirk und von 400 Wählern je Stichprobenbriefwahlbezirk.
* Zusammenfassung der Geburtsjahrgänge zu Gruppen, sodass keine Rückschlüsse auf das Wahlverhalten einzelner Wähler möglich sind.
* Trennung der für die Stimmenauszählung und für die statistische Auswertung zuständigen Stellen sowie strenge Zweckbindung für die Statistikstellen hinsichtlich der ihnen zur Auswertung überlassenen Wahlunterlagen.

Die Wahlberechtigten der repräsentativen Wahlbezirke werden durch ein Plakat und die Auslage eines [Faltblatts](https://download.statistik-berlin-brandenburg.de/906c82c06f35bdcc/c4ee7067aba6/ew24_rws_faltblatt-online.pdf) im Wahllokal, die Zusendung eines Merkblatts mit den Briefwahlunterlagen und persönliche Beantwortung von Fragen im Wahllokal informiert. Die Stimmzettel sind mit einem Unterscheidungsaufdruck versehen.

Historische Daten
-----------------

**Endgültige Ergebnisse zu Europawahlen in Brandenburg**

**Landes-wahlleitung**

**nach  
Gemeinden**

[**Repräsentative Wahlstatistiken zu Europawahlen in Brandenburg**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000756)

**Wahlbezirksergebnisse zu Europawahlen in Brandenburg**

[**Strukturdaten, Vorwahldaten zu Europawahlen in Brandenburg**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000709)
##### Europawahlen in Brandenburg**Wahlbeteiligung 1994 bis 2024**

**Quelle:** Amt für Statistik Berlin-Brandenburg
##### **Entwicklung der Wahlergebnisse im Zeitverlauf:**

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/e87ef447cc3b29f4/95e93e65257f/Europawahlen_Lange-Reihe_2024_Berlin-Brandenburg.xlsx)

Weiterführende Informationen
----------------------------

###### Metadaten

Unsere Metadaten liefern Informationen zu den erhobenen Daten und der angewendeten Methodik. Ergänzt werden diese durch Musterstimmzettel, Datensatzbeschreibungen und gegebenenfalls einen Qualitätsbericht.

**Allgemeine Europawahlstatistik (2024)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/f93d4ead287a9b09/ee54cec40399/MD_14211_2024.pdf)

**Allgemeine Europawahlstatistik (2019)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/1637048cc1ac65b7/0b3340adb963/MD_14211_2019.pdf) 

**Repräsentative Europawahlstatistik (2024)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/9e0e6c9de46f2607/5b489eb6e687/MD_14221_2024.pdf)

**Repräsentative Europawahlstatistik (2019)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/bfe329ec38b623d9/e87b0eabc197/MD_14221_2019.pdf)

#### Der Landeswahlleiter für Brandenburg auf [wahlen.brandenburg.de](https://wahlen.brandenburg.de/wahlen/de/)


