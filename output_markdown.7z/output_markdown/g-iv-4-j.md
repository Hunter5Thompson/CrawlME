

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Umsatz, Beschäftigung und Investitionen im Gastgewerbe in Berlin und Brandenburg](/g-iv-4-j)

Umsatz, Beschäftigung und Investitionen im Gastgewerbe
------------------------------------------------------

#### 2020, jährlich

###### Die jährlichen Erhebungen im Gastgewerbe liefern Informationen über die Struktur, Rentabilität und Produktivität der Unternehmen in diesem Wirtschaftsbereich.

BerlinBrandenburgMethodik
### Berlin

#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/5ad2547c2bedae12/0e30b4d26a48/SB_G04-04-00_2020j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/a283f6e0096d2ea1/24ca98abcf3a/SB_G04-04-00_2020j01_BE.pdf)
### Kontakt

#### Nadine Pierron

Gastgewerbe Struktur

#### Nadine Pierron

Gastgewerbe Struktur

* [0331 8173-1331](tel:0331 8173-1331)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4368e7ec2b037701/2dc9e876c4c0/SB_G04-04-00_2020j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/29f93282fb661a2c/2b05f6bb3fc2/SB_G04-04-00_2020j01_BB.pdf)
### Kontakt

#### Nadine Pierron

Gastgewerbe Struktur

#### Nadine Pierron

Gastgewerbe Struktur

* [0331 8173-1331](tel:0331 8173-1331)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Ergebnisse zu den Kennziffern Umsatz, tätige Personen, Bruttolohnsumme und Investitionen werden als absolute Werte dargestellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Jahresstatistik im Gastgewerbe**  
Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/3e162edc9666f5fc/23e685d09fff/MD_45342_2020.pdf)[Archiv](/search-results?q=MD_45342&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-iv-4-j)
