

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Regionale Statistiken](/meine-region/regionale-statistiken)

Regionale Statistiken
=====================

In vielen statistischen
Auswertungen können für Berlin Ergebnisse nach Bezirken und unterhalb der
Bezirksebene für die Lebensweltlich orientierten Räume (LOR) ausgewiesen werden. Für Brandenburg sind Auswertungen auf Ebene der
Landkreise und kreisfreien Städte sowie Gemeinden möglich.

[Überblick
#### Meine Region](/meine-region)[+ InfoRegionale Statistiken
#### Welche lokalen Daten bieten wir?](/meine-region/regionale-statistiken)[+ DatenBerlin-Statistik 
#### Bezirks-, Stadtteil- und Kiezdaten](/kommunalstatistik)[+ InfoLebensweltlich orientierte Räume
#### Was sind Berlins Raumbezüge?](/meine-region/lebensweltlich-orientierte-raeume-berlin)

Welche kleinräumigen Daten bieten wir?
--------------------------------------

#### Hier finden Sie einen Überblick, für welche Themen Auswertungen unterhalb der Landesebene möglich sind.

* Bevölkerung
* Gesellschaft
* Wirtschaft
#### Bevölkerung

###### Demografie

[Bevölkerungsstand](/bevoelkerung/demografie/bevoelkerungsstand)

[Geburten, Sterbefälle, Eheschließungen](/bevoelkerung/demografie/geburten-sterbefaelle-eheschliessungen)

[Zu- und Fortzüge](/bevoelkerung/demografie/zu-und-fortzuege)

[Einbürgerungen, Ausländer](/bevoelkerung/demografie/einbuergerungen-auslaender)

###### Zensus

[Zensus 2011](/bevoelkerung/zensus/zensus_2011)  


###### Wahlen in Berlin

[Europawahlen](/europawahlen-berlin)

[Bundestagswahlen](/bundestagswahlen-berlin)

[Berliner Wahlen](/abgeordnetenhauswahlen-bvv-berlin)

[Volksentscheide](/volksentscheide-berlin)

###### Wahlen in Brandenburg

[Europawahlen](/europawahlen-brandenburg)

[Bundestagswahlen](/bundestagswahlen-brandenburg)

[Landtagswahlen](/landtagswahlen-brandenburg)

[Kommunalwahlen](/kommunalwahlen-brandenburg)

#### Gesellschaft

###### Arbeit

[Erwerbstätigkeit](/erwerbstaetigkeit)

###### Verkehr

[Straßenverkehr](/strassenverkehr)

###### Gesundheit

[Pflege](/pflege)

###### Soziales

[Sozialhilfe](/gesellschaft/soziales/sozialhilfe)

[Wohngeld](/wohngeld)

[Kinder- und Jugendhilfe](/daten-melden/kinder-und-jugendhilfe)

[Menschen mit Behinderung](/menschen-mit-behinderung-eingliederungshilfe)

[Asylbewerberleistungen](/asylbewerberleistungen)

  
###### Staat

[Steuern](/oeffentliche-finanzen)

[Flächennutzung](/oeffentliche-finanzen)

[Öffentliche Finanzen](/oeffentliche-finanzen)

[Öffentlicher Dienst](/oeffentlicher-dienst)

  


###### Bildung

[Schulen](/gesellschaft/bildung/schulen)

#### Wirtschaft

###### Volkswirtschaft

[Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)

[Unternehmen](/unternehmen)

[Gewerbeanzeigen](/gewerbeanzeigen)

[Insolvenzen](/insolvenzen)

###### Wirtschaftsbereiche

[Land- und Forstwirtschaft](/land-und-forstwirtschaft)

[Tourismus](/tourismus-und-gastgewerbe)   


[Verarbeitendes Gewerbe](/verarbeitendes-gewerbe)

[Bauen und Wohnungen](/bauen-und-wohnungen)  


###### Preise

[Bodenmarkt](/bodenmarkt)

###### Umwelt

[Wasser](/wasser)

[Abfall, Luftbelastungspotenzial](/luftverunreinigungen)

Weitere Datenangebote
---------------------

#### Im Statistischen Verbund stehen unsere Daten auch für bundesweite Vergleiche von Kreisen oder Gemeinden bereit.

#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik für alle Länder, Kreise und Gemeinden in Deutschland.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online)
#### Regionalatlas

![](https://download.statistik-berlin-brandenburg.de/ae8a424315f7a77f/074dfe2a1cc3/v/89bcd1d9de5e/Regionalatlas.PNG)

Statistische Ergebnisse für alle Bundesländer, Regierungsbezirke sowie Landkreise und kreisfreien Städte Deutschlands kartografisch dargestellt.

[Zum Regionalatlas](https://regionalatlas.statistikportal.de/)
#### Kommunalatlas Berlin

![](https://download.statistik-berlin-brandenburg.de/fca98ac647310452/ac3c9ec8d71e/v/7e67598b939c/schmuckbild-kommunalatlas.png)

Die interaktiven Karten beantworten vielfältige Fragen zur Bevölkerungsstruktur und -entwicklung in den Berliner Bezirken.

[Zum Kommunaltlas](https://web.statistik-berlin-brandenburg.de/instantatlas/interaktivekarten/kommunalatlas2021/atlas.html)

Nicht gefunden, was Sie suchen?
-------------------------------

#### Wir helfen weiter und erstellen Ihnen auch individuelle Auswertungen.

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)
#### Individuelle Geodaten und Karten:

#### Unser Geoservice

[Mehr erfahren](/geoservice)

[* Meine Region](/search-results?q=tag%3AMeine Region)[* Regionalstatistik](/search-results?q=tag%3ARegionalstatistik)[* Regionaldaten](/search-results?q=tag%3ARegionaldaten)[* Interaktive Karten](/search-results?q=tag%3AInteraktive Karten)
