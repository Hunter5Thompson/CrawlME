

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Verarbeitendes Gewerbe](/verarbeitendes-gewerbe)
* [Monatsbericht für Betriebe im Verarbeitenden Gewerbe in Berlin und Brandenburg](/e-i-2-m)

Betriebe im Verarbeitenden Gewerbe
----------------------------------

#### Oktober 2024, monatlich

###### Die Ergebnisse des Monatsberichts stellen eine kurzfristige Beurteilung der konjunkturelle Lage der Industriebetriebe ab 50 Beschäftige dar. Sie informieren über die Auftragslage, Umsätze und Beschäftigtenzahlen, gegliedert nach Wirtschaftsbereichen, und dienen der regionalen Strukturpolitik.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/70fb0bf84b1b128f/b684cce75c61/SB_E01-02-00_2024m10_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f0c60ea17c2e2f79/166005f9937a/SB_E01-02-00_2024m10_BE.pdf)

**Umsatz um 1,2 % gestiegen**

Die Umsätze der 330 Berliner Industriebetriebe mit 50 und mehr tätigen Personen stiegen im Oktober 2024 im Vergleich zum Vorjahresmonat um 1,2 % auf 2,8 Mrd. EUR. Sie setzten sich aus jeweils aus 1,4 Mrd. EUR Inlands- und 1,4 Mrd. EUR Auslandsumsatz zusammen.

Die Auftragseingänge lagen um 10,2 % unter dem Wert des Vorjahresmonats. Im Inlandsgeschäft wurde ein Minus von 9,9 % und im Auslandsgeschäft ein Minus von 10,4 % verzeichnet. Die Zahl der tätigen Personen erhöhte sich um 1,0 % auf 74.328.

Berlins umsatzstärkster Industriezweig, die Hersteller pharmazeutischer Erzeugnisse, erhöhten ihre Umsätze um 6,0 % (Inland –8,4 %, Ausland +8,5 %). Das Auftragsvolumen nahm um 23,8 % ab (Inland –45,5 %, Ausland –17,1 %).

### Kontakt

#### Kati Bleck

VERARBEITENDES GEWERBE BERLIN

#### Kati Bleck

VERARBEITENDES GEWERBE BERLIN

* [0331 8173-3816](tel:0331 8173-3816 )
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Umsatzzuwachs von 0,9 %**

In Brandenburg stiegen die Umsätze der 434 Industriebetriebe mit 50 und mehr tätigen Personen im Oktober 2024 im Vergleich zum Vorjahresmonat um 0,9 % auf 3,0 Mrd. EUR. 1,6 Mrd. EUR entfielen auf den Inlands- und 1,4 Mrd. EUR auf den Auslandsumsatz.

Die Auftragseingänge lagen um 6,7 % über denen des Vorjahresmonats. Im Inlandsgeschäft ergab sich ein Plus von 2,5 % und im Auslandsgeschäft 9,6 %. Die Zahl der tätigen Personen sank um 1,0 % auf 87.269.

Der beschäftigten- und umsatzstärkste Industriezweig in Brandenburg, die Hersteller von Kraftwagen und Kraftwagenteilen, erhöhte seine Umsätze um 14,1 %. Das Auftragsvolumen stieg um 10,7 Prozent (Inland –14,8 %, Ausland +16,7 %).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/79c88ab2e4faca94/109530458194/SB_E01-02-00_2024m10_BB.xlsx) 

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/f7e66181d70fc2c6/f7e3bb8321fc/SB_E01-02-00_2024m10_BB.pdf)
### Kontakt

#### Ines Neumann

VERARBEITENDES GEWERBE BRANDENBURG

#### Ines Neumann

VERARBEITENDES GEWERBE BRANDENBURG

* [0331 8173-3725](tel:0331 8173-3725)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Erfasst werden im Rahmen einer monatlichen Totalerhebung mit Abschneidegrenze sämtliche im Inland gelegenen Betriebe des **Verarbeitenden Gewerbes** sowie des Bergbaus und der Gewinnung von Steinen und Erden mit 50 und mehr Beschäftigten.

Erhoben werden die Gesamtzahl der tätigen Personen zum Monatsende, der Umsatz sowie der Auftragseingang und Auftragsbestand für ausgewählte Wirtschaftsbereiche im Berichtsmonat, jeweils nach fachlichen Betriebsteilen in der Differenzierung nach dem Inland sowie dem Ausland der Euro- oder Nicht-Eurozone. Entgelte und geleistete Arbeitsstunden werden für den gesamten Betrieb erfasst.

Die Ergebnisse des Monatsberichts dienen der kurzfristigen Beurteilung der konjunkturellen Lage im Wirtschaftsbereich sowie der Bereitstellung von Daten für die regionale und sektorale Strukturpolitik. Zu den Hauptnutzenden des Monatsberichts für Betriebe zählen die Bundesministerien, insbesondere das Bundesministerium für Wirtschaft und Technologie, die jeweiligen Länderressorts und die Bundesbank sowie die Europäische Kommission, die Europäische Zentralbank und andere öffentliche Institutionen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatsbericht einschl. Auftragseingangserhebung für Betriebe im Bereich Verarbeitendes Gewerbe, Bergbau und Gewinnung von Steinen und Erden**  
Metadaten ab Juni 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/cf00553ae2daa402/d4f506d10f20/MD_42111_2024.pdf)[Archiv](/search-results?q=MD_42111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-i-2-m)
