

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Daten melden](/daten-melden)
* [Wie funktioniert eSTATISTIK.core?](/estatistikcore)
#### Wie funktioniert

#### eSTATISTIK.core?

eSTATISTIK.core steht für „Common Online Rawdata Entry“ und unterstützt die automatisierte Gewinnung der statistischen Rohdaten aus den betrieblichen Daten von Unternehmen und Behörden sowie die medienbruchfreie Übermittlung an die zentrale Online-Dateneingangsstelle.

Was ist eSTATISTIK.core?
------------------------

[eSTATISTIK.core](https://core.estatistik.de/core/) ist ein innovatives Online-Meldeverfahren sowie eine bequeme Alternative zum Papierfrage- und Onlinefragebogen.

Anders als bei Meldungen mittels Fragebogen können die erfragten Daten von den auskunftspflichtigen Unternehmen oder öffentlichen Stellen mit [eSTATISTIK.core](https://core.estatistik.de/core/) automatisiert aus ihrem jeweiligen Softwaresystem in elektronischer Form gewonnen werden. Vor der Übermittlung können Sie in der Regel die Daten am Bildschirm daraufhin überprüfen, ob sie vollständig und richtig sind. Im Anschluss daran übermitteln Sie als Anwenderin oder Anwender das Datenpaket (XML) über eine sichere Internetverbindung an den zentralen Dateneingang der amtlichen Statistik. Von dort wird die Datenlieferung umgehend an das Amt für Statistik Berlin-Brandenburg übermittelt.  


Wie funktioniert eSTATISTIK.core?
---------------------------------

Mit [eSTATISTIK.core](https://core.estatistik.de/core/) können die von der amtlichen Statistik erfragten Daten automatisiert den jeweiligen Softwaresystemen der auskunftspflichtigen Unternehmen oder öffentlichen Stellen gewonnen werden.

#### 1. Aufforderung

Sie erhalten einen Brief mit Meldeaufforderung und Log-in-Daten für [eSTATISTIK.core](https://core.estatistik.de/core/).  


#### 2. Zusammenstellen

Sie stellen Ihre entsprechenden Zahlen zusammen, idealerweise automatisiert mithilfe einer Software.

#### 3. Anmelden

Sie melden sich im [eStatistik.core- Portal a](https://core.estatistik.de/core/)n und klicken auf Berlin bzw. Brandenburg oder Sie melden sich in „Mein Portal“ an und werden weitergeleitet.  


#### 4. Melden

Sie wählen die Statistikmeldung aus, die Sie erfüllen müssen, geben die Daten ein bzw. laden die Daten hoch und schicken sie ab.

Datenschutz und Datensicherheit
-------------------------------

Die Statistischen Ämter des Bundes und der Länder haben nach dem Bundesstatistikgesetz (BStatG) die Aufgabe, Daten zu erheben, aufzubereiten und zu veröffentlichen. Die Erhebungen/Bundesstatistiken werden in einzelnen fachstatistischen Rechtsvorschriften geregelt. Für die Auskunftgebenden besteht in der Regel Auskunftspflicht. Die amtliche Statistik garantiert die Geheimhaltung der erhobenen Einzelangaben. Eine Weitergabe von Einzeldaten, die für eine Bundesstatistik gemacht werden, ist nur in ausdrücklich gesetzlich geregelten Ausnahmefällen zulässig.

Die Online-Systeme IDEV und eSTATISTIK.core für den elektronischen Dateneingang der Statistischen Ämter unterliegen Sicherheitsanforderungen gemäß BSI-Standards  
[(BSI = Bundesamt für Sicherheit in der Informationstechnik).](https://www.bsi.bund.de/DE/Home/home_node.html) Wir arbeiten beständig daran, die Systeme auf dem aktuellen technischen Stand zu halten und weiter zu verbessern. Dazu gehören auch Sicherheitstests.

Geeignete Sicherheitsmaßnahmen für Ihren PC oder Ihr Notebook finden Sie übersichtlich und kurz gefasst auf der Webseite des BSI unter [www.bsi-fuer-buerger.de](https://www.bsi-fuer-buerger.de/) bzw. für den professionellen Bereich ausführlich unter [www.bsi.bunde.de,](https://www.bsi.bund.de/) dort in der Rubrik „Cyber-Sicherheit – BSI-Standards zur Internet-Sicherheit (ISi-Reihe)“ bzw. in der Rubrik „IT-Grundschutz-Kataloge“. Unter [www.botfrei.de](https://www.botfrei.de/) haben Sie zudem die Möglichkeit, Ihren Rechner mithilfe der dort verfügbaren kostenlosen und vom BSI geprüften DE-Cleaner-Software zu überprüfen.

Die Übermittlung der statistischen Daten mit IDEV und eSTATISTIK.core erfolgt immer in verschlüsselter Form via Internet an die Dateneingangsserver der Statistischen Ämter. Das dabei verwendete technische Verfahren HTTPS ist ein allgemein anerkanntes Verfahren zur verschlüsselten Datenübertragung und Serverauthentifizierung, durch das sichergestellt wird, dass die Daten während der Übertragung von Unbefugten nicht eingesehen, verändert oder umgeleitet werden können.

Informationen zu den Maßnahmen werden zur Gewährleistung des Schutzes der Systeme nicht an Dritte weitergeben.

Individuelle Zweifel an den von den Statistischen Ämtern angebotenen Online-Meldesystemen entbinden Sie nicht von Ihrer gesetzlichen Meldepflicht.

Eine sichere Datenübermittlung erfordert jedoch auch Ihren Beitrag, in dem auch Sie Ihren Rechner frei von Schadsoftware halten.

Zur umfassenden Gewährleistung der Datensicherheit bitten wir Sie, ergänzend zu unseren internen Sicherheitsmaßnahmen auch die vorgeschlagenen Maßnahmen im eigenen Bereich zu beachten.

Sie benötigen Unterstützung?
----------------------------

Bei technischen Fragen und Problemen wenden Sie sich bitte per E-Mail an [idev@statistik-bbb.de](mailto:idev@statistik-bbb.de).  


Fachlich-inhaltliche Fragen zu Ihrer Statistik beantwortet Ihnen die entsprechende Fachabteilung.   
Die Telefonnummer und die E-Mail-Adresse entnehmen Sie bitte Ihrem Anschreiben.

[* Daten melden](/search-results?q=tag%3ADaten melden)
