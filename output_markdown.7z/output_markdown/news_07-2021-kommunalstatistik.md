

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 21.07.2021

#### Berlin-Statistik

Neues kommunalstatistisches Datenangebot für Berlin
---------------------------------------------------

![iStock.com / 3dan3](https://download.statistik-berlin-brandenburg.de/31a3a0989d664ca9/8d97900f9d5c/v/845391179cbd/wirtschaft-wirtschaftsbvereiche-berlin-prenzlauer-berg-picture-id1157122883.jpg "iStock.com / 3dan3")

**Als führender Informationsdienstleister für amtliche Statistik in der Region bieten wir unseren Datennutzenden auch ein breites Spektrum an kleinräumigen Informationen, Tabellen und Visualisierungen zu den vielfältigen Themen der Kommunalstatistik für Berlin.** 

Schwerpunkte bilden der Einwohnerbestand und die Einwohnerbewegung mit Auskünften zur Einwohnerzahl, zu den abgeleiteten Merkmalen Haushalte und Migrationshintergrund sowie Geburten, Sterbefällen und Wanderungen.

Die Daten stehen auf der Ebene der Lebensweltlich orientierten Räume (LOR) zur Verfügung. Diese wichtigste kleinräumige Gliederung für Berlin wurde bereits 2006 festgelegt, um das Raumbezugssystem der Statistischen Gebiete/Verkehrszellen für sozialräumliche Planungszwecke abzulösen, und 2021 grundlegend überarbeitet.

**Stadtleben Berlin**

Wie viele Hydranten stehen einem Berliner Hund durchschnittlich zum Gassi gehen zur Verfügung? Wie viele Taxen sind eigentlich in Berlin gemeldet? Und hat der Klimawandel auch Berlin erreicht? Daten zu diesen Fragen und weiteren Themen aus den Bereichen Kultur, Freizeit, Religion, Arbeitsmarkt, Verkehr, Umwelt und Sicherheit finden Interessierte unter[Stadtleben Berlin](/kommunalstatistik/stadtleben-berlin).

**Kommunalatlas**

Neben Basistabellen, Zeitreihen und Statistischen Berichten sowie Aufsätzen und Datenbanken stellt das AfS mit dem [Kommunalatlas](https://instantatlas.statistik-berlin-brandenburg.de/instantatlas/interaktivekarten/kommunalatlas/atlas.html) ein interaktives kleinräumiges Kartentool zur Verfügung. Dieses bietet neben allgemeinen demografischen Grunddaten auch ein Set an Indikatoren (z. B. Geburtenziffer, Jugendquotient) zur Visualisierung der Bevölkerungsstruktur und -entwicklung in Berlin.

###### Fühlen Sie sich angesprochen und wollen die Bundeshauptstadt statistisch unter die Lupe nehmen? Dann schauen Sie vorbei.

[Zur Stadtstatistik](/kommunalstatistik)
### Ähnliche Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![Fussball-Fans beim Jubeln in einem Wohnzimmer](https://download.statistik-berlin-brandenburg.de/34373f395a5df526/72a06c9000cd/v/32f583b789d6/gesellschaft-menschen-fussball-iStock-1250480649.jpg "Fussball-Fans beim Jubeln in einem Wohnzimmer")](/news/2024/fussball-europameisterschaft)**Zu den Spielen der Fußball-Europameisterschaft 2024 in Berlin**[#### Wird’s laut in meinem Kiez?](/news/2024/fussball-europameisterschaft)

In fast allen Nachbarschaften Berlins leben zahlreiche Menschen mit den Nationalitäten der teilnehmenden Teams bei der Fußball-Europameisterschaft 2024.

Mehr anzeigen

[* Berlin](/search-results?q=tag%3ABerlin)[* Kommunalstatistik](/search-results?q=tag%3AKommunalstatistik)[* Kommunalatlas](/search-results?q=tag%3AKommunalatlas)
