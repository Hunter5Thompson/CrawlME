

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Energie](/energie)

Energie
=======

Im Rahmen der Energiewende sollen erneuerbare Energien langfristig zum wichtigsten Energieträger werden. Die amtlichen Energiestatistiken stellen Daten zu den verschiedenen erneuerbaren und fossilen Energieträgern zur Verfügung.

Außerdem werden Daten zur Erzeugung und Abgabe von Strom und Gas, zur Wärmeerzeugung und zum Energieverbrauch in der Industrie veröffentlicht. Zusammengefasst werden diese Daten in der Energie- und CO₂-Bilanz dargestellt.

[![iStock.com / jotily](https://download.statistik-berlin-brandenburg.de/bc84f523d272e119/3538d6cc5df4/v/39612975c6ec/bevoelkerung-gesellschaft-berlin-kreuzberg-oberbaumbridge-picture-id913311660.jpg "iStock.com / jotily")](/news/2023/klima-berlin)**Zehn Diagramme zur Klimasituation in der Hauptstadt**[#### Klimaportrait Berlin](/news/2023/klima-berlin)

Kann Berlin bis 2030 klimaneutral werden? Entwicklung der Treibhausgasemissionen und weitere aktuelle amtliche Klimakennzahlen für Berlin....

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Energie-, Wasser- und Gasversorgung in Brandenburg, jährlich (EIV1-j)](/e-iv-1-j)[Energieverwendung der Betriebe des Verarbeitenden Gewerbes in Berlin und Brandenburg, jährlich (EIV3-j)](/e-iv-3-j)[Energie- und CO₂-Bilanz Berlin und Brandenburg, jährlich (EIV4-j)](/e-iv-4-j)[Energie- und CO₂-Bilanz Berlin (vorläufig), jährlich (EIV5-j)](/e-iv-5-j)

Zeitreihen
----------

Energie- und WasserversorgungEnergievebrauchCO₂-EmissionenEnergieverwendung1 Betriebe von Unternehmen mit im Allgemeinen 20 und mehr Beschäftigten**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Energie- und Wasserversorgung

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/cfd4b54ed8d4f503/9bb61c7123e1/energie-lange-reihe-2022-energie-und-wasserverwendung.xlsx)
#### Energie- und CO₂-Bilanz

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/7158c16f221e4d65/b0c6c19a53bf/energie-zeitreihe-2021-energiebilanz.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/a2212b231745b176/a2ad4d43ed19/energie-lange-reihe-2021-energie-und-co2-bilanz.xlsx)
#### Energie­verwendung

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/fe5a78a59688cf56/a9d7cc8b785a/Energie-Energieverwendung-Zeitreihe-2022.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/6ab85f1ab5deefac/699a0fc51154/energie-lange-reihe-2022-energieverwendung.xlsx)

Basisdaten
----------

Energie- und WasserversorgungEnergie- und CO₂-BilanzEnergieverwendung

Weitere Datenangebote
---------------------

#### Energiebilanzen der Länder

![](https://download.statistik-berlin-brandenburg.de/df6a888a4837f5e6/697cd995964f/v/27695d816605/lak-energiebilanz)

Daten zur Energie- und CO₂-Bilanz (wie temperaturbereinigte Zahlen) finden Sie auf den Seiten des Länderarbeitskreises Energiebilanzen.

[Zu den Energiebilanzen](http://www.lak-energiebilanzen.de/)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/energie)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zur GENESIS-Online Datenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1614761986476&code=43531#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Mathias Geburek

Energie

#### Mathias Geburek

Energie

* [0331 8173-3817](tel:0331 8173-3817)
* [energie@statistik-bbb.de](mailto:energie@statistik-bbb.de)
* [0331 817330-4013](fax:0331 817330-4013)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-968906216.jpg](https://download.statistik-berlin-brandenburg.de/de73473a84e6df5a/fd72727beb4c/v/9e312ba3eb79/gaspipeline.jpg "iStock-968906216.jpg")](/169-2024)**Energie- und CO₂-Bilanz 2023 Berlin**[#### Energieverbrauch und CO₂-Emissionen weiter gesunken](/169-2024)

Die vorläufigen Ergebnisse der Energie- und CO₂-Bilanz 2023 zeigen auch weiterhin einen Rückgang beim Energieverbrauch und bei den CO₂-Emissionen.

[![iStock-489193525.jpg](https://download.statistik-berlin-brandenburg.de/82f8600a57afaea2/97abf801f9a3/v/c70b556b56c6/wirtschaft-wirtschaftsbereiche-photovoltaikanlage.jpg "iStock-489193525.jpg")](/130-2024)**Stromeinspeisung 1. Halbjahr 2024 in Berlin und Brandenburg**[#### Sommer, Sonne, Sonnenschein… Ausbau der Photovoltaikanlagen schreitet voran](/130-2024)

Pressemitteilung Nr. 130 Das erste Halbjahr 2024 zeichnete sich durch einen beachtenswerten Zuwachs der Stromeinspeisung aus Photovoltaikanlagen aus. Während in Berlin im ersten Halbjahr 2023 noch...

[![istock-id464457434.jpg](https://download.statistik-berlin-brandenburg.de/b3afeaef9d639a63/a5256772f965/v/a58ac027b6b2/wirtschaft-umwelt-id464457434.jpg "istock-id464457434.jpg")](/006-2024)**Energieverwendung in Berliner Betrieben des Verarbeitenden Gewerbes**[#### Erdgasverbrauch gesunken](/006-2024)

Pressemitteilung Nr. 6 Im Jahr 2022 verbrauchten die Berliner Industriebetriebe 4.264 Terrajoule Erdgas, 6,6 Prozent weniger als im Jahr zuvor. Der gesamte industrielle Erdgasverbrauch in der 16,......

[Zu unseren News](/news)

[* Energiebilanz](/search-results?q=tag%3AEnergiebilanz)[* Energieverbrauch](/search-results?q=tag%3AEnergieverbrauch)[* Energiewirtschaft](/search-results?q=tag%3AEnergiewirtschaft)[* Erneuerbare Energien](/search-results?q=tag%3AErneuerbare Energien)[* Gas](/search-results?q=tag%3AGas)[* Strom](/search-results?q=tag%3AStrom)[* Wärme](/search-results?q=tag%3AWärme)[* CO₂](/search-results?q=tag%3ACO₂)
