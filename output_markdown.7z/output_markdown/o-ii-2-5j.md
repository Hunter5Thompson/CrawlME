

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Einkommen und Konsum](/einkommen-und-konsum)
* [Haus- und Grundbesitz, Geldvermögen und Schulden privater Haushalte](/o-ii-2-5j)

Haus- und Grundbesitz, Geldvermögen und Schulden privater Haushalte
-------------------------------------------------------------------

#### 2018, fünfjährlich

###### Die Daten zu Haus- und Grundbesitz sowie der monetären Situation privater Haushalte sind Teil der Ergebnisse der Einkommens- und Verbrauchsstichprobe, die bei einem Teil der Bevölkerung auf freiwilliger Basis durchgeführt wird.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2018**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/2ec415a6679d81ed/7437fa2c2b58/SB_O02-02-00_2018j05_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/bc1ad71b79ddfd72/eb2099c75436/SB_O02-02-00_2018j05_BE.pdf)

2018 gab es 500 000 Berliner Haushalte mit Haus- und Grundbesitz. Im Vergleich zum Jahr 2013 ist das eine leichte Steigerung von 43 000 Haushalten.

Darunter waren 222 000 Berliner Haushalte Besitzer eines Einfamilienhauses. 5 Jahre zuvor waren es hier noch 36 000 Haushalte mehr.

### Kontakt

#### Nicole Baier

Haushaltserhebungen

#### Nicole Baier

Haushaltserhebungen

* [0331 8173-1912](tel:0331 8173-1912)
* [evs@statistik-bbb.de](mailto:evs@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

2018 gab es 614 000 Brandenburger Haushalte mit Haus- und Grundbesitz. Im Vergleich zum Jahr 2013 ist das eine leichte Steigerung von 2 000 Haushalten.

Darunter waren 466 000 Brandenburger Haushalte Besitzer eines Einfamilienhauses. 5 Jahre zuvor waren es hier noch 8 000 Haushalte mehr.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2018**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ddc25f223968db76/e9e1e22e33d8/SB_O02-02-00_2018j05_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/162975e66a35b06b/77fe7d78d515/SB_O02-02-00_2018j05_BB.pdf)
### Kontakt

#### Nicole Baier

Haushaltserhebungen

#### Nicole Baier

Haushaltserhebungen

* [0331 8173-1912](tel:0331 8173-1912)
* [evs@statistik-bbb.de](mailto:evs@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die **Einkommens- und Verbrauchsstichprobe (EVS)** ist eine im fünfjährigen Abstand dezentral durchgeführte bundesweite Quotenstichprobe zur Erfassung der Einnahmen und Ausgaben privater Haushalte. Die Statistik wird in allen EU-Mitgliedsstaaten durchgeführt. Es handelt sich um eine Primärerhebung.

In der Erhebung sind nur solche Haushalte vertreten, die sich auf Grund von Werbe­maßnahmen der Statistischen Ämterdes Bundes und der Länder bereit erklärten, die mit den Erhebungs­unterlagen abgefragten Angaben freiwillig zu machen.

Die Erhebung besteht aus vier Erhebungsteilen „Allgemeine Angaben“, „Geld- und Sachvermögen“, das „Haushaltsbuch" sowie das „Feinaufzeichnungsheft“ für Nahrungsmittel, Getränke und Tabakwaren.

Der zweite Erhebungsteil „**Geld- und Sachvermögen**“ (Stichtag 1. Januar des jeweiligen Jahres) beschäftigt sich mit der Vermögenssituation der Haushalte. Es werden u.a. Angaben zum Haus- und Grundbesitz sowie zur Vermögens- und Schuldensituation der Haushalte abgefragt.

Die Erhebungsgesamtheit umfasst alle Privathaushalte am Ort der Hauptwohnung, deren monatliches Haushaltsnettoeinkommen weniger als 18 000 EUR beträgt.

Generell nicht in die Erhebung einbezogen werden Personen ohne festen Wohnsitz (Obdachlose) sowie Personen in Gemeinschaftsunterkünften und Anstalten.

Die EVS gibt einen Überblick über die soziale Lage, den sozioökonomischen Status und insbesondere über die Einkommenssituation und das Konsumverhalten der Bevölkerung in Deutschland und ist damit wichtig für die Sozialpolitik, aber auch für die Politikberatung im Rahmen der Familien-, Konjunktur- und Steuerpolitik. Sie bildet eine wichtige Säule der Armuts- und Reichtumsberichterstattung der Bundesregierung. Als statistische Grundlage fließen die Ergebnisse der EVS in die (Neu-)Festsetzung der Regelbedarfe der sozialen Grundsicherung (z. B. Arbeitslosengeld II), in die Ermittlung des Verbraucherpreisindex sowie in die Verwendungsrechnung der volkswirtschaftlichen Gesamtrechnungen (z. B. für private Konsumausgaben) ein.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zu Stande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Einkommens- und Verbrauchsstichproben: Allgemeine Angaben**  
Metadaten 2018

[Download PDF](https://download.statistik-berlin-brandenburg.de/accd4c673f0e6295/4fbc17f02e52/MD_63211_2018.pdf)[Archiv](/search-results?q=MD_63211&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/o-ii-2-5j)
