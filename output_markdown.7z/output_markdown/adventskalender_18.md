

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
#### Türchen Nr. 18: Was tun an Heiligabend? *Wenn es eine Zeit gibt, in der Berlin nahezu leer erscheint, dann ist es Weihnachten. Nach dem Zensus 2022 sind ungefähr 55 % der Berliner Bevölkerung nicht in Berlin geboren. Es ist daher anzunehmen, dass viele der hier lebenden Menschen über die Feiertage in ihre Heimat fahren. Das bietet eine schöne Gelegenheit, einige Orte ganz in Ruhe zu besuchen.* *Unsere Karte zeigt, welche Orte in Berlin am 24. Dezember geöffnet haben. Ob ein entspannter Museumsbesuch, eine Runde Schwimmen oder ein letzter Glühwein auf dem Weihnachtsmarkt – der Tag der Bescherung lässt sich mit Sicherheit abwechslungsreich gestalten.*

###### 

#### Geöffnete Einrichtungen am 24.12.2024

Chart druckenDownload JPEGDownload EXCEL

wird geladen...


