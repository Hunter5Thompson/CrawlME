

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 16.10.2022

#### 20 Jahre Forschungsdatenzentrum der Statistischen Ämter der Länder

Bewährtes bewahren, Neues wagen
-------------------------------

![](https://download.statistik-berlin-brandenburg.de/659b8e15c0c434de/88376536d34e/v/031046298ba4/Jubilaum-FDZ.PNG)

**Wir feiern ein Doppel-Jubiläum. Vor 20 Jahren wurde das Forschungsdatenzentrum der Statistischen Ämter der Länder (FDZ) ins Leben gerufen. Das Amt für Statistik Berlin-Brandenburg war von Anfang an dabei. Und****heute vor 15 Jahren eröffneten wir unsere FDZ-Außenstelle in Berlin-Mitte, die mittlerweile ein zentraler Anlaufpunkt für Wissenschaftlerinnen und Wissenschaftler ist, die Mikrodaten der amtlichen Statistik analysieren wollen.**

Qualitativ hochwertige Daten sind eine wesentliche Grundlage für politische, wirtschaftliche und gesellschaftliche Entscheidungen. Gleichzeitig bilden sie eine zentrale Säule für die empirische wissenschaftliche Forschung. Der Zugang zu solchen Daten ist also ein zentraler Wettbewerbsvorteil für Hochschulen und Forschungseinrichtungen sowie ein wichtiger Baustein für eine fundierte, evidenzbasierte Politikberatung.

Genau diesen Datenzugang schaffen die Forschungsdatenzentren der Statistischen Ämter des Bundes und der Länder seit nunmehr 20 Jahren. In den Jahren seit der Gründung hat sich das Angebot der bereitstehenden Mikrodaten in den FDZ der amtlichen Statistik deutlich erweitert – nicht nur um die jeweils aktuellen Jahresscheiben der Statistiken, sondern auch durch Neuaufnahme von Statistiken in das Produktportfolio. Auch qualitativ konnte mit dem erfolgreich durchgeführten Projekt AFiD (Amtliche Firmendaten für Deutschland), bei dem der FDZ-Standort des Amtes für Statistik Berlin-Brandenburg die Federführung innehat, das Analysepotenzial insbesondere bei den Wirtschaftsdaten noch erheblich gesteigert werden.

![](https://download.statistik-berlin-brandenburg.de/59418fdb482abe86/09ceb274f4f3/v/9be18f2f3fcd/Zeitstrahl_FDZ.jpg)
#### Was bedeutet eigentlich...?

###### FDZ

Die **Forschungsdatenzentren der Statistischen Ämter des Bundes und der Länder** ermöglichen der Wissenschaft die Analyse von hochwertigen anonymisierten Mikrodaten der amtlichen Statistik über unterschiedliche Zugangswege. Das verfügbare [Produktportfolio](https://www.forschungsdatenzentrum.de/de/alle-daten) ist an den Bedarf der Wissenschaft angepasst und umfasst eine Fülle von Statistiken aus allen gesellschaftlich relevanten Bereichen.

###### AFiD

Die **Amtlichen Firmendaten für Deutschland** (AFiD) sind ein [Baukastensystem](https://www.forschungsdatenzentrum.de/sites/default/files/FDZ_AFiD_Produkt%C3%BCbersicht.pdf) aus kombinierbaren Paneldaten und Modulen aus den Wirtschafts- und Umweltstatistiken. Informationen zum AFiD-Datenangebot finden Sie auf der [Homepage des FDZ](https://www.forschungsdatenzentrum.de/de/afid). Einen Eindruck der wissenschaftlichen Arbeit mit den AFiD-Daten bietet  [Ausgabe 2/2017 der Zeitschrift für amtliche Statistik Berlin Brandenburg](https://www.statistischebibliothek.de/mir/receive/BBHeft_mods_00028648).

###### GWAP

An den **Gastwissenschafts­arbeitsplätzen** (GWAP) können Mikrodaten in vollständig abgeschotteten Räumen der amtlichen Statistik durch Wissenschaftlerinnen und Wissenschaftler analysiert werden. Da die Einzeldaten bereits durch die Regulierung des Datenzugangs und die Ausstattung des PC-Arbeitsplatzes geschützt werden, können am GWAP – je nach Sensibilität der Daten – faktisch oder formal anonyme Mikrodaten bereitgestellt werden.

###### KDFV

Bei der**kontrollierten Datenfernverarbeitung** (KDFV) erhalten Forschende keinen direkten Zugang zu den Mikrodaten. Stattdessen werden Datenstrukturfiles zur Verfügung gestellt, die in Aufbau und Merkmalsausprägung dem Originalmaterial entsprechen. Mittels dieser Datensätze können Auswertungsprogramme (Syntax-Skripte) in den Analyseprogrammen SPSS, SAS, Stata oder teilweise R erstellt werden, mit denen die Statistischen Ämter anschließend die Originaldaten auswerten. Die Datennutzenden erhalten die Ergebnisse ihrer Auswertungen, nachdem diese auf die Einhaltung der absoluten Anonymität geprüft wurden.

###### SUF

**Scientific Use Files**(SUF) sind standardisierte Datensätze, die von den Forschungsdatenzentren für gängige Statistiken erstellt werden. SUF bieten im Vergleich zu GWAP und KDFV ein geringeres Analysepotenzial, sind jedoch so konzipiert, dass sie sich für einen großen Teil der wissenschaftlichen Forschungsvorhaben eignen. Durch die faktische Anonymisierung der Mikrodaten dürfen sie außerhalb der geschützten Räume der amtlichen Statistik verwendet werden.

###### DIW

Das [**Deutsche Institut für Wirtschaftsforschung e.V.**](https://www.diw.de/de)(DIW Berlin) ist eines der führenden Wirtschafts­forschungs­institute in Deutschland. In seinem Gebäude befindet sich seit 15 Jahren die Außenstelle des FDZ-Standortes Berlin mit fünf Gastwissenschaftsarbeitsplätzen.

###### RatSWD

Der [**Rat für Sozial- und Wirtschaftsdaten**](https://www.konsortswd.de/ratswd/) (RatSWD) bietet Wissenschaft und Datenproduktion ein Austauschforum zur Verbesserung des Zugangs zu qualitativ hochwertigen, wissenschaftlich interessanten Daten. Er berät seit 2004 die Bundesregierung und die Regierungen der Länder zur Forschungsdateninfrastruktur.

#### **15 Jahre Außenstelle im Herzen Berlins**

Das Amt für Statistik Berlin-Brandenburg betreibt einen der größten FDZ-Standorte im Statistischen Verbund. Dazu gehören seit dem 16. Oktober 2007 auch die [Gastwissenschaftsarbeitsplätze (GWAP) im Gebäude des DIW Berlin](https://www.forschungsdatenzentrum.de/de/kontakt/berlin). Seit nunmehr 15 Jahren können dort Mikrodaten aus dem reichhaltigen Angebot der amtlichen Statistik ausgewertet werden.

Die regionale Verbundenheit mit dem Wissenschaftsstandort Berlin mit einer Vielzahl an Hochschulen und wissenschaftlichen Instituten spiegelt sich in der hohen Auslastung der Gastwissenschaftsarbeitsplätze und der intensiven Betreuung durch unser FDZ-Team bei zahlreichen Forschungsprojekten wider. Von allen zwischen 2012 und Mai 2022 laufenden GWAP-Projekten in den Forschungsdatenzentren der Statistischen Ämter der Länder wurden 22 % am Standort Berlin betreut; dreimal so viel wie im Durchschnitt aller FDZ-Standorte.

Etwa 1 200 Wissenschaftlerinnen und Wissenschaftler wurden in den letzten 20 Jahren am FDZ-Standort Berlin von uns betreut. Ein Großteil dieser Nutzenden kommt aus Berlin und Brandenburg. Unser Service wird aber auch durch Institute aus anderen Teilen Deutschlands und von ausländischen Institutionen nachgefragt.

Dabei hat die Komplexität der betreuten Forschungsprojekte im Laufe der Jahre deutlich zugenommen. Unter anderem stieg die Nachfrage nach der Verknüpfung von Produkten untereinander oder mit externen Datenmaterialien deutlich an und lag mit 42 % auch 2021 auf einem hohen Niveau. In diesem Zusammenhang nimmt auch der zeitliche Aufwand bei der fachlichen Beratung, der projektbezogenen Datenaufbereitung und bei der Prüfung der erzeugten Ergebnisse für die FDZ-Mitarbeiterinnen und Mitarbeiter zu. Die Bindung der personellen Kapazitäten ist daher im Vergleich zu 2007 deutlich höher einzuschätzen.

![](https://download.statistik-berlin-brandenburg.de/ecdbcf9ca76fd395/2cc011095e10/v/b1408f455f8d/DIW-FDZ-Eroeffnung.jpg)

v.l.: Dr. Ulrike Rockmann (2007–2014 Vorstand/Präsidentin des Amtes für Statistik Berlin-Brandenburg ) und Dr. Ramona Voshage (damals Leiterin des FDZ im Amt für Statistik Berlin-Brandenburg) bei der feierlichen Eröffnung der Außenstelle im Gebäude des DIW Berlin am 16. Oktober 2007.

#### Am**GWAP mit formal anonymisierten Daten arbeiten**

Durch eine [BStatG](https://www.gesetze-im-internet.de/bstatg_1987/)-Novellierung im Jahr 2016 dürfen die FDZ an den Gastwissenschaftsarbeitsplätzen weniger stark anonymisierte Mikrodaten anbieten. Die sogenannten formal anonymisierten – also lediglich um die direkten Identifikatoren und Hilfsmerkmale bereinigten – Mikrodaten sind seitdem nicht mehr nur über die kontrollierte Datenfernverarbeitung (KDFV) zugänglich, sondern auch an den Gastwissenschaftsarbeitsplätzen. Ein großer Vorteil sowohl für die Wissenschaft als auch für die FDZ: Am GWAP können die Nutzerinnen und Nutzer sowohl die Daten als auch die erzeugten Ergebnisse direkt vor Ort betrachten und bei auftretenden Geheimhaltungsfällen eigenständig entsprechende Anpassungen in ihren Programmen vornehmen. Dadurch reduziert sich die Zahl der potenziellen Geheimhaltungsfälle und das FDZ-Team muss bei der finalen Prüfung der Ergebnisse vor der Herausgabe an die Nutzenden weniger Sperrungen vornehmen.

Leider ist die Bereitstellung von formal anonymisierten Einzeldaten an den Gastwissenschaftsarbeitsplätzen noch immer nicht für alle Statistiken möglich. So hat die abweichende bayerische Auffassung des [§ 16 Abs. 6 Nr. 2 BStatG](https://www.gesetze-im-internet.de/bstatg_1987/__16.html) zur Folge, dass bayerische Wirtschaftsdaten am Gastwissenschaftsarbeitsplatz nicht zur Verfügung stehen und Ergebnisse erst nach einer zusätzlichen Datenfernverarbeitung durch die FDZ-Standorte bereitgestellt werden können. Dadurch erhöht sich der Aufwand sowohl für die Wissenschaft als auch für die FDZ.

Die Aufrechterhaltung des wissenschaftlichen Betriebs in der Pandemiezeit seit 2020 war mit großen Hürden verbunden. Die Außenstelle musste – wie viele andere dienstleistende Institutionen – temporär schließen. Auch nach Wiederaufnahme des Betriebs war die Nutzung zur Eindämmung des Infektionsrisikos nur beschränkt möglich (verringerte Anzahl gleichzeitiger Nutzungen, Kontaktnachverfolgung, Maskenpflicht). Projekte wurden kostenneutral verlängert oder Daten übergangsweise über andere Zugangswege bereitgestellt, um die durch die Schließung der Außenstelle entstandenen Schäden für die Wissenschaft zumindest teilweise abzumildern.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Wege in eine digitale(re) Zukunft**

Trotz hoher Zufriedenheit bei den Nutzenden mit dem FDZ-Datenangebot und den Dienstleistungen muss sich das FDZ kontinuierlich weiterentwickeln. Zum einen soll das Angebot der qualitativ hochwertigen Mikrodaten und die Infrastruktur stärker am Bedarf der Wissenschaft ausgerichtet werden. Zum anderen sollen einheitliche und schlanke Prozesse in den FDZ eine schnelle Daten- und Ergebnisbereitstellung gewährleisten. Dabei ist die Digitalisierung das wichtigste Thema bei der strategischen Neupositionierung der FDZ.

GWAP-Buchungssystem

Ein digitales Buchungssystem bietet den nutzungsberechtigten Gastwissenschaftlerinnen und Gastwissenschaftlern seit März 2022 die Möglichkeit, nach verfügbaren Terminen an den FDZ-Standorten zu suchen, diese verbindlich zu reservieren sowie die eigenen Termine einfach, bequem und schnell zu verwalten. Die teils aufwändige manuelle Pflege und die Überwachung der Termine durch die FDZ-Teams an den Standorten entfallen.

Online-Nutzungsantrag

Im Rahmen der aktuellen Überarbeitung und Umprogrammierung des bestehenden Online-Nutzungsantrags wurde im FDZ-Verbund beschlossen, die Beantragung von Mikrodaten zukünftig vorrangig per Online-Antrag anzubieten. Gründe hierfür sind die geringere Fehleranfälligkeit als bei Papieranträgen, die Umsetzung medienbruchfreier Prozesse, die Digitalisierung gemäß [E-Government-Gesetz](https://www.gesetze-im-internet.de/egovg/) sowie die Reduktion des administrativen und Pflegeaufwandes. Die Bereitstellung und Entgegennahme eines Papier-Antrags erfolgen nur noch auf Anfrage.

Remote-Access

In den FDZ werden derzeit Vorarbeiten für die Einführung eines Remote-Access-Systems durchgeführt. Damit könnten Wissenschaftlerinnen und Wissenschaftler bequem vom Büro aus direkt auf die Daten der amtlichen Statistik zugreifen und Auswertungen durchführen. Dabei müssen alle IT-sicherheitstechnischen und rechtlichen Rahmenbedingungen berücksichtigt werden. So wird das System zum Beispiel für Daten mit hohem Schutzbedarf programmiert. Wegen der aktuell geltenden rechtlichen Rahmenbedingungen des BStatG wird mit dem derzeit erstellten Prototyp zunächst nur der Zugriff zu Daten getestet, die bereits jetzt per DVD an die Wissenschaft übermittelt werden (sogenannte SUF). Künftig soll aber auch auf weniger stark anonymisierte Daten aus der Ferne zugegriffen werden.

Der Statistische Verbund möchte zusätzlich auf eine entsprechende Gesetzesänderung hinwirken, die eine Auswertung von formal anonymisierten Sozial-, aber auch Wirtschaftsstatistiken per Remote-Zugriff ermöglicht. Damit folgt der Statistische Verbund den dringenden [Empfehlungen des Rats für Sozial- und Wirtschaftsdaten zur Etablierung eines Remote Access zu Daten der amtlichen Statistik](https://doi.org/10.17620/02671.42) in Anlehnung an die Vorgehensweisen anderer europäischer amtlicher Datenproduzenten.Eine Gesetzesänderung zusammen mit der dann bestehenden IT-Infrastruktur für Remote-Access wäre disruptiv und könnte andere Zugangswege, wie die Gastwissenschaftsarbeitsplätze, auf lange Sicht ersetzen. Die Wissenschaft kann dann weitgehend autark arbeiten und die FDZ würden sich auf eine schnellere Bereitstellung der amtlichen Daten sowie die Geheimhaltung der Ergebnisse fokussieren.

[Sie wollen mit amtlichen Daten forschen? Hier geht's zu weiteren Infos.](https://www.forschungsdatenzentrum.de/de)
###### *Autorinnen:*

**Anja Malchin** ist Referentin im Referat *Gesamtrechnungen, *Forschungsdatenzentrum** des Amtes für Statistik Berlin-Brandenburg.  
**Dr. Ramona Voshage** leitet die Abteilung Gesamtwirtschaft des Amtes für Statistik Berlin-Brandenburg.

### Kontakte

#### Anja Malchin

Forschungsdatenzentrum

#### Anja Malchin

Forschungsdatenzentrum

* [forschungsdatenzentrum@statistik-bbb.de](mailto:forschungsdatenzentrum@statistik-bbb.de)
#### Nicole Dombrowski

Fachredaktion

#### Nicole Dombrowski

Fachredaktion

* [zeitschrift@statistik-bbb.de](mailto:zeitschrift@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* FDZ](/search-results?q=tag%3AFDZ)[* Forschungsdatenzentrum](/search-results?q=tag%3AForschungsdatenzentrum)[* Mikrodaten](/search-results?q=tag%3AMikrodaten)[* Wissenschaft](/search-results?q=tag%3AWissenschaft)[* Wissenschaftsstandort](/search-results?q=tag%3AWissenschaftsstandort)
