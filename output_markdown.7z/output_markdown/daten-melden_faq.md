

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Daten melden](/daten-melden)
* [FAQ Daten melden](/daten-melden/faq)

Häufige Fragen
--------------

### Allgemeine Fragen

###### Unterliege ich einer Auskunftspflicht?

Ja, für die meisten amtlichen Statistiken besteht Auskunftspflicht. Durch die statistische Auskunftspflicht besteht die rechtliche Verpflichtung im Rahmen der amtlichen Statistik die geforderten Auskünfte zu erteilen. Nur wenige Angaben sind freiwillig.

Sofern Auskunftspflicht besteht, sind die Befragten zur wahrheitsgemäßen und vollständigen Beantwortung der ordnungsgemäß gestellten Fragen innerhalb der festgelegten Fristen verpflichtet.   


###### Warum sind meine Daten wichtig?

Die Daten der amtlichen Statistik sind wichtige Entscheidungsgrundlagen und bilden die aktuelle Lage von Wirtschaft und Gesellschaft ab. Sie eine wichtige Grundlage für faktenbasierte Entscheidungen – gerade in Krisenzeiten.

###### Welche gesetzlichen Grundlagen gelten für die Statistik?

Für jede Statistik ist grundsätzlich eine Rechtsgrundlage erforderlich (Prinzip der Gesetzmäßigkeit). Hier sind ebenfalls Erhebungsmerkmale, die Art der Erhebung, der Berichtszeitraum und -zeitpunkt, die Periodizität sowie der Kreis der zu Befragenden festgelegt.

[Bundesstatistikgesetz](https://www.gesetze-im-internet.de/bstatg_1987/index.html)

[Landesstatistikgesetz Berlin](https://gesetze.berlin.de/bsbe/document/jlr-StatGBErahmen)

[Landesstatistikgesetz Brandenburg](https://bravors.brandenburg.de/gesetze/bbgstatg)

###### Was passiert, wenn ich der Auskunftspflicht nicht nachkomme?

Wenn Sie angeschrieben wurden und es sich um eine Statistik mit Auskunftspflicht handelt, sind Sie gesetzlich zur Meldung verpflichtet. Werden die Auskünfte vorsätzlich oder fahrlässig verweigert oder nicht fristgemäß erteilt, so stellt das eine Ordnungswidrigkeit dar, die mit einem Bußgeld von bis zu 5.000 Euro verfolgt werden kann.

###### Wie lange, wie oft und wann muss ich meine Daten melden?

Bei vielen Statistiken rotiert die Pflicht zur Mitwirkung nach einigen Jahren. Wenn Sie bei einer Statistik immer wieder angeschrieben werden, fragen Sie bei der oder dem im Anschreiben genannten Ansprechpartnerin oder Ansprechpartner gern nach.

###### Wie sicher ist die Onlinemeldung?

Die amtliche Statistik in Deutschland gewährleistet die Sicherheit und Vertraulichkeit Ihrer Daten. Die Übermittlung über unsere Online-Meldewege erfolgt über verschlüsselte Verbindungen, die Online-Meldeverfahren entsprechen höchsten IT-Sicherheitsstandard. Bei der Verarbeitung werden Ihre Daten anonymisiert und nur aggregierte Ergebnisse veröffentlicht, die keine Rückschlüsse auf Einzelpersonen oder -unternehmen zulassen. Alle Mitarbeitenden sind zur statistischen Geheimhaltung verpflichtet, sodass alle veröffentlichten Daten anonym und geschützt sind.

###### Wer hilft mir weiter, wenn ich Fragen habe?

Sie haben Fragen zum Ablauf? Sie haben technische Probleme mit den Online-Meldeverfahren?

Wir haben Ihnen auf dieser Seite verschiedene Informationen rundum das Thema „Daten melden“ zusammengestellt. Außerdem gibt es einen „Häufige Fragen und Antworten“-Bereich, der regelmäßig ergänzt wird.

### Fragen zur Verdiensterhebung

###### Warum gerade ich?

In einem Video haben unsere Kollegen aus Nordrhein-Westfalen den Auswahlprozess anschaulich erklärt.

###### Wie erstelle ich eine CSV-Datei für die Verdiensterhebung?

Ein Video-Tutorial inklusive einer Beispiel csv finden Sie auf den Seiten unserer Kollegen aus NRW.

[Videoanleitung Erstellung einer CSV inklusive Beispieldatei](https://www.it.nrw/verdienststatistik)
###### Wo finde ich den Tätigkeitsschlüssel?

Auf den Meldungen zur Sozialversicherung ist er bei dem Merkmal Tätigkeit oder Tätigkeitsschlüssel hinterlegt (siehe Beispielbild unten)*.*

![](https://download.statistik-berlin-brandenburg.de/6059c7ba28330be0/fa9573997535/v/8050f9c5723a/Meldebescheinigung_SV.PNG)
###### Sind alle Arbeitnehmenden zu melden?

Nein - ausschließlich die Beschäftigten, die den vollen Monat bzw. die vertraglich vereinbarte Zeit entlohnt wurden. Beschäftigte, die sich beispielsweise in Krankheit ohne Lohnfortzahlung, in unbezahlter Freistellung, Beginn oder Ausscheiden im laufenden Monat befanden, sind nicht zu melden.

Ausnahmen bilden Kurzarbeit, Streik und Entschädigungen bei Quarantäne, Tätigkeitsverbot oder Betreuungserfordernis nach §56 Abs. 1 und §56 Abs. 1a des Infektionsschutzgesetzes (IfSG).

###### Welche Zahlungen gehören nicht zum Bruttomonatsverdienst?

Entgeltbestandteile, bei denen der Arbeitgeber in Vorleistung tritt, sich aber anschließend diese Zahlungen erstatten lässt (z.B. Entschädigungen bei Quarantäne, Tätigkeitsverbot oder Betreuungserfordernis, Energiepreispauschale), sind beim Bruttomonatsverdienst nicht zu berücksichtigen und die bezahlten Stunden entsprechend zu kürzen.

###### Ist die Energiepreispauschale ein Verdienst?

Die Energiepreispauschale ist **kein**Verdienst und bei der Verdiensterhebung weder im Gesamtbruttoentgelt noch in den sonstigen Bezügen zu melden. Hier tritt der Arbeitgeber nur in Vorleistung und bekommt anschließend diese Zahlungen erstatten.

###### Welcher Monat ist bei versetzter Entgeltabrechnung zu melden?

Wir benötigen die Daten der Entgeltbescheinigung, die der Arbeitnehmer in dem jeweiligen Monat erhält, auch wenn damit der Vormonat abgerechnet wird.

###### Mein Unternehmen besteht aus mehreren Betrieben. Was genau soll ich melden?

Wir können Ihnen auf Anfrage die entsprechende Betriebsnummer der Bundesagentur für Arbeit für die ausgewählte Einheit übermitteln.

Wenn Sie mehrere Betriebe in unterschiedlichen Bundesländern haben, aber nur unter einer Betriebsnummer der Bundesagentur für Arbeit melden, achten Sie bitte darauf, dass ausschließlich Beschäftigte des Bundeslandes, in dem sich der Betrieb befindet, in die Meldung einbezogen werden.

###### Für was werden die Daten erhoben?

Es werden Nominal-, Reallöhne und Durchschnittsverdienste für die einzelnen Wirtschaftsbereiche und Berufe veröffentlicht. Mit den Merkmalen Beruf, Alter, Geschlecht, Geburtsjahr, Beschäftigungsbeginn, Ausbildungsstand, Unternehmensgröße und -zugehörigkeit sowie der Tarifbindung wird deren Einfluss auf das Verdienstniveau dargestellt.

Die Ergebnisse sind eine wesentliche Grundlage wichtiger Entscheidungen in Politik und Wirtschaft. Sie werden vom Staat, Unternehmen, Verbänden, Medien sowie Privatpersonen intensiv nachgefragt.

Auf unserer Internetseite finden Sie viele Veröffentlichungen zu den Ergebnissen zum Thema [Verdienste](/verdienste).

### Sie haben weitere Fragen?

#### IDEV und .core

Bei technischen Fragen und Problemen

#### IDEV und .core

Bei technischen Fragen und Problemen

* [idev@statistik-bbb.de](mailto: idev@statistik-bbb.de)
#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)


