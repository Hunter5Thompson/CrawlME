

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Datenschutz](/datenschutz)

Datenschutzerklärung
====================

Im Amt für Statistik Berlin-Brandenburg ist die Einhaltung des gesetzlich vorgeschriebenen Datenschutzes oberstes Gebot.

VerantwortlicherKontaktIhre RechteDatenverarbeitungHinweiseCookie-Einstellungen

1. Verantwortlicher i. S. d. Europäischen Datenschutz-Grundverordnung
---------------------------------------------------------------------

Amt für Statistik Berlin-Brandenburg  
Steinstraße 104–106  
14480 Potsdam

2. Kontakt und Aufsichtsbehörde
-------------------------------

Ihr Vertrauen ist uns wichtig! Daher möchten wir Ihnen jederzeit Rede und Antwort bezüglich der Verarbeitung Ihrer personenbezogenen Daten stehen. Wenn Sie Fragen haben, die diese Datenschutzerklärung nicht beantworten konnte, oder wenn Sie weitergehende Informationen wünschen, wenden Sie sich bitte an unseren behördlichen **Datenschutzbeauftragten Herrn Wennrich**:

> Amt für Statistik Berlin-Brandenburg  
> Steinstraße 104–106  
> 14480 Potsdam  
> Telefon: 0331 8173-1880 oder 0331 8173 -3422  
> E-Mail: [Datenschutz@statistik-bbb.de](mailto:Datenschutz@statistik-bbb.de)

Unsere **datenschutzrechtliche Aufsichtsbehörde** erreichen Sie wie folgt:

> Die Landesbeauftragte für den Datenschutz und für das Recht auf Akteneinsicht  
> Stahnsdorfer Damm 77  
> 14532 Kleinmachnow  
> Telefon: 033203 356-0  
> Telefax: 033203 356-49  
> E-Mail: [Poststelle@LDA.Brandenburg.de](mailto:Poststelle@LDA.Brandenburg.de)

3. Ihre Rechte
--------------

**Nach der Datenschutz-Grundverordnung stehen Ihnen folgende Rechte zu:**

* Werden Ihre personenbezogenen Daten verarbeitet, so haben Sie das Recht Auskunft über die zu Ihrer Person gespeicherten Daten zu erhalten (Art. 15 Datenschutz-Grundverordnung ).
* Sollten unrichtige personenbezogene Daten verarbeitet werden, steht Ihnen ein Recht auf Berichtigung zu (Art. 16 Datenschutz-Grundverordnung).
* Liegen die gesetzlichen Voraussetzungen vor, so können Sie die Löschung oder Einschränkung der Verarbeitung verlangen sowie Widerspruch gegen die Verarbeitung einlegen (Art. 17, 18 und 21 Datenschutz-Grundverordnung).
* Wenn Sie in die Datenverarbeitung eingewilligt haben oder ein Vertrag zur Datenverarbeitung besteht und die Datenverarbeitung mithilfe automatisierter Verfahren durchgeführt wird, steht Ihnen gegebenenfalls ein Recht auf Datenübertragbarkeit zu (Art. 20 Datenschutz-Grundverordnung).
* Sollten Sie von Ihren oben genannten Rechten Gebrauch machen, prüfen wir, ob die gesetzlichen Voraussetzungen hierfür erfüllt sind.

4. Zwecke und Umfang der Datenverarbeitung
------------------------------------------

**a) Internetauftritt – Verarbeitung von Kommunikationsdaten**

Bei jedem Zugriff eines Nutzers auf eine Seite aus dem Angebot des AfS und bei jedem Abruf einer Datei werden Daten über diesen Vorgang vorübergehend in einer Protokolldatei gespeichert und verarbeitet. Im Einzelnen werden folgende Daten gespeichert:

* die Seite, von der aus die Datei angefordert wurde
* der Namen der aufgerufenen Datei
* das Datum und Uhrzeit der Anforderung
* die übertragene Datenmenge
* der Zugriffsstatus (Datei übertragen, Datei nicht gefunden etc.)
* die Beschreibung des verwendeten Webbrowsertyps bzw. des verwendeten Betriebssystems

Nicht gespeichert wird die IP-Adresse des Rechners, von dem die Anfrage abgeschickt wurde. Personenbezogene Nutzerprofile können daher nicht gebildet werden.

Im Informationsangebot des AfS können Cookies verwendet werden. Die Verwendung dieser Funktionalitäten kann durch Einstellungen des Browserprogramms vom jeweiligen Nutzer ausgeschaltet werden. Cookies sind Dateien, die auf Ihrer Festplatte abgelegt werden. Cookies werden von uns ausschließlich für die Speicherung sitzungsrelevanter Informationen innerhalb unserer Website genutzt. Sie verfallen automatisch am Ende der Sitzung und werden nicht dauerhaft gespeichert.

**b) Öffentlichkeitsarbeit – Verarbeitung von Inhaltsdaten**

Sofern innerhalb des Internetangebotes die Möglichkeit zur Eingabe persönlicher oder geschäftlicher Daten (z. B. E-Mail-Adressen, Namen, Anschriften) besteht, so beispielsweise über unsere Kontaktformulare, erfolgt die Mitteilung dieser Daten seitens des Nutzers auf ausdrücklich freiwilliger Basis gemäß Artikel 6 Absatz 1 Buchstabe a DS-GVO. Auch hier werden Ihre Daten vertraulich behandelt und ohne Ihre Einwilligung nicht an Dritte weitergegeben. Auch eine Verknüpfung mit oben genannten Kommunikationsdaten findet nicht statt.

**c) Umfragen und Verlosungen**

Wenn Sie an einer unserer Umfragen teilnehmen, verwenden wir Ihre Daten zur Markt- und Meinungsforschung. Wir werten die Daten grundsätzlich anonymisiert für interne Zwecke aus. Sofern Umfragen ausnahmsweise nicht anonym ausgewertet werden, werden die Daten ausschließlich mit Ihrer Einwilligung erhoben. Bei anonymen Umfragen ist die Datenschutz-Grundverordnung  nicht anwendbar und bei ausnahmsweise personenbezogenen Auswertungen ist Rechtsgrundlage die zuvor genannte Einwilligung nach Art. 6 Abs. 1 S. 1 lit. a Datenschutz-Grundverordnung . Diese Einwilligung ist freiwillig und jederzeit widerrufbar per E-Mail an [Datenschutz@statistik-bbb.de](mailto:Datenschutz@statistik-bbb.de)

Im Rahmen von Verlosungen verwenden wir Ihre Daten zum Zweck der Durchführung der Verlosung und der Gewinnbenachrichtigung. Rechtsgrundlage für die Abwicklung der Verlosung ist Art. 6 Abs. 1 S. 1 lit. b Datenschutz-Grundverordnung .

Alle personenbezogenen Daten werden unverzüglich 6 Monate nach Ende der Verlosung gelöscht.

Wurden Daten zur Abwicklung einer Verlosung an uns übermittelt (Namen, Adressdaten etc.), werden diese nur für die Durchführung der Verlosung und nicht für andere Zwecke genutzt. Die Daten des Gewinners werden entsprechend der gesetzlichen Aufbewahrungsfristen gespeichert und nach deren Ablauf gelöscht.

**d) Matomo**

Diese Website benutzt Matomo (ehemals Piwik), eine Open-Source-Analysesoftware zur statistischen Auswertung der Besucherzugriffe. Matomo wird auf unserem Webspace betrieben und es werden keine Daten an Dritte weitergegeben.

Folgende Daten können im Besucher-Log zusammen mit einer pseudonymisierten Besucher-ID gespeichert werden:

* Anonymisierte IP-Adresse;
* Referrer-URL (zuvor besuchte Seite);
* Aufgerufene Seiten (Datum, Uhrzeit, URL, Titel, Verweildauer);
* Heruntergeladene Dateien;
* Angeklickte Links zu anderen Websites;
* ggf. Erreichung von bestimmten Zielen (Conversions);
* Technische Informationen: Betriebssystem; Browsertyp, -version und –sprache; Gerätetyp, -marke, -modell und -auflösung;
* Ungefährer Standort (Land und ggf. Stadt, ausgehend von anonymisierter IP-Adresse).

Bei der Nutzung von Matomo werden folgende Cookies zum angegebenen Zweck mit der jeweiligen Speicherdauer gesetzt:

* „CookieConsent“ für 1 Jahr (Erinnerung an die Einwilligung).

Rechtsgrundlage für die Reichweitenanalyse zur Optimierung und bedarfsgerechten Gestaltung unserer Website ist Ihre Einwilligung gemäß Art. 6 Abs. 1 lit. a Datenschutz-Grundverordnung.

Nähere Informationen hierzu finden Sie auch in den [Hinweisen zum Datenschutz](https://matomo.org/privacy-policy/) von Matomo.

**e) Newsletter**

Wir eröffnen die Möglichkeit, sich als Empfänger für einen oder mehrere unserer Newsletter zu registrieren. Dafür müssen Sie Ihre E-Mailadresse angeben. Ihre E-Mailadresse nutzen wir ausschließlich zu dem Zweck, Ihnen den Newsletter zu dem von Ihnen gewählten Themenbereich zuzusenden. Die Zusendung der jeweiligen Informationen sowie die Speicherung Ihrer E-Mailadresse bei uns basiert auf Ihrer Einwilligung nach Artikel 6 Abs. 1 lit. a) DS-GVO. Ihre eingegebenen Daten werden lediglich zur Personalisierung des Newsletters verwendet und grundsätzlich nicht an Dritte weitergegeben. Sie können sich jederzeit aus dem Newsletter heraus abmelden oder Ihre Einwilligung jederzeit mit Wirkung für die Zukunft per E-Mail an [newsletter@statistik-bbb.de](mailto:newsletter@statistik-bbb.de) widerrufen. Wenn Sie widerrufen oder sich selbst von allen Newslettern abmelden, wird Ihre E-Mailadresse innerhalb von 6 Monaten gelöscht, sofern der Löschung keine gesetzlichen Aufbewahrungspflichten entgegenstehen.

**f) Oracle Analytics**

Oracle Analytics setzt technisch notwendige Cookies ein, um die Dashboards korrekt darzustellen und die ordnungsgemäße Funktionsweise sicherzustellen. Diese Cookies enthalten keine persönlichen Daten. Sie sind für die Funktion dieses Systems unbedingt erforderlich und werden nur für die Dauer der jeweiligen Sitzung gespeichert.

* \_WL\_AUTHCOOKIE\_JSESSIONID: Enthält eine zufällig generierte, sichere Sitzungskennung für den Anwendungsserver.
* JESSIONID: Speichert Ihre Sitzungs-ID, die vom ISP-Server verwendet wird, um Sie von anderen zu unterscheiden.
* ORA\_BI\_SESSPARAM: Damit Sie in den relevanten Teilen des Systems angemeldet bleiben.
* ORA\_BI\_SESSTOK: Damit Sie in den relevanten Teilen des Systems angemeldet bleiben.
* ORA\_BIPS\_LBINFO: Damit Sie in den relevanten Teilen des Systems angemeldet bleiben.
* ORA\_BIPS\_NQID: Damit Sie in den relevanten Teilen des Systems angemeldet bleiben.

Durch die Nutzung unserer Website stimmen Sie der Verwendung von Oracle Analytics und den damit verbundenen Cookies zu. Sie können die Verwendung von Cookies jederzeit in den Einstellungen Ihres Browsers deaktivieren. Beachten Sie jedoch, dass dies die Funktionalität unserer Website beeinträchtigen kann.

5. Verarbeitung durch das Amt für Statistik Berlin-Brandenburg und die kreisfreien Städte und Landkreise des Landes Brandenburg
-------------------------------------------------------------------------------------------------------------------------------

Das Amt für Statistik Berlin-Brandenburg und die kreisfreien Städte und Landkreise des Landes Brandenburg führen den Zensus 2022 im Land Brandenburg als gemeinsame Aufgabe durch. Im Rahmen des Zensus 2022 verarbeiten wir Ihre personenbezogenen Daten auf der gesetzlichen Grundlage des Artikel 6 Absatz 1 Buchstabe c) Datenschutz-Grundverordnung (DS-GVO) in Verbindung mit dem Zensusgesetz 2022 als gemeinsame Verantwortliche nach Artikel 26 Datenschutz-Grundverordnung.

Sie haben nach der Datenschutz-Grundverordnung hinsichtlich der Sie betreffenden personenbezogenen Daten gegenüber der für Sie örtlich zuständigen Zensus-Erhebungsstelle der kreisfreien Stadt oder des Landkreises sowie dem Amt für Statistik Berlin-Brandenburg bei Vorliegen der Voraussetzungen die folgenden Rechte auf:

* Auskunft nach Artikel 15 DS-GVO
* Berichtigung nach Artikel 16 DS-GVO
* Löschung nach Artikel 17 DS-GVO
* Einschränkung der Verarbeitung nach Artikel 18 DS-GVO
* Widerspruch gegen die Verarbeitung nach Artikel 21 DS-GVO
* Datenübertragbarkeit nach Artikel 20 DS-GVO.

Ihren Antrag hinsichtlich Ihres Rechtes nach Artikel 15 DS-GVO können Sie als betroffene Person im Rahmen von Verarbeitungen Ihrer personenbezogenen Daten für den Zensus 2022 beim

Amt für Statistik Berlin-Brandenburg,   
Steinstraße 104-106,   
14480 Potsdam   
E-Mail: [datenschutz@zensus.brandenburg.de](mailto:datenschutz@zensus.brandenburg.de)

stellen.

Die Anträge für Ihre übrigen oben genannten Rechte können Sie sowohl beim Amt für Statistik Berlin-Brandenburg als auch bei Ihrer Zensus-Erhebungsstelle (bzw. kreisfreien Stadt oder Landkreis) stellen.

6. Ergänzende Hinweise
----------------------

Die Kommunikation über E-Mail kann Sicherheitslücken aufweisen. Beispielsweise können E-Mails auf ihrem Weg an die Beschäftigten des AfS von versierten Internet-Nutzern aufgehalten und eingesehen werden. Sollten wir eine E-Mail von Ihnen erhalten, so gehen wir davon aus, dass wir zu einer Beantwortung per E-Mail berechtigt sind. Ansonsten müssen Sie ausdrücklich auf eine andere Art der Kommunikation verweisen.

Im Zuge der Weiterentwicklung unserer Webseiten und der Implementierung neuer Technologien können Änderungen dieser Datenschutzerklärung erforderlich werden. Daher empfehlen wir Ihnen, sich diese Datenschutzerklärung ab und zu erneut durchzulesen.

**Stand: 18. April 2024**


