

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 13.09.2022

#### Konferenz-Artikel

24. Konferenz „Messung der Preise“
----------------------------------

![](https://download.statistik-berlin-brandenburg.de/d468d88661bf0b57/1205b5813bde/v/e012b33daca2/iStock-1305998551.jpg)

**Die Konferenzreihe „Messung der Preise“ fand nach zweijähriger Corona-Pause am 8. September 2022 erstmals wieder statt. Die vom Amt für Statistik Berlin-Brandenburg veranstaltete Konferenz, hat einen Austausch zwischen nationaler und internationaler amtlicher Preisstatistik und deren Nutzenden zum Ziel. Sie wurde in den 1990er Jahren ins Leben gerufen und findet seitdem an regelmäßig wechselnden Standorten statt. In diesem Jahr wurde die 24. Konferenz erstmals virtuell durchgeführt.**

Nahezu 60 Teilnehmende, darunter Vertreter der Statistischen Ämter des Bundes und der Länder, der Deutschen Bundesbank, der Europäischen Zentralbank (EZB), Eurostat, Statistik Austria und der Wissenschaft nahmen teil.

Über eine Dauer von 6 Stunden wurde ein breites Spektrum an interessanten Themen vorgestellt und diskutiert. Die Beiträge beleuchteten u. a. die Notwendigkeit methodischer und technischer Weiterentwicklungen. Auf der Tagesordnung standen Beiträge, wie die Nutzung von Scannerdaten in der Preisstatistik, Erfahrungen aus der Erhebung der Verbraucherpreise in Zeiten der Pandemie oder die Plausibilisierung von Transaktionsdaten für Pauschalreisen. Aber auch Fragestellungen zur Indexrevision, die Analyse von Mikropreisdaten, der Einfluss von Gewichtsverschiebungen auf die Inflation oder der Einbezug von selbstgenutztem Wohneigentum wurden vorgestellt und diskutiert.

Die spannenden Diskussionen der Konferenzteilnehmenden zeigten, dass die Herausforderungen der Preismessung durch einen intensiven fachlichen Austausch und eine konstruktive Zusammenarbeit zwischen den statistischen Ämtern, der Bundesbank, der EZB und der Wissenschaft zu meistern sind.

###### ***Save the date.***

***Die 25. Konferenz „Messung der Preise“ findet am 5./6. Juni 2023 in Berlin statt.******Anmeldungen richten Sie bitte bis zum 19. Mai 2023 an [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de).***

###### Freigegebene Konferenzunterlagen zum Download

[Agenda der 24. Konferenz „Messung der Preise“](https://download.statistik-berlin-brandenburg.de/24a710ef0ecc2047/f6177e775f36/Konferenz_Messung_der_Preise_Agenda.pdf)[Dr. Thomas Knetsch (Deutsche Bundesbank): Zur Diskussion über die Einbeziehung der Kosten des selbst genutzten Wohneigentums in den HVPI](https://download.statistik-berlin-brandenburg.de/0bb9338e8f061a4c/72232cae00f2/MessungderPreise2022_Bundesbank-HVPI.pdf)[Sebastian Weinand (Deutsche Bundesbank): Der Einfluss von Gewichtsverschiebungen auf die Inflation – Befunde für den HVPI](https://download.statistik-berlin-brandenburg.de/11f24c100b9b2b5b/2590d356cda6/MessungderPreise2022_Bundesbank-HVPI-2.pdf)
###### Weiterführende Literatur:

* [Thomas A. Knetsch, Patrick Schwind, Sebastian Weinand (2022): The impact of weight shifts on inflation: Evidence for the euro area HICP, Discussion Paper Deutsche Bundesbank No 27/2022.](https://www.bundesbank.de/resource/blob/894228/e4098d0181d9ecb3266577f3784942dc/mL/2022-07-11-dkp-27-data.pdf)
### Kontakte

#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Preise](/search-results?q=tag%3APreise)[* News](/search-results?q=tag%3ANews)[* Konferenz](/search-results?q=tag%3AKonferenz)[* Messung der Preise](/search-results?q=tag%3AMessung der Preise)
