

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Todesursachen](/todesursachen)
* [Gestorbene nach ausgewählten Todesursachen in Berlin und Brandenburg](/a-iv-12-m)

Gestorbene nach ausgewählten Todesursachen
------------------------------------------

#### April 2024 (BE) Mai 2024 (BB), monatlich – vorläufige Ergebnisse, Stand: November 2024

###### Seit Beginn der Corona-Pandemie gibt es einen wachsenden Bedarf an zeitnahen Daten der Gesundheitsstatistiken. Die Statistischen Ämter des Bundes und der Länder haben eine monatliche Berichterstattung mit vorläufigen Daten entwickelt, die auch erste Rückschlüsse auf die saisonale Sterblichkeit nach Todesursachen in den Ländern ermöglichen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – April 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/af9c1169102f7535/09960fa26c43/SB_A04-12-00_2024m04_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/a210ee362bc49179/bdc8cb7d92d1/SB_A04-12-00_2024m04_BE.pdf)

**Stand: November 2024**   
      
Bei 18 Sterbefällen von den 86,1 % ausgewerteten Todesbescheinigungen wurde im April 2024 laut den vorläufigen Daten der Todesursachenstatistik COVID-19 als Erkrankung vermerkt. In 9 Fällen war dies die Todesursache, in den anderen 9 Fällen war es eine Begleiterkrankung. Somit starben in 50,0 % dieser Fälle die betroffenen Personen an COVID-19 als sogenanntem Grundleiden. Das heißt, die Krankheit war die für den Tod verantwortliche Todesursache. In 50,0 % der Fälle starben die Personen mit COVID-19 als Begleiterkrankung, jedoch an einem anderen Grundleiden.

### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Stand: November 2024**      
      
Bei 9 Sterbefällen von den 83,9 % ausgewerteten Todesbescheinigungen wurde im Mai 2024 laut den vorläufigen Daten der Todesursachenstatistik COVID-19 als Erkrankung vermerkt. In 5 Fällen war dies die Todesursache, in den anderen 4 Fällen war es eine Begleiterkrankung. Somit starben in 55,6 % dieser Fälle die betroffenen Personen an COVID-19 als sogenanntem Grundleiden. Das heißt, die Krankheit war die für den Tod verantwortliche Todesursache. In 44,4 % der Fälle starben die Personen mit COVID-19 als Begleiterkrankung, jedoch an einem anderen Grundleiden.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – Mai 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/3e9ff33ae004eb93/9e419defa8cf/SB_A04-12-00_2024m05_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/ed78bac91d2ad9b7/fe4d89e7d732/SB_A04-12-00_2024m05_BB.pdf)
### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die monatlichen Berichte in der Todesursachenstatistik stellen vorläufige Daten dar, die für ausgewählte Merkmale aufbereitet und hier veröffentlicht werden. Die Daten bilden den jeweiligen Bearbeitungsstand zum monatlichen Stichtag ab und können sich durch zeitlich verzögerte Nachmeldungen oder Korrekturen noch verändern. Die Monatsberichte der Todesursachenstatistik stellen damit fortlaufend revidierte und vervollständigte Ergebnisse dar, bei denen es sich grundsätzlich weiterhin um vorläufige Daten handelt.

Ein Fokus liegt dabei auf allen Sterbefällen im Zusammenhang mit COVID-19. Somit enthalten die Monatsberichte sowohl Sterbefälle, in denen COVID-19 die eigentliche Todesursache ist („an“ COVID-19 Gestorbene), als auch nachrichtlich jene Sterbefälle, bei denen COVID-19 eine Begleiterkrankung war („mit“ COVID-19 Gestorbene).

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Todesursachenstatistik**2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/7411bad9524236a4/16cbeb271fc7/MD_23211_2020.pdf)[Archiv](/search-results?q=23211&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-12-m)
