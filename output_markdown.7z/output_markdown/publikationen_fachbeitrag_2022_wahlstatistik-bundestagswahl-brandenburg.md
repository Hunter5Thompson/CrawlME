

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 04.07.2022

#### Repräsentative Wahlstatistik zur Bundestagswahl 2021 in Brandenburg

Über 60 Prozent der Wählenden sind älter als 50 Jahre
-----------------------------------------------------

![iStock.com / cbies](https://download.statistik-berlin-brandenburg.de/b4cb759b6ac111fc/5a0d6ce83420/v/7bcc8c5418df/bevoelkerung-wahlen-germany-politics-concept-german-flag-in-front-of-the-reichstag-picture-id1020839762.jpg "iStock.com / cbies")

**Am 26. September 2021 fand die Wahl zum 20. Deutschen Bundestag statt. Neben den amtlichen Wahlergebnissen ist auch das Wahlverhalten von erheblichem öffentlichem Interesse. Das Amt für Statistik Berlin-Brandenburg wertet die Ergebnisse der repräsentativen Wahlstatistik für Brandenburg aus, informiert die Öffentlichkeit über das Wahlergebnis und -verhalten und analysiert altersspezifische Unterschiede sowie die Struktur der Wählenden und Nichtwählenden.**

###### Statistik erklärt: Repräsentative Wahlstatistik

Im Unterschied zu Daten, die von Meinungs- und Wahlforschungsinstituten gewonnen werden, basieren die **Ergebnisse der repräsentativen Wahlstatistik** auf der Auszählung der Wählerverzeichnisse und der Stimmzettel, die in ausgewählten Wahllokalen, sogenannten Stichprobenwahlbezirken, abgegeben wurden. Die zugrunde liegende Datenbasis ist wesentlich breiter als jene der Wahlbefragungen von Wählenden am Wahltag. Ferner spiegelt sie nicht das angegebene, sondern das tatsächliche Wahlverhalten wider. Die Ergebnisse der repräsentativen Wahlstatistik wertet das Amt für Statistik Berlin-Brandenburg auf Grundlage des [Wahlstatistikgesetzes](http://www.gesetze-im-internet.de/wstatg/) aus.

Die in den Stichprobenwahlbezirken betroffenen Bürgerinnen und Bürger werden beim Versand der Wahlbenachrichtigung und des Wahlscheins oder beim Betreten des Wahllokals über die Teilnahme an der repräsentativen Wahlstatistik in Kenntnis gesetzt.

Die Stichprobe zur repräsentativen Wahlstatistik in Brandenburg umfasst 89 der 2 835 Urnenwahlbezirke, sowie 24 der 865 Briefwahlbezirke. Insgesamt werden 113 der 3 700 Brandenburger Wahlbezirke analysiert. Der Auswahlsatz lag, bezogen auf die Wahlberechtigten, bei 4,5 Prozent und, bezogen auf die Wählenden im Wahllokal, bei 3,8 Prozent. Die Ergebnisse der Stichprobe wurden auf das amtliche Endergebnis hochgerechnet.

**ⓘ Klicken Sie sich hier durch die Kapitel des Artikels.**

* ###### Altersstruktur der Wahlberechtigten
* ###### Briefwahlanteil auf neuem Höchststand
* ###### Wahlbeteiligung im Vergleich zu 2017 leicht gestiegen
* ###### Wahlverhalten der Geschlechter und Generationen im Vergleich
* ###### Stimmensplitting
  
  Bereitschaft, die Stimmen aufzuteilen, nimmt mit zunehmendem Alter ab

#### Altersstruktur der Wahlberechtigten

Wie bereits bei der Vorwahl 2017 machten die älteren Generationen auch bei der Bundestagswahl 2021 den weitaus größten Anteil der Wahlberechtigten aus. Während die Altersgruppen ab 18 Jahre bis unter 50 Jahre lediglich 38,4 Prozent aller Wahlberechtigten ausmachten, stellten die Altersgruppen ab 50 Jahre zusammen 61,6 Prozent der Wahlberechtigten. Besonders stark zeigt sich dieser Unterschied beim Vergleich der ältesten und der jüngsten Wählergruppe. Während lediglich 2,6 Prozent der Wahlberechtigten zwischen 18 und 21 Jahre alt waren, betrug der Anteil der über 70-Jährigen 23,4 Prozent.¹ Gemäß der Annahme, dass verschiedene Altersgruppen ein unterschiedliches Abstimmungsverhalten aufweisen, sind die Interessen der älteren Generation im Vergleich zur jüngeren bei ähnlicher Wahlbeteiligung stärker repräsentiert.

In fast allen Altersgruppen stieg der Anteil der Wahlberechtigten, lediglich bei den 25- bis unter 30-Jährigen, den 45- bis unter 50-Jährigen und den 50- bis unter 60-Jährigen sank der Anteil. Die größten Zugewinne konnten die Altersgruppen 40 bis unter 45 Jahre (+1,3 Prozentpunkte) und 60 bis unter 70 Jahre (+1,4 Prozentpunkte) verzeichnen.

In allen Altersgruppen ist ein ähnlicher Anteil von weiblichen sowie nicht weiblichen Personen² wahlberechtigt, lediglich in der Altersgruppe 70 Jahre und älter besteht eine Differenz von 6 Prozentpunkten zugunsten weiblicher Wahlberechtigter, was auf die höhere Lebenserwartung von Frauen zurückgeführt werden kann.

**Quelle:** Amt für Statistik Berlin-Brandenburg

¹ Dieser Vergleich unterliegt dem Vorbehalt, dass die jüngste Altersgruppe lediglich drei Geburtsjahrgänge umfasst und die älteste nach oben offen ist.  
² Nicht weiblich umfasst Personen; die männlich, divers oder ohne Angabe im Geburtenregister sind.

###### *Autorin und Autor:*

**Dunja Gabriel**studiert an der Freien Universität Berlin Politikwissenschaften und war 2021 Praktikantin im Bereich *Wahlstatistik* des Amtes für Statistik Berlin-Brandenburg.  
**Thomas Lehmann** ist Referent für Wahlstatistik im Referat „*Bevölkerung, Kommunal- und Wahlstatistik*“ und organisiert die Durchführung der repräsentativen Wahlstatistik in Berlin und Brandenburg.

### Kontakte

#### Corinna Brückner

Wahlstatistik

#### Corinna Brückner

Wahlstatistik

* [0331 8173-3172](tel:0331 8173-3172)
* [wahlstatistik@statistik-bbb.de](mailto:wahlstatistik@statistik-bbb.de)
#### Nicole Dombrowski

Fachredaktion

#### Nicole Dombrowski

Fachredaktion

* [zeitschrift@statistik-bbb.de](mailto:zeitschrift@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Aufsätze und Analysen](/search-results?q=tag%3AAufsätze und Analysen)[* Wahlstatistik](/search-results?q=tag%3AWahlstatistik)[* Wahlverhalten](/search-results?q=tag%3AWahlverhalten)[* Bundestagswahl](/search-results?q=tag%3ABundestagswahl)
