

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [MATS-FAQ](/datenportal/mats-hilfe)

Frequently Asked Questions
--------------------------

![](https://download.statistik-berlin-brandenburg.de/9347f106c3327b46/65c9f51ff527/v/5a2eb5b24619/Logo_MATS.png)
###### Was bedeuten leere Felder?

Ist ein Zahlenfeld in einer Tabelle leer, liegen für diese Auswahl keine Zahlen vor, zum Beispiel wenn für ein früheres Berichtsjahr das Merkmal erhoben wurde, aktuell aber nicht mehr, die Zahlen geheim zu halten sind oder erst zu einem späteren Zeitpunkt veröffentlicht werden. Dies ist beispielsweise bei Monatsdaten des laufenden Jahres der Fall.

###### Wie kann ich einen Filter zurücksetzen?

Ist ein Indikator oder ein Berichtsjahr ausgewählt, können Sie diese Auswahl mit einem Mausklick neben die filternde Visualisierung rückgängig machen. Ist das filternde Element eine Liste, wählen Sie einfach wieder "Alle" aus und es werden Ihnen zum Beispiel die Daten für alle Brandenburger Gemeinden, also Brandenburg insgesamt, angezeigt.

###### Wie kann ich die Daten exportieren?

Sie können die Daten in verschiedenen Formaten exportieren. Mit einem Rechtsklick auf die Tabelle oder Visualisierung gelangen Sie in das entsprechende Menü.

###### Warum finde ich keine Daten für die Berliner Bezirke oder Brandenburger Gemeinden?

Es gibt Statistiken, die weder für die Berliner Bezirke noch die Brandenburger Landkreise oder Gemeinden Daten liefern. Dann liegt dafür keine rechtliche Grundlage vor. Beispiel Bevölkerungsfortschreibung: Mit Inkrafttreten des Bevölkerungsstatistikgesetzes am 1. Januar 2014 werden Daten aus der amtlichen Bevölkerungsfortschreibung nur noch für das gesamte Gebiet einer Gemeinde bereitgestellt. Berlin gilt in der amtlichen Statistik sowohl als Land als auch als Gemeinde. Deshalb liegen im Dashboard zum Bevölkerungsstand für die Jahre vor 2014 auch Daten für die Berliner Bezirke vor, für die Jahre danach nicht. Mit der neuen Fortschreibung auf Basis des Zensus 2022 werden wieder Daten für die Berliner Bezirke bereitgestellt.

###### Ich finde bestimmte Daten in den Tabellen nicht oder ich möchte zwei Statistiken vergleichen. An wen kann ich mich wenden?

Haben Sie Anliegen oder Fragen, die über unser Tabellen-Angebot hinausgehen, wenden Sie sich gern an unseren Informationsservice: Tel. 0331 8173 -1777 oder [info@statistik-bbb.de](mailto:info@statistik-bbb.de).

### Nicht gefunden, wonach Sie gesucht haben?

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)


