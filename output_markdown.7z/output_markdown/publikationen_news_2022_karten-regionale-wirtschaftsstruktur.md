

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 22.12.2022

#### Regionale Wirtschaftsstruktur in Berlin und Brandenburg

Interaktive Karten bis auf Kreisebene
-------------------------------------

![Interaktive Karten regionale Wirtschaftsstruktur](https://download.statistik-berlin-brandenburg.de/879b9356e1230b60/b0b3f7479c80/v/72a3012fdb70/Screenshot_Unternehemsregister-1.png "Interaktive Karten regionale Wirtschaftsstruktur")

**Wo gibt es in Deutschland besonders strukturschwache und strukturstarke Regionen? Wie stellen sich die regionalen Disparitäten in der Wirtschaftsstruktur insgesamt dar? Die interaktiven Kreiskarten zu den Niederlassungen und deren Beschäftigten bieten einen schnellen und anschaulichen Überblick über die Wirtschaftsstruktur in Deutschland.**

Mit einem neuen interaktiven Kartenangebot zur regionalen Wirtschaftsstruktur geben die Statistischen Ämter des Bundes und der Länder einen schnellen und anschaulichen Überblick über wirtschaftsstarke und -schwache Regionen in Deutschland.

In den Karten werden die Anzahl der Niederlassungen sowie die Anzahl der abhängig, sozialversicherungspflichtig und geringfügig entlohnt Beschäftigten für das Jahr 2021 untergliedert nach Kreisen und kreisfreien Städten dargestellt.

Das neue kartografische Veröffentlichungsangebot ergänzt die bestehenden tabellarischen Auswertungen des statistischen Unternehmensregisters (URS) in der [Regionaldatenbank](http://www.regionalstatistik.de/genesis/online/statistic/52111 "Externer Link Verlinkung auf Datenbank Unternehmensregister (Öffnet neues Fenster)").

###### Die interaktiven Karten zur regionalen Wirtschaftsstruktur sind über das Statistikportal abrufbar:

[Zu den interaktiven Karten](https://www.statistikportal.de/de/karten/wirtschaftsstruktur)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Unternehmen](/search-results?q=tag%3AUnternehmen)[* Unternehmensregister](/search-results?q=tag%3AUnternehmensregister)[* Niederlassungen](/search-results?q=tag%3ANiederlassungen)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)
