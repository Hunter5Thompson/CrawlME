

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Berlin-Statistik](/kommunalstatistik)
* [Einwohnerbestand Berlin](/kommunalstatistik/einwohnerbestand-berlin)

Einwohnerbestand Berlin
=======================

**Die halbjährlich veröffentlichten Ergebnisse zum Einwohnerbestand enthalten u. a. demografische Informationen zu Geschlecht, Alter, Staatsangehörigkeit und Herkunftsland sowie Religionszugehörigkeit. Abgeleitet werden zudem Daten zum Migrationshintergrund und den Haushaltszusammenhängen.**

Zur Ermittlung des Einwohnerbestandes werden Daten des Einwohnerregisters des Landesamtes für Bürger- und Ordnungsangelegenheiten (LABO) kleinräumig ausgewertet. Methodisch bedingt weichen die Ergebnisse von den Daten des Zensus und der amtlichen Bevölkerungsstatistik ab.

Informationen zum Bevölkerungsstand der amtlichen Bevölkerungsfortschreibung finden Sie [hier](/bevoelkerung/demografie/bevoelkerungsstand).

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

Statistische BerichteBasisdatenZeitreihenRegionaldatenOpen Data

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Einwohnerbestand in Berlin – Grunddaten (AI5-hj)](/a-i-5-hj)[Einwohnerbestand in Berlin – LOR-Planungsräume (AI16-hj)](/a-i-16-hj)[Einwohnerbestand in Berlin – Privathaushalte (AI17-j)](/a-i-17-j)

Zeitreihen
----------

EinwohnerbestandMigrationshintergrundFamilienstand**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/ecbc11dbb5ecb0b2/6a3745d04571/einwohnerbestand-lange-reihe-2023.xlsx)

Basisdaten
----------

GeschlechtAltersgruppenMigrationshintergrundWohnlagenReligion

Regionaldaten
-------------

###### zum 31.12.2023

#### Ausländeranteil in Berlin nach Planungsräumen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Open Data
---------

Aus der Einwohnerregisterstatistik Berlin werden ab 2001 jährlich die Bestandsdaten auf der Ebene der [Lebensweltlich orientierten Räume (LOR)](/meine-region/lebensweltlich-orientierte-raeume-berlin) im Open Data Portal des Landes Berlin bereitgestellt. Daten zum  Migrationshintergrund und zur Wohndauer und -lage für LOR ab 2007 und Bestandsdaten für Ortsteile ab 2011 ergänzen das Angebot der Kommunalstatistik Berlin. Weitere Informationen finden Sie im [OpenData Portal Berlin](https://daten.berlin.de/kategorie/demographie).

  


![](https://download.statistik-berlin-brandenburg.de/010eefcdce7870b9/0f7d0f6dd5d9/v/50f24f6df3b7/schmuckbild-opendata-berlin-black.png)

Haben Sie Fragen?
-----------------

#### Petra Dehniger

Einwohnerbestand, Haushalte, Migrationshintergrund

#### Petra Dehniger

Einwohnerbestand, Haushalte, Migrationshintergrund

* [0331 8173-3508](tel:0331 8173-3508)
* [einwohner@statistik-bbb.de](mailto:einwohner@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![iStock.com / Dmytro Varavin](https://download.statistik-berlin-brandenburg.de/dafdd0edce64b1a7/f48269a57bf6/v/bdbe069a4e98/bevoelkerung-demographie-aerial-interested-crowd-of-people-in-one-place-top-view-from-drone-picture-id1190039899.jpg "iStock.com / Dmytro Varavin")](/141-2024)**Einwohnerregisterstatistik Berlin, Stand: 30.06.2024**[#### Weniger Wachstum als im 1. Halbjahr 2023](/141-2024)

Pressemitteilung Nr. 141 Am 30. Juni 2024 waren im Einwohnerregister Berlin rund 3.886.000 Einwohnerinnen und Einwohner mit Hauptwohnsitz erfasst. Damit ist die Bundeshauptstadt im 1. Halbjahr 2024...

[Zu unseren News](/news)

[* Berlin](/search-results?q=tag%3ABerlin)[* Einwohner](/search-results?q=tag%3AEinwohner)[* Migrationshintergrund](/search-results?q=tag%3AMigrationshintergrund)[* Haushalte](/search-results?q=tag%3AHaushalte)[* Alter](/search-results?q=tag%3AAlter)[* Geschlecht](/search-results?q=tag%3AGeschlecht)[* Staatsangehörigkeit](/search-results?q=tag%3AStaatsangehörigkeit)[* Ausländer](/search-results?q=tag%3AAusländer)[* Familienstand](/search-results?q=tag%3AFamilienstand)
