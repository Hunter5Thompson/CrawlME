

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Menschen mit Behinderung/Eingliederungshilfe](/menschen-mit-behinderung-eingliederungshilfe)
* [Schwerbehinderte Menschen in Berlin und Brandenburg](/k-iii-1-2j)

Schwerbehinderte Menschen
-------------------------

#### 2023, zweijährlich

###### Mit der Erhebung werden schwerbehinderte Menschen mit einem gültigen Ausweis nach persönlichen Merkmalen wie Alter, Geschlecht, Staatsangehörigkeit, Wohnort sowie Art, Ursache und Grad der Behinderung nachgewiesen.

BerlinBrandenburgMethodik
### Berlin

1 Zu Zwecken der Geheimhaltung erfolgt ab dem Berichtsjahr 2021 die Veröffentlichung der Ergebnisse unter Anwendung der 5er-Rundung. Der Insgesamtwert kann von der Summe der Einzelwerte abweichen. Durchschnittswerte werden nicht veröffentlicht, sofern diese auf eine geringe Fallzahl basieren.2 Personen mit der Signierung des Geschlechts "divers" und "ohne Angabe (nach § 22 Abs. 3 PStG)" werden ab 2021 in Geheimhaltungsfällen per Zufallsprinzip dem männlichen oder weiblichen Geschlecht zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ba120d7d3dc0e426/4d978ba413bf/SB_K03-01-00_2023j02_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/d75757197a723a24/e13cd316da96/SB_K03-01-00_2023j02_BE.pdf)

**Schwerbehinderte Menschen in Berlin**

Ende 2023 lebten in Berlin 333.320 schwerbehinderte Menschen, das waren 1,9 % weniger als Ende 2021. Als schwerbehindert gelten Personen, denen ein Grad der Behinderung von 50 und mehr zuerkannt wurde.

Betroffen sind überwiegend ältere Menschen. So waren 59 % der Schwerbehinderten 65 Jahre und älter.

Häufigster Grund für die Anerkennung einer Schwerbehinderung war die Beeinträchtigung der Funktion von inneren Organen bzw. Organsystemen mit 92.915 Fällen. Querschnittslähmung, zerebrale Störungen, geistig-seelische Behinderungen und Suchtkrankheiten stellten mit 91.095 Fällen die zweithäufigste Art der Schwerbehinderung dar.

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Schwerbehinderte Menschen in Brandenburg**

Ende 2023 lebten in Brandenburg 268.260 schwerbehinderte Menschen, das waren 0,2 % mehr als Ende 2021. Als schwerbehindert gelten Personen, denen ein Grad der Behinderung von 50 und mehr zuerkannt wurde.

Betroffen sind überwiegend ältere Menschen. So waren knapp 64 % der Brandenburger Schwerbehinderten 65 Jahre und älter.

Mit 90.665 Fällen war die Beeinträchtigung der Funktion von inneren Organen bzw. Organsystemen häufigster Grund für die Anerkennung einer Schwerbehinderung. Gefolgt von Querschnittslähmung, zerebrale Störungen, geistig-seelische Behinderungen und Suchtkrankheiten mit 62.390 Fällen.

1 Zu Zwecken der Geheimhaltung erfolgt ab dem Berichtsjahr 2021 die Veröffentlichung der Ergebnisse unter Anwendung der 5er-Rundung. Der Insgesamtwert kann von der Summe der Einzelwerte abweichen. Durchschnittswerte werden nicht veröffentlicht, sofern diese auf eine geringe Fallzahl basieren.2 Personen mit der Signierung des Geschlechts "divers" und "ohne Angabe (nach § 22 Abs. 3 PStG)" werden ab 2021 in Geheimhaltungsfällen per Zufallsprinzip dem männlichen oder weiblichen Geschlecht zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/69b1504880d2f6d0/7cd55195e36d/SB_K03-01-00_2023j02_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/683c4f8a5a914291/de1ad48057ad/SB_K03-01-00_2023j02_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Mit der Erhebung werden die schwerbehinderten Menschen mit einem gültigen Ausweis nach persönlichen Merkmalen wie Alter, Geschlecht, Staatsangehörigkeit, Wohnort sowie Art, Ursache und Grad der Behinderung nachgewiesen.

Schwerbehinderte Menschen im Sinne des § 2 Absatz 2 SGB IX sind Personen mit einem Grad der Behinderung von wenigstens 50. Sie müssen ihren Wohnsitz bzw. gewöhnlichen Aufenthalt in Deutschland haben oder hier beschäftigt sein. In der Erhebung sind nur Schwerbehinderte mit ausgehändigtem und gültigem Ausweis zu zählen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der schwerbehinderten Menschen**Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/54180614c3cc7b87/b70f3c7b1125/MD_22711_2023.pdf)[Archiv](/search-results?q=22711&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-iii-1-2j)
