

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

Jede Stelle zählt
=================

#### Karriere beim Amt für Statistik Berlin-Brandenburg

[Ab sofortInitiativbewerbung](/initiativbewerbung)[Alle offenen Stellen](/aktuelle-stellenausschreibungen)VorteileStimmenEinstiegsmöglichkeitenStatistikKontakt[Stellenangebote](/aktuelle-stellenausschreibungen)
#### Vorteile

**Worauf Sie zählen können**
----------------------------

#### **Was wir tun.**

Wir sammeln Daten, werten sie aus, bereiten sie auf und stellen sie der Allgemeinheit zur Verfügung. Damit liefern wir Planungssicherheit für das Leben in unserer Gesellschaft – für heute, für morgen und für übermorgen.

#### **Wen wir suchen.**

Wenn Sie diese spannende und wichtige Aufgabe anspricht und Sie sich mit Zahlen und Fakten identifizieren können und einen fairen und vertrauensvollen Arbeitgeber suchen, dann sind Sie bei uns genau richtig.

#### **Was wir Ihnen bieten.**

  

Vergütung nach dem [Tarifvertrag](https://www.tdl-online.de/tv-l/tarifvertrag.html) für den öffentlichen Dienst der Länder (TV-L)

Bei Vorliegen der Voraussetzungen zusätzliche Sonderzahlung zum Jahresende

Separate Zusatzversorgung als Leistung der betrieblichen Altersvorsorge [(VBL)](https://www.vbl.de/)

Vermögenswirksame Leistungen (optional)

30 Tage Urlaub (bei 5-Tage-Woche)

Wir unterstützen Mobilität mit Jobticket und Dienstfahrrädern (Cottbus).

#### **Weitere Vorteile.**

  
#### #familien**gerecht**

Zertifizierung [audit berufundfamilie](/audit-beruf-und-familie)

Familien- und Lebensphasen **bewusste Personalpolitik**

**Flexible Arbeitszeiten** und mobiles Arbeiten

Kurzfristige **Betreuung von Kindern** auf der Arbeit möglich

**Mitnahme von Hunden** ins Büro grundsätzlich möglich

#### #viel**fältig**

Unterzeichnung der [Charta der Vielfalt](/charta-der-vielfalt)
Berufliche **Gleichstellung** von Frauen und Männern
**100 % Wertschätzung** – unabhängig von Geschlecht, Nationalität, ethnischer und sozialer Herkunft, Religion und Weltanschauung, Behinderung, Alter, sexueller Orientierung und Identität

**Barrierefreiheit**

#### #gesundheits**fördernd**

**Gesundheitsfördernde Maßnahmen** an allen Standorten

**1 Stunde/Woche** für Ihre Gesundheit

**Trinkwasserspender** an allen Standorten

Betriebliches **Eingliederungsmanagement** (BEM)

**Ergonomieberatung,** leidensgerechte Arbeitsplatzausstattung

#### #zukunfts**sicher**

Individuelle **Fort- und Weiterbildungsprogramme**

Sachbearbeiter-Lehrgang (Qualifizierung für gehobenen Dienst)

**Nachwuchskräfteförderung** (Ausbildung/Duales Studium)

Bezahlte **Freistellung für Bildungsurlaub**

**Wissensmanagement** im eigenen Wiki

Charta der Vielfalt
-------------------

Unser Ziel ist es, ein Arbeitsumfeld zu schaffen, das frei von Vorurteilen ist.  Das Amt für Statistik Berlin-Brandenburg…

[Mehr erfahren](/charta-der-vielfalt)

Audit berufundfamilie
---------------------

Das Amt für Statistik steht für familien- und lebensphasenbewusste Personalpolitik. Das Audit berufundfamilie unterstützt Arbeit...

[Mehr erfahren](/audit-beruf-und-familie)![](https://download.statistik-berlin-brandenburg.de/f3dcea26812f352f/b83eaa3765c4/v/c221c079c2f6/karriere-logos.png)
#### 3 Standorte, 2 Länder, 1 Amt – das sind unsere Standorte**.**

  [Zu unseren Standorten](/kontakt)
#### Stimmen

**Was für mich zählt**
----------------------

Lernen Sie Ihre neuen Kolleginnen und Kollegen besser kennen. Erfahren
Sie hier, wie vielfältig die Arbeit beim Amt für Statistik
Berlin-Brandenburg ist, warum es dabei nicht immer nur um Zahlen geht
und was Zusammenhalt für uns bedeutet.

![](https://download.statistik-berlin-brandenburg.de/0b73b1224313099b/0a8d5d14c5c6/v/01ce4d8c1a19/Kerstan_Tom_Nahaufnahme.jpg)![](https://download.statistik-berlin-brandenburg.de/ae0cd9858a7b8ca0/32fc35bb30d4/v/123d4df3d9bb/Wagenknecht_Lars_Foto.PNG)![](https://download.statistik-berlin-brandenburg.de/8a39bf8a8afa3f38/e0f203764101/v/fc4321952e13/Staehle_Sylvia_Foto2.png)![](https://download.statistik-berlin-brandenburg.de/68b6017a8791513f/9aead192cf82/v/c99a8ae77cf4/Joerger_Franziska_Foto2.png)![](https://download.statistik-berlin-brandenburg.de/79d2a72415b8230d/924eae1869fa/v/2b2cc6f55be8/albat.jpeg)![](https://download.statistik-berlin-brandenburg.de/40705ebead7f2811/7acd397097e6/v/282cc3f390e3/Lueke_Monique_Foto2.jpeg)
#### Einstiegsmöglichkeiten

**Damit können Sie rechnen**
----------------------------

Unsere Stellenausschreibungen beinhalten immer die Information, welche formale Voraussetzung für die Besetzung einer Stelle vorliegen muss. Daraus ergeben sich folgende Einstiegsmöglichkeiten.

#### Ausbildung & Studium

![](https://download.statistik-berlin-brandenburg.de/144442c386474ed0/fff6410193f4/v/4549ff8044f7/id1194859007-schmuckbild-karriere.jpg)

**Formale Voraussetzung:**  
Erfolgreich abgeschlossenes Abitur oder Fachhochschulreife

**Ausbildung:**Fachangestellte (m/w/d) für Markt- und Sozialforschung (Anstellung, Vergütung und Sozialleistungen richten sich nach [TVA-L BBiG](https://www.tdl-online.de/tarifvertraege/ausbildung))

**Studiengang:** Wirtschaftsinformatik (in Kooperation mit der HWR Berlin)

#### Mittlerer Dienst

![](https://download.statistik-berlin-brandenburg.de/9e37f018fdf1ebcb/e31f5fe31a03/v/a19088ccdd9e/id693665302-schmuckbild-karriere.jpg)

**Formale Voraussetzung:** Erfolgreich abgeschlossene Berufsausbildung

**Stellenbezeichnung:**z. B. Mitarbeiter, Assistenz (m/w/d)

**Verdienst**: je nach Tätigkeitsmerkmalen Entgeltgruppe E6 bis E9a TV-L

#### Gehobener Dienst

![](https://download.statistik-berlin-brandenburg.de/d040ed743438ff56/6a3614ac91bc/v/0d7b4e9a69fd/id1227527658-schmuckbild-karriere.jpg)

**Formale Voraussetzung:**  
Erfolgreich abgeschlossenes Fachhochschul- bzw. Bachelorstudium

**Stellenbezeichnungen:**z. B. Sachbearbeiter, Sachgebietsleiter (m/w/d)

**Verdienst:**Je nach Tätigkeitsmerkmalen Entgeltgruppe E9b bis E12 TV-L

#### Höherer Dienst

![](https://download.statistik-berlin-brandenburg.de/23383881513f391f/56e44b3cb344/v/30bf7ba4a06a/id603992132-schmuckbild-karriere.jpg)

**Formale Voraussetzung:**  
Erfolgreich abgeschlossenes Universitäts- bzw. Masterstudium

**Stellenbezeichnungen:**z. B. Referent, Referatsleiter, Abteilungsleiter (m/w/d)

**Verdienst:**Je nach Tätigkeitsmerkmalen Entgeltgruppe ab E13 TV-L

#### Statistiken

Wir haben mal nachgerechnet
---------------------------

Sie wollen mehr wissen über das Amt für Statistik Berlin-Brandenburg   
und sind auf der Suche nach verlässlichen Informationen und knallharten Fakten? Dann sind Sie hier genau richtig. Wir lieben Statistiken – und haben uns deshalb selbst unter die Lupe genommen. **Das Amt in Zahlen.** 

###### Beschäftigte 2023

#### nach Altersgruppen

 Stand: 30.06.2023**Quelle:** Amt für Statistik Berlin-Brandenburg
###### Beschäftigte 2023

#### nach Standort

 Stand: 30.06.2023**Quelle:** Amt für Statistik Berlin-Brandenburg
###### Beschäftigte 2023

#### Durchschnittsalter

 Stand: 30.06.2023**Quelle:** Amt für Statistik Berlin-Brandenburg![](https://download.statistik-berlin-brandenburg.de/851736e2eb41fb99/bfb4432893e6/v/fc0cf0835532/karriere-verhaeltnis.png)![](https://download.statistik-berlin-brandenburg.de/edbf8aaa1008cadb/c9bc190a2862/v/50ba7050c95d/karriere-beeintraechtigte.png)![](https://download.statistik-berlin-brandenburg.de/2355de3233ab2c3d/7b9dd2245796/v/53d1fd767b76/karriere-brillen.png)![](https://download.statistik-berlin-brandenburg.de/caf43f11ac6e50bb/b372df40671a/v/0d602641f34a/karriere-kinder.png)![](https://download.statistik-berlin-brandenburg.de/cfc1b264b9203ecd/cc9f7c130f56/v/8272c7515385/karriere-bewegung.png)![](https://download.statistik-berlin-brandenburg.de/56e93204a2e9ddc8/7cda3bf1ab73/v/b20c987ca806/karriere-hunde.png)

Stand: 2021, Quelle: Amt für Statistik Berlin-Brandenburg

### Besuchen Sie uns auch auf folgenden Portalen:

[![](https://download.statistik-berlin-brandenburg.de/9e6418669d9b26b4/cdce7f130c88/v/cea9f737f75c/kununu.png)](https://www.kununu.com/de/amt-fuer-statistik-berlin-brandenburg1/kommentare)[![](https://download.statistik-berlin-brandenburg.de/bb69aaa0f8bb5b8e/aaf9ddc4d7b0/v/a7e0be0fd59e/logo-linkedin.png)](https://www.linkedin.com/company/statistik-berlin-brandenburg/)
#### Kontakt

**Wir zählen auf Sie**
----------------------

Wir haben Ihr Interesse geweckt? Dann freuen wir uns auf Ihre aussagekräftige Bewerbung. Sollten Sie noch offene Fragen haben oder mehr Informationen benötigen, melden Sie sich gerne direkt bei uns.

RECRUITING

[**bewerbung****@statistik-bbb.de**](mailto:bewerbung@statistik-bbb.de)

Christina Rambow  
Tel. 0331 8173-1719

![](https://download.statistik-berlin-brandenburg.de/e6932197de8c8dd5/95cb0b2034e6/v/8e283cb43775/foto-christina-rambow.jpg)
