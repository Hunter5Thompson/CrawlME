

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Bauen und Wohnungen](/bauen-und-wohnungen)
* [Baugenehmigungen in Berlin und Brandenburg](/f-ii-1-m)

Baugenehmigungen
----------------

#### Oktober 2024, monatlich

###### Die Statistik derBaugenehmigungen liefert Ergebnisse über die Struktur, den Umfang und die Entwicklung der Bautätigkeit im Hochbau und ist somit ein wichtiger Indikator für die Beurteilung der Wirtschaftsentwicklung im Bausektor. Darüber hinaus stellt sie Daten z.B. für die Planung in den Gebietskörperschaften, für Wirtschaft, Forschung und den Städtebau bereit.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/6a610e1dbeeaffa5/f3d2d232cf39/SB_F02-01-00_2024m10_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/96367bc19b432fb9/11272660e0a5/SB_F02-01-00_2024m10_BE.pdf)

**Baugenehmigungen in Berlin**

Von Januar bis Oktober 2024 wurden 8.496 genehmigte Wohnungen gemeldet. Das sind 35,8 % weniger als im Vorjahreszeitraum. 7.545 der Wohnungen bzw. 88,8 % werden in neuen Wohn- und Nichtwohngebäuden entstehen.

1.761 Genehmigungen wurden für Bauvorhaben im Wohn- und Nichtwohnbau gemeldet. 189 Genehmigungen (Vorjahreszeitraum: 183) betreffen den Neubau gewerblicher Bauten. Die veranschlagten Kosten aller genehmigten Bauvorhaben im Wohn- und Nichtwohnbau betragen 4.298,5 Millionen EUR, 16,3 % weniger als im Vergleichszeitraum des Vorjahres.

In Ein- und Zweifamilienhäusern sind 503 Wohnungen geplant (–23,6 %), in Mehrfamilienhäusern 6.986 (–35,2 %). Durch geplante Baumaßnahmen an bestehenden Gebäuden, z. B. Nutzungsänderungen und Dachgeschossausbauten, werden weitere 951 Wohnungen (Vorjahr: 1.240) zur Verfügung stehen.

### Kontakt

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Baugenehmigungen in Brandenburg**

7.961 genehmigte Wohnungen wurden von Januar bis Oktober 2024 gemeldet. Das sind 17,0 % weniger als im Vorjahreszeitraum. In neuen Wohn- und Nichtwohngebäuden werden 6.227 der Wohnungen entstehen (–27,2 %).

Es wurden 4.631 Genehmigungen für Bauvorhaben im Wohn- und Nichtwohnbau gemeldet. 607 Genehmigungen (Vorjahreszeitraum: 613) entfallen auf den Neubau gewerblicher Bauten. Die veranschlagten Kosten aller genehmigten Bauvorhaben im Wohn- und Nichtwohnbau betragen 3.176,8 Millionen EUR, 9,8 % weniger als im Vorjahreszeitraum.

2.558 Wohnungen (–28,3 %) sind in Ein- und Zweifamilienhäusern und 3.529 (–27,9 %) in Mehrfamilienhäusern geplant. Durch geplante Baumaßnahmen an bestehenden Gebäuden, z. B. Nutzungsänderungen und Dachgeschossausbauten, werden weitere 1.734 Wohnungen (Vorjahr: 1.043) zur Verfügung stehen.

Von den 6.087 genehmigten Wohnungen in neuen Wohngebäuden sind 2.662 im Weiteren Metropolenraum und 3.425 im Berliner Umland geplant.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a76a00e7d18b2190/22c30f2bd341/SB_F02-01-00_2024m10_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/f17539f8175160fa/2cddc0665b96/SB_F02-01-00_2024m10_BB.pdf)
### Kontakt

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Gegenstand der Bautätigkeitsstatistiken sind Baugenehmigungen und Baufertigstellungen im Hochbau, der Bauüberhang am Jahresende und Bauabgänge von Gebäuden und Gebäudeteilen im Hochbau. Die Baugenehmigungsstatistik wird monatlich und jährlich aufbereitet, die anderen Statistiken jährlich. Auch die Fortschreibung des Wohngebäude- und Wohnungsbestandes erfolgt jährlich.

Im Rahmen der Bautätigkeitsstatistiken werden die gemäß Landesbauordnungen (Berlin und Brandenburg unterschiedlich) genehmigungs- und zustimmungsbedürftigen sowie kenntnisgabe- oder anzeigepflichtigen oder einem Genehmigungsfreistellungsverfahren unterliegenden Bauvorhaben erfasst, bei denen Wohn- oder Nutzraum geschaffen bzw. verändert wird. Das geschieht überwiegend durch Neubau, aber zum Teil auch durch Baumaßnahmen an bestehenden Gebäuden, wie z. B. den Ausbau von Dachgeschossen.

Die Erhebung wird monatlich als Totalerhebung durchgeführt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Baugenehmigungen**  
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/29c99b37174359e3/5d2f58270aba/MD_31111_2023.pdf)[Archiv](/search-results?q=MD_31111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/f-ii-1-m)
