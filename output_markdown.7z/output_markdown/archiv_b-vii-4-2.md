

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Berlin](/wahlen-berlin)
* [Volksentscheide in Berlin](/volksentscheide-berlin)
* [B VII 4-2](/archiv/b-vii-4-2)

Archiv: Statistischer Bericht
=============================

#### Volksentscheide Berlin (B VII 4-2, unregelmäßig)


