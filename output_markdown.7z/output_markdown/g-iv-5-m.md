

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Umsatz und Beschäftigung im Gastgewerbe in Berlin und Brandenburg – Messzahlen –](/g-iv-5-m)

Umsatz und Beschäftigung im Gastgewerbe– Messzahlen
---------------------------------------------------

#### September 2024, monatlich

###### Die monatlichen Erhebungen im Gastgewerbe liefern kurzfristige Informationen zur konjunkturellen Entwicklung dieser Bereiche. Dazu zählen Daten zu Umsatz und tätigen Personen aufgegliedert nach Wirtschaftsbereichen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/b79e8af5b623a8ef/bdd3c08dc621/SB_G04-05-00_2024m09_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/bb53a81c76023dcf/db09fbbf06e5/SB_G04-05-00_2024m09_BE.pdf)

**Leichter Umsatzrückgang trotz Wachstum im Beherbergungssektor**

Im September 2024 verzeichnete das Berliner Gastgewerbe insgesamt einen realen (preisbereinigten) Umsatzrückgang von 0,2 % im Vergleich zum Vorjahresmonat. Diese Entwicklung wurde stark von den gegensätzlichen Ergebnissen in den beiden Teilbranchen beeinflusst. Während das Beherbergungsgewerbe einen deutlichen Umsatzzuwachs von 11,3 % meldete, musste die Gastronomie einen Rückgang von 8,8 % hinnehmen.

Die Zahl der Beschäftigten im Berliner Gastgewerbe sank insgesamt um 2,9 %. Im Beherbergungsgewerbe stieg die Beschäftigtenzahl leicht um 0,5 %, während die Gastronomie einen Rückgang von 3,8 % zu verzeichnen hatte.

### Kontakt

#### Robby Trinks

Gastgewerbe Konjunktur

#### Robby Trinks

Gastgewerbe Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Umsatzrückgang in der Gastronomie setzt sich fort, Beherbergung stabil**

Im September 2024 verzeichnete das Gastgewerbe in Brandenburg einen realen (preisbereinigten) Umsatzrückgang von 6,3 % im Vergleich zum Vorjahresmonat. Dabei entwickelten sich die beiden Teilbereiche des Gastgewerbes unterschiedlich. Im Beherbergungsgewerbe fiel der Umsatz mit einem Minus von 0,7 % nur leicht geringer aus als im Vorjahr, während die Gastronomie einen deutlichen Rückgang von 10,1 % hinnehmen musste.

Parallel dazu sank die Zahl der Beschäftigten im Gastgewerbe insgesamt um 8,4 %. Im Beherbergungsgewerbe ging die Beschäftigtenzahl um 4,8 % zurück, während die Gastronomie einen Rückgang von 9,9 % zu verzeichnen hatte.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/95887eed96e5f2ec/91b34fc8bed1/SB_G04-05-00_2024m09_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/960eeb2f754984aa/b22bc52d6118/SB_G04-05-00_2024m09_BB.pdf)
### Kontakt

#### Robby Trinks

Gastgewerbe Konjunktur

#### Robby Trinks

Gastgewerbe Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die monatlichen Erhebungen im Gastgewerbe liefern kurzfristige Informationen zur Beurteilung der konjunkturellen Entwicklung dieses Wirtschaftsbereiches. Erhoben werden der Nettoumsatz (ohne Umsatzsteuer) und die Zahl der tätigen Personen.

Alle Messzahlen und Veränderungsraten sind, soweit sie Erhebungszeiträume des aktuellen Jahres und des Vorjahres betreffen, vorläufig und werden monatlich rückwirkend durch nachträglich eingehende Meldungen und Korrekturen der in die Berichtskreise einbezogenen Unternehmen aktualisiert.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatsstatistik im Gastgewerbe**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/d58a43b9e9ee8ead/cdb5c3d361b2/MD_45213_2024.pdf)[Archiv](/search-results?q=MD_45213&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-iv-5-m)
