

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Zensus](/bevoelkerung/zensus)
* [Zensus 2011](/bevoelkerung/zensus/zensus_2011)
* [Ergebnisdokumentation Berlin](/bevoelkerung/zensus/zensus_2011/ergebnisse-berlin)

Ergebnisdokumentation Berlin
----------------------------

#### 9. Mai 2011

###### Die Gemeindeblätter präsentierendie Ergebnisse des Zensus 2011 für Berlin und seine Bezirke zu den Themen Bevölkerung und Haushalte, Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte am 9. Mai 2011 nach Abschluss der Datenaufbereitung.

**ⓘ Sie werden über den jeweiligen Button zu den Gemeindeblättern im PDF- und Excel-Format in der Statistischen Bibliothek weitergeleitet.**

### Gemeindeblätter für Berlin

| Land/Bezirk | Bevölkerung und Haushalte am 9. Mai 2011 | Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte am 9. Mai 2011 |  |
| --- | --- | --- | --- |
| **Land Berlin** |  |  |  |
| Mitte |  |  |  |
| Friedrichshain- Kreuzberg |  |  |  |
| Pankow |  |  |  |
| Charlottenburg-Wilmersdorf |  |  |  |
| Spandau |  |  |  |
| Steglitz-Zehlendorf |  |  |  |
| Tempelhof-Schöneberg |  |  |  |
| Neukölln |  |  |  |
| Treptow-Köpenick |  |  |  |
| Marzahn-Hellersdorf |  |  |  |
| Lichtenberg |  |  |  |
| Reinickendorf |  |  |  |
|  |  |

#### Hinweis zur Geheimhaltung

Die Geheimhaltung wird durch das Verfahren „Sichere Anonymisierung für Einzeldaten“ (SAFE) sichergestellt. Weitere Informationen zur Geheimhaltung beim Zensus erhalten Sie auf der Zensus-Seite [www.zensus2022.de](https://www.zensus2022.de).

[Hier gelangen Sie zu den Gemeindeblättern für Brandenburg.](/bevoelkerung/zensus/zensus_2011/ergebnisse-brandenburg)
### Kontakt

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)

[* Zensus 2011](/search-results?q=tag%3AZensus 2011)[* Gemeindeblätter](/search-results?q=tag%3AGemeindeblätter)[* Gebäude](/search-results?q=tag%3AGebäude)[* Wohnungen](/search-results?q=tag%3AWohnungen)[* Bevölkerung](/search-results?q=tag%3ABevölkerung)[* Haushalte](/search-results?q=tag%3AHaushalte)[* Bezirke](/search-results?q=tag%3ABezirke)
