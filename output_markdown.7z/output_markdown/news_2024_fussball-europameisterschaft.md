

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 04.07.2024

#### Zu den Spielen der Fußball-Europameisterschaft 2024 in Berlin

Wird’s laut in meinem Kiez?
---------------------------

![Fussball-Fans beim Jubeln in einem Wohnzimmer](https://download.statistik-berlin-brandenburg.de/34373f395a5df526/72a06c9000cd/v/32f583b789d6/gesellschaft-menschen-fussball-iStock-1250480649.jpg "Fussball-Fans beim Jubeln in einem Wohnzimmer")

**Berlin wird während der Fußball-Europameisterschaft 2024 zum Schauplatz spannender Begegnungen. Allein in der Gruppenphase finden drei Spiele bei uns in der Hauptstadt statt. Fangesänge werden dann nicht nur durchs Olympiastadion schallen.****In fast allen Nachbarschaften leben zahlreiche Menschen mit den Nationalitäten der teilnehmenden Teams. Wir schauen genau auf die Zahlen und zeigen, in welchen Ecken es vielleicht etwas lauter werden könnte**–**und wo man noch einen Flecken Ruhe findet.**

*Hinweis aus der Redaktion: Der Beitrag wird mit jeden weiteren feststehenden Spielnationen aktualisiert.*

### 6. Juli – Niederlande : Türkei

Am Samstag trifft die Türkei auf die Niederlande. Setzt man auf unsere Statistik, ist die Türkei mit 191.397 Personen in Berlin, die türkische Wurzeln haben, ungeschlagen. Die Niederlande dagegen zählt nur knapp über 10.000 Personen (Karte siehe unten). Ballungszentren finden wir in den Stadtteilen Kreuzberg, Neukölln, Reinickendorf und Wedding – die Top-Gegenden darunter Brunnenstraße (3.289 Personen), Prinzenstraße (3.100), Gropiusstadt Süd-Ost (2.361). Auf dem Olympiagelände wohnen 9 türkische Personen – laut wird es hier wohl trotzdem.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Türkei-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

### 29. Juni – Schweiz : Italien

Im Achtelfinale in Berlin stehen sich die Schweiz und Italien gegenüber. Unter den hier betrachteten Nationen ist die Schweiz mit 10.974 Personen bisher die kleinste Gruppe. Die meisten Personen mit schweizerischem Migrationshintergrund in Berlin leben in Mitte am Arkonaplatz (173) sowie am Teutoburger Platz (137), auch der Chamissokiez (132) in Kreuzberg ist vorne mit dabei. Hier zeigt sich ein ganz ähnliches Bild wie bei den Nationen Spanien, Österreich, Niederlande und – Achtung Spoiler – Italien. Auch in den Ceciliengärten in Tempelhof-Schöneberg wird man voraussichtlich den ein oder anderen Jubelruf mehr hören können. 91 Personen mit schweizerischen Wurzeln leben hier.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Schweiz-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Diese Wohngegend ist auch unter Personen mit italienischem Migrationshintergrund nicht unbeliebt – 176 Personen sind in den Ceciliengärten gemeldet. Top-Gegenden sind erneut der Arkonaplatz (418), der Viktoriapark in Kreuzberg (361), der Falkplatz am Mauerpark im Prenzlauer Berg (337) und umliegende Kieze. Zusammenfeiern ist also auf jeden Fall drin.

Mit 43.901 Personen ist Italien stärker in Berlin vertreten als die Schweiz. Beide Nationen könnten die 74.475 Plätze im Olympiastadion zu 74 % belegen. Wer sich übrigens fragt, wie unsere Einwohnerregisterstatistik den Migrationshintergrund definiert: „Ausländer wie auch Deutsche – mit Geburtsland außerhalb Deutschlands oder mit zweiter Staatsangehörigkeit oder mit Einbürgerungskennzeichen oder mit Optionskennzeichen sowie Personen im Alter unter 18 Jahren ohne eigene Migrationsmerkmale aber mit Migrationshintergrund zumindest eines Elternteils, wenn die Person an der Adresse der Eltern/des Elternteils gemeldet ist.“

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Italien-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

### 15. Juni – Spanien : Kroatien

Anpfiff für das erste Spiel in Berlin ist am 15. Juni um 18 Uhr für Spanien und Kroatien. Insgesamt leben in Berlin 17.797 Menschen mit kroatischem und 21.543 mit spanischem Migrationshintergrund. Würden beide Gruppen gemeinschaftlich an dem Tag das Berliner Olympiastadion besuchen, wäre es zu 53 % belegt. Es bietet genau 74.475 Plätze – genug Luft nach oben für Fans von außerhalb also.

Blickt man auf die einzelnen Ortsteile (bei uns [Planungsräume](/meine-region/lebensweltlich-orientierte-raeume-berlin)) zeigt sich, dass viele Personen mit spanischem Background innerhalb des Berliner Rings wohnen, die meisten am Arkonaplatz im Bezirk Mitte (233 gemeldete Personen). Auch in der Gegend Weberwiese, Boxhagener Platz und Revaler Straße könnten sich potenziell mehr Menschen über einen Sieg der spanischen Mannschaft freuen.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Spanien-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Personen mit kroatischem Migrationshintergrund wohnen tendenziell vermehrt in westlichen Teilen Berlins. Eine Häufung findet sich im Bezirk Tempelhof-Schöneberg, insbesondere in den Ecken Wittekindstraße (140 gemeldete Personen) und Eisenacher Straße (138). Auch in Spandau, unweit vom Olympiastadion, wohnen überdurchschnittlich viele potenzielle Kroatien-Fans. Insgesamt werden im Osten der Stadt wahrscheinlich weniger kroatische Fangesänge zu hören sein.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Kroatien-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

### 21. Juni – Polen : Österreich

Das zweite Spiel startet ebenfalls um 18 Uhr. Am längsten Tag des Jahres treffen Polen und Österreich aufeinander. Unter den Gruppen, die wir hier betrachten, zählt Polen mit Abstand (108.563 Personen) zu den größten. Sie allein könnte das Olympiastadion füllen. Menschen mit polnischem Migrationshintergrund wohnen über ganz Berlin verteilt. In vielen Ortsteilen leben mehr als 200 Personen. In den Nachbarschaften um die Gartenfelder Straße und die Westerwaldstraße in Spandau sowie in Jungfernheide/Plötzensee sind es sogar jeweils über 900. Die polnische Flagge könnte also oft zu sehen sein.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Polen-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

17.417 Personen mit österreichischen Wurzeln leben in Berlin. So kommen hier auf jede oder jeden dieser Gruppe sechs Personen mit polnischen Wurzeln. Stärker vertreten ist die Gruppe der Österreicher in Mitte rund um die Oranienburger Straße (167 Einwohnende), aber auch in Kreuzbeug im Chamissokiez (163) und im Graefekiez Nord (121).

Wer tendenziell lieber österreichischen als polnischen Fangesängen lauschen möchte, der sollte definitiv einen Spaziergang durch Grunewald und Wannsee unternehmen. Und wer mit Fußball nichts zu tun haben möchte, dem empfehlen wir einen Ausflug in den Blankenburger Süden. Hier, zwischen Heinersdorf und Blankenburg, leben kaum Menschen, ein neues Startquartier ist jedoch aktuell in Planung.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Österreich-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

### 25. Juni – Niederlande : Österreich

Am 25. Juni startet um 18 Uhr das letzte Gruppenspiel in der Hauptstadt. Österreich spielt gegen die Niederlande. Diese Nation ist in Berlin mit 10.140 Einwohnenden vertreten. Beide Gruppen zusammen würden das Olympiastadion zu 37 % füllen. Hier zeigt sich eine Ansammlung an niederländischen Mitbürgerinnen und Mitbürgern innerhalb des Berliner Rings. Rund um den Arkonaplatz und die Oranienburger Straße oder auch im Chamissokiez ist die Wahrscheinlichkeit hoch, dass die Fans aus Österreich und den Niederlanden die Spiele gemeinsam verfolgen. Insgesamt könnte es jedoch etwas ruhiger werden als bei den vorherigen Spielen.

###### Einwohnende am 31.12.2023 in Berlin am Ort der Hauptwohnung

#### Potenzielle Niederlande-Fans

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Unterschätzen sollte man die Niederlande jedoch nicht. Blickt man auf die Gästezahlen für Berlin aus der Tourismus-Statistik zeigt sich nämlich ein anderes Bild: Unter den ausgewählten Gruppen kamen im Jahr 2023 die meisten Gäste aus den Niederlanden nach Berlin (300.621). Möglicherweise lässt sich aus der Reisebereitschaft auch eine breite Unterstützung aus dem Ausland an diesem Spieltag ableiten. Auch für Menschen aus Spanien, Polen und Italien ist Berlin ein beliebtes Reiseziel. Lediglich Menschen aus Kroatien zieht es weniger in die Stadt. Es kamen weniger Personen (12.293) zu Besuch als es hier kroatische Einwohnende gibt.

\* Melderechtlich registrierte Einwohnerinnen und Einwohner mit Migrationshintergrund am Ort der Hauptwohnung in Berlin am 31.12.2023 nach ausgewählten Herkunftsgebieten.**Quelle:** Amt für Statistik Berlin-Brandenburg
### 

###### Diese Spiele finden außerdem in Berlin statt (den Beitrag erweitern wir jeweils zu gegebener Zeit um entsprechende Karten).

Sonntag, 14.07.2024 – Finale

###### Sie wollen wissen, in welchem Planungsraum (LOR) Sie wohnen? Unsere Adressauskunft hilft Ihnen weiter.

[Zur Adressauskunft Berlin](/adressauskunft)
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Fußball](/search-results?q=tag%3AFußball)[* Kommunalstatistik](/search-results?q=tag%3AKommunalstatistik)[* Migrationshintergrund](/search-results?q=tag%3AMigrationshintergrund)
