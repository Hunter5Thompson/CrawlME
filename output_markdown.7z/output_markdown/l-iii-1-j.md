

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen in Berlin und Brandenburg](/l-iii-1-j)

Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen
-----------------------------------------------------------------------------------------------------------------------

#### 2023, jährlich

###### Die Daten über die Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen in Berlin und Brandenburg liefern ein Abbild der finanziellen Lage der öffentlichen Haushalte in Berlin und Brandenburg.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/50d2a06ca4a48806/5049189809fd/SB_L03-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/91e7ef3df77cec54/769cb1199ff6/SB_L03-01-00_2023j01_BE.pdf)

**Anstieg bei den Schulden**

Für den Landeshaushalt Berlin beliefen sich die Schulden Ende 2023 auf 65,3 Mrd. EUR. 2022 waren es 64,1 Mrd. EUR. Den größten prozentualen Anteil mit 69,2 % hatten die Wertpapierschulden. Sie lagen bei 45,2 Mrd. EUR.

Die Schulden der öffentlichen Fonds, Einrichtungen und Unternehmen des Staatssektors in Berlin betrugen am 31.12.2023 insgesamt 3,8 Mrd. EUR.

Bei den sonstigen öffentlichen bestimmten Fonds, Einrichtungen und Unternehmen beliefen sich die Schulden auf 29,9 Mrd. EUR.

### Kontakt

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Schuldenstand gestiegen**

Der Schuldenstand des öffentlichen Gesamthaushalts im Land Brandenburg belief sich am 31.12.2023 auf 21,7 Mrd. EUR. Gegenüber dem Vorjahr erhöhte er sich um 3,8 %. Zum öffentlichen Gesamthaushalt zählen die Kernhaushalte und die Fonds, Einrichtungen und Unternehmen des Staatssektors des Landes, der kommunalen Haushalte und der Träger der Sozialversicherungen.

Die Schulden des Kernhaushaltes des Landes betrugen 18,9 Mrd. EUR und die der Gemeinden und Gemeindeverbände 1,1 Mrd. EUR.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/43af4ec04cd3c09c/01cf3b23dcbf/SB_L03-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/62d772a14140fe9e/e12fbdcdac63/SB_L03-01-00_2023j01_BB.pdf)
### Kontakt

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik über die Schulden der öffentlichen Haushalte, ist eine jährliche Totalerhebung und berichtet über den Stand der Schulden, Schuldenaufnahmen, Schuldentilgungen und sonstigen Schuldenbewegungen des Berichtsjahres.

Die Erhebungseinheiten sind die staatlichen (Bund, Länder) und kommunalen Haushalte (Gemeinden, Gemeindeverbände), die Träger der Sozialversicherung und die Bundesagentur für Arbeit sowie Fonds, Einrichtungen und Unternehmen (FEU), die von den öffentlichen Haushalten (auch von diesen gemeinsam) bestimmt sind.

Für die Kernhaushalte und die Fonds, Einrichtungen und Unternehmen des Staatssektors erfolgt eine detaillierte Erhebung der Schuldenarten. Die sonstigen öffentlichen Fonds, Einrichtungen und Unternehmen werden mit einem verkürzten Erhebungsprogramm befragt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Jährliche Schulden der Kern- und Extrahaushalte und der sonstigen öffentlichen Fonds, Einrichtungen und Unternehmen des öffentlichen Bereichs**  
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/5ea255466cd64e0e/34149e4d93c1/MD_71321_2023.pdf)[Archiv](/search-results?q=71321&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-iii-1-j)


