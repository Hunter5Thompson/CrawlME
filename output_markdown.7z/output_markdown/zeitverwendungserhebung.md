

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Zeitverwendungserhebung](/zeitverwendungserhebung)

Zeitverwendungs­erhebung
========================

Bei der Zeitverwendungserhebung (ZVE) werden alle zehn Jahre verschiedenste Haushalte in Deutschland über ihren Tagesablauf befragt. Hierbei erfassen alle Teilnehmenden ab zehn Jahren ihre vollständigen Tagesabläufe über 24 Stunden von Arbeit oder Schule über Hobbies und Internetnutzung bis hin zu Einkaufen, Kinderbetreuung, ehrenamtlichen Tätigkeiten sowie den dazugehörigen Wegezeiten mit dem Auto, Bus, Bahn, Fahrrad oder zu Fuß.

Rechtliche Basis für die ZVE 2022 ist erstmals ein eigenes Gesetz ([Zeit­verwendungs­erhebungsgesetz – ZVEG](https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Einkommen-Konsum-Lebensbedingungen/Zeitverwendung/zve2022/zveg.html?nn=458120)), das am 1. Juli 2021 in Kraft trat.

BasisdatenWorum geht's?

Basisdaten
----------

BerlinBrandenburg

Die ZVE kurz erklärt
--------------------

Was ist die Zeitverwendungserhebung?Erhebungsteile der Zeitverwendung

Die Zeitverwendungserhebung (ZVE) liefert Informationen darüber, wieviel Zeit Menschen für unterschiedliche Tätigkeiten zu unterschiedlichen Tageszeiten aufwenden. Da die ZVE die einzige amtliche Informationsquelle für derartige Informationen ist, dient SiealsGrundlage für politische und wissenschaftliche Entscheidungen oder für Empfehlungen. Von besonderem Interesse sind hierbei die unbezahlten Arbeiten wie Kinderbetreuung, Pflege, Arbeiten im Haushalt oder ehrenamtliches Engagement.

Weitere Informationen über die ZVE 2022 finden Sie unter [zve2022.de](http://www.zve2022.de/).

Haben Sie Fragen?
-----------------

#### Nicole Baier

Haushaltserhebungen

#### Nicole Baier

Haushaltserhebungen

* [0331 8173-1123](tel:0331 8173-1123)
* [zve@statistik-bbb.de](mailto:zve@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / monkeybusinessimages](https://download.statistik-berlin-brandenburg.de/e7327d30f20c168b/ea95519b1cb1/v/9189ed5e3293/bevoelkerung-gesellschaft-gay-male-couple-with-children-walking-by-lake-picture-id514319002.jpg "iStock.com / monkeybusinessimages")](/224-2022)**Zeitverwendungserhebung (ZVE) 2022 in Berlin und Brandenburg**[#### Letzter Aufruf zur Teilnahme](/224-2022)

Pressemitteilung Nr. 224 Wie oft und wie lange sind meine Kinder online? Bekommen sie ausreichend Schlaf? Womit habe ich eigentlich den Tag verbracht? Antworten auf diese und weitere Fragen liefert...

[![iStock.com / fizkes](https://download.statistik-berlin-brandenburg.de/59ff41215e92a154/de624b8c4887/v/4dd18e6905d9/bevoelkerung-gesellschaft-young-father-playing-with-bricks-and-toys-with-little-kids-picture-id1201510270.jpg "iStock.com / fizkes")](/054-2022)**Familien in Berlin und Brandenburg gesucht**[#### Wo bleibt meine Zeit?](/054-2022)

Pressemitteilung Nr. 54 Unter diesem Motto führen die Statistischen Ämter des Bundes und der Länder 2022 gemeinsam die Zeitverwendungserhebung (ZVE) durch. Wie das Amt für Statistik mitteilt,...

[![Schmuckbild Karriere](https://download.statistik-berlin-brandenburg.de/0abb31092c440f5e/c976fbd3aa51/v/0ac0a78a7a7a/mother-at-home-trying-to-work-with-child-distracting-her-picture-id1192677586.jpg "Schmuckbild Karriere")](/325-2021)**Haushalte für Zeitverwendungserhebung 2022 gesucht**[#### Womit verbringen die Menschen in Berlin und Brandenburg ihre Zeit?](/325-2021)

Pressemitteilung Nr. 325 Der tägliche Zeitaufwand im persönlichen Bereich (Schlafen, Essen, Trinken) betrug 2012/13 im Bundesdurchschnitt täglich elf Stunden und sieben Minuten. Paare mit Kindern...

[Zu unseren News](/news)

[* Zeitverwendungserhebung](/search-results?q=tag%3AZeitverwendungserhebung)[* ZVE](/search-results?q=tag%3AZVE)
