

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 28.03.2024

#### Pro-Kopf-Wirtschaftsleistung in Berlin

Hauptstadt stärkt deutsche Wirtschaft – oder doch nicht?
--------------------------------------------------------

![Liniendiagramm Berlins Wirtschaftsleistung seit 2000](https://download.statistik-berlin-brandenburg.de/bc95625ce9732c21/f91e5c95cd65/v/7f622b2483e4/BIP.PNG "Liniendiagramm Berlins Wirtschaftsleistung seit 2000")

**Berlins Wirtschaftsleistung nimmt in den letzten Jahren mit hoher Dynamik zu. Seit 2014 entwickelte sich das preisbereinigte Bruttoinlandsprodukt (BIP) in der Hauptstadt deutlich stärker als die gesamtdeutsche Wirtschaft, zuletzt auch im Jahr 2023. Doch zeigt sich dieser Prozess auch in der Wirtschaftsleistung pro Kopf und pro gearbeiteter Stunde?**

Das BIP je Einwohnerin bzw. Einwohner wird häufig als Wohlstandsindikator einer Region gelesen. In Berlin lag der Wert 2023 in jeweiligen Preisen bei 51.209 EUR und damit knapp 2.500 EUR über dem bundesweiten Schnitt. Seit 2018 trägt Berlin damit wieder zu einer Stärkung des durchschnittlichen Wohlstands in Deutschland bei. Zwischen 2001 und 2017 lag die Wirtschaftskraft der Hauptstadt gemessen an der Bevölkerung unter dem Bundesdurchschnitt.

Um die Wirtschaftsleistung einzelner Regionen vergleichbar zu machen, wird das BIP ins Verhältnis zu Pro-Kopf-Angaben gesetzt, zum Beispiel je Einwohnerin bzw. Einwohner oder je erwerbstätiger Person.

**Quelle:**  Arbeitskreis „Volkswirtschaftliche Gesamtrechnungen der Länder" und Amt für Statistik Berlin-Brandenburg
#### **Arbeitsproduktivität in Berlin unterdurchschnittlich**

Wird die Wirtschaftskraft allerdings nicht in das Verhältnis zur gesamten Bevölkerung am Wohnort, sondern zu den, tatsächlich am Wertschöpfungsprozess beteiligten, erwerbstätigen Personen gesetzt, ergibt sich ein anderes Bild. Berlins BIP in jeweiligen Preisen je erwerbstätiger Person am Arbeitsort betrug 2023 88.132 EUR. Deutschlandweit erwirtschafteten alle erwerbstätigen Personen mit 89.721 EUR knapp 1.600 EUR mehr. Gemessen an der Erwerbstätigkeit drückt Berlin den bundesweiten Schnitt also etwas. Dieser Unterschied besteht seit 2001. Lediglich in den Jahren 2009 und 2020, die von großer Rezession geprägt waren, lag Berlins Wirtschaftsleistung je erwerbstätiger Person nahe beim Deutschlandwert.

**Quelle:**  Arbeitskreis „Volkswirtschaftliche Gesamtrechnungen der Länder" und Amt für Statistik Berlin-Brandenburg

Berücksichtigt man nur die gearbeiteten Stunden der Erwerbstätigen als Bezugsgröße, zeigt sich ein ähnliches Bild. Berlins Erwerbstätige erwirtschafteten 2023 je Arbeitsstunde 65,48 EUR, bundesweit waren es 66,84 EUR. Dieser Indikator stellt ein Maß für die Arbeitsproduktivität dar. Auch hier holte Berlin zuletzt auf. Das BIP je Arbeitsstunde lag 2007 noch 9,4 % unter dem Durchschnitt, 2023 waren es nur noch 2,0 %. Die gearbeiteten Stunden der Erwerbstätigen liegen auf Länderebene erst seit 2000 vor. Beim BIP je Arbeitsstunde hat Berlin seitdem jedoch noch keinen überdurchschnittlichen Wert erreicht.

**Quelle:**  Arbeitskreis „Volkswirtschaftliche Gesamtrechnungen der Länder" und Amt für Statistik Berlin-Brandenburg
#### Bezugszahlen

In den Volkswirtschaftlichen Gesamtrechnungen werden die Erwerbstätigen und die Bevölkerungszahl als Bezugsgrößen für die Berechnung von Aggregaten verwendet. Für die Berechnung je Arbeitsstunde wird zudem das Arbeitsvolumen als Summe der tatsächlich geleisteten Arbeitszeit aller Erwerbstätigen verwendet.

Berlins wirtschaftlicher Aufschwung steht in engem Zusammenhang mit dem Wachstum der Bevölkerung und der Erwerbstätigen. Im Vergleich zu 2000 ist Berlins Bevölkerung um 14,4 % auf gut 3,77 Mill. Einwohner gewachsen**.**Die Zahl der Erwerbstätigen mit Arbeitsort Berlin stieg im gleichen Zeitraum jedoch um mehr als ein Drittel auf gut 2,19 Mill. Personen.

###### **Datenangebot**

Diese und weitere Daten der Volkswirtschaftlichen Gesamtrechnungen finden Sie unter [www.statistik-berlin-brandenburg.de/wirtschaft/volkswirtschaft/gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen). Ergebnisse für alle Länder und methodische Erläuterungen stellt der Arbeitskreis „Volkswirtschaftliche Gesamtrechnungen der Länder“ unter <http://www.statistikportal.de/de/vgrdl> zur Verfügung.

[Mehr Informationen zur Wirtschaftsleistung 2023 in Berlin finden Sie in unserer aktuellen Pressemitteilung](/042-2024)
### Kontakte

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Volkswirtschaftliche Gesamtrechnungen](/search-results?q=tag%3AVolkswirtschaftliche Gesamtrechnungen)[* Bruttoinlandsprodukt](/search-results?q=tag%3ABruttoinlandsprodukt)[* Wirtschaftsleistung](/search-results?q=tag%3AWirtschaftsleistung)
