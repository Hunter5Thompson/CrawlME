

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Viehbestände in Brandenburg – Schafe](/c-iii-10-j)

Schafe in Brandenburg– Repräsentative Erhebung
----------------------------------------------

#### 3. November 2023, jährlich


###### Die Erhebung über die Schafbestände erfasst den Schafbestand in landwirtschaftlichen Betrieben. Aus den Ergebnissen werden Prognosen über die Entwicklung auf den Vieh- und Fleischmärkten erstellt.

BrandenburgMethodik
### Brandenburg

**Zahl der Schafe auf **72.900**gesunken**

Am 3. November 2023 wurden in Brandenburg 72.900 Schafe gehalten. Das waren 1.900 Tiere oder 2,5 % weniger als im Jahr zuvor. Die Zahl der Schafe haltenden Betriebe ist dagegen um 12,4 % auf 280 gestiegen. In jedem dieser Betriebe wurden rein rechnerisch gut 260 Schafe gehalten.

Der Rückgang des Schafbestandes ist vor allem auf die geringere Zahl an Lämmern zurückzuführen.  Ihre Zahl ging im Jahresvergleich um 2.000 auf 16.100 Tiere zurück (–11,1%). Der Bestand an Mutterschafen blieb mit 53.700 Tieren nahezu unverändert. Im Vorjahr waren es 200 Tiere oder 0,4 % mehr. Die Zahl der Milchschafe – Schafe, deren Milch für die menschliche Ernährung genutzt wird  –blieb mit 400 Tieren unverändert im Vergleich zum Vorjahr. Leicht zugenommen hat der Bestand der Schafböcke. Er stieg um knapp 100 Tiere oder 6,4 % auf 1.300 Tiere.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 3. November 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/b2d6cc07fd19d23c/b7cb7a1b4397/SB_C03-10-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/0ae789b51237ba53/cd8d001e603a/SB_C03-10-00_2023j01_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Olaf Müller

Tierische Produktion

#### Olaf Müller

Tierische Produktion

* [0331 8173-3051](tel:0331 8173-3051)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung über die Schafbestände ist eine dezentrale, repräsentative Bundesstatistik, wobei die Stadtstaaten ausgenommen sind. Erhebungsstichtag ist der 3. November eines jeden Jahres.

Zur Grundgesamtheit zählen alle landwirtschaftlichen Betriebe mit mindestens 20 Schafen. Für die Zufallsauswahl der Stichprobenbetriebe wird das Verfahren der „Kontrollierten Auswahl“ angewendet. Die Betriebe melden ihre Daten online bzw. per Erhebungsbogen.

Erhebungsmerkmale sind die Anzahl der Mutter- und Milchschafe einschließlich gedeckter Jungschafe, der Lämmer und Jungschafe unter einem Jahr, der Schafböcke sowie der Hammel und übrigen Schafe.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Viehbestandserhebung Schafe**Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/c5985f35b381ab39/d87f3703f40a/MD_41314_2021.pdf)[Archiv](/search-results?q=MD_41314&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-10-j)
