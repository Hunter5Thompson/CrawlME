

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Newsletter](/newsletter)

In zwei Schritten zum Newsletter
--------------------------------

1
-

**Formular ausfüllen**

Newsletter
----------

### Anmeldeformular

### Informationen

E-Mail \*E-Mail wiederholen \*Titel-Vorname \*Nachname \*
### Themen

Bevölkerung & KommunalstatistikWahlenZensusBildung & ArbeitGesundheit & SozialesStaatVolkswirtschaft & PreiseWirtschaftsbereicheUmwelt, Energie & VerkehrAktuelles aus dem Amt \*  
### Datenschutz und Einwilligungserklärung

Ich habe die Informationen zum [Datenschutz](/datenschutz) gelesen und bin damit einverstanden. \*Ich erlaube Ihnen, mir Einladungen zu Terminen Ihres Hauses zuzusenden.Anmelden

2
-

**E-Mail-Adresse im Postfach bestätigen**

Nachdem Sie das Anmeldeformular abgeschickt haben, erhalten Sie von uns eine E-Mail. Bitte bestätigen Sie Ihre Anmeldung, indem Sie auf den Link in der E-Mail klicken. Schauen Sie ggf. auch in Ihrem Spam-Ordner nach, falls Sie keine E-Mail in Ihrem Posteingang vorfinden.

Erst nach dieser Bestätigung erhalten Sie den Newsletter mit den neuesten Zahlen und Informationen zur amtlichen Statistik in Berlin und Brandenburg.

![](https://download.statistik-berlin-brandenburg.de/05f968e7ecfdd8db/cc3cda5c24bf/v/3f7bd1db526f/schmuckbild-newsletter.png)

FAQ
---

**Sie haben noch Fragen?**

###### Warum erhalte ich trotz Anmeldung keinen Newsletter?

Bitte überprüfen Sie, ob Sie Ihre Anmeldung bereits per Klick auf den Link in der E-Mail bestätigt haben, die wir Ihnen zugesandt haben. Nur mit diesem Double-Opt-In-Verfahren sind wir berechtigt, Ihnen einen Newsletter zuzusenden.

Prüfen Sie, ob der Newsletter in Ihrem Spam-Ordner bzw. Ihren Junk-Mails zu finden ist. Ist dies der Fall, fügen Sie die Mailadresse [newsletter@statistik-bbb.de](mailto: newsletter@statistik-bbb.de) den sicheren Absendern hinzu und verschieben den Newsletter in Ihren Posteingang.

Vergewissern Sie sich, dass die Zustellung nicht durch interne Spam-Filter Ihres Unternehmens verhindert wird. Bitte wenden Sie sich ggf. an Ihre IT-Abteilung.

Sollten alle Punkte nicht zutreffen, helfen wir Ihnen gern weiter. Schreiben Sie uns einfach eine E-Mail: [newsletter@statistik-bbb.de](mailto:newsletter@statistik-bbb.de).

###### Wie kann ich die Themen in einem bestehenden Newsletter-Abo ändern?

Um in einem bestehenden Newsletter-Abonnement Themen zu ergänzen oder abzuwählen, bitten wir Sie, das Anmeldeformular mit den neuen gewünschten Themen ausfüllen und sich erneut für den Newsletter anmelden.

###### Ich sehe keine Bilder. Wie kann ich den Newsletter korrekt anzeigen?

Wenn Ihnen keine Bilder im Newsletter angezeigt werden, könnten dafür die Einstellungen in Ihrem Mailprogramm verantwortlich sein. Sie finden im Kopf der E-Mail einen Systemhinweis. Mit einem Mausklick darauf können Sie die Bilder herunterladen bzw. den Newsletter-Absender zu den "sicheren Absendern" hinzufügen.

###### Sind meine Daten bei Ihnen sicher?

Im Amt für Statistik Berlin-Brandenburg ist die Einhaltung des gesetzlich vorgeschriebenen Datenschutzes oberstes Gebot. Die im Formular eingetragenen Daten werden mithilfe einer SSL-Verschlüsselung  sicher übertragen und nicht an Dritte weitergegeben. Weitere Informationen zum Datenschutz finden Sie [hier](/datenschutz).

###### Wie kann ich den Newsletter abmelden?

Schade, dass Sie unseren Newsletter nicht weiter abonnieren möchten. Sie können in jedem Newsletter ganz nach unten scrollen und dort über einen Link den Newsletter abbestellen. Sie können auch jederzeit Ihre Einwilligung per E-Mail an [newsletter@statistik-bbb.de](mailto:Newsletter@statistik-bbb.de?subject=Das%20Newsletter-Abonnement%20abbestellen&body=Sehr%20geehrte%20Damen%20und%20Herren,%0D%bitte%20melden%20Sie%20mich%20vom%20Newsletter%20des%20Amtes%20für%20Statistik%20Berlin-Brandenburg%20ab.%0D%0Mit%20freundlichen%20Grüßen%0D%0) widerrufen.

###### Was passiert mit meinen personenbezogenen Daten nach der Abmeldung?

Ihre Daten werden nach Beendigung des Newsletter-Abonnements innerhalb von sechs Monaten gelöscht, sofern der Löschung keine gesetzlichen Aufbewahrungspflichten entgegenstehen.


