

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Erwerbstätigkeit](/erwerbstaetigkeit)
* [Sozialversicherungspflichtig Beschäftigte in Berlin und Brandenburg](/a-vi-20-j)

Sozialversicherungspflichtig Beschäftigte
-----------------------------------------

#### 2023, jährlich

###### Die Beschäftigungsstatistik der Bundesagentur für Arbeit informiert über sozialversicherungspflichtig Beschäftigte am Arbeits- und Wohnort in Berlin und Brandenburg jeweils zum Stichtag 30. Juni eines Jahres. Für Brandenburg werden zudem Daten auf Kreisebene ausgewiesen.

BerlinBrandenburgMethodik

Berlin
------

**Quelle:** Beschäftigungsstatistik der Bundesagentur für Arbeit
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/fbcc1bbae94e6ce5/ebb6a5716f19/SB_A06-20-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/46fe002c607a203e/a096f91885aa/SB_A06-20-00_2023j01_BE.pdf)

**Zahl der Beschäftigten 2023 in Berlin stärker gestiegen als im Bundesdurchschnitt**

Am 30. Juni 2023 arbeiteten 1.680.089 sozialversicherungspflichtig Beschäftigte in Berlin und damit 26.178 Personen mehr als im Vorjahr. Die Zunahme 2023 lag in der Bundeshauptstadt mit 1,6 % über der bundesweiten Entwicklung von 0,8 %.

Im Jahr 2022 hatte sich die Zahl der sozialversicherungspflichtig Beschäftigten mit Arbeitsort in Berlin gegenüber 2021 noch um 4,5 % erhöht. Das war jedoch teilweise noch auf eine Erholung nach dem pandemiebedingten Einbruch des Arbeitsmarktes zurückzuführen. Der Anstieg der Beschäftigung 2023 in Berlin fiel allerdings auch geringer als im Durchschnitt der Jahre 2013 bis 2022 (+3,3 %).

Unter den rund 1,68 Millionen sozialversicherungspflichtig Beschäftigten am 30. Juni 2023 in Berlin waren 19,8 % unter 30 Jahre alt, 28,3 % im Alter von 30 bis unter 40 Jahren, 21,7 % im Alter von 40 bis unter 50 Jahren, 20,6 % im Alter von 50 bis unter 60 Jahren und 9,6 % mindestens 60 Jahre alt.

Die meisten der insgesamt 400.228 einpendelnden sozialversicherungspflichtig Beschäftigten kamen mit 240.430 Personen aus dem Nachbarland Brandenburg, gefolgt von 29.895 Personen aus Nordrhein-Westfalen und 21.627 Personen aus Bayern. Unter den insgesamt 219.936 auspendelnden Berlinerinnen und Berlinern hatten 96.537 Personen ihren Arbeitsplatz in Brandenburg, gefolgt von 26.500 Auspendelnden nach Nordrhein-Westfalen und 23.456 Auspendelnden nach Bayern.

### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Zahl der Beschäftigten 2023 in Brandenburg leicht gestiegen**

Am 30. Juni 2023 betrug die Zahl der sozialversicherungspflichtig Beschäftigten mit Arbeitsort in Brandenburg 883.289. Im Vergleich zum Vorjahr erhöhte sich die Beschäftigung um 1.083 Personen bzw. 0,1 %. Bundesweit nahm die Zahl der sozialversicherungspflichtig Beschäftigten 2023 mit plus 0,8 % stärker zu als in Brandenburg.

Im Jahr 2022 hatte sich die Zahl der sozialversicherungspflichtig Beschäftigten mit Arbeitsort in Brandenburg gegenüber 2021 noch um 1,8 % erhöht. Der Anstieg der Beschäftigung 2023 in Brandenburg fiel auch geringer als im Durchschnitt der Jahre 2013 bis 2022 (+1,2 %).

Unter den 883.289 sozialversicherungspflichtig Beschäftigten am 30. Juni 2023 in Brandenburg waren 15,7 % unter 30 Jahre alt, 23,3 % im Alter von 30 bis unter 40 Jahren, 23,2 % im Alter von 40 bis unter 50 Jahren, 25,4 % im Alter von 50 bis unter 60 Jahren und 12,5 % mindestens 60 Jahre alt.

Die meisten der insgesamt 176.314 einpendelnden sozialversicherungspflichtig Beschäftigten kamen mit 96.537 Personen aus Berlin, gefolgt von 15.655 Personen aus Sachsen und 10.136 Personen aus Sachsen-Anhalt. Unter den insgesamt 320.694 auspendelnden Brandenburgerinnen und Brandenburger hatten 240.430 Personen ihren Arbeitsplatz in Berlin, gefolgt von 18.206 Auspendelnden nach Sachsen und 10.632 Auspendelnden nach Nordrhein-Westfalen.

**Quelle:** Beschäftigungsstatistik der Bundesagentur für Arbeit
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/6968c917399876e9/a5643ac8a1df/SB_A06-20-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/c6ce1a7024017e71/ffa2e04a7861/SB_A06-20-00_2023j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Alle Ergebnisse zu sozialversicherungspflichtig Beschäftigten entstammen der Beschäftigungsstatistik der Bundesagentur für Arbeit (BA). Als sozialversicherungspflichtig Beschäftigte gelten demnach Personen, die folgende Kriterien erfüllen:

* eine Arbeitgebermeldung zur Sozialversicherung liegt vor,
* die Beschäftigung ist versicherungspflichtig in mindestens einem der Zweige der Sozialversicherung (Renten-, Kranken-, Pflege-, Arbeitslosenversicherung),
* es handelt sich um abhängige Beschäftigung bzw. Arbeit, die im Allgemeinen gegen Entgelt entrichtet wird (Ausnahmen sind Unterbrechungstatbestände wie z. B. Elternzeit),
* es wird mindestens eine Stunde pro Woche gearbeitet – soweit aus der Personengruppendefinition erkennbar.

Dazu gehören u. a. auch Auszubildende, Beschäftigte in Altersteilzeit, Prak­ti­kan­tin­nen und Prak­ti­kan­ten, Werk­stu­den­tin­nen und Werk­stu­den­ten, Beschäftigte in Werkstätten für Menschen mit Behinderung oder gleichartigen Einrichtungen, Per­so­nen, die ein freiwilliges so­zia­les, ein freiwilliges ökologisches Jahr oder einen Bun­des­frei­willi­gen­dienst leisten sowie Personen, die aus einem sozialversicherungspflichtigen Beschäftigungsverhältnis zur Ableistung von gesetzlichen Dienstpflichten (z. B. Wehrübung) einberufen werden.

Nicht zu den sozialversicherungspflichtig Beschäftigten zählen dagegen insbesondere Beamtinnen und Beamte, Selbstständige und mithelfende Familienangehörige sowie Berufs- und Zeitsoldaten. Zudem sind die ausschließlich geringfügig Beschäftigten nicht unter den sozialversicherungspflichtig Beschäftigten ausgewiesen.

Weitergehende Informationen und Daten erhalten Sie beim [Statistik-Service Ost der Bundesagentur für Arbeit](https://statistik.arbeitsagentur.de/DE/Navigation/Service/Kontakt/Kontakt-Nav.html "Verknüpfung folgen") und im [Internetangebot der Bundesagentur für Arbeit](https://statistik.arbeitsagentur.de/DE/Navigation/Statistiken/Fachstatistiken/Beschaeftigung/Beschaeftigung-Nav.html "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Sozialversicherungspflichtig Beschäftigte**ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/249d6705da4b7a3c/f69fbd33ccc1/MD_13111_2023.pdf)[Archiv](/search-results?q=MD_13111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-vi-20-j)


