

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Verkehr](/gesellschaft/verkehr)
* [Personenverkehr](/personenverkehr)
* [Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg](/h-i-6-j)

Personenverkehr mit Bussen und Bahnen
-------------------------------------

#### 2023, jährlich

###### Wie entwickelt sich der öffentliche Personennahverkehr in der Region? Die jährliche Erhebung gibt Auskunft über das Angebot von Eisen- und Straßenbahnen im Nahverkehr bzw. Bussen im Nah- und Fernverkehr sowie Fahrgastzahlen und Einnahmen.

BerlinBrandenburgMethodik
### Berlin

1 Angaben der Unternehmen mit Sitz in Berlin 2 Unternehmensfahrten**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/bbf18c7febc7ed8a/fd7d06d90a19/SB_H01-06-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/c16242268b4e7fff/426c55e7151b/SB_H01-06-00_2023j01_BE.pdf)

**Anzahl der Fahrgäste gestiegen**

Die Zahl der Fahrgäste im Berliner Schienen- und Liniennahverkehr stieg 2023 gegenüber dem Vorjahr um 12,5 % auf 1.549,9 Millionen (Mill.). Der Anteil der Fahrgäste im Verkehr mit Straßen- und U-Bahnen betrug 47,1 %. Die Beförderungsleistung stieg im Vergleich zu 2022 um 13,8 % auf 9.462,0 Mill. Personenkilometer. Die Fahrleistung stieg um 1,4 % auf 180,0 Mill. Fahrzeugkilometer. Das Beförderungsangebot erhöhte sich um 1,9 % auf 36.933,0 Mill. Platzkilometer. Die Beförderungseinnahmen betrugen 2.402,4 Mill. EUR. Das waren 23,5 % mehr als im Vorjahr.

### Kontakt

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Fast jeder Dritte von vier Fahrgästen mit dem Bus unterwegs**

Im Land Brandenburg sank die Zahl der Fahrgäste im Schienen- und Liniennahverkehr 2023 gegenüber 2022 um 0,2 % auf 149,4 Millionen (Mill.). Der Anteil der Fahrgäste im Verkehr mit Omnibussen betrug 73,1 %. Die Beförderungsleistung stieg gegenüber dem Vorjahr um 10,4 % auf 1.857,7 Mill Personenkilometer. Die Fahrleistung sank um 2,3 % auf 99,4 Mill. Fahrzeugkilometer. Das Beförderungsangebot stieg um 0,7 % auf 7.700,7 Mill. Platzkilometer. Die Beförderungseinnahmen waren mit 138,7 Mill. EUR um 8,5 % höher als im Vorjahr.

1 Angaben der Unternehmen mit Sitz im Land Brandenburg2 Unternehmensfahrten**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8622fe1a37931ecd/1d1de6f8c748/SB_H01-06-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/a1c635d7b1329f37/82a9d5fda221/SB_H01-06-00_2023j01_BB.pdf)
### Kontakt

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Mit der jährlichen bzw. 5-jährlichen Statistik des gewerblichen Personennahverkehrs und des Omnibusfernverkehrs soll die Entwicklung und die Struktur der Verkehrsleistungen sowie die dafür erforderlichen Voraussetzungen beobachtet werden. Detaillierte Ergebnisse über das Verkehrsaufkommen sind Grundlage für eine Vielzahl von Maßnahmen im Bereich der Gesetzgebung, Verwaltung und Verkehrswirtschaft. Die Ergebnisse dieser Statistik sind Bestandteil des verkehrsstatistischen Systems zur Erfassung des Personenverkehrs und werden für die Aufstellung volkswirtschaftlicher Gesamtrechnungen verwendet.

Zur Entlastung der Verkehrsunternehmen, die Personenbeförderung im Schienennahverkehr und im gewerblichen Omnibusverkehr durchführen, werden diese auf der Grundlage des [Verkehrsstatistikgesetzes (VerkStatG)](https://www.gesetze-im-internet.de/verkstatg/BJNR245210999.html) nur noch alle fünf Jahre vollständig nach Verkehrsarten, Beförderungsleistungen und Unternehmensstrukturen befragt. Ergänzend gibt es eine jährliche Stichprobenerhebung sowie eine vierteljährliche Befragung von Unternehmen mit mindestens 250 000 Fahrgästen im Vollerhebungsjahr.

Beim Nachweis von Länderergebnissen werden die von einem Unternehmen ggf. auch in anderen Bundesländern erbrachten Verkehrsleistungen dem Bundesland zugeordnet, in dem das auskunftspflichtige Unternehmen seinen Hauptsitz hat.

Erhebungsinhalte sind Fahrgäste, Beförderungsleistung, Beförderungsangebot, Fahr­leistungen und Einnahmen im Linienverkehr. Bei der 5-jährlichen Erhebung werden zusätzlich Infrastrukturangaben, Linienfahrzeuge und Beschäftigte erfragt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Jährliche/5-jährliche Statistik**  
**des gewerblichen Personenverkehrs**  
**und des Omnibusfernverkehrs**  
ab 2017

[Download PDF](https://download.statistik-berlin-brandenburg.de/54d2fed5a36678ce/04ce55c9125c/MD_46182_2017.pdf)[Archiv](/search-results?q=46182&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/h-i-6-j)
