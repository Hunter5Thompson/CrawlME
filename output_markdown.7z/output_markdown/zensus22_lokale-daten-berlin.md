

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Zensus](/bevoelkerung/zensus)
* [Zensus 2022](/zensus22)
* [Lokale Daten für Berlin](/zensus22/lokale-daten-berlin)

Lokale Daten für Berlin
-----------------------

Hier finden Sie ein vielfältiges, kleinräumiges Datenangebot mit Ergebnissen des Zensus 2022 für die Lebensweltlich orientierten Räume, die Berlin u.a. in 182 Bezirksregionen und 542 Planungsräume einteilt. Auswertungen sind bis auf Blockebene möglich. Die Datenbereitstellung umfasst 35 Merkmale aus den Themenbereichen Bevölkerung, Familien, Haushalte sowie Wohnungen und Gebäude.

BevölkerungHaushalte und FamilienGebäude und WohnungenDownloads

Bevölkerung
-----------

Geschlecht und FamilienstandStaatsangehörigkeit und Einwanderungsgeschichte
###### Zensus 2022

#### Bevölkerung insgesamt

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Zensus 2022

#### Ledige Bevölkerung

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Haushalte und Familien
----------------------

Haushalte (mit Kindern)WGs und Singlehaushalte
###### Zensus 2022

#### Haushalte

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Zensus 2022

#### Haushalte mit Kindern

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Gebäude und Wohnungen
---------------------

Wohnungen und MieteHeizart und Leerstand
###### Zensus 2022

#### Wohnungen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Zensus 2022

#### Durchschnittliche Nettokaltmiete

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Daten als Download
------------------

#### Laden Sie hier unser vielfältiges Datenangebot mit 35 Merkmalen aus den Bereichen Bevölkerung, Familien, Haushalte sowie Wohnungen und Gebäude herunter – für Bezirksregionen, Planungsräume und Blockebenen.

[Bezirksregionen (Download XLSX)](https://download.statistik-berlin-brandenburg.de/971797171ae35b6e/35b52c5cd5ca/Zensus_2022_BE_SKA_110000000000_Bezirksregionen.xlsx)[Planungsräume (Download XLSX)](https://download.statistik-berlin-brandenburg.de/ee987961392c26fe/4a3c29d7770d/SKA_110000000000_Planungsraum.xlsx)[Blockebene (Download XLSX)](https://download.statistik-berlin-brandenburg.de/045bb437a461c913/de5a5a87fc90/SKA_110000000000_Statistische_Bloecke.xlsx)[#### Merkmalskatalog (XLSX)

Für diese Merkmale stellen wir kleinräumige Daten bereit.](https://download.statistik-berlin-brandenburg.de/302f2645e557710f/b3968ebb233a/Merkmalskatalog-kleinraeumige-Auswertung.xlsx)[#### Glossar zu den Daten (PDF)

Die wichtigsten Begriffe erklärt.](https://download.statistik-berlin-brandenburg.de/390c64d06e53c60b/d7fd8c7e757f/Glossar-SKA-berlin-brandenburg-zensus2022.pdf)

Sie haben Fragen?
-----------------

#### Unser Zensus-Team ist gerne für Sie da. Weitere Auswertungen erhalten Sie auf Anfrage.

#### Zensus

#### Zensus

* [zensus@statistik-bbb.de](mailto:zensus@statistik-bbb.de)


