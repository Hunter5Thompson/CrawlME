

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Anbau von Blumen und Zierpflanzen zum Verkauf in Brandenburg](/c-i-6-4j)

Anbau von Blumen und Zierpflanzen zum Verkauf in Brandenburg
------------------------------------------------------------

#### 2021, vierjährlich

###### Die aus der Zierpflanzenerhebung gewonnenen Daten bieten Informationen über den Anbau von Zierpflanzen und die Anzahl und Struktur der Betriebe mit Zierpflanzenanbau.

BrandenburgMethodik
### Brandenburg

**58 Betriebe für Produktion und Verkauf**

In Brandenburg gab es 2021 insgesamt 58 Betriebe, die sich mit der Produktion und dem Verkauf von Blumen und Zierpflanzen befassten. Diesen Betrieben standen für die Zierpflanzenerzeugung 32 Hektar Freilandflächen (2017: 41 Hektar) sowie 22 Hektar (2017: 23 Hektar) unter hohen begehbaren Schutzabdeckungen einschließlich Gewächshäusern zur Verfügung.

Beet- und Balkonpflanzen wurden z. B. 7,1 Millionen Stück produziert. Zu diesen zählen beispielsweise Veilchen und Stiefmütterchen (2,4 Millionen), Primeln (0,6 Millionen) sowie Geranien (0,8 Million).

In der Zierpflanzenerhebung werden alle vier Jahre die Grundflächen, die Anbauflächen von Zierpflanzen zum Schnitt, die Zahl der erzeugten Topfpflanzen, die Pflanzengruppen, Pflanzenarten, Kulturformen und die Verwendungszwecke beim Anbau von Blumen und Zierpflanzen erhoben.

  


1 seit 2012 eingeschränkte Vergleichbarkeit mit den Vorjahren aufgrund methodischer Veränderungen2 einschl. Gewächshäusern**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a3d906f62a1b6f88/be9c6bce4fc0/SB_C01-06-00_2021j04_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/9552f3cc4d935edb/10fa53456ec5/SB_C01-06-00_2021j04_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Zierpflanzenerhebung ist eine dezentrale Bundesstatistik. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

Auskunftspflichtig sind immer die Inhaberinnen und Inhaber bzw. Leiterinnen und Leiter von Betrieben mit einer Blumen- oder Zierpflanzenfläche von mindestens 0,3 ha Blumen- oder Zierpflanzenfläche im Freiland und/oder 0,1 ha Blumen- oder Zierpflanzenfläche unter hohen begehbaren Schutzabdeckungen einschl. Gewächshäusern.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Allgemeine Zierpflanzenerhebung**  
Metadaten 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/fb89bf294d449df0/14da33ce76a8/MD_41213_2021.pdf)[Archiv](https://download.statistik-berlin-brandenburg.de/fb89bf294d449df0/14da33ce76a8/MD_41213_2021.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-6-4j)
