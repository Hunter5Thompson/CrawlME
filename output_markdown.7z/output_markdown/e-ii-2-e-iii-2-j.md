

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Bauen und Wohnungen](/bauen-und-wohnungen)
* [Baugewerbe in Berlin und Brandenburg (Ergänzungserhebung)](/e-ii-2-e-iii-2-j)

Baugewerbe
----------

#### Ergänzungserhebung 2023, jährlich

###### Die Ergänzungserhebung dient der Beurteilung der Struktur des Baugewerbes. Die Daten enthalten Angaben zu tätigen Personen, geleisteten Arbeitsstunden, Umätzen und Entgelten.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/3afd71d2f9813ad7/d5c9c0bbe8ab/SB_E02-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/0ab1f1394fa20f88/fdb1e888b149/SB_E02-02-00_2023j01_BE.pdf)

**Umsatzsteigerung und mehr tätige Personen**

Die Betriebe des Berliner Bauhauptgewerbes und Ausbaugewerbes meldeten im Rahmen der jährlich stattfindenden Erhebungen im Juni 2023 bzw. im 2. Quartal 2023 mehr Umsätze als im Vorjahresmonat und im Vorjahresquartal, teilt das Amt für Statistik Berlin-Brandenburg mit.

Im Berliner Bauhauptgewerbe wurden Ende Juni 2023 im Rahmen einer Totalerhebung 2.480 Betriebe befragt. Das waren 23 Betriebe bzw. 0,9 % weniger als im Vorjahr. Die Zahl der in diesen Betrieben tätigen Personen sank um 1,9 % auf 26.434. Der baugewerbliche Umsatz betrug im Juni 2023 500,9 Mill. EUR. Gegenüber Juni 2022 ist das ein Anstieg um 9,9 %.

Ende Juni 2023 wurde die jährliche Erhebung in den Betrieben des Berliner Ausbaugewerbes durchgeführt. 1.013 Betriebe mit zehn und mehr tätigen Personen wurden befragt. Die Zahl der Betriebe stieg im Vergleich zum Vorjahr um 3,6 %. Ebenfalls war ein Zuwachs bei den tätigen Personen, um 1,2 % auf 29.353 Personen zu verzeichnen. Der baugewerbliche Umsatz betrug im 2. Quartal 2023 1,0 Milliarden EUR. Das entspricht einer Steigerung um 10,5 % im Vergleich zum Vorjahresquartal.

### Kontakt

#### Diana Geipel

Baugewerbe

#### Diana Geipel

Baugewerbe

* [0331 8173-3745](tel:0331 8173-3745)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Marlies Quägwer

Bauhauptgewerbe

#### Marlies Quägwer

Bauhauptgewerbe

* [0331 8173-3831](tel:0331 8173-3831)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Birgit Wimmer

Ausbaugewerbe

#### Birgit Wimmer

Ausbaugewerbe

* [0331 8173-3057](tel:0331 8173-3057)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Umsatzsteigerung und mehr tätige Personen**

Die Betriebe des Brandenburger Bauhauptgewerbes meldeten im Rahmen der jährlich stattfindenden Erhebungen im Juni 2023 weniger Umsätze als im Vorjahresmonat. Hingegen steigerten die Betriebe des Brandenburger Ausbaugewerbes im 2. Quartal 2023 die Umsätze gegenüber dem Vorjahresquartal, teilt das Amt für Statistik Berlin-Brandenburg mit.

Im Brandenburger Bauhauptgewerbe fand Ende Juni 2023 eine Totalerhebung in 5.112 Betrieben statt. Das waren 108 Betriebe bzw. 2,1 % weniger als 2022. In diesen Betrieben arbeiteten 36.944 Personen, 2,0 % weniger als im Vorjahresmonat. Der baugewerbliche Umsatz betrug im Juni 2023 594,1 Mill. EUR. Gegenüber Juni 2022 ist das ein Rückgang um 0,3 %.

Die jährliche Erhebung in Betrieben des Ausbaugewerbes mit zehn und mehr tätigen Personen erfasste Ende Juni 2023 im Land Brandenburg 825 Betriebe mit 19.321 tätigen Personen. Die Zahl der Betriebe stieg gegenüber dem Vorjahr um 7,8 %, die der tätigen Personen um 5,3 %. Der baugewerbliche Umsatz erreichte im 2. Quartal 2023 insgesamt 670,6 Mill. EUR, was einem Zuwachs um 17,5 % im Vergleich zum Vorjahresquartal entspricht.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/876b27cbcf1057f0/e23793e2604c/SB_E02-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/d86622e022c41b6c/368a6e9bd56e/SB_E02-02-00_2023j01_BB.pdf)
### Kontakt

#### Diana Geipel

Baugewerbe

#### Diana Geipel

Baugewerbe

* [0331 8173-3745](tel:0331 8173-3745)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Marlies Quägwer

Bauhauptgewerbe

#### Marlies Quägwer

Bauhauptgewerbe

* [0331 8173-3831](tel:0331 8173-3831)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Birgit Wimmer

Ausbaugewerbe

#### Birgit Wimmer

Ausbaugewerbe

* [0331 8173-3057](tel:0331 8173-3057)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Im Baugewerbe, einem Teil des Produzierenden Gewerbes, werden Unternehmen bzw. Betriebe des Baugewerbes befragt.

Das Baugewerbe unterscheidet zwei große Teilbereiche, das Bauhauptgewerbe und das Ausbaugewerbe. Im Bauhauptgewerbe werden Unternehmen bzw. Betriebe mit Tätigkeits­schwerpunkt im Bereich der vorbereitenden Baustellenarbeiten, dem Bau von Gebäuden und dem Tiefbau untersucht. Im Ausbaugewerbe liegt der Tätigkeitsschwerpunkt der Unternehmen bzw. Betriebe in der Bauinstallation und im sonstigen Ausbau. Mit der Umstellung auf die Klassifikation der Wirtschaftszweige (WZ 2008) wurde dem Baugewerbe noch ein weiterer Teil zugeordnet, die Bauträger.

Die Untersuchung des Baugewerbes erfolgt in unterschiedlichen zeitlichen Abständen. Die kurzfristigen Statistiken (Konjunkturstatistiken) werden monatlich und vierteljährlich und die langfristigen Statistiken (Strukturstatistiken) werden jährlich durchgeführt. Für die Konjunkturstatistiken werden im Wesentlichen Indikatoren wie Umsatz, tätige Personen, geleistete Arbeitsstunden, Entgelte, Auftragseingänge und Auftragsbestände erfasst. Die Strukturstatistiken liefern u. a. Informationen zu tätigen Personen, Umsatz und Investitionen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

**[Jahreserhebung einschl. Investitionserhebung im Bauhauptgewerbe (2019)](https://download.statistik-berlin-brandenburg.de/34ec1409e70688af/a7fae229a864/MD_44211_2019.pdf)** | [Archiv](/search-results?q=MD_44211&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Jahreserhebung einschl. Investitionserhebung bei Unternehmen des Ausbaugewerbes und bei Bauträgern (2019)](https://download.statistik-berlin-brandenburg.de/c73edf5b860a8167/712de1a141e0/MD_44221_2019.pdf)** | [Archiv](/search-results?q=MD_44221&searchMethodik=true&pageNumber=1&sortBy=date-desc)  


**[Ergänzungserhebung im Bauhauptgewerbe (2019)](https://download.statistik-berlin-brandenburg.de/2c0ee269d18e8428/d4d528e07ce3/MD_44231_2019.pdf)** | [Archiv](/search-results?q=MD_44231&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Jährliche Erhebung im Ausbaugewerbe und bei Bauträgern (2019)](https://download.statistik-berlin-brandenburg.de/4fa84f64dbacc40a/b17c0b8e9e47/MD_44241_2019.pdf)** | [Archiv](/search-results?q=MD_44241&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-ii-2-e-iii-2-j)
