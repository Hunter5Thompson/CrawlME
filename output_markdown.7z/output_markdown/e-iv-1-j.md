

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Energie](/energie)
* [Energie-, Wasser- und Gasversorgung in Brandenburg](/e-iv-1-j)

Energie-, Wasser- und Gasversorgung in Brandenburg
--------------------------------------------------

#### Beschäftigte, geleistete Arbeitsstunden, Löhne und Gehälter der Betriebe

#### 2022, jährlich

###### Die Statistik gibt jährlich Auskunft über tätige Personen in den hauptbetrieblichen Bereichen und den fachlichen Wirtschaftszweigen, ihre geleisteten Arbeitsstunden sowie Bruttolöhne und Bruttogehälter.

BrandenburgMethodik
### Brandenburg

**Kontinuität bei Brandenburger Betrieben der Energie- und Wasserwirtschaft** 

Im Jahr 2022 waren 8.383 Personen in den 106 Betrieben der Energie- und Wasserversorgung in Brandenburg tätig. Das waren 47 Personen oder 0,6 % weniger gegenüber dem Vorjahr.

In der Gaswirtschaft ging die Zahl der Beschäftigten um 26 Personen zurück, was einem prozentualen Rückgang von 6 % entspricht. In der  Wärme- und Elektrizitätswirtschaft war dagegen ein geringer prozentualer Rückgang der Beschäftigten in Höhe von  –0,6  % bzw. –1,0 % zu verzeichnen. Die höchste absolute Steigerung hatte bei den hauptbetrieblichen Betriebsteilen die Wasserwirtschaft, mit einem Plus von 51 Beschäftigten. Das entspricht einem Plus von 3 %.

Die Steigerung der Entgelte betrug gegenüber dem Vorjahr durchschnittlich 2,2 % nominal. Während in der Elektrizitäts- und Wasserwirtschaft die Entgelte um 2 % anstiegen, betrug die Steigerung in Gas- und Wärmewirtschaft 3 % im Vergleich zu 2021.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/612fd5aa66998b49/57635a39e77e/SB_E04-01-00_2022j01_BB.xlsx)

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/266891d5bfa25cf9/d733b460790d/SB_E04-01-00_2022j01_BB.pdf)
### Kontakt

#### Dr. Christian Hager

Energie- und Wasserversorgung

#### Dr. Christian Hager

Energie- und Wasserversorgung

* [0331 8173-3663](tel:0331 8173-3663)
* [Energie@statistik-bbb.de](mailto:Energie@statistik-bbb.de)
* [0331 817330-4013](fax:0331 817330-4013)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung dient der kurzfristigen Beurteilung der konjunkturellen Lage des Wirtschaftsbereichs Energie- und Wasserversorgung. Sie stellt damit unverzichtbare Daten für die Arbeit der gesetzlichen Körperschaften, der Bundes- und Landesregierungen zur Verfügung und ist eine Grundlage für zahlreiche Entscheidungen auf dem Gebiet der gesamten Wirtschaftspolitik, insbesondere der Energiepolitik.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatsbericht bei Betrieben in der Energie- und Wasserversorgung**  
Metadaten ab 2022

[Download](https://download.statistik-berlin-brandenburg.de/142dd49b2f768df9/44bd1f19fc58/MD_43111_2022.pdf)[Archiv](/search-results?q=43111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-iv-1-j)
