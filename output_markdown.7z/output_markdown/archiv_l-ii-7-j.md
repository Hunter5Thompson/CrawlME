

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Realsteuervergleich in Berlin und Brandenburg](/l-ii-7-j)
* [L II 7 – j](/archiv/l-ii-7-j)

Archiv: Statistischer Bericht
=============================

#### Realsteuervergleich (L II 7 – j)

![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben dieses Statistischen Berichts jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000408)


