

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Ernteberichterstattung über Baumobst in Brandenburg](/c-ii-6-j)

Ernteberichterstattung über Baumobst in Brandenburg
---------------------------------------------------

#### 2023, jährlich

###### Die Ernteberichterstattung Baumobst liefert die im Inland erzeugten Obstmengen für die Berechnung des Beitrages des Obstes in der Landwirtschaftlichen Gesamtrechnung, betriebswirtschaftliche Kennzahlen für die Landwirtschaft und die nationalen und EU-Versorgungsbilanzen.

BrandenburgMethodik
### Brandenburg

**Unterdurchschnittliches Ernteergebnis 2023**

Nach den endgültigen Meldungen der Betriebsberichterstatter wurde ein Apfelertrag von 236 Dezitonnen pro Hektar eingefahren. Das sind 90 Dezitonnen pro Hektar weniger als im Vorjahr. Dieser Ertrag liegt gleichzeitig um 11 % unter dem langjährigen Mittel (2017 bis 2022).

Trotz wenigen Frostphasen im Frühling war nach Aussagen der Brandenburger Obstbauern die wesentliche Ursache für das mittelmäßige Ernteergebnis eine Trockenheitsphase zwischen Mai und Juli. Schädlingsbefall und lokale Unwetter drückten weiter das Ernteergebnis. Auch die Ernteergebnisse der Birnen, Süßkirschen, Sauerkirschen, Pflaumen und Mirabellen lagen unter dem Vorjahresergebnis.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/54b73064343de378/f747258badf4/SB_C02-06-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7df6bc57dea91176/b9862af209c4/SB_C02-06-00_2023j01_BB.pdf)
### Kontakt

#### Regina Kurz

Ernte- und Weinstatistiken

#### Regina Kurz

Ernte- und Weinstatistiken

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

* [0331 8173-3054](tel:0331 8173-3054)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Ernte- und Betriebsberichterstattung Baumobst ist eine dezentrale Bundesstatistik.

Die Erhebung der Angaben erfolgt durch Befragung der Ernte- und Betriebsberichterstatter/-innen. Die Berichterstattung ist nach [§ 93 Absatz 3 Nummer 1 AgrStatG](https://www.gesetze-im-internet.de/agrstatg/__93.html) in Verbindung mit [§ 15 Absatz 1 Satz 1 BStatG](https://www.gesetze-im-internet.de/bstatg_1987/__15.html) freiwillig.

Die Daten der Betriebe werden über einen Fragebogen in Papierform und zusätzlich über einen Online-Fragebogen (IDEV) erhoben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Ernte- und Betriebsberichterstattungen (EBE): Baumobst**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/a995137ea773b3d4/6db70ca5645d/MD_41243_2023.pdf)[Archiv](/search-results?q=MD_41243&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-ii-6-j)
