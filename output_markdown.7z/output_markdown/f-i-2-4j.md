

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Mikrozensus](/bevoelkerung/demografie/mikrozensus)
* [Ergebnisse des Mikrozensus in Berlin und Brandenburg – Wohnsituation](/f-i-2-4j)

Mikrozensus – Zusatzerhebung Wohnsituation
------------------------------------------

#### 2022, vierjährlich

###### Die Zusatzerhebung zur Wohnsituation der Haushalte erfolgt im Abstand von vier Jahren ergänzend zum jährlich erhobenen Grundprogramm des Mikrozensus.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/167555afd12b0012/354695ab2b73/SB_F01-02-00_2022j04_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/701521a9dd8689d4/aea0f83295f7/SB_F01-02-00_2022j04_BE.pdf)

**Zahl der Mieterhaushalte überwiegt**

2022 gab es in Berlin 1.672.000 Haushalte in Wohnungen, die von der Eigentümerin bzw. dem Eigentümer zu Wohnzwecken vermietet wurden, 304.000 Haushalte lebten als Eigentümer selbst in ihren Wohnungen.

Die Wohnfläche, die einem Haushalt zur Verfügung stand, betrug 2022 im Durchschnitt 74,8 m². Dabei lebten Haushalte in Eigentümerwohnungen mit durchschnittlich 109,7 m² deutlich geräumiger als in Mietwohnungen mit 68,2 m².

Analog zur flächenmäßigen Wohnungsgröße weisen die Eigentümerwohnungen in Berlin durchschnittlich mehr Räume (3,8) auf als Mietwohnungen (2,5).

### Kontakt

#### Jörg Feilbach

Mikrozensus

#### Jörg Feilbach

Mikrozensus

* [0331 8173-3644](tel:0331 8173-3644)
* [mikrozensus@statistik-bbb.de](mailto:mikrozensus@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Wohnfläche größer als in Berlin**

In Brandenburg überwiegen weiterhin Haushalte in vermieteten Wohnungen gegenüber solchen in Eigentümerwohnungen. Die 695.000 Mieterhaushalte stellen dabei mit 55,3 % immer noch einen größeren Anteil dar, als die 561.000 Eigentümerhaushalte mit 44,7 %.

Die durchschnittliche Wohnfläche eines Haushalts in Brandenburg war mit 90,6 m² deutlich größer als in Berlin. Dies liegt vorrangig an dem höheren Anteil der Haushalte in Eigentümerwohnungen, aber auch daran, dass in den Eigentümerwohnungen außerhalb Berlins mehr Wohnfläche zur Verfügung steht (durchschnittlich 117,9 m²). Für die Mieterhaushalte traf dies nicht zu: Diese bewohnen in Brandenburg mit durchschnittlich 68,3 m² etwa dieselbe Fläche wie die Berliner Haushalte.

Die Anzahl der Wohnräume lag in Mietwohnungen durchschnittlich bei 2,7 und in Eigentümerwohnungen bei 4,2 Räumen.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/b73a00e0b92eedbe/1faf2cc590c0/SB_F01-02-00_2022j04_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/9832fc6bdf4a2b35/e1b023f08d14/SB_F01-02-00_2022j04_BB.pdf)
### Kontakt

#### Jörg Feilbach

Mikrozensus

#### Jörg Feilbach

Mikrozensus

* [0331 8173-3644](tel:0331 8173-3644)
* [mikrozensus@statistik-bbb.de](mailto:mikrozensus@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Mikrozensus-Zusatzerhebung zur Wohnsituation ermöglicht es, statistische Angaben in tiefer fachlicher und regionaler Gliederung über die Wohnverhältnisse der privaten Haushalte für Politik, Wissenschaft und die interessierte Bevölkerung bereitzustellen und diese mit sozioökonomischen Merkmalen der Grunderhebung zu kombinieren.

Sie umfasst die Merkmale Art, Typ und Größe des Gebäudes mit Wohnraum, leerstehende Wohnung, Baualtersgruppe des Gebäudes, Fläche der gesamten Wohnung, Besitzverhältnis, Nutzung der Wohnung (als Eigentümer/in, Hauptmieter/in, Untermieter/in), Kalenderjahr des Einzugs des Haushalts, Ausstattung der Wohnung mit Heiz- und Warmwasserbereitungsanlagen nach einzelnen Energieträgersystemen, Barrieren beim Zugang zur Wohnung, Barrieren innerhalb der Wohnung, Höhe der monatlichen Miete und der anteiligen Betriebs- und Nebenkosten für Mietwohnungen, Kredite für selbstgenutztes Wohneigentum, Art der öffentlichen Leistungen für die Wohnkosten.

Die Daten aus der Mikrozensus-Zusatzerhebung 2018 sind aufgrund der Umstellung auf eine neue Stichprobe ab dem Jahr 2016 nur begrenzt mit den Ergebnissen aus den Vorjahren vergleichbar. Außerdem ist zu beachten, dass die Gesamtzahl der Haushalte kleiner ausfällt als in anderen Veröffentlichungen, je nachdem, ob Informationen zur Wohnsituation vorliegen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Zusatzprogramm des Mikrozensus**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/ee4801c09f1a0f90/2345e42e68ce/MD_12212_2022.pdf)[Archiv](/search-results?q=MD_12212&sortBy=date-desc&pageNumber=1&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/f-i-2-4j)
