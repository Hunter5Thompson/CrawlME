

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
#### Überblick

Staat
=====

Im Bereich „Staat“ finden Sie Tabellen, Grafiken und Statistische Berichte zu Steuern in Berlin und Brandenburg, den Kommunalfinanzen, dem Personal im öffentlichen Dienst, zur Flächennutzung sowie zur Justiz und Rechtspflege.

**Personal im öffentlichen Dienst**2023 nach Geschlecht

BerlinBrandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg[Voranmeldung, Veranlagung, Festsetzung
#### Steuern](/gesellschaft/staat/steuern)[Gebiet
#### Flächennutzung](/flaechennutzung)[Kommunen und öffentliche Unternehmen
#### Öffentliche Finanzen](/oeffentliche-finanzen)[Personal und Versorgungsempfänger
#### Öffentlicher Dienst](/oeffentlicher-dienst)[Strafrechtspflege und Geschäftsstatistiken
#### Justiz und Rechtspflege](/justiz-und-rechtspflege)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Staat

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg, 2016–2019 Jahresrechnungsstatistik, 2020 Vierteljährliche Kassenstatistik (vorläufig)**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Neues aus dem Bereich Staat

Zuletzt veröffentlicht
----------------------

![iStock.com / Rawf8](https://download.statistik-berlin-brandenburg.de/bb9c63d4a21d952a/78b18f7a17ff/v/85a71b6cd4c6/gesellschaft-staat-judge-gavel-and-a-laptop-wooden-background-online-auction-concept-picture-id1220820993.jpg)20.12.2024Pressemitteilung[#### Strafverfolgung 2023 in Berlin und Brandenburg: Abwärtstrend in Brandenburg setzt sich fort](/180-2024)

2023 nahm die Zahl der Verurteilungen in Berlin im Vergleich zum Vorjahr um 2,1 % zu, in Brandenburg ging sie um 11,1 % zurück.

[Ansehen](/180-2024)![iStock.com / serts](https://download.statistik-berlin-brandenburg.de/dd6e941c8ce73a94/2daf4f79fd95/v/32cedc604422/gesellschaft-staat-statue-of-lady-justice-rmerberg-frankfurt-germany-picture-id840831682.jpg)20.12.2024Statistischer Bericht[#### 2023, jährlich, B VI 1 – j: Abgeurteilte und Verurteilte in Berlin](/b-vi-1-j)

In dieser Statistik wird die Anzahl der Abgeurteilten und Verurteilten aus der Strafverfolgungsstatistik veröffentlicht.

[Ansehen](/b-vi-1-j)![iStock.com / BongkarnThanyakij](https://download.statistik-berlin-brandenburg.de/e290824131875f05/9512c6b1278e/v/2b87513e5a84/gesellschaft-soziales-man-looking-at-his-empty-leather-wallet-in-office-picture-id835036152.jpg)18.12.2024Statistischer Bericht[#### jährlich, 2023, L III 1 – j: Schulden der öffentlichen Haushalte und der öffentlich bestimmten Fonds, Einrichtungen und wirtschaftlichen Unternehmen in Berlin und Brandenburg](/l-iii-1-j)

Stand der Schulden, Schuldenaufnahmen, Schuldentilgungen und sonstigen Schuldenbewegungen des Berichtsjahres in Berlin und Brandenburg.

[Ansehen](/l-iii-1-j)Mehr anzeigen
#### Fragen & Antworten

### Kommunale Steuereinnahmen

Neben den Zuweisungen aus dem kommunalen Finanzausgleich und den Gebühren sind die Gemeindesteuern und steuerähnliche Einzahlungen eine wichtige Einnahmequelle der Kommunen. Auf die Höhe dieser Einnahmen können sie über die Anpassung von Hebesätzen für die Grundsteuern und die Gewerbesteuer oder über Abgabeordnungen und kommunale Satzungen, zum Beispiel für die Zweitwohnsitzsteuer oder die Hundesteuer, in gewissem Umfang Einfluss nehmen.

###### Welche Steuereinzahlungen werden berücksichtigt?

Kommunale Steuereinzahlungen sind die Gemeindesteuern und steuerähnliche Einzahlungen, die direkt den Gemeinden oder Gemeindeverbänden (zum Beispiel den Städten und Landkreisen) zufließen. Dazu zählen:

**1. Realsteuern** 

* Grundsteuer A
* Grundsteuer B
* Gewerbesteuer

**2. Gemeindeanteile an den Gemeinschaftssteuern** 

* Gemeindeanteil an der Einkommensteuer
* Gemeindeanteil an der Umsatzsteuer

  

**3. Sonstige Gemeindesteuern**

* Vergnügungssteuer
* Hundesteuer
* Jagdsteuer
* Zweitwohnsitzsteuer
* Sonstige örtliche Steuern

  

**4. Steuerähnliche Einzahlungen**  

* Fremdenverkehrsabgabe
* Abgaben von Spielbanken
* Sonstige steuerähnliche Einzahlungen
###### Wie wird die Gewerbesteuerumlage berechnet?

Die Höhe der Gewerbesteuerumlage einer Gemeinde errechnet sich, indem das Ist-Aufkommen der Gewerbesteuer der Gemeinde durch den von der Gemeinde festgesetzten Hebesatz dividiert wird und mit dem Vervielfältiger multipliziert wird. Der Vervielfältiger ist die Summe des Bundes- und des Landesvervielfältigers. Der Bundesvervielfältiger beträgt 14,5 %, der Landesvervielfältiger 20,5 %. Das Ist-Aufkommen der Gewerbesteuer ergibt sich durch Multiplikation von Steuermessbetrag und festgesetztem Hebesatz. Der Steuermessbetrag ergibt sich aus der Multiplikation des Gewerbeertrages mit der Steuermesszahl in Höhe von 3,5 %.

###### Warum eine Nettobetrachtung?

Die Gewerbesteuereinnahmen stehen den Gemeinden nicht vollumfänglich zur eigenen Verfügung. Einen bestimmten Anteil des Gewerbesteueraufkommens – die Gewerbesteuerumlage – müssen die Gemeinden an Bund und Land abführen. Rechtlich ist dies im Gemeindefinanzreformgesetz geregelt beziehungsweise in Art. 106 Abs. 6 S. 4 des Grundgesetzes verankert. Im Gegenzug zu dieser Minderung der Gewerbesteuereinnahmen erhalten die Gemeinden einen Anteil am Einkommen- und Umsatzsteueraufkommen. Bedingt durch die abzuführende Gewerbesteuerumlage wird bei finanzstatistischen Berechnungen unterschieden zwischen den Gewerbesteuereinnahmen (brutto) und den Gewerbesteuereinnahmen (netto). Unter den Gewerbesteuereinnahmen (brutto) wird das gesamte Gewerbesteueraufkommen der betrachteten Gemeinden vor Abzug der Umlage verstanden. Der nach Abzug der Umlage bei den Gemeinden verbleibende Anteil des Gewerbesteueraufkommens wird als Gewerbesteuereinnahmen (netto) bezeichnet.


