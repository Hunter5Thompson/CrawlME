

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Bauen und Wohnungen](/bauen-und-wohnungen)
* [Fortschreibung des Wohngebäude- und Wohnungsbestandes in Berlin und Brandenburg](/f-i-1-j)

Fortschreibung des Wohngebäude- und Wohnungsbestandes
-----------------------------------------------------

#### 31. Dezember 2023, jährlich

###### Zwischen den Gebäude- und Wohnungszählungen wird der Bestand an Wohngebäuden und Wohnungen mithilfe der Bautätigkeitsstatistiken amtlich fortgeschrieben. Statistische Daten über den Bestand an Wohnungen geben u. a. Auskunft über die Versorgung der Bevölkerung mit Wohnraum.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/08570921ab238985/3ce4512b5b37/SB_F01-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f918b03661b6743a/83037424277f/SB_F01-01-00_2023j01_BE.pdf)

**Wohngebäude- und Wohnungsbestand in Berlin**

Am Jahresende 2023 gab es in Berlin 2.030.259 Wohnungen. Das waren 15.697 Wohnungen bzw. 0,8 % mehr als Ende 2022.Durch den Bau neuer Gebäude kamen 14.633 Wohnungen hinzu. Weitere 1.420 Wohnungen entstanden durch Baumaßnahmen an bestehenden Gebäuden. 359 Wohnungen gingen durch Nutzungsänderungen, Zusammenlegungen und Abbrüche verloren.

In Mehrfamilienhäusern befanden sich 86,6 % aller Berliner Wohnungen, 1,6 % in Wohnheimen und weitere 1,5 % in Nichtwohngebäuden. 57,1 % der 334.716 Wohngebäude (einschließlich Wohnheimen) waren Ein- und Zweifamilienhäuser.

Der Wohnungsbestand ist in den letzten zehn Jahren um 147.098 Wohnungen bzw. 7,8 % gewachsen. 2023 hat er sich in allen Berliner Bezirken erhöht, am stärksten in Lichtenberg (+2,1 %), Marzahn-Hellersdorf (+1,4 %) und Treptow-Köpenick (+1,4 %). Unter 0,5 % lag die Steigerung in Friedrichshain-Kreuzberg, Steglitz-Zehlendorf, Neukölln und Reinickendorf.

Über die meisten Wohnungen verfügte der Bezirk Pankow, gefolgt von Mitte und Charlottenburg-Wilmersdorf. Die Bezirke mit dem geringsten Wohnungsbestand waren Spandau und Reinickendorf.

### Kontakt

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Wohngebäude- und Wohnungsbestand in Brandenburg**

1.379.845 Wohnungen gab es am Jahresende 2023 in Brandenburg, 10.814 Wohnungen bzw. 0,8 % mehr als Ende 2022. Durch den Bau neuer Gebäude kamen 10.806 Wohnungen hinzu. Weitere 1.168 Wohnungen entstanden durch Baumaßnahmen an bestehenden Gebäuden.

In Ein- und Zweifamilienhäusern befand sich knapp die Hälfte aller Brandenburger Wohnungen (49,2 %), in Mehrfamilienhäusern 47,6 %, 0,9 % in Wohnheimen und 2,3 % in Nichtwohngebäuden. 87,3 % der 699.408 Wohngebäude einschließlich Wohnheimen waren Ein- und Zweifamilienhäuser.

56,6 % der neuen Wohnungen (6.112) kamen im Berliner Umland hinzu, 2.651 in Ein- und Zweifamilienhäusern und 3.404 in Mehrfamilienhäusern einschließlich Wohnheimen. Im Weiteren Metropolenraum entstanden 2.665 neue Wohnungen in Ein- und Zweifamilienhäusern und 1.989 Wohnungen in Mehrfamilienhäusern einschließlich Wohnheimen.

In den letzten zehn Jahren hat sich der Wohnungsbestand in Brandenburg um 93.324 Wohnungen bzw. 7,3 % erhöht. Den größten Bestandszuwachs an Wohnungen gab es 2023 im Landkreis Dahme-Spreewald (+1.537). Unter den kreisfreien Städten war der Zuwachs in Potsdam mit einem Plus von 619 Wohnungen am höchsten. Alle kreisfreien Städte und Landkreise bilanzierten eine positive Bestandsentwicklung.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4aac71b52121b88e/106b9da396c7/SB_F01-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/bccfac3f2c82fe76/bff226de8ede/SB_F01-01-00_2023j01_BB.pdf)
### Kontakt

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Fortschreibung des Wohngebäude- und Wohnungsbestandes ist eine dezentrale Statistik in Form eines Rechenmodells anhand vorliegender Statistiken. Aufgesetzt wird auf der jeweils letzten allgemeinen Gebäude- und Wohnungszählung. Dafür werden die Statistiken der Baufertigstellungen und Bauabgänge herangezogen. Liegt der Wohngebäude- und Wohnungsbestand der letzten allgemeinen Gebäude- und Wohnungszählung vor, werden anhand von Zu- und Abgängen des Berichtsjahrs (Baufertigstellungen, Bauabgänge) die Bestandsdaten zum 31.12. des jeweiligen Berichtsjahrs berechnet.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Fortschreibung des Wohngebäude- und Wohnungsbestandes**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/cd5fc3a1c63391d5/7cb149e3b287/MD_31231_2022.pdf)[Archiv](/search-results?q=MD_31231&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/f-i-1-j)
