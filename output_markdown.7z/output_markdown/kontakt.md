

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

Kontakt
=======

#### So erreichen Sie uns.

![](https://download.statistik-berlin-brandenburg.de/a83899ace657209a/4679d9db80fb/v/4a2814d45dfe/schmuckbild-hauptstandort-potsdam.jpg)![](https://download.statistik-berlin-brandenburg.de/4538da37488a29f3/f7d981ba9a34/v/a94ebdee2c11/schmuckbild-standort-berlin.jpg)![](https://download.statistik-berlin-brandenburg.de/aacec299f409778d/bdf4bc89ff84/v/beaf2576c393/schmuckbild-hauptstandort-cottbus.jpg)
### Hauptstandort Potsdam

Steinstraße 104–106  
14480 Potsdam  
**Telefon:** 0331 8173-1777  
**Fax:** 0331 817330-4091

**Anbindung öffentliche Verkehrsmittel:**   
Bus 118/694/601

**Der Informationsservice ist telefonisch für Sie erreichbar:**  
Montag bis Donnerstag 8.00 bis 15.30 Uhr,  
Freitag 8.00 Uhr bis 13.30 Uhr.  
Außerhalb dieser Sprechzeiten senden Sie uns bitte eine E-Mail.

[E-Mail senden](mailto:info@statistik-bbb.de)

Ihr Browser kann leider keine eingebetteten Frames anzeigen:
Sie können die eingebettete Seite über den folgenden Verweis aufrufen:
[SELFHTML](https://wiki.selfhtml.org/wiki/Startseite)


#### Standort Berlin

Alt-Friedrichsfelde 60  
10315 Berlin  
**Telefon:** 0331 8173-1777  
**Fax:** 0331 817330-4091

**Anbindung öffentliche Verkehrsmittel:**   
Bus 194, S-Bahn

Ihr Browser kann leider keine eingebetteten Frames anzeigen.


#### Standort Cottbus

Tranitzer Str. 16  
03048 Cottbus  
**Telefon:**0331 8173-1777  
**Fax:**0331 817330-4091

**Anbindung öffentliche Verkehrsmittel:**   
Tram 1/5

Ihr Browser kann leider keine eingebetteten Frames anzeigen.



