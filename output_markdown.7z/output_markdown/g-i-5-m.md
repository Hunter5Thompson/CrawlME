

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Handel](/wirtschaft/wirtschaftbereiche/handel)
* [Umsatz und Beschäftigung im Kraftfahrzeughandel einschl. Instandhaltung und Reparatur und im Großhandel in Berlin und Brandenburg](/g-i-5-m)

Umsatz und Beschäftigung im Kraftfahrzeughandel einschl. Instandhaltung und Reparatur und im Großhandel
-------------------------------------------------------------------------------------------------------

#### September 2024, monatlich

###### Die monatlichen Erhebungen zum Kraftfahrzeug- und Großhandel liefern kurzfristige Informationen zur konjunkturellen Entwicklung dieser Bereiche. Dazu zählen Daten zu Umsatz und tätigen Personen aufgegliedert nach Wirtschaftsbereichen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8c241241495a2c84/0d2c74b64083/SB_G01-05-00_2024m09_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/2b935ab18754c8c1/f4bb0d16058a/SB_G01-05-00_2024m09_BE.pdf)

**Umsatzrückgang im Handel mit Kraftwagen und im Großhandel**

Im September 2024 lag der reale (preisbereinigte) Umsatz im Berliner Kraftfahrzeughandel, einschließlich Instandhaltung und Reparatur, um 6,2 % unter dem Niveau des Vorjahresmonats.

Besonders stark war der Rückgang im Handel mit Kraftwagen, wo die Umsätze um 15,5 % sanken. In der Instandhaltung und Reparatur von Kraftfahrzeugen verzeichnete man ebenfalls ein Minus von 1,1 %. Im Gegensatz dazu meldete der Handel mit Kraftwagenteilen und -zubehör eine Umsatzsteigerung von 13,3 %. Die Anzahl der tätigen Personen im gesamten Berliner Kraftfahrzeughandel stieg im Vergleich zum Vorjahr um 3,6 %.

Für die Berliner Großhändler, einschließlich Handelsvermittlungen, ergab sich ein realer Umsatzrückgang von 6,0 %, während die Zahl der Beschäftigten in diesem Bereich um 3,7 % zurückging.

  


### Kontakt

#### Robby Trinks

Handel Konjunktur

#### Robby Trinks

Handel Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Höhere Umsätze im Handel mit Ersatzteilen und Zubehör**

Im September 2024 lag der reale (preisbereinigte) Umsatz im Brandenburger Kraftfahrzeughandel, einschließlich Instandhaltung und Reparatur, um 0,4 % über dem Niveau des Vorjahresmonats.

Im Handel mit Kraftwagen zeigte sich ein Umsatzrückgang von 2,8 %. Im Gegensatz dazu stiegen die Umsätze im Handel mit Kraftwagenteilen und -zubehör um 7,6 %. In der Instandhaltung und Reparatur von Kraftfahrzeugen wurden 2,1 % mehr umgesetzt. Insgesamt stieg die Beschäftigtenzahl im gesamten Brandenburger Kraftfahrzeughandel im Vergleich zum Vorjahr um 0,7 %.

Die Brandenburger Großhändler, einschließlich Handelsvermittlungen, verzeichneten einen realen Umsatzrückgang von 1,0 %, während die Zahl der Beschäftigten in diesem Bereich um 0,7 % stieg.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/12a2d9d00a177260/c5a202ab0daf/SB_G01-05-00_2024m09_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/d22c662e28df8b67/32153bdec2e7/SB_G01-05-00_2024m09_BB.pdf)
### Kontakt

#### Robby Trinks

Handel Konjunktur

#### Robby Trinks

Handel Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die monatlichen Erhebungen im Kraftfahrzeughandel einschl. Instandhaltung und Reparatur von Kfz und im Großhandel (einschließlich Handelsvermittlung) liefern kurzfristige Informationen zur Beurteilung der konjunkturellen Entwicklung dieser Wirtschaftsbereiche. Erhoben werden der Nettoumsatz (ohne Umsatzsteuer) sowie die Zahl der tätigen Personen. Die Ergebnisse der monatlichen Statistik werden als Messzahlen und Veränderungsraten ausgewiesen.

Alle Messzahlen und Veränderungsraten sind, soweit sie Erhebungszeiträume des aktuellen Jahres und des Vorjahres betreffen, vorläufig und werden monatlich rückwirkend durch nachträglich eingehende Meldungen und Korrekturen der in die Berichtskreise einbezogenen Unternehmen aktualisiert.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatsstatistik im Einzelhandel**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/45e77d946b49d27b/113bc6c8c6ca/MD_45212_2024.pdf)[Archiv](/search-results?q=MD_45212&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-i-5-m)
