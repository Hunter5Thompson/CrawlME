

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Energie](/energie)
* [Energie- und CO₂-Bilanz in Berlin und Brandenburg](/e-iv-4-j)

Energie- und CO₂-Bilanz
-----------------------

#### 2022, jährlich

###### Die Daten geben Auskunft über das Aufkommen und die Verwendung von Energieträgern sowie die energiebedingten CO2-Emissionen in den Wirtschaftsräumen Berlin und Brandenburg. Berechnungsgrundlage ist die Methodik des „Länderarbeitskreises Energiebilanzen“.

BerlinBrandenburgMethodik
### Berlin

1 Fossiler Anteil des Abfalls.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a67d8fc8e8e0529b/078ba8846dca/SB_E04-04-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/5b3e078a1c9aee1c/541dc16dd777/SB_E04-04-00_2022j01_BE.pdf)

**Sinkender Erdgasverbrauch im Jahr 2022**

In den endgültigen Energie- und CO2-Bilanzen 2022 wurde ein Rückgang des Energieverbrauchs und der energiebedingten CO2-Emissionen verzeichnet. Aufgrund der Gasmangellage wurden Einsparungen insbesondere beim Energieträger Erdgas beobachtet.

Der Endenergieverbrauch von Erdgas ging gegenüber dem Vorjahr um 12,7 % auf 46.178 Terajoule zurück. Der Primärenergieverbrauch und der Endenergieverbrauch gingen insgesamt um 5,0 % und 5,5 % zurück. Einsparungen wurden ebenfalls beim Energieträger Fernwärme (–10,8 %) ermittelt.

Die CO2-Emissionen sanken infolgedessen ebenfalls. Nach Quellenbilanz um 4,9 % auf 12,8 Mill. Tonnen und nach Verursacherbilanz um 1,8 % auf 15,1 Mill. Tonnen. Die Gesamtemissionen (Verursacherbilanz) lagen demnach um 48,5 % unter dem Niveau des Basisjahres 1990.

### Kontakt

#### Mathias Geburek

Energiebilanzen

#### Mathias Geburek

Energiebilanzen

* [0331 8173-3817](tel:0331 8173-3817)
* [energiebilanzen@statistik-bbb.de](mailto:energiebilanzen@statistik-bbb.de)
* [0331 817330-4013](fax:0331 817330-4013)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Rückgang des Energieverbrauchs und Zunahme der CO2-Emissionen**

Im Jahr 2022 ging der Primärenergieverbrauch um 4,9 % im Vergleich zum Vorjahr zurück. Ursache war der Rückgang beim Verbrauch von "Gase" (–9,2 %) und Mineralölen (–2,4 %). Der Primärenergieverbrauch betrug somit 579,2 Petajoule.

Der Endenergieverbrauch betrug im Jahr 2022 295,7 PJ und damit 0,1 % weniger als im Vorjahr. Insbesondere "Strom" (–3,8 %) und "Fernwärme und Andere" (–4,8 %)  wurden weniger verbraucht. Die CO2-Emissionen nach Verursacherbilanz stiegen hingegen um 2,7 %, allein im Sektor Verkehr um 9,8 %. Dies lag am zunehmenden Flugverkehr (+73,5 %).

Die Stromerzeugung sank um 1,3 % auf nun 49.436 Gigawattstunden. Dabei fielen 45,8 % der Stromerzeugung auf Braunkohle, gefolgt von erneuerbaren Energien mit 42,7 %. Ein erheblicher Teil des in Brandenburg erzeugten Stroms wird in andere Bundesländer ausgeführt.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/53d004370dafe133/7c7fc70b8275/SB_E04-04-00_2022j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/a83646fb8e7d1654/dbdc8a94243c/SB_E04-04-00_2022j01_BB.pdf)
### Kontakt

#### Mathias Geburek

Energiebilanzen

#### Mathias Geburek

Energiebilanzen

* [0331 8173-3817](tel:0331 8173-3817)
* [energiebilanzen@statistik-bbb.de](mailto:energiebilanzen@statistik-bbb.de)
* [0331 817330-4013](fax:0331 817330-4013)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Energiebilanzen geben Aufschluss über die energiewirtschaftliche Entwicklung in den Ländern Berlin und Brandenburg, mit Aussagen über den Verbrauch von Energieträgern in einzelnen Sektoren sowie deren Fluss von der Erzeugung bis zur Verwendung in den verschiedenen Umwandlungs- und Verbrauchsbereichen. Unter Energieträgern versteht man alle Quellen, aus denen direkt oder durch Umwandlung Energie gewonnen wird.

In den CO2-Bilanzen wird die Gesamtmenge des emittierten Kohlendioxids, getrennt nach Energieträgern, in den Sektoren nachgewiesen. Die Bilanzierung der energiebedingten CO2-Emissionen erfolgt nach einer im Länderarbeitskreis Energiebilanzen abgestimmten Methodik. Den Berechnungen liegen die Energiebilanzen zu Grunde. Daneben werden spezifische, auf den Heizwert eines Energieträgers bezogene CO2-Faktoren benötigt, die das Umweltbundesamt zur Verfügung stellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

Zu diesem Bericht sind keine Metadaten vorhanden. Mehr Informationen finden Sie auf der [**Website des Länderarbeitskreises Energiebilanzen**](http://www.lak-energiebilanzen.de).

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-iv-4-j)


