

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Schwerpunkte](/schwerpunkte)
* [Auswirkungen des Ukraine-Krieges](/schwerpunkte/ukraine)
#### Schwerpunktthema

Auswirkungen des
================

Ukraine-Krieges
===============

Inwieweit die Menschen in der Hauptstadtregion die Folgen des Konflikts trifft, zeigen wir Ihnen auf dieser Themenseite.  Ausgehend vom aktuellen Ist-Zustand beleuchten wir – je nach Verfügbarkeit aktueller Daten – die Auswirkungen und Folgen in der Bevölkerung, in Bildungseinrichtungen, im Portemonnaie sowie in verschiedenen Wirtschaftsbereichen.

Die Seite wird aktualisiert bis zum Berichtszeitraum 2023.  


BevölkerungBildungPreiseEnergieWirtschaftPressemitteilungen

Bevölkerung
-----------

**Wie viele Menschen mit ukrainischer oder russischer Staatsangehörigkeit leben in der Hauptstadtregion, wieviele lassen sich in Berlin und Brandenburg nieder und wieviele nehmen soziale Leistungen in Anspruch?**

**Quelle:** Amt für Statistik Berlin-Brandenburg

**Wanderung:** 2023 zogen gegenüber 2022 erneut mehr Menschen von Russland nach **Berlin** (3.432), während 1.027 Personen Berlin in Richtung Russland verließen. Im Saldo hatte Berlin eine Nettozuwanderung von 2.405 Personen gegenüber Russland. Die Zuwanderung aus der Ukraine sank im Jahr 2023 auf 11.759, während 6.282 Personen von Berlin in die Ukraine umzogen. Die Nettozuwanderung aus der Ukraine betrug im Saldo 5.477 Personen. Auch in **Brandenburg** sind die Folgen des Kriegsgeschehens in der Ukraine weiter spürbar, wenn auch auf niedrigerem Niveau. Im Jahr 2023 war gegenüber dem Vorjahr eine niedrigere Nettozuwanderung aus Russland in Höhe von 190 und aus der Ukraine in Höhe von 1.375 Personen zu verzeichnen.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

ukrainische Staatsangehörige lebten  
am 31.12.2023 in der Hauptstadtregion.

**Einbürgerung:** 2023 erhielten in Berlin 9.041 Personen und in Brandenburg 2.488 Personen die deutsche Staatsbürgerschaft. Die 332 in Berlin und 142 in Brandenburg eingebürgerten Ukrainerinnen und Ukrainer leben seit durchschnittlich 14,1 Jahren in Deutschland. Aus der Russischen Föderation nahmen in Berlin 205 und in Brandenburg 41 Personen die deutsche Staatsbürgerschaft an. Die meisten Einbürgerungen fanden nach § 10 Abs. 1 StAG (im Inland wohnhafte Ausländer mit einem Mindestaufenthalt von 8 Jahren in Deutschland) statt.

**Quelle:** Amt für Statistik Berlin-Brandenburg
###### am Ort der Hauptwohnung in Berlin am 31.12.2023

#### Melderechtlich registrierte ukrainische Staatsangehörige

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

**Quelle:** Amt für Statistik Berlin-Brandenburg, Einwohnerregisterstatistik**Quelle:** Amt für Statistik Berlin-Brandenburg, Einwohnerregisterstatistik

**Die Zahl der ukrainischen Wohnbevölkerung in Berlin nahm 2023 weiter zu. Mit einem Zuwachs um 5.000 auf 62.495****Personen bildet sie die zweitstärkste ausländische Gruppe in der Stadt. Platz 1 nehmen weiterhin Staatsangehörige aus der Türkei mit 107.022 Personen ein.**

Die **Einwohnerregisterstatistik** bereitet die Daten des Berliner Einwohnermelde­registers des Landesamtes für Bürger und Ordnungsangelegenheiten statistisch auf. Im Unterschied zur amtlichen Bevölkerungs­fortschreibung wird in der Einwohner­register­statistik eine stichtagsbezogene Bestandänderung im Register dargestellt. Somit ist eine Vergleichbarkeit mit den Daten der Bevölkerungs­statistik nicht gegeben.

\* Zu Zwecken der Geheimhaltung erfolgt die Veröffentlichung der Ergebnisse unter Anwendung der 5er-Rundung. Der Insgesamtwert kann von der Summe der Einzelwerte abweichen.**Quelle:** Amt für Statistik Berlin-Brandenburg\* Anteil in der ukrainischen bzw. russischen Bevölkerung in Berlin (Bevölkerungsstand: 31.12. des jeweiligen Jahres). Zu Zwecken der Geheimhaltung erfolgt die Veröffentlichung der Ergebnisse unter Anwendung der 5er-Rundung. Der Insgesamtwert kann von der Summe der Einzelwerte abweichen.**Quelle:** Amt für Statistik Berlin-Brandenburg

Bildung
=======

**Bildung ist grundlegend für die Zukunft eines Kindes, besonders in einem erst einmal fremden Land. Sie beginnt in jungen Jahren in der Kita und reicht bis zur beruflichen Bildung oder einem Studium.****Wie ist die Bildungsbeteiligung von Personen mit ukrainischer und russischer Staatsangehörigerigkeit in unserer Region?**

##### Auslastung der Kindertageseinrichtungen am 01.03.2024

#### Berlin: 86,5 %Brandenburg: 87,4 %

Hinweis Die Schülerzahlen für das Schuljahr 2022/2023 wurden berichtigt, rote Markierung in Excel-Datei.**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg\* Bildungsinländer sind ausländische Studierende, die ihre Hochschulzugangsberechtigung in Deutschland, aber nicht an einem Studienkolleg erworben haben.**Quelle:** Amt für Statistik Berlin-BrandenburgHinweis Für Kita-Kinder liegen keine Daten nach einzelnen Staatsangehörigkeiten in der amtlichen Statistik vor.**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

**Bildungsinländer**sind ausländische Studierende, die ihre Hochschulzugangsberechtigung in Deutschland erworben haben.

\* Bildungsinländer sind ausländische Studierende, die ihre Hochschulzugangsberechtigung in Deutschland, aber nicht an einem Studienkolleg erworben haben.**Quelle:** Amt für Statistik Berlin-Brandenburg

Preise
======

**Die Preise steigen. Begonnen mit der Corona-Pandemie dreht sich die Preisspirale unter dem Druck der Ukraine-Krise unaufhörlich weiter. Wir merken es u.a. an der Supermarktkasse und an der Zapfsäule. Welche Produkte sind besonders betroffen? Wie stark ist die Veränderung im Vergleich zum Vorjahr?**

**Quelle:** Amt für Statistik Berlin-Brandenburg![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)

Die Verbraucherpreise erhöhten sich im Jahresdurchschnitt 2023 gegenüber dem Vorjahr in Berlin um 6,2 % und in Brandenburg um 6,5 %. Damit schwächte sich die Teuerung im Vergleich zu 2022 ab. Einen hohen Anteil an der Teuerung hatten die Nahrungsmittelpreise. Sie stiegen im Jahresdurchschnitt in Berlin um 12,2 %, in Brandenburg um 13,8 %.

![](https://download.statistik-berlin-brandenburg.de/9046063cf1b29180/d2e02cfec38e/v/253c174afacf/wirtschaft-preise-electricity-savings-and-euro-banknotes-picture-id1203584875.jpg)

Die **Preise für Energie** stiegen im Dezember 2023 gegenüber dem Vorjahresmonat in Berlin um 12,4 % und in Brandenburg um 3,2 %. Deutlich günstiger war leichtes Heizöl mit einem Minus von 11,2 % in Berlin und 18,8 % in Brandenburg.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
##### Durchschnittliche Tagespreise an öffentlichen Tankstellen stellt das Statistische Bundesamt im [Dashboard Deutschland](https://dashboard-deutschland.de/#/themen/konjunktur_wirtschaft/preise) bereit.

Energie
=======

**Wie setzt sich die Energieversorgung in der Haupstadtregion zusammen? Wie hoch ist der Anteil erneuerbarer Energien in beiden Ländern?**

¹ Sitz der einspeisenden Anlagen**Quelle:** Amt für Statistik Berlin-Brandenburg

**Anteil erneuerbarer Energien bei der Stromeinspeisung**  
**in das Stromnetz im Dezember 2023**

### Berlin: 3,4 %Brandenburg: 52,7 %

**Anteil von Gas bei der Stromeinspeisung**  
**in das Stromnetz im Dezember 2023**

### Berlin: 76,9 %Brandenburg: 5,3 %

¹ Sitz der einspeisenden Anlagen**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Die **Nettowärmeerzeugung**ist die gemessene nutzbare Wärme, die in einer Berichtszeit von einer Wärme­erzeugungsanlage (Heizwerks- oder Kraftwerksprozess) an Endverbraucher abgegeben wurde.

In Berlin lag sie im Dezember 2022 bei 1.429 GWh. Erdgas hatte dabei einen Anteil von 70,9 %. In Brandenburg lag der Gas-Anteil bei 32,9 %.

Wirtschaft
==========

**Vor allem energieintensive Wirtschaftszweige spüren die Abhängigkeit Deutschlands von russischem Öl oder Gas. Unterbrochene Lieferketten, ausgefallene Ernten, steigende Produktionskosten machen der Industrie, dem Handel und vielen anderen Branchen in der Region zu schaffen. Wieviele Meschen arbeiten in Wirtschaftszweigen, die viel Energie benötigen? Und wie sieht es mit der Versorgung mit Gütern aus?**

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg Für die Wirtschaftsabteilung "Kokerei und Mineralölverarbeitung" sind die Werte unbekannt oder geheim zu halten. **Quelle:** Amt für Statistik Berlin-Brandenburg Für die Wirtschaftsabteilung "Kokerei und Mineralölverarbeitung" sind die Werte unbekannt oder geheim zu halten. **Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Statistisches Bundesamt**Quelle:** Statistisches Bundesamt

Der **Berliner Außenhandel** legte 2023 bei den Importen um 10,2 % zu und erreichte einen Wert von 20,2 Mrd. EUR. Die Exporte blieben mit 0,1 % Steigerung nahezu auf dem Vorjahresniveau. Sie lagen bei einem Wert von 16,7 Mrd. EUR. Die Ausfuhren nach Russland gingen um 41,0 % zurück und die Einfuhren um 57,3 %. Richtung Ukraine sanken die Exporte minimal um 0,1 % und die Importe um 9,1 %. In **Brandenburg** stiegen die Ausfuhren um 31,0 % auf 23,5 Mrd. EUR. Die Einfuhren gingen hingegen um 5,1% auf 25,2 Mrd. EUR zurück. **Vor allem die Importe aus Russland brachen um 98,3 % ein.** Die Exporte nach Russland stiegen um 18,1 %. Im Handel mit der Ukraine stiegen die Ausfuhren um 11,0 % und die Einfuhren sanken um 6,3 %.

![](https://download.statistik-berlin-brandenburg.de/a941f7bf0a2c6a6b/a7e40f5c0908/v/cdb0509c65dc/wirtschaft-volkswirtschaft-container.jpg)**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
### Pressemitteilungen zum Thema

[![iStock.com / Dmytro Varavin](https://download.statistik-berlin-brandenburg.de/dafdd0edce64b1a7/f48269a57bf6/v/bdbe069a4e98/bevoelkerung-demographie-aerial-interested-crowd-of-people-in-one-place-top-view-from-drone-picture-id1190039899.jpg "iStock.com / Dmytro Varavin")](/141-2024)**Einwohnerregisterstatistik Berlin, Stand: 30.06.2024**[#### Weniger Wachstum als im 1. Halbjahr 2023](/141-2024)

Pressemitteilung Nr. 141 Am 30. Juni 2024 waren im Einwohnerregister Berlin rund 3.886.000 Einwohnerinnen und Einwohner mit Hauptwohnsitz erfasst. Damit ist die Bundeshauptstadt im 1. Halbjahr 2024...

[![iStock.com / Alexey_Fedoren](https://download.statistik-berlin-brandenburg.de/ad3b2d87c9da676d/1401756d9bd8/v/337c8ff93757/bevoelkerung-gesellschaft-aerial-view-of-brandenburg-gate-in-berlin-picture-id1216855080.jpg "iStock.com / Alexey_Fedoren")](/020-2024)**Einwohnerregisterstatistik 31.12.2023 Berlin**[#### Berlin international: Anteil nicht-deutscher Staatsangehörigkeit bei 24,4 Prozent](/020-2024)

Pressemitteilung Nr. 20 Zum Stichtag 31.12.2023 registrierte das Einwohnermelderegister 946.369 Personen nicht-deutscher Staatsangehörigkeit. Mit einem Zuwachs von 46.225 ausländischen Personen, 5,1...

[![iStock.com / Vladimir Vladimirov](https://download.statistik-berlin-brandenburg.de/28f89edc69872268/e06d02e6b471/v/d5c20a972f18/bevoelkerung-gesellschaft-tourist-in-berlin-picture-id1213944145.jpg "iStock.com / Vladimir Vladimirov")](/168-2023)**Einwohnerregisterstatistik 30.06.2023 Berlin**[#### Berlin wächst im 1. Halbjahr 2023 um 15.576 Personen](/168-2023)

Pressemitteilung Nr. 168 Am 30.06.2023 waren 3,87 Millionen (Mill.) Einwohnerinnen und Einwohner mit Hauptwohnsitz im Berliner Einwohnermelderegister gemeldet. Im Vergleich zum 31.12.2022 ist die um...

[![iStock.com / hanohiki](https://download.statistik-berlin-brandenburg.de/4307297505b030fa/f8f77146a052/v/f83a507626fc/bevoelkerung-gesellschaft-people-at-park-on-a-sunny-day-in-berlin-picture-id685461162.jpg "iStock.com / hanohiki")](/117-2023)**Amtliche Bevölkerungsfortschreibung 2022 für Berlin**[#### Bevölkerung wächst durch hohe Zuwanderung aus dem Ausland](/117-2023)

Pressemitteilung Nr. 117 In Berlin lebten am 31.12.2022 laut amtlicher Bevölkerungsstatistik insgesamt 3 755 251 Menschen, 77 779 Menschen bzw. 2,1 Prozent mehr als ein Jahr zuvor. Damit erreichte...

[![iStock.com / RomanBabakin](https://download.statistik-berlin-brandenburg.de/cf6b1747e2224019/eede7a24f6d9/v/98550d5aeb7f/bevoelkerung-gesellschaft-iStock-587203648.jpg "iStock.com / RomanBabakin")](/118-2023)**Amtliche Bevölkerungsfortschreibung 2022 für Brandenburg**[#### Wachstumsrekord bei Brandenburger Bevölkerung](/118-2023)

Pressemitteilung Nr. 118 Am 31.12.2022 lebten im Land Brandenburg 2 573 135 Menschen, 35 267 Menschen bzw. 1,4 Prozent mehr als ein Jahr zuvor. Das ist der stärkste Bevölkerungsanstieg, den die...

[![Antrag Einbürgerung, Copyright: Stadtratte](https://download.statistik-berlin-brandenburg.de/82c9efc5ac797917/55d7a34c9f97/v/54a1575c336f/bevoelkerung-einbuergerung-iStock-839845642-.jpg "Antrag Einbürgerung, Copyright: Stadtratte")](/093-2023)**Einbürgerungsstatistik 2022 für Berlin und Brandenburg**[#### Mehr syrische und ukrainische Staatsangehörige eingebürgert](/093-2023)

Pressemitteilung Nr. 93 2022 erhielten in Berlin 8 875 Personen und in Brandenburg 1 197 Personen die deutsche Staatsbürgerschaft. Wie das Amt für Statistik Berlin-Brandenburg mitteilt, bekamen...

Mehr anzeigen
