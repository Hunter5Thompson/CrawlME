

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Daten melden](/daten-melden)
* [So erkennen Sie, dass wir es sind.](/daten-melden/fakt-oder-fake)

Fakt oder Fake?
===============

#### Aufforderung zur Datenlieferung: An diesen Hinweisen erkennen Sie das Amt für Statistik Berlin-Brandenburg.

**Gefälschte Anschreiben, Spam-Mails u. Ä. sind ein Problem unserer Zeit. Wir möchten Ihnen Hinweise an die Hand geben, damit Sie sicher sein können, dass eine Aufforderung zur Datenlieferung auch tatsächlich von uns, dem Amt für Statistik Berlin-Brandenburg, kommt:**

Eine Aufforderung zur Datenmeldung für die amtliche Statistik erhalten Sie von uns immer schriftlich.

  


Achten Sie bei den benannten Kontaktdaten auf folgende Hinweise:

  


• E-Mail-Adressen enden immer auf: **...@statistik-bbb.de**

• Telefonnummern beginnen mit **0331 8173 -**

  


Wir fordern Sie niemals auf, uns persönliche Daten per E-Mail zu schicken. Zum Schutz Ihrer Daten sind wir verpflichtet. Daher erfolgen elektronische Datenmeldungen an uns nur über unsere Online-Meldeverfahren, die strengen IT-Sicherheitsvorgaben unterliegen.

###### **Achtung! Ein Logo ist kein Echtheitsgarant:**

Anschreiben erkennen Sie zwar an unserem Logo, allerdings kann dieses über entsprechende Programme kopiert und unrechtmäßig verwendet werden, sodass dies kein sicheres Indiz für die Echtheit des Schreibens ist.

Wenn Sie dennoch unsicher sind, ob ein Schreiben von uns ist, rufen Sie einfach unseren Infoservice unter **0331 8173 -1777** an und sprechen Sie direkt mit uns oder schreiben Sie eine Mail: [**info@statistik-bbb.de**](mailto:info@statistik-bbb.de).

**Sie haben Fragen?**
---------------------

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)

[* Fakt](/search-results?q=tag%3AFakt)[* Fake](/search-results?q=tag%3AFake)[* Fakenews](/search-results?q=tag%3AFakenews)
