

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Mikrozensus](/bevoelkerung/demografie/mikrozensus)

Mikrozensus
===========

Wie leben die Menschen in Berlin und Brandenburg? Was prägt die Lebensverhältnisse der Erwerbstätigen, der Seniorinnen und Senioren, der Alleinerziehenden? Wie werden die Kinder betreut, und welche Bildungswege werden eingeschlagen? Wie wohnen wir in der Hauptstadtregion? Antworten auf solche Fragen gibt der Mikrozensus.

Es handelt sich um eine repräsentative amtliche Befragung von 1 % aller Haushalte in Deutschland. Der Mikrozensus ist eine wichtige Planungs- und Entscheidungsgrundlage für Politik und Verwaltung und eine nachgefragte Informationsquelle für Medien, Wissenschaft und die interessierte Öffentlichkeit.

###### Wie werden die Daten erhoben?

In jedem Jahr werden 1 % aller Haushalte in Deutschland befragt – in Berlin rund 18 000 und in Brandenburg rund 11 000 Haushalte. Die Befragung findet persönlich (telefonisch), online oder mittels Papierfragebogen statt. In die Zufallsauswahl gelangen Gebäude und Gebäudeteile. Die darin wohnenden Personen werden bis zu vier Mal befragt. Für den überwiegenden Teil der Fragen besteht Auskunftspflicht, damit die Ergebnisse des Mikrozensus ein Abbild der gesamten Bevölkerung darstellen.

###### Welche Daten werden im Mikrozensus erhoben?

Der Mikrozensus erhebt u. a. Informationen zur Haushalts- und Familienstruktur, zu Schule und Studium, Aus- und Weiterbildung, Erwerbstätigkeit und Arbeitssuche, Lebensunterhalt und Einkommen, Kinderbetreuung, Internetnutzung und Wohnsituation. Die Themen des Mikrozensus sind gesetzlich festgelegt. Namen und Adressinformationen dienen der Erhebungsorganisation, werden getrennt von den Befragungsinhalten gespeichert, geheim gehalten und nach Abschluss der Datenerhebung und -aufbereitung gelöscht.

###### Wozu werden die Daten erhoben?

Der Mikrozensus informiert Politik und Verwaltung bei wichtigen Planungen und Entscheidungen, u. a. bei Anpassungen des Eltern- oder Wohngeldes und der Rente. Mikrozensusdaten fließen in die Armuts- und in die Kinder- und Jugendberichterstattung des Bundes und der Länder ein, wie auch in die Arbeitsmarkt- und Berufsforschung. In den Mikrozensus sind EU-weit vergleichbare Statistiken integriert, die u. a. benötigt werden, um EU-Mittel aus den Regional- und Sozialfonds gerecht zu verteilen.

Statistische BerichteZusammenlebenBildungswegeErwerbslebenEinkommen/ArmutWohnsituationWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Ergebnisse des Mikrozensus in Berlin und Brandenburg, jährlich (AI10, AI11, AVI2-j)](/a-i-10-a-i-11-a-vi-2-j)[Ergebnisse des Mikrozensus in Berlin und Brandenburg – Wohnsituation, vierjährlich (FI2-4j)](/f-i-2-4j)

Formen des Zusammenlebens
-------------------------

#### Dieser Themenbereich behandelt grundlegende Haushalts- und Familienstrukturen: Leben die Menschen vorwiegend allein oder in Mehrpersonenhaushalten? Wie viele Familien mit Kindern gibt es in Berlin und Brandenburg und wie alt sind die Kinder? Wie hoch ist die Zahl der Alleinerziehenden? Und wie viele Ehepaare und Lebensgemeinschaften, gleich- oder gemischtgeschlechtlich, leben in der Region?

Familienformen und KinderbetreuungPrivathaushalteZeitreihen: KinderzahlBasisdaten: Lebensformen**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Bildungswege
------------

#### Welche Betreuungsangebote für die Kleinsten werden wahrgenommen? Welche allgemeinbildenden, berufs- oder weiterbildenden Schulen werden von den Menschen besucht? Wie unterscheiden sich die Bildungsabschlüsse nach Altersgruppe, Geschlecht oder Migrationshintergrund? Und wie sehen die Unterschiede zwischen den Berliner Bezirken und den Brandenburger Landkreisen und kreisfreien Städten aus?

BildungsabschlüsseZeitreihe: GeringqualifizierteBasisdaten: allgemeiner SchulabschlussBasisdaten: beruflicher Bildungsabschluss**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Erwerbsleben
------------

#### Die Frage nach der Beteiligung am Erwerbsleben unterscheidet zwischen Erwerbstätigen, Erwerbslosen und Nichterwerbspersonen – dies sind beispielsweise Personen unter 15 Jahre. Wir zeigen in welchen Branchen die Erwerbstätigen arbeiten, ob als Selbstständige, Arbeiter oder Angestellte, ob in Vollzeit oder Teilzeit. Welche Besonderheiten ergeben sich mit Blick auf die Geschlechter oder den Bildungsabschluss?

Zeitreihe: ErwerbstätigenquoteBasisdaten: Beteiligung am ErwerbslebenMännliche ErwerbstätigeWeibliche Erwerbstätige\* Erstergebnisse1  Anteil der Erwerbstätigen an der Bevölkerungsgruppe**Quelle:** Amt für Statistik Berlin-Brandenburg\* Erstergebnisse1  Anteil der Erwerbstätigen an der Bevölkerungsgruppe**Quelle:** Amt für Statistik Berlin-Brandenburg

Einkommen und Armut
-------------------

#### Die Einkommen und Lebensverhältnisse der Berliner und Brandenburger Haushalte unterscheiden sich zwischen den Bevölkerungsgruppen und mit regionalen Besonderheiten. Als Gruppen mit einem höheren Armutsrisiko gelten Familien mit mehreren Kindern, Alleinerziehende, alte Menschen, Geringqualifizierte oder Menschen mit Migrationshintergrund.

#### Regionaler

#### Sozialbericht 2021 fürBerlin/Brandenburg

[Zum Sozialbericht](/publikationen#sonderveroeffentlichungen)Bevölkerung nach LebensunterhaltZeitreihe: ArmutsgefährdungsquoteBasisdaten: BerlinBasisdaten: Brandenburg1 Einkünfte der Eltern, auch Einkünfte vom Lebens- oder Ehepartner oder von anderen Angehörigen, Unterhaltszahlungen2 Zum Beispiel Grundsicherung im Alter und bei Erwerbsminderung, Eingliederungshilfe, Hilfe zur Pflege, Hilfe zum Lebensunterhalt3 Zum Beispiel BAföG, Vorruhestandsgeld, Stipendium, Pflegeversicherung, Asylbewerberleistungen, Pflegegeld für Pflegekinder, Elterngeld**Quelle:** Amt für Statistik Berlin-Brandenburg1  Einkünfte der Eltern, auch Einkünfte vom Lebens- oder Ehepartner oder von anderen Angehörigen, Unterhaltszahlungen2 Zum Beispiel Grundsicherung im Alter und bei Erwerbsminderung, Eingliederungshilfe, Hilfe zur Pflege, Hilfe zum Lebensunterhalt3  Zum Beispiel BAföG, Vorruhestandsgeld, Stipendium, Pflegeversicherung, Asylbewerberleistungen, Pflegegeld für Pflegekinder, Elterngeld**Quelle:** Amt für Statistik Berlin-Brandenburg

Wohnsituation
-------------

#### Wie hoch sind die Mieten in Berlin und Brandenburg? Wie stark sind die Menschen durch ihre Miete belastet, gemessen an ihrem Einkommen? Wie viel Wohnraum steht Familien in Berlin und Brandenburg zur Verfügung? Und wie sieht es mit der Barrierefreiheit in Berliner und Brandenburger Gebäuden und Wohnungen aus? Diesen und weiteren Fragen geht der Mikrozensus zur Wohnsituation nach.

BarrierereduktionZeitreihe: MietbelastungBasisdaten: BerlinBasisdaten: Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Weitere Datenangebote
---------------------

#### Erhebungsportal

![](https://download.statistik-berlin-brandenburg.de/c982a327c147aa2f/2634fbfc0847/v/31dcbd367112/mikrozensus-erhebungsportal.jpg)

Der Mikrozensus ist eine gesetzlich verbindliche, repräsentative Befragung von Haushalten in Deutschland. Hier finden Sie alle Informationen gebündelt.

[Zum Erhebungsportal](https://www.mikrozensus.de)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik für den Mikrozensus auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1716552150981&code=12211#abreadcrumb)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1716542866818&code=22#abreadcrumb)
#### Eurostat

![](https://download.statistik-berlin-brandenburg.de/58432ea843230f08/e9a1f7fde172/v/ca068ecf5813/eurostat-datenbank.jpg)

Der Mikrozensus im europäischen Vergleich findet sich in der Eurostat-Datenbank – eine offizielle Website der Europäischen Union.

[Zur Eurostat-Datenbank](https://ec.europa.eu/eurostat/de/data/database)

Haben Sie Fragen?
-----------------

#### Mikrozensusteam

Mikrozensus

#### Mikrozensusteam

Mikrozensus

* [0331 2016 4000](tel:0331 2016 4000)
* [mikrozensus@statistik-bbb.de](mailto:mikrozensus@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Eine Gruppe junger Frauen und Männer liegt mit geschlossenen Augen auf Yogamatten](https://download.statistik-berlin-brandenburg.de/fac13b4915a10f67/a1e4342c21fd/v/db251120bba7/group-of-young-sporty-people-in-dead-body-pose-picture-id846236682.jpg "Eine Gruppe junger Frauen und Männer liegt mit geschlossenen Augen auf Yogamatten")](/news/2024/gesundheit-mikrozensus)**Armut und Gesundheit in Berlin und Brandenburg**[#### Je höher das Einkommen, desto gesünder?](/news/2024/gesundheit-mikrozensus)

Menschen mit einem geringen Pro-Kopf-Einkommen sind öfter krank, übergewichtig und rauchen häufiger als der Durchschnitt der Bevölkerung....

[![iStock.com / fizkes](https://download.statistik-berlin-brandenburg.de/59ff41215e92a154/de624b8c4887/v/4dd18e6905d9/bevoelkerung-gesellschaft-young-father-playing-with-bricks-and-toys-with-little-kids-picture-id1201510270.jpg "iStock.com / fizkes")](/news/2024/nationaler-bildungsbericht-3)**10. Nationaler Bildungsbericht erschienen**[#### Familienformen in Deutschland – zwischen Nesthockern und Alleinerziehenden](/news/2024/nationaler-bildungsbericht-3)

Der erste und oft wesentliche Ort für die Sozialisation und Persönlichkeitsbildung von Kindern ist die Familie. Hier findet ein Großteil der informellen und non-formalen Bildung statt. Der 10....

[![Alte Frau im Rollstuhl führt angenehmes Gespräch mit Tee](https://download.statistik-berlin-brandenburg.de/bce0024fa4a325f9/a8d8eb37d2d9/v/e6a5a3500058/bevoelkerung-gesellschaft-rentnerin-frau-pflege-iStock-1468292192-web.jpg "Alte Frau im Rollstuhl führt angenehmes Gespräch mit Tee")](/news/2024/hochaltrige)**Die Bevölkerungsgruppe 80+ in Berlin und Brandenburg**[#### Wie leben Hochaltrige?](/news/2024/hochaltrige)

Hochaltrige – Menschen, die das 80. Lebensjahr erreicht haben – machen in Berlin 6,3 % und in Brandenburg 8,6 % der Bevölkerung aus. Eine kleiner Anteil, der aber stetig wächst. Wir zeigen Ihnen,...

[Zu unseren News](/news)
