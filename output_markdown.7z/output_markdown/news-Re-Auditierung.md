

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 08.10.2021

#### Als familien- und lebensphasenbewusster Arbeitgeber ausgezeichnet

Amt für Statistik Berlin-Brandenburg erhält erneut Zertifikat zum „audit berufundfamilie“
-----------------------------------------------------------------------------------------

![](https://download.statistik-berlin-brandenburg.de/3f3de7f85c2eec34/059234f2480f/v/d8e69fc66f7b/audit_bf_rz_18_1_RGB_Zuschnitt.png)

Für die strategische Gestaltung seiner familien- und lebensphasenbewussten Personalpolitik erhielt **das Amt für Statistik Berlin-Brandenburg am 30. September 2021 zum zweiten Mal das Zertifikat zum audit berufundfamilie.** Das drei Jahre gültige Zertifikat, das als **Qualitätssiegel für eine betriebliche Vereinbarkeitspolitik** gilt, wird vom Kuratorium der berufundfamilie Service GmbH erteilt.   


Nach der ersten Zertifizierung im Jahr 2018 stellte sich das Amt für Statistik Berlin-Brandenburg erfolgreich dem Re-Auditierungsprozess, in dem der Status quo der bereits vorhandenen familien- und lebensphasenbewussten Maßnahmen überprüft wurde und eine Vertiefung der Institutionalisierung der Vereinbarkeitspolitik und Kultur stattfand. Ein Schwerpunkt lag dabei in den Handlungsfeldern Arbeitszeit und Arbeitsort.

Im Rahmen der **Re-Auditierung** wurden nicht nur strategische Ziele, sondern auch konkrete Maßnahmen definiert, die in einer Zielvereinbarung festgehalten sind. Diese gilt es nun während der dreijährigen Zertifikatslaufzeit bedarfsgerecht zu realisieren. Die praktische Umsetzung wird von der berufundfamilie Service GmbH jährlich überprüft.

**Zu den bereits vorhandenen Maßnahmen zur Vereinbarkeit von Beruf, Familie und Privatleben des Amtes für Statistik Berlin-Brandenburg gehören u. a.:**

* Die Angebote zum ortsflexiblen Arbeiten wurden weiter ausgebaut und neue Rahmenbedingungen definiert.
* Vereinbarkeitsförderung wurde als Führungsaufgabe definiert.
* Die Führungskräfte erhalten regelmäßiges Feedback zu ihrem Führungsverhalten.
* Ein strukturierter Elternzeitprozess wurde etabliert.
* Die Informationsangebote rund um die Pflegethematik wurden entsprechend der demografischen Situation des Amtes ausgebaut.

**Gearbeitet wird jetzt an folgenden Maßnahmen:**

* Die vorhandenen sehr guten Rahmenbedingungen zur flexiblen Gestaltung von Arbeitszeitrahmen und Arbeitszeitlage sollen die Nutzung der Angebote zum ortsflexiblen Arbeiten unterstützen.
* Es wird ein Selbstverständnis der Organisation zum „Neuen Normal“ beim Übergang vom „Pandemie-Office“ zu hybriden Arbeitsformen erarbeitet.
* Die Ziele und Maßnahmen zum audit berufundfamilie werden als Teil der Arbeitgebermarke transparent und aktiv beworben.
* Die Führungsleitlinien werden in „Grundsätze der Führung und Zusammenarbeit“ transformiert.
* Ein zielgruppenspezifisches Personalentwicklungsangebot zur Förderung der Digitalkompetenz wird entwickelt.
* Analog zum Elternzeitprozess wird ein Pflegeprozess etabliert.

###### Laden Sie hier aktuelle Informationen zum Zertifikat herunter:

[Zertifikat 2021](https://download.statistik-berlin-brandenburg.de/aad6d36b141b958b/85c763bf56c0/Zertifikat_audit-beruf-und-familie.pdf)[Pressemitteilung audit berufundfamilie](https://bit.ly/3inDeRw)[Kurzporträt Zertifikat 2021](https://download.statistik-berlin-brandenburg.de/d20ba60864727c3c/3f81e0dcbf5a/Kurzportraet_178300.pdf)[Webseite audit berufundfamilie](https://www.berufundfamilie.de/)
### Unsere aktuellen Stellenausschreibungen

![Platzhalterbild](/assets/blindbild.abc32a225a4b567916b847eb1a3ef894.png)**Werden Sie Teil unseres Teams**[#### Initiativbewerbung](/initiativbewerbung)

befristet, unbefristet

Mehr anzeigen


