

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Unternehmen](/unternehmen)
* [Rechtliche Einheiten und Niederlassungen in Berlin und Brandenburg](/d-ii-1-j)

Rechtliche Einheiten und Niederlassungen
----------------------------------------

#### 2022 , jährlich

###### Das statistische Unternehmensregister ist eine regelmäßig aktualisierte Datenbank mit Informationen aus Verwaltungsdaten und öffentlich zugänglichen Quellen zu Niederlassungen, Rechtlichen Einheiten, Unternehmen und Unternehmensgruppen aus allen Wirtschaftsbereichen und deren Beziehungen zueinander.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4cf160d34329c555/eff2c0042de9/SB_D02-01-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/804bd997a5793bda/feb501891802/SB_D02-01-00_2022j01_BE.pdf)

**Unternehmensregister in Berlin**

Für insgesamt 184.021 Rechtliche Einheiten und 191.177 Niederlassungen mit Sitz in Berlin waren im Berichtsjahr 2022 auswertungsrelevante Informationen im statistischen Unternehmensregister erfasst.

Hierbei wurden Rechtliche Einheiten und Niederlassungen gezählt, für die im Berichtszeitraum Beschäftigtenmeldungen vorlagen und/oder die umsatzsteuerpflichtig waren.

Mit 29.025 bzw. 28.842 Niederlassungen in den Bezirken Mitte und Charlottenburg-Wilmersdorf wurde die höchste Anzahl von Niederlassungen in den Berliner Innenstadtbezirken erfasst.

Der geringste Bestand an Niederlassungen konnte in den Bezirken Lichtenberg (8.200), Spandau (7.679) und Marzahn-Hellersdorf (7.505) nachgewiesen werden.

### Kontakt

#### Andreas Brachlow

Unternehmensregister

#### Andreas Brachlow

Unternehmensregister

* [0331 8173-3803](tel:0331 8173-3803)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Kerstin Leonhardt

Unternehmensregister

#### Kerstin Leonhardt

Unternehmensregister

* [0331 8173-3806](tel:0331 8173-3806)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Ole Jeran

Unternehmensregister

#### Ole Jeran

Unternehmensregister

* [0331 8173-3818](tel:0331 8173-3818)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
### Brandenburg

**Unternehmensregister in Brandenburg**

Für insgesamt 95.925 Rechtliche Einheiten und 106.503 Niederlassungen mit Sitz in Brandenburg waren im Berichtsjahr 2022 auswertungsrelevante Informationen im statistischen Unternehmensregister erfasst.

Hierbei wurden Rechtliche Einheiten und Niederlassungen gezählt, für die im Berichtszeitraum Beschäftigtenmeldungen vorlagen und/oder die umsatzsteuerpflichtig waren.

Mit 10.307 bzw. 8.632 Niederlassungen wurde die höchste Anzahl von Niederlassungen in Brandenburg in den Landkreisen Potsdam-Mittelmark und Oberhavel erfasst.

Der geringste Bestand an Niederlassungen konnte in dem Landkreis Prignitz (3.204) sowie in den kreisfreien Städten Brandenburg an der Havel (2.531) und Frankfurt (Oder) (2.276) nachgewiesen werden.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/057c689054e72dad/c05f98a3275e/SB_D02-01-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/ca4feff6877beebb/e756a14f9ae8/SB_D02-01-00_2022j01_BB.pdf)
### Kontakt

#### Andreas Brachlow

Unternehmensregister

#### Andreas Brachlow

Unternehmensregister

* [0331 8173-3803](tel:0331 8173-3803)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Kerstin Leonhardt

Unternehmensregister

#### Kerstin Leonhardt

Unternehmensregister

* [0331 8173-3806](tel:0331 8173-3806)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Ole Jeran

Unternehmensregister

#### Ole Jeran

Unternehmensregister

* [0331 8173-3818](tel:0331 8173-3818)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
### Methodik und weitere Informationen

Das statistische Unternehmensregister (URS) ermöglicht umfangreiche Auswertungen insbesondere zu den Merkmalen Beschäftigte und Umsatz. Diese können mit der Darstellung nach den verschiedenen Gliederungsebenen der Klassifikation der Wirtschaftszweige oder auch nach regionalen Abgrenzungen wie die der Berliner Bezirke oder der Brandenburger Kreise bzw. der Kreisfreien Städte verknüpft werden.

Auswertungsebenen sind die Niederlassungen, die das örtlich abgegrenzte Prinzip repräsentieren, oder die Rechtlichen Einheiten, denen jeweils mindestens eine Niederlassung in einem Bundesland zugeordnet ist.

Weitere Details sind den Metadaten zu entnehmen, die passend zum jeweiligen Berichtsjahr bereitgestellt werden.

  


#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Unternehmensregister-System (URS)**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/6e5ec676abe9f1bb/5e58afacf4f0/MD_52111_2022.pdf)[Archiv](/search-results?q=MD_52111&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/d-ii-1-j)
