

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Mikrozensus](/bevoelkerung/demografie/mikrozensus)
* [Ergebnisse des Mikrozensus in Berlin und Brandenburg](/a-i-10-a-i-11-a-vi-2-j)
* [A I 10 A I 11 A VI 2 – j](/archiv/a-i-10-a-i-11-a-vi-2-j)

Archiv: Statistischer Berichte
==============================

#### Ergebnisse des Mikrozensus (A I 10  A I 11  A VI 2 – j )

#### Ergebnisse des Mikrozensus in Berlin und Brandenburg: Bevölkerung und Erwerbstätigkeit (A I 10, A VI 2 - j)

#### Ergebnisse des Mikrozensus: Haushalte, Familien und Lebensformen (A I 11-j )

![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben dieses Statistischen Berichts jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

  


**Archiv :  A I 10, A VI 2 - J**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000009)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000005)

**Archiv : A I 11 -j**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000011)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000007)

**Archiv : A I 10 A I 11 A VI 2 – j**

[Ältere Berichte Berlin](https://appweb.stba.testa-de.net/mir/receive/BBSerie_mods_00000633)[Ältere Berichte Brandenburg](https://appweb.stba.testa-de.net/mir/receive/BBSerie_mods_00001431)


