

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Publikationen](/publikationen)
* [News](/news)

News
====

#### 

#### Informationen und Analysen zu den Ergebnissen der amtlichen Statistik in der Region, zu methodischen und gesetzlichen Entwicklungen, Fachgespräche und Neuigkeiten aus dem Amt

![](https://download.statistik-berlin-brandenburg.de/3b26206531588510/77eb539bbaaf/v/3f8152ee4ce2/schmuckbild-zeitschrift.png)
#### Ältere Beiträge finden Sie in der Zeitschrift für amtliche Statistik Berlin Brandenburg

Alle Ausgaben von 2007 bis 2021 stehen in der Statistischen Bibliothek, dem gemeinsamen Publikationenserver der Statistischen Ämter des Bundes und der Länder.

[Zur Statistischen Bibliothek](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000025)

[* Aufsätze](/search-results?q=tag%3AAufsätze)[* Artikel](/search-results?q=tag%3AArtikel)[* Zeitschrift](/search-results?q=tag%3AZeitschrift)[* Fachgespräch](/search-results?q=tag%3AFachgespräch)[* Analysen](/search-results?q=tag%3AAnalysen)[* News](/search-results?q=tag%3ANews)[* Interview](/search-results?q=tag%3AInterview)
