

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Zensus](/bevoelkerung/zensus)
* [Zensus 2011](/bevoelkerung/zensus/zensus_2011)

Zensus 2011
===========

Der Zensus 2011 war die erste registerbasierte Bevölkerungs-, Gebäude- und Wohnungszählung. Die Ergebnisse der Erhebung zeigen, wie die Menschen am 9. Mai 2011 in Deutschland lebten, wohnten und arbeiteten.

Das wiedervereinigte Deutschland erhielt erstmals – nach den Volkszählungen in der BRD 1987 und in der damaligen DDR 1981 – aktuelle Einwohnerzahlen und einheitliche statistische Daten zur demografischen Struktur der Bevölkerung sowie Informationen zum Gebäude- und Wohnungsbestand.

###### Hinweis zur statistischen Geheimhaltung beim Zensus

Beim Zensus 2011 wurde die statistische Geheimhaltung durch das Verfahren „Sichere Anonymisierung für Einzeldaten“ (SAFE) sichergestellt. Für den Zensus 2022 haben sich die Statistischen Ämter des Bundes und der Länder für einen Verfahrenswechsel entschieden: Beim Zensus 2022 wird die Cell-Key-Methode (CKM) verwendet.

Mit dem Relaunch der Zensusdatenbank 2011 wurde auf alle Daten die CKM nachträglich angewendet. So liegen dann Zensusergebnisse 2011 und 2022 auf Basis eines identischen Geheimhaltungsverfahrens (CKM) vor.

Es kommt zu geringen Abweichungen zwischen den mit Safe und mit CKM geheimgehaltenen Ergebnissen des Zensus 2011. Dadurch sind weder die Qualität bisher verfügbarer Publikationen noch die Qualität der in dieser Datenbank abrufbaren Ergebnisse beeinträchtigt.

Weitere Informationen zur Geheimhaltung beim Zensus erhalten Sie auf der [Zensus-Seite](https://www.zensus2022.de/DE/Wie-funktioniert-der-Zensus/geheimhaltung-beim-zensus.html).

BasisdatenRegionaldatenErgebnisdokumentationWeitere Datenangebote

Basisdaten
----------

BevölkerungsstandWohngebäudeHaushalte und Familien

Regionaldaten
-------------

BevölkerungsstandWohngebäudeHaushalte und Familien
###### Berliner Bezirke

#### Bevölkerung am 9. Mai 2011

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise

#### Bevölkerung am 9. Mai 2011

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Gemeindeblätter
---------------

#### Ergebnisse des Zensus 2011 zu den Themen Bevölkerung und Haushalte, Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte am 9. Mai 2011

Gemeindeblätter für Berlin
--------------------------

Die wichtigsten Ergebnisse des Zensus 2011 für Berlin zu den Themen Bevölkerung und Haushalte, Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte.

[Mehr erfahren](/bevoelkerung/zensus/zensus_2011/ergebnisse-berlin)

Gemeindeblätter für Brandenburg
-------------------------------

Die wichtigsten Ergebnisse des Zensus 2011 für Brandenburg zu den Themen Bevölkerung und Haushalte, Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte.

[Mehr erfahren](/bevoelkerung/zensus/zensus_2011/ergebnisse-brandenburg)

Weitere Datenangebote
---------------------

#### Zensusatlas 2011

![](https://download.statistik-berlin-brandenburg.de/0b28408c3c3f9458/01a072deeca7/v/33d4aa01ea34/Zensusatlas-BE.PNG)

Der Zensusatlas bietet umfangreiche Auswertungs­möglichkeiten für die Ergebnisse des Zensus 2011 in individuellen Karten und als Excel-Import.

[Zensusatlas Berlin](https://web.statistik-berlin-brandenburg.de/instantatlas/interaktivekarten/zensusatlas-berlin/atlas.html)[Zensusatlas Brandenburg](https://web.statistik-berlin-brandenburg.de/instantatlas/interaktivekarten/zensusatlas-brandenburg/atlas.html)
#### Zensusdatenbank

![](https://download.statistik-berlin-brandenburg.de/01f175f9181d6f6a/fff06ec0b163/v/dfed144dd029/zensusdatenbank.PNG)

Die Zensusdatenbank enthält bundesweite Daten zu Bevölkerung, Gebäuden und Wohnungen, Haushalts- und Familienstrukturen am 9. Mai 2011.

[Zur Zensusdatenbank](https://ergebnisse2011.zensus2022.de/datenbank/online/)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1716887439695&code=12111#abreadcrumb)

Methodik und weitere Informationen
----------------------------------

Der Zensus 2011 ist die erste registergestützte, durch eine Stichprobe und eine Vollerhebung in Gemeinschaftsunterkünften ergänzte Bevölkerungszählung, die in Kombination mit einer Vollerhebung der Gebäude- und Wohnungszählung stattfand.

**Methodische Erläuterungen**  


[Download PDF](https://download.statistik-berlin-brandenburg.de/d05005edf3127662/1e54b7771b0b/zensus-20211-methodische_erlaeuterungen_ueberarbeitet.pdf)

Die Ergebnisse des Zensus 2011 zeigen, wie die Menschen in Deutschland am 9. Mai 2011 lebten, wohnten und arbeiteten. Öffentlich zugänglich sind dabei die im Merkmalskatalog beschriebenen Merkmale.  
  


**Merkmalskatalog**  


[Download PDF](https://download.statistik-berlin-brandenburg.de/7a26d4b2328a5777/784b251fbf3f/zensus-2011-merkmalskatalog.pdf)

In Deutschland kann keine amtliche Statistik ohne gesetzliche Grundlage durchgeführt werden. Diese regelt die Erhebung durch die statistischen Ämter, die zu erhebenden Merkmale, den Erhebungsumfang und den Erhebungszeitpunkt.  
  


**Rechtliche Grundlagen**

Zur Übersicht

Haben Sie Fragen?
-----------------

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![Schmuckbild Zensus 2022 Heizung und Gebäude](https://download.statistik-berlin-brandenburg.de/6566e7c034d35542/dc5b764f0d2f/v/9c28a2322780/Zensus.png "Schmuckbild Zensus 2022 Heizung und Gebäude")](/168-2024)**Zensus 2022 für Berlin und Brandenburg**[#### Zensusdaten ermöglichen Analysen unterhalb der Gemeindeebene](/168-2024)

Das Amt für Statistik Berlin-Brandenburg bietet ab sofort Auswertungen unterhalb der Gemeindeebene an.

[![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)](/news/2024/zensus-generation-alpha)**Zensus 2022 in Berlin und Brandenburg**[#### So wächst die Generation Alpha auf](/news/2024/zensus-generation-alpha)

Der Zensus 2022 gibt Einblicke in die Einwanderungsgeschichte der Generation Alpha in Berlin und Brandenburg.

[Zu unseren News](/news)

[* Volkszählung](/search-results?q=tag%3AVolkszählung)[* Gemeindeblätter](/search-results?q=tag%3AGemeindeblätter)[* Melderegister](/search-results?q=tag%3AMelderegister)[* Einwohnerzahlen](/search-results?q=tag%3AEinwohnerzahlen)[* Erhebungsbeauftragte](/search-results?q=tag%3AErhebungsbeauftragte)[* Haushaltebefragung](/search-results?q=tag%3AHaushaltebefragung)[* Registerzensus](/search-results?q=tag%3ARegisterzensus)[* Interviewer](/search-results?q=tag%3AInterviewer)[* Zensus 2011](/search-results?q=tag%3AZensus 2011)
