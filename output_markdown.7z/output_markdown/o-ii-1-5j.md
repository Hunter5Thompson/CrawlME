

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Einkommen und Konsum](/einkommen-und-konsum)
* [Ausstattung mit ausgewählten Gebrauchsgütern und Wohnsituation privater Haushalte](/o-ii-1-5j)

Ausstattung mit ausgewählten Gebrauchsgütern und Wohnsituation privater Haushalte
---------------------------------------------------------------------------------

#### 2018, fünfjährlich

###### Die Einkommens- und Verbrauchsstichprobe ist eine freiwillige Befragung  privater Haushalte. Diese geben im Rahmen der Erhebung auch zur Ausstattung mit Gebrauchsgütern und ihrer Wohnsituation Auskunft.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2018**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8de1caed5db35345/4ceaca6bf55f/SB_O02-01-00_2018j05_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/7724905a915dc6b2/a992cebb8f35/SB_O02-01-00_2018j05_BE.pdf)

Flachbildfernseher, mobile Personalcomputer und Mobiltelefone sind in den meisten Haushalten in Berlin präsent. Das geht aus den ersten Ergebnissen der Einkommens- und Verbrauchsstichprobe 2018 (EVS) hervor, die das Amt für Statistik Berlin-Brandenburg veröffentlicht hat. Während 2008 knapp 16 % der Fernsehgeräte in Berliner Haushalten Flachbildschirme waren, lag ihr Anteil zehn Jahre später bei 81 %.

Bei der mobilen PC-Technik hat sich im gleichen Zeitraum der Anteil in Berlin fast verdoppelt.

### Kontakt

#### Nicole Baier

Haushaltserhebungen

#### Nicole Baier

Haushaltserhebungen

* [0331 8173-1912](tel:0331 8173-1912)
* [evs@statistik-bbb.de](mailto:evs@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

Flachbildfernseher, mobile Personalcomputer und Mobiltelefone sind in den meisten Haushalten in Brandenburg präsent. Das geht aus den ersten Ergebnissen der Einkommens- und Verbrauchsstichprobe 2018 (EVS) hervor, die das Amt für Statistik Berlin-Brandenburg veröffentlicht hat. Während 2008 knapp 19 % der Fernsehgeräte in Brandenburger Haushalten Flachbildschirme waren, lag ihr Anteil zehn Jahre später bei 91 %.

Bei der mobilen PC-Technik hat sich im gleichen Zeitraum der Anteil in Brandenburg fast verdreifacht.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2018**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/b0e7d2024b3c2625/18e47cbcd41a/SB_O02-01-00_2018j05_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/026cfc1457e03628/8688d78e6f68/SB_O02-01-00_2018j05_BB.pdf)
### Kontakt

#### Nicole Baier

Haushaltserhebungen

#### Nicole Baier

Haushaltserhebungen

* [0331 8173-1912](tel:0331 8173-1912)
* [evs@statistik-bbb.de](mailto:evs@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die **Einkommens- und Verbrauchsstichprobe (EVS)** ist eine im fünfjährigen Abstand dezentral durchgeführte bundesweite Quotenstichprobe zur Erfassung der Einnahmen und Ausgaben privater Haushalte. Die Statistik wird in allen EU-Mitgliedsstaaten durchgeführt. Es handelt sich um eine Primärerhebung.

In der Erhebung sind nur solche Haushalte vertreten, die sich aufgrund von Werbe­maßnahmen der Statistischen Ämter des Bundes und der Länder bereit erklärten, die mit den Erhebungs­unterlagen abgefragten Angaben freiwillig zu machen.

Die Erhebung besteht aus vier Erhebungsteilen „Allgemeine Angaben“, „Geld- und Sachvermögen“, das „Haushaltsbuch sowie das „Feinaufzeichnungsheft“ für Nahrungsmittel, Getränke und Tabakwaren.

In den**„Allgemeinen Angaben“** (Stichtag 1. Januar des jeweiligen Jahres) werden soziodemografische und sozioökonomische Grunddaten der Haushalte, die Wohnsituation und die Ausstattung mit Gebrauchsgütern sowie das Vorhandensein von Versicherungen erfasst.

Die Erhebungsgesamtheit umfasst alle Privathaushalte am Ort der Hauptwohnung, deren monatliches Haushaltsnettoeinkommen weniger als 18 000 EUR  beträgt.

Generell nicht in die Erhebung einbezogen werden Personen ohne festen Wohnsitz (Obdachlose) sowie Personen in Gemeinschaftsunterkünften und Anstalten.

Die EVS gibt einen Überblick über die soziale Lage, den sozioökonomischen Status und insbesondere über die Einkommenssituation und das Konsumverhalten der Bevölkerung in Deutschland und ist damit wichtig für die Sozialpolitik, aber auch für die Politikberatung im Rahmen der Familien-, Konjunktur- und Steuerpolitik. Sie bildet eine wichtige Säule der Armuts- und Reichtumsberichterstattung der Bundesregierung. Als statistische Grundlage fließen die Ergebnisse der EVS in die (Neu-)Festsetzung der Regelbedarfe der sozialen Grundsicherung (z. B. Arbeitslosengeld II), in die Ermittlung des Verbraucherpreisindex sowie in die Verwendungsrechnung der volkswirtschaftlichen Gesamtrechnungen (z. B. für private Konsumausgaben) ein.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zu Stande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen, sowie ggf. auch eine Datensatzbeschreibung.

**Einkommens- und Verbrauchsstichproben: Allgemeine Angaben**  
Metadaten 2018

[Download PDF](https://download.statistik-berlin-brandenburg.de/accd4c673f0e6295/4fbc17f02e52/MD_63211_2018.pdf)[Archiv](/search-results?q=MD_63211&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/o-ii-1-5j)
