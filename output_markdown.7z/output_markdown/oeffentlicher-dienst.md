

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentlicher Dienst](/oeffentlicher-dienst)

Öffentlicher Dienst
===================

Die Personalstandstatistik liefert Daten über die Beschäftigten der öffentlichen Arbeitgeber, die am 30. Juni eines Jahres in einem unmittelbaren Dienst- oder Arbeitsvertragsverhältnis mit der jeweiligen Einrichtung stehen.

Die öffentlichen Arbeitgeber umfassen den öffentlichen Dienst und die rechtlich selbstständigen Einrichtungen und Unternehmen in privater Rechtsform mit überwiegend öffentlicher Beteiligung. Zum öffentlichen Dienst gehören die Beschäftigten des Bundes, der Länder, der Gemeinden und Gemeindeverbände, der rechtlich selbstständigen Einrichtungen in öffentlich-rechtlicher Rechtsform und der Sozialversicherungsträger. Die rechtlich selbstständigen Organisationen ohne Erwerbszweck für Wissenschaft, Forschung und Entwicklung mit überwiegend öffentlicher Finanzierung werden im Rahmen der Forschungsstatistik nachgewiesen.

Die Versorgungsempfängerstatistik liefert Daten über die Leistungsberechtigten des öffentlich-rechtlichen Alterssicherungssystems.

Zu den Erhebungseinheiten gehören der Bund, die Länder, die Gemeinden/Gemeindeverbände, die Sozialversicherungsträger sowie öffentliche Einrichtungen mit Dienstherrenfähigkeit.

###### Mehr erfahren

Bei allen Einheiten des Bundes wird die Befragung zentral vom Statistischen Bundesamt durchgeführt. Die Bundes- und einzelnen Länderergebnisse werden vom Statistischen Bundesamt in aggregierter Form zusammengeführt. Auswertungen hierzu finden Sie **[hier](https://www.destatis.de/DE/Themen/Staat/Oeffentlicher-Dienst/_inhalt.html#sprg236406)**.  


Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Personal im öffentlichen Dienst in Berlin und Brandenburg, jährlich (LIII2-j)](/l-iii-2-j)[Versorgungsempfänger in Berlin und Brandenburg, jährlich (LIII5-j)](/l-iii-5-j)

Zeitreihen
----------

BeschäftigteVersorgungsempfänger1 Die Daten der Personalstatistiken unterliegen der Geheimhaltung. Als Geheimhaltungsverfahren wurde die 5er-Rundung angewendet.**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/7def51aa90b909cc/95cbdf263087/oeffentlicherdienst-beschaeftigte-versorgungsempfaenger-zeitreihe.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/73f82ecb770ceb25/6f31f3999339/oeffentlicherdienst-lange-reihe.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Brandenburger Landkreise und kreisfreie Städte

#### Personal im öffentlichen Dienst 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1715948448231&code=74#abreadcrumb)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1715948368406&code=74#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Ramona Baumert

Personalstatistiken

#### Ramona Baumert

Personalstatistiken

* [0331 8173-1251](tel:0331 8173-1251)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Janet Hamann

Personalstatistiken

#### Janet Hamann

Personalstatistiken

* [0331 8173-1265](tel:0331 8173-1265)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Cathleen Faber

FinanzSTATISTIKEN

#### Cathleen Faber

FinanzSTATISTIKEN

* [0331 8173-1264](tel:0331 8173-1264)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / AndreyPopov](https://download.statistik-berlin-brandenburg.de/9c6b37d8968643ea/c333ef4f1b46/v/1f3a6daca24f/gesellschaft-arbeit-man-comparing-two-coin-stacks-picture-id1174295678.jpg "iStock.com / AndreyPopov")](/l-iii-5-j)**1. Januar 2024, jährlich, L III 5 – j**[#### Versorgungsempfänger in Berlin und Brandenburg](/l-iii-5-j)

Die Versorgungsempfängerstatistik liefert Daten über die Leistungsberechtigten des öffentlich-rechtlichen Alterssicherungssystems.

[![iStock.com / stockfour](https://download.statistik-berlin-brandenburg.de/8e0e00b918a74772/704aa663145a/v/ec5891f3443d/gesellschaft-bildung-portrait-of-young-man-in-office-team-meeting-picture-id1227527658.jpg "iStock.com / stockfour")](/l-iii-2-j)**Juni 2023, jährlich, L III 2 – j**[#### Personal im öffentlichen Dienst in Berlin und Brandenburg](/l-iii-2-j)

Beschäftigte der öffentlichen Arbeitgeber, die am 30. Juni eines Jahres in einem unmittelbaren Dienst- oder Arbeitsvertragsverhältnis mit der jeweiligen Einrichtung stehen.

[![iStock.com / stockfour](https://download.statistik-berlin-brandenburg.de/8e0e00b918a74772/704aa663145a/v/ec5891f3443d/gesellschaft-bildung-portrait-of-young-man-in-office-team-meeting-picture-id1227527658.jpg "iStock.com / stockfour")](/085-2024)**Tag des öffentlichen Dienstes am 23. Juni 2024**[#### Mehr öffentlich Beschäftigte in Berlin und Brandenburg](/085-2024)

In Berlin beschäftigte der öffentliche Dienst am 30. Juni 2023 insgesamt 225.910 Personen. Im Land Brandenburg gab es insgesamt 128.505 Beschäftigte,

[Zu unseren News](/news)

[* Personal](/search-results?q=tag%3APersonal)[* Beamte](/search-results?q=tag%3ABeamte)[* Sonderrechnungen](/search-results?q=tag%3ASonderrechnungen)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)[* Bezirksverwaltung](/search-results?q=tag%3ABezirksverwaltung)[* Beschäftigungsverhältnis](/search-results?q=tag%3ABeschäftigungsverhältnis)[* ohne Bezüge Beschäftigte](/search-results?q=tag%3Aohne Bezüge Beschäftigte)[* Hinterbliebene](/search-results?q=tag%3AHinterbliebene)[* Vollzeitbeschäftigte](/search-results?q=tag%3AVollzeitbeschäftigte)
