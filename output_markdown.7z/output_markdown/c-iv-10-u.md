

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Ausgewählte Ergebnisse der Landwirtschaftszählung in Berlin](/c-iv-10-u)

Ausgewählte Ergebnisse der Landwirtschaftszählung in Berlin
-----------------------------------------------------------

#### 2020, zehnjährlich

###### Der Bericht enthält Angaben zur Bodennutzung, zu Viehbeständen, Rechtsformen, Pachtflächen und -entgelten sowie betriebswirtschaftliche Ausrichtung und landwirtschaftliche Berufsbildung.

BerlinMethodik
### Berlin

¹ repräsentatives Ergebnis² seit 2010 eingeschränkte Vergleichbarkeit mit den Vorjahren aufgrund methodischer Veränderungen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/6fffdfb981ee6b65/73b8caf1c632/SB_C04-10-00_2020u00_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/ef8e40c65c964a09/32bf401f0b3a/SB_C04-10-00_2020u00_BE.pdf)

**Durchschnittliche Pachtpreis bei 146 Euro je Hektar**

2020 gab es in Berlin 47 landwirtschaftliche Betriebe, die 1.864 Hektar landwirtschaftlich genutzte Fläche (LF) mit 233 Arbeitskräften bewirtschafteten, darunter 1.073 Hektar Ackerland und 778 Hektar Dauergrünland.

6 Betriebe (12,8 %) wirtschafteten nach den Prinzipien des ökologischen Landbaus. Diese Betriebe verfügten über 15,8 % der LF (295 Hektar).

84,8 % der LF waren Pachtflächen (1.580 Hektar). Im Durchschnitt zahlten die Berliner Landwirtschaftsbetriebe 146 EUR je Hektar LF.

### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Birger Schmidt

Viehbestände und tierische Erzeugung

#### Birger Schmidt

Viehbestände und tierische Erzeugung

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Landwirtschaftszählung**  
Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/023848dc8f72ca47/3f8123557a5c/MD_41141_2020.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-10-u)
