

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Abfall, Luftbelastungspotenzial](/luftverunreinigungen)

Abfall, Luft­belastungs­potenzial
=================================

Das gültige [Umweltstatistikgesetz (UStatG)](https://www.gesetze-im-internet.de/ustatg_2005/BJNR244610005.html) regelt im Themenbereich „Abfallwirtschaft“ verschiedene Erhebungen.

In jährlichen und mehrjährlichen Statistiken werden Daten zu Haushaltsmüll bis Sondermüll zur Verfügung gestellt. Außerdem werden jährliche Daten zu klimawirksamen Stoffen, wie zum Beispiel Kühlmittel in Autos, erfasst. Die meisten dieser Stoffe gelangen erst nach Jahren in die Umwelt.

Statistische BerichteZeitreihenBasisdatenRegionaldaten

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Abfallentsorgung in Berlin und Brandenburg, zweijährlich (QII1-2j)](/q-ii-1-2j)[Klimawirksame Stoffe in Berlin und Brandenburg, jährlich (QIV1-j)](/q-iv-1-j)

Zeitreihen
----------

Abfall: EntsorgungsanlagenAbfall: AbfallmengeLuftbelastungspotenzial: UnternehmenLuftbelastungspotenzial: Verwendungsmenge **Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Abfall

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/b6e4ea143d47d859/a39120429eb2/abfall-luftverunreinigung-zeitreihe-2018-abfallwirtschaft.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/107162b6d2737f56/80bc7821eca1/abfall-luftverunreinigung-lange-reihe-2018-abfallwirtschaft.xlsx)
#### Luftbelastungspotenzial

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/f17378c636cdbe50/12978d973d2c/abfall-luftbelastungspotenzial-zeitreihe-2019-luftverunreinigungen.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/c2f33d57f0c11c04/e4de0f598a57/abfall-luftbelastungspotenzial-lange-reihe-2019-luftverunreinigungen.xlsx)

Basisdaten
----------

AbfallLuftverunreinigung

Regionaldaten
-------------

###### Landkreise und kreisfreie Städte 2019

#### Haushaltsabfälle Brandenburg

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Haben Sie Fragen?
-----------------

#### Stephan Opitz

Umwelt, Umweltökonomische Gesamtrechnungen

#### Stephan Opitz

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1240](tel:0331 8173-1240)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Anne-Katrin Stephan

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Dr. Anne-Katrin Stephan

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1247](tel:0331 8173-1247)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-968906216.jpg](https://download.statistik-berlin-brandenburg.de/de73473a84e6df5a/fd72727beb4c/v/9e312ba3eb79/gaspipeline.jpg "iStock-968906216.jpg")](/169-2024)**Energie- und CO₂-Bilanz 2023 Berlin**[#### Energieverbrauch und CO₂-Emissionen weiter gesunken](/169-2024)

Die vorläufigen Ergebnisse der Energie- und CO₂-Bilanz 2023 zeigen auch weiterhin einen Rückgang beim Energieverbrauch und bei den CO₂-Emissionen.

[![Ein Windrad und weiter Blick in die Landschaft](https://download.statistik-berlin-brandenburg.de/2fe0c01ea1e3b28f/36c8abef068e/v/58c54355b18c/wirtschaft-preise-wind-turbine-in-the-sunset-seen-from-an-aerial-view-picture-id864427886.jpg "Ein Windrad und weiter Blick in die Landschaft")](/news/2024/nachhaltigkeit-biodiversitaet)**10 Diagramme zu den Deutschen Aktionstagen Nachhaltigkeit**[#### Biodiversität im Fokus](/news/2024/nachhaltigkeit-biodiversitaet)

Deutsche Aktionstage Nachhaltigkeit mit Schwerpunkt Biodiversität: Mit aktuellen Zahlen unterstreichen wir die Bedeutung der biologischen Vielfalt in unserer Region.

[![iStock-489193525.jpg](https://download.statistik-berlin-brandenburg.de/82f8600a57afaea2/97abf801f9a3/v/c70b556b56c6/wirtschaft-wirtschaftsbereiche-photovoltaikanlage.jpg "iStock-489193525.jpg")](/130-2024)**Stromeinspeisung 1. Halbjahr 2024 in Berlin und Brandenburg**[#### Sommer, Sonne, Sonnenschein… Ausbau der Photovoltaikanlagen schreitet voran](/130-2024)

Pressemitteilung Nr. 130 Das erste Halbjahr 2024 zeichnete sich durch einen beachtenswerten Zuwachs der Stromeinspeisung aus Photovoltaikanlagen aus. Während in Berlin im ersten Halbjahr 2023 noch...

[Zu unseren News](/news)

[* Müll](/search-results?q=tag%3AMüll)[* Klimawirksame Stoffe](/search-results?q=tag%3AKlimawirksame Stoffe)[* Luftreinhaltung](/search-results?q=tag%3ALuftreinhaltung)[* Abfallentsorgung](/search-results?q=tag%3AAbfallentsorgung)[* Abfallentstehung](/search-results?q=tag%3AAbfallentstehung)[* Luftbelastungspotenzial](/search-results?q=tag%3ALuftbelastungspotenzial)[* Abfall](/search-results?q=tag%3AAbfall)[* Umwelt](/search-results?q=tag%3AUmwelt)
