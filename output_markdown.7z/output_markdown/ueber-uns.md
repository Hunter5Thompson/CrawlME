

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
#### Die Fakten

Gründung

**1. Januar 2007**

Rechtsform

**Anstalt des öffentlichen Rechts**

Aufsichtsgremium

**Verwaltungsrat**

Standorte

**Potsdam** (Hauptstandort)  
**Berlin**  
**Cottbus**

Mitarbeitende

**ca. 450**

[Zu den Geschäftsberichten](/geschaeftsberichte)[Zur Rückschau 2021/2022](/rueckschau)
#### Wer wir sind

Das Amt für Statistik Berlin-Brandenburg ist der Informationsdienstleister für Berlin und Brandenburg. Wir liefern amtliche Daten für die Region aus nahezu allen Lebensbereichen und damit Planungssicherheit für Politik, Wirtschaft, Wissenschaft und Gesellschaft.

#### Was wir bieten

Die von uns erhobenen Statistiken stehen allen interessierten Bürgerinnen und Bürgern auf unseren Internetseiten kostenfrei zur Verfügung. Darüber hinaus erstellen wir kundenspezifische Datenaufbereitungen.

#### Was wir tun

Wir erheben Daten, werten sie aus, bereiten sie auf und stellen sie der Allgemeinheit zur Verfügung. Die Datenerhebung erfolgt dabei nach einheitlichen Standards (EU-Statistiken, Bundesstatistiken sowie koordinierte Länderstatistiken).

#### Wie wir arbeiten

Unsere rund 450 Mitarbeitenden in Potsdam, Berlin und Cottbus sind die Basis für Leistungen von höchster Qualität. Neben Produkt- und Kundenzufriedenheit ist die Zufriedenheit aller Mitarbeitenden für uns besonders wichtig.

OrganisationAuftragAufgabenIntegrität[Karriere](/karriere)

Unser Management
----------------

AuswahlHausleitung

* Hausleitung
* Verwaltungsrat
* Beauftragte
* Personalvertretung

VOLLBILD![](https://download.statistik-berlin-brandenburg.de/7bb500cbf3816561/43e768d4dac6/v/3c128adcc0e9/fidorra.jpeg)

Jörg Fidorra

##### Vorstand

VOLLBILD![](https://download.statistik-berlin-brandenburg.de/79d2a72415b8230d/924eae1869fa/v/2b2cc6f55be8/albat.jpeg)

Norman Albat

##### Vertreter des Vorstands, Abteilungsleitung Zentraler Service

VOLLBILD![](https://download.statistik-berlin-brandenburg.de/f2a89fca9e3287bb/aa04faad4a40/v/7246df80609e/kuss-grau.png)

Steffi Kuß

##### Büroleitung des Vorstands

VOLLBILD![](https://download.statistik-berlin-brandenburg.de/0e3adbd53de3dbdf/4487ae2ff2ed/v/a4af6ad0c37b/hannemann.jpg)

Tobias Hannemann

##### Abteilungsleitung Bevölkerung und Soziales

VOLLBILD![](https://download.statistik-berlin-brandenburg.de/8ab41cbaf78de26b/f33426300ebd/v/3dea24350880/maedler.png)

Ralf Mädler

##### Abteilungsleitung Wirtschaftsbereiche und Unternehmen

VOLLBILD![](https://download.statistik-berlin-brandenburg.de/5334fc49f1b1b8b0/c4f3676700d5/v/6ddebacc3a8d/kaufmann-grau.png)

Violetta Kaufmann

##### Abteilungsleitung Gesamtwirtschaft

Das Amt für Statistik Berlin-Brandenburg entstand am **1. Januar 2007** durch den Zusammenschluss des Statistischen Landesamtes Berlin und der Abteilung Statistik des Landesbetriebes für Datenverarbeitung und Statistik Brandenburg.

Es wurde durch den [Staatsvertrag](https://download.statistik-berlin-brandenburg.de/6eed5c49d0fafe98/65d5430813e1/staatsvertrag.pdf) vom 13. Dezember 2005 zwischen Berlin und Brandenburg als Anstalt des öffentlichen Rechts errichtet. Ein Verwaltungsrat mit Vertretenden der Innen- und Finanzressorts steuert und entscheidet in grundsätzlichen Angelegenheiten. Ihm steht ein uneingeschränktes Auskunftsrecht gegenüber dem Vorstand zu.

Lesen Sie auch die [Satzung des Amtes für Statistik Berlin-Brandenburg](https://download.statistik-berlin-brandenburg.de/beebb82d637a1988/01f5763e7a0a/satzung-afs.pdf) für weitere Informationen.

[Auskunft zu rechtsgeschäftlichen Befugnissen](https://download.statistik-berlin-brandenburg.de/6f51d2008f0106df/c539eb5f1e6e/20241014_vertretungs-zeichnungsberechtigte-personen.pdf)[#### Erfahren Sie mehr über unsere interne Struktur!

![Organigramm](https://download.statistik-berlin-brandenburg.de/b8c47c363c840d9a/574ce5e74dd8/v/fca8abf346be/Organigramm.jpg)](https://download.statistik-berlin-brandenburg.de/602b639ba2c2722a/b5d06dc33c8f/Organigramm.pdf)[Download Organigramm](https://download.statistik-berlin-brandenburg.de/602b639ba2c2722a/b5d06dc33c8f/Organigramm.pdf)

Wir gehen neue Wege und schaffen Fakten.
----------------------------------------

#### In einer Welt, die zunehmend von Unsicherheit und irreführenden Informationen geprägt ist, sind unsere Daten zuverlässig und unabhängig. Sie sind aktuell und jederzeit verfügbar. Sie bieten Orientierung und beantworten Fragen. Sie sind eine unverzichtbare Hilfe, um Entscheidungen zu treffen.

#### **So werden wir den Anforderungen der Kundinnen und Kunden gerecht:**

**Kundenzufriedenheit**

Unsere Statistiken entsprechen den Anforderungen unserer Kundinnen und Kunden. Ihre Bedürfnisse stehen im Mittelpunkt unserer Arbeit. Wir setzen alles daran, sie zu erfüllen. Dabei handeln wir stets in Übereinstimmung mit unserem gesetzlichen Auftrag und garantieren die Einhaltung des Datenschutzes.

**Produktqualität**

Unsere Prozesse, Technologien und Produkte sind zeitgemäß, effizient und nachhaltig. Wir verwenden angemessene statistische Methoden und geeignete Verfahren.

**Vertrauen**

Wir übernehmen gemeinsam mit unseren Kundinnen und Kunden Verantwortung für unsere Gesellschaft. Dafür bauen wir auf ein starkes Netzwerk. Wir tauschen Wissen aus und arbeiten erfolgreich zusammen. Wir nutzen ihre und unsere Ressourcen effektiv.

**Mitarbeiterzufriedenheit**

Unsere Mitarbeitenden arbeiten gern bei uns. Sie sind der „Schlüssel“ unseres Erfolgs. Die Erfüllung unseres Auftrags ist unser gemeinsames Ziel. Wir legen Wert auf ein respektvolles und vertrauensvolles Miteinander. Unsere Leistungen erkennen wir an. Sowohl neue Impulse als auch langjährige Erfahrungen sind bei uns willkommen.

Was wir tun
-----------

Bei uns werden Statistiken aus allen Bereichen des gesellschaftlichen Lebens – auch für Wahlen und Volksabstimmungen – erhoben, aufbereitet und ausgewertet.  Mit der Herausgabe verschiedenster Publikationen wird die amtliche Statistik den Informationsanforderungen aus Wirtschaft, Gesellschaft und Wissenschaft gerecht.

**Unser Kerngeschäft ist die Erhebung und Aufbereitung der EU-, Bundes- und Landesstatistiken sowie deren Auswertung, Analyse und Veröffentlichung.**

**Wir kümmern uns auch um die methodische und technische Vorbereitung und Weiterentwicklung der Statistiken.**

**Wir erarbeiten und veröffentlichen volkswirtschaftliche und umweltökonomische Gesamtrechnungen sowie andere Gesamtsysteme statistischer Daten.**

****Wir beteiligen uns aktiv an****Diskussionen als Referierende****und Moderierende.****

****Wir informieren auf Fachtagungen****und Pressekonferenzen zu verschiedensten gesellschaftlichen Themen.****

**Wir führen außerdem ein statistisches Informationssystems.**

Wir arbeiten termingerecht:  
Von insgesamt **272 Statistiken** im Jahr 2023 wurden **94,3 %** termingerecht an das Statistische Bundesamt geliefert.

Dezentrale   
Bundesstatistiken

darunter Dezentrale Bundesstatistiken  
aufgrund von EU-Gesetzen

Koordinierte   
Länderstatistiken

Sonstige   
Statistiken

#### Erfahren Sie mehr über unsere Ziele und Aufgaben

  

Wozu wir uns verpflichten
-------------------------

#### Grundsätze der amtlichen Statistik und Code of Practice

Die wichtigsten Grundsätze der deutschen amtlichen Statistik sind im [Bundesstatistikgesetz](https://www.gesetze-im-internet.de/bstatg_1987/index.html) verankert: Objektivität, Neutralität und wissenschaftliche Unabhängigkeit der statistischen Ämter. Darüber hinaus ist dort die statistische Geheimhaltung als zentrales Fundament der Beziehungen zu den Auskunftgebenden geregelt. Das bedeutet, dass die für statistische Zwecke erhobenen Angaben strikt geheim zu halten sind und nur für die gesetzlich bestimmten Zwecke verwendet werden.

Zusätzlich definiert der **EU-Verhaltenskodex (Code of Practice****)** einheitliche und verbindliche Standards für alle europäischen statistischen Ämter, um sicherzustellen, dass öffentliche Statistiken unabhängig von politischem Druck und gemäß wissenschaftlich anerkannter Methoden erstellt werden.

[Mehr über amtliche Statistik](/amtliche-statistik)![](https://download.statistik-berlin-brandenburg.de/6541bd07476c41ec/6bc53cb419aa/v/492a90bc5327/schmuckbild-statistikgesetze.png)![](https://download.statistik-berlin-brandenburg.de/06ad7ffc82f199f9/bfe5d156f37e/v/b4b86bb36a19/schmuckbild-ueber-uns-getting-together-for-a-greener-future-picture-id1282388319.jpg)
#### Wir richten uns nach dem Corporate Governance Kodex

Der Corporate Governance Kodex enthält Regeln guter und verantwortungsvoller Unternehmensleitung und -kontrolle. Mit ihm soll auch die Transparenz des Leitungs- und Kontrollsystems für die Unternehmen gegenüber der Öffentlichkeit verbessert werden. Der Kodex ist ein notwendiges Element der Vorsorge gegen wirtschaftliche Fehlentwicklungen bei landesbeteiligten Unternehmen.

Als eines der ersten Bundesländer hatte Brandenburg den Corporate Governance Kodex im Jahr 2005 eingeführt. Seitdem wird er regelmäßig aktualisiert und geltenden Standards angepasst.

**[Erklärung des AfS zum Corporate Governance Kodex (PDF)](https://download.statistik-berlin-brandenburg.de/9a787b5674552df1/9802621435b2/corporate-governance-kodex-erklaerung.pdf)**

**[Lagebericht 2023 (PDF)](https://download.statistik-berlin-brandenburg.de/5e1418c34a02d03b/254a1b3cfd01/afs-lagebericht-2023.pdf)**

**[Gesamtbezüge des Vorstands 2023 (PDF)](https://download.statistik-berlin-brandenburg.de/368bce9edabbc7e2/35a502bc17b3/afs-verguetung-vorstand-2023.pdf)**

### Darauf können Sie zählen:Jobs beim Amt für Statistik Berlin-Brandenburg

[Zum Karrierebereich](/karriere)

Wir nehmen keine Geschenke an
-----------------------------

**Eine besondere Bitte an alle, die unsere Arbeit schätzen und würdigen wollen:**

Drücken Sie Ihre Zufriedenheit über eine gute Zusammenarbeit bitte nicht mit Geschenken aus. Lassen Sie es erst gar nicht dazu kommen, dass unsere Beschäftigten – von Ihnen gut gemeinte – Geschenke zurückweisen müssen, damit kein Anschein für eine mögliche Beeinflussung bei der Wahrung öffentlicher Aufgaben entstehen kann.

Mit dem Verzicht auch auf kleine Geschenke, die Ihnen als Selbstverständlichkeit oder wegen ihres Wertes als Bagatelle erscheinen, betreiben wir aktiv **Korruptionsprävention**. Als Teil der öffentlichen Verwaltung ist für die Beschäftigten des Amtes für Statistik Berlin-Brandenburg selbst die Annahme kleiner Geschenke immer mit einer Anzeigepflicht verbunden und nur in sehr engen Grenzen erlaubt.

![](https://download.statistik-berlin-brandenburg.de/460dee5bc3c59dac/94ef4e273114/v/c9eb743fead3/Korruption.png)
