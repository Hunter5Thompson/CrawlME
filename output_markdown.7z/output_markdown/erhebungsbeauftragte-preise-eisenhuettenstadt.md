

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Preise](/wirtschaft/preise)
* [Verbraucherpreise](/verbraucherpreise)

**Wir suchen Preisererheber/-innen für Seelow und Eisenhüttenstadt**
--------------------------------------------------------------------

Als Preiserheberin oder Preiserheber besuchen Sie bestimmte Geschäfte und Dienstleistungsfirmen, um dort monatlich die Preisentwicklung ausgewählter Waren und Dienstleistungen zu beobachten. Neben dem Preis werden weitere Informationen wie die Menge der erhobenen Waren gesammelt.

Die Daten erfassen Sie mit einem Tablet und übermitteln diese dann über einen gesicherten Weg via Internet an uns. In der Regel ist für die Erhebung der Preise ein Zeitraum von sechs Tagen vorgesehen. In diesem Zeitraum sind Sie in Ihrer persönlichen **Zeiteinteilung flexibel**. Der Zeitaufwand hängt von der Anzahl der übernommenen Geschäfte und Unternehmen sowie vom Umfang der zu erhebenden Preise ab.

Selbstverständlich erhalten Sie eine umfassende Einweisung in diese verantwortungsvolle Aufgabe und in die methodischen Grundlagen. Im Rahmen der Tätigkeit werden Sie intensiv von unseren Mitarbeiterinnen und Mitarbeitern unterstützt.

#### Verbraucherpreisindex

Der Verbraucherpreisindex der amtlichen Statistik misst die durchschnittliche Preisentwicklung der Waren und Dienstleistungen, die private Haushalte für Konsumzwecke kaufen. Darunter fallen z. B. Nahrungsmittel, Friseurdienstleistungen oder Kraftstoffe. Die Veränderung des Index gegenüber dem Vorjahresmonat oder dem Vorjahr wird auch als Inflationsrate bezeichnet.

### Wir haben Ihr Interesse geweckt?

Wir freuen uns auf Ihre Bewerbung per E-Mail an[**preise@statistik-bbb.de**](mailto:preise@statistik-bbb.de?subject=Preisererheber%2F-innen%20f%C3%BCr%20Eisenh%C3%BCttenstadt&body=Sehr%20geehrte%20Damen%20und%20Herren%2C%0D%0A%0D%0Ahiermit%20bekunde%20ich%20mein%20Interesse%2C%20im%20Rahmen%20der%20Verbraucherpreisstatistik%20als%20Preiserheber%2F-in%20t%C3%A4tig%20sein%20zu%20wollen.%0D%0A%0D%0AMeine%20pers%C3%B6nlichen%20Angaben%3A%0D%0A%0D%0AVorname%3A%0D%0AName%3A%0D%0AStra%C3%9Fe%20und%20Hausnummer%3A%0D%0APLZ%2C%20Ort%3A%0D%0AGeburtsdatum%3A%0D%0ATel.-Nr.%3A%0D%0A). Bitte teilen Sie uns darin Ihren vollständigen Namen, Ihre Adresse, Ihre Telefonnummer und ggf. Ihr Geburtsdatum mit.

[Jetzt bewerben](mailto:preise@statistik-bbb.de?subject=Preisererheber%2F-innen%20f%C3%BCr%20Eisenh%C3%BCttenstadt&body=Sehr%20geehrte%20Damen%20und%20Herren%2C%0D%0A%0D%0Ahiermit%20bekunde%20ich%20mein%20Interesse%2C%20im%20Rahmen%20der%20Verbraucherpreisstatistik%20als%20Preiserheber%2F-in%20t%C3%A4tig%20sein%20zu%20wollen.%0D%0A%0D%0AMeine%20pers%C3%B6nlichen%20Angaben%3A%0D%0A%0D%0AVorname%3A%0D%0AName%3A%0D%0AStra%C3%9Fe%20und%20Hausnummer%3A%0D%0APLZ%2C%20Ort%3A%0D%0AGeburtsdatum%3A%0D%0ATel.-Nr.%3A%0D%0A)
### Was wird von mir erwartet?

Interesse an der Entwicklung von Preisen.

Ein freundliches Auftreten.

Sicherheit im Umgang mit einem Tablet.

Eine zuverlässige und gewissenhafte Arbeitsweise.

Sie werden verpflichtet, die Geheimhaltung gemäß Bundesstatistikgesetz zu wahren.

### Wie wird die Leistung vergütet?

Bei der Tätigkeit handelt es sich um eine selbstständige Tätigkeit.

Für jeden erhobenen Preis wird eine Vergütung in Höhe von 0,55 EUR gezahlt.

Für Bekleidungsartikel, Schuhe, technische Güter und Möbel beträgt die Vergütung 0,65 EUR pro Beobachtung.

Zusätzlich hierzu werden Fahrtkosten in Höhe der ortsüblichen Preise des ÖPNV und Schulungsgeld als Aufwandsentschädigung gezahlt.

Bitte beachten Sie, dass ab einer bestimmten Höhe die Vergütung steuerpflichtig ist.

### Kontakt

#### Berit Nimmich

Verbraucherpreise

#### Berit Nimmich

Verbraucherpreise

* [0331 8173 3034](tel:0331 8173 3034)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)

[* Verbraucherpreise](/search-results?q=tag%3AVerbraucherpreise)[* Preise](/search-results?q=tag%3APreise)[* Erhebungsbeauftragte](/search-results?q=tag%3AErhebungsbeauftragte)[* Job](/search-results?q=tag%3AJob)
