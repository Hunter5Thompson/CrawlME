

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Ausbildungsförderung](/ausbildungsfoerderung)
* [Förderung beruflicher Aufstiegsfortbildung nach dem Aufstiegsfortbildungsförderungsgesetz (AFBG) in Berlin und Brandenburg](/k-ix-2-j)
* [K IX 2 – j](/archiv/k-ix-2-j)

Archiv: Statistischer Bericht
=============================

#### **Förderung beruflicher Aufstiegsfortbildung nach dem Aufstiegsfortbildungsförderungsgesetz (K IX 2 – j)**

![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben dieses Statistischen Berichts jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000557)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000559)


