

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Schulen](/gesellschaft/bildung/schulen)
* [Ausbildungsstätten für Fachberufe des Gesundheitswesens](/b-ii-6-j)

Ausbildungsstätten für Fachberufe des Gesundheitswesens
-------------------------------------------------------

#### Schuljahr 2023/2024, jährlich

###### Der Statistische Bericht enthält ausgewählte Daten des aktuell vorliegenden Schuljahres und liefert detaillierte Informationen u.a. über die Entwicklung der Schülerzahlen, zu Absolventinnen und Absolventen und zu Lehrkräften.

BerlinBrandenburgMethodik

Berlin
------

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – Schuljahr 2023/24**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/33ead109b9a8030b/1fffd531622a/SB_B02-06-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b8b599ad0ff769e8/363488a1a052/SB_B02-06-00_2023j01_BE.pdf)

**Pflegefachfrau/-mann seit Einführung 2020 der am stärksten besetzte Ausbildungsberuf**

An den 50 staatlich anerkannten Schulen des Gesundheitswesens wurden im aktuellen Schuljahr 10.355 Auszubildende, darunter 7.029 Frauen (67,9 %) von 1.450 Lehrkräften unterrichtet.

Im Vergleich zum vergangenen Schuljahr ist die Anzahl an Lehrkräften um 109 gesunken. Dies bedeutet für Berlin einen Rückgang an Lehrkräften um 7,0 %. Die Anzahl an Schülerinnen und Schüler hingegen stieg im gleichen Zeitraum um 553 (5,6 %).

6.900 Auszubildende absolvierten eine Ausbildung in den Pflegeberufen. Im Vergleich zum Vorjahr ein Anstieg von 6,3 %. Für eine Ausbildung in den medizinisch-technisch/therapeutischen Berufen entschieden sich 3.455 Auszubildende.

Eine Ausbildung zur Pflegefachfrau bzw. zum Pflegefachmann absolvierten in Berlin 6.287 Schülerinnen und Schüler, darunter 4.423 Frauen (70,4 %). Die Ausbildung zur Pflegefachfrau bzw. zum Pflegefachmann stellt mit 60,7 % den am stärksten besetzten Ausbildungsberuf an den Berliner Gesundheitsschulen dar.

### Kontakt

#### Silke Tasler

Berufsbildung

#### Silke Tasler

Berufsbildung

* [0331 8173-1175](tel:0331 8173-1175)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Katrin Springer

Berufsbildung

#### Katrin Springer

Berufsbildung

* [0331 8173-1143](tel:0331 8173-1143)
* [gesundheitsschulen@statistik-bbb.de](mailto:gesundheitsschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Ausbildung zur/zum Pflegefachfrau/-mann mit den meisten Schülerinnen und Schüler besetzt**

Im Schuljahr 2023/24 absolvierten 4.436 Auszubildende eine Ausbildung in den Pflegeberufen. Im Vergleich zum Vorjahr ein Anstieg von 3,3 %. Für eine Ausbildung in den medizinisch-technisch/therapeutischen Berufen entschieden sich 1.567 Auszubildende.

An den 43 brandenburgischen Schulen des Gesundheitswesens erlernten insgesamt 6.003 Auszubildende, darunter 4.343 Frauen (72,4 %) einen Beruf im Gesundheitswesen. Im Vergleich zum vergangenen Schuljahr stieg die Zahl der Schülerinnen und Schüler um 6,4 %.

Die Schülerinnen und Schüler wurden von 1.002 Lehrkräften unterrichtet.

Die Ausbildung zur Pflegefachfrau bzw. zum Pflegefachmann absolvierten 3.887 Auszubildende, darunter 2.878 Frauen (74,0 %). Die Ausbildung zur Pflegefachfrau bzw. zum Pflegefachmann stellt mit 64,8 % den am stärksten besetzten Ausbildungsberuf an den Gesundheitsschulen in Brandenburg dar.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht –****Schuljahr 2023/24**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a2d81fc9682f8c1d/07e09ca0c40a/SB_B02-06-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/823603e0c41b68db/be91cb9dbdb3/SB_B02-06-00_2023j01_BB.pdf)
### Kontakt

#### Silke Tasler

Berufsbildung

#### Silke Tasler

Berufsbildung

* [0331 8173-1175](tel:0331 8173-1175)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Katrin Springer

Berufsbildung

#### Katrin Springer

Berufsbildung

* [0331 8173-1143](tel:0331 8173-1143)
* [gesundheitsschulen@statistik-bbb.de](mailto:gesundheitsschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Statistik der Ausbildungsstätten für Fachberufe des Gesundheitswesens wird jährlich für die Länder Berlin und Brandenburg mit differenzierter Erhebungsmethodik durchgeführt.

Der statistische Bericht enthält Ergebnisse über Ausbildungsstätten, Klassen, Auszubildende, Absolventinnen und Absolventen, Abgängerinnen und Abgänge, und Lehrkräfte im Land Brandenburg im Berichtsjahr. Die Ergebnisse sind nach Ländersystematik aufbereitet und für Ländervergleiche nur bedingt geeignet.

**Berlin**

Es handelt sich um eine koordinierte Länderstatistik als Totalerhebung mit Auskunftspflicht. Die Erhebung bezieht sich auf den Stichtag 1. November des laufenden Schuljahres, Zahlen über Absolventinnen und Absolventen sowie Abgängerinnen und Abgänger auf den Zeitraum nach dem Stichtag des Vorjahres bis zum Stichtag des aktuellen Jahres.

Hauptnutzer sind die Senatsverwaltung für Wissenschaft, Gesundheit, Pflege und Gleichstellung, die Senatsverwaltung für Arbeit, Soziales, Gleichstellung, Integration, Vielfalt und Antidiskriminierung, die Senatsverwaltung für Bildung, Jugend und Familie, das Bundesministerium für Bildung und Forschung, die Kultusministerkonferenz, Eurostat, wissenschaftliche Einrichtungen und die interessierte Öffentlichkeit.

**Brandenburg**

Seit 2012 werden Individualdaten für Auszubildende, Klassen, Lehrkräfte und Absolventinnen und Absolventen und Abgängerinnen und Abgänger erhoben. Die Erhebungsmerkmale orientieren sich an den Kerndatensatz der Länder für schulstatistische Individualdaten in den Gesundheitsfachberufen (KDS-G).

Hauptnutzer der Statistik sind das Ministerium für Soziales, Gesundheit, Integration und Verbraucherschutz, das Landesamt für Soziales und Versorgung, das Landesamt für Arbeitsschutz, Verbraucherschutz und Gesundheit, die Gesundheitsministerkonferenz und das Statistische Bundesamt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Schulen des Gesundheitswesens**2023/2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/6648ba8c56a8d629/ae301abf003f/MD_21131_2023.pdf)[Archiv](/search-results?q=21131&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-ii-6-j)
