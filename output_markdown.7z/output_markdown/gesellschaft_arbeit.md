

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
#### Überblick

Arbeit
======

Höhe und strukturelle Zusammensetzung der Kosten des
Produktionsfaktors Arbeit sind von großer Bedeutung für die
Arbeitsmarkt- und Wirtschaftspolitik. Hier finden Sie Informationen zu
Erwerbstätigkeit, sozialversicherungspflichtiger Beschäftigung und
Arbeitslosigkeit in Berlin und Brandenburg sowie zur Struktur der Verdienste
und der Arbeitskosten.

BerlinBrandenburg

**Stellung im Beruf**Erwerbstätige am Arbeitsort 2023 in Berlin – Stand: 08/24

**Quelle:** Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: August 2023)[Erwerbstätige und Beschäftigte
#### Erwerbstätigkeit](/erwerbstaetigkeit)[Bruttoverdienste und Arbeitszeiten
#### Verdienste](/verdienste)[Bruttoverdienste und Lohnnebenkosten
#### Arbeitskosten](/arbeitskosten)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Arbeit

Die wichtigsten Kennzahlen
--------------------------

1 Erwerbstätige nach dem Inlandskonzept (Arbeitsort), im Jahresdurchschnitt auf der Grundlage der WZ 2008**Quelle:** Vorläufige Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: August 2024)
###### Veränderung gegenüber dem Vorjahr in %

#### Erwerbstätige am Arbeitsort 2022

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

1  Der Nominallohnindex wurde 2022 einer Revision unterzogen, zudem umfassen die Ergebnisse die Wirtschaftszweige A-S (bis 2021 B-S).2  Infolge einer Revision des Verbraucherpreisindex (VPI) und des Index der Nominallöhne wurde der Reallohnindex angepasst. Ab 2022 umfassen die Ergebnisse die Wirtschaftszweige A-S (bis 2021 B-S).**Quelle:** Amt für Statistik Berlin-BrandenburgB BerlinD Deutschland**Quelle:** Amt für Statistik Berlin-Brandenburg
##### 

#### Neues aus dem Bereich Arbeit

Zuletzt veröffentlicht
----------------------

![iStock.com / Jirapong Manustrong](https://download.statistik-berlin-brandenburg.de/dad6d5e55f0bb1b6/f05da019c495/v/68adaaa1a726/gesellschaft-arbeit-young-businesses-hold-cell-phone-smartphones-to-call-partners-to-picture-id905778168.jpg)17.12.2024Statistischer Bericht[#### 2014 bis 2023, halbjährlich, A VI 17 - hj: Geleistete Arbeitsstunden in Berlin und Brandenburg](/a-vi-17-hj)

Die jährlichen Ergebnisse zum Arbeitsvolumen (Inlandskonzept) geben den Gesamtumfang der tatsächlich geleisteten Arbeitszeit aus der Erwerbstätigenrechnung wieder.

[Ansehen](/a-vi-17-hj)![](https://download.statistik-berlin-brandenburg.de/34cfa0a358b226ad/096628a87685/v/4d8073e7738f/gesellschaft-Arbeit-Stock-1194077283.jpg)29.11.2024Pressemitteilung[#### Verdienstentwicklung im 3. Quartal 2024 in Berlin und Brandenburg: Deutlich positive Entwicklung der Reallöhne](/165-2024)

Im 3. Quartal 2024 legten die Reallöhne in Berlin und Brandenburg deutlich zu. Verantwortlich dafür waren gestiegene Bruttolöhne bei einer gleichzeitig niedrigen Teuerung.

[Ansehen](/165-2024)![iStock.com / stockfour](https://download.statistik-berlin-brandenburg.de/8e0e00b918a74772/704aa663145a/v/ec5891f3443d/gesellschaft-bildung-portrait-of-young-man-in-office-team-meeting-picture-id1227527658.jpg)29.10.2024Statistischer Bericht[#### 2014 bis 2023, drei mal jährlich, A VI 9: Erwerbstätige am Arbeitsort in Berlin und Brandenburg – Jahresergebnisse](/a-vi-9-hj)

Erwerbstätige am Arbeitsort – Jahresergebnisse 2014 bis 2023, drei mal jährlich, Berechnungsstand: August 2024 Hier finden Sie jährliche Ergebnisse zur Erwerbstätigkeit am Arbeitsort in Berlin und...

[Ansehen](/a-vi-9-hj)Mehr anzeigen


