

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Erwerbstätigkeit](/erwerbstaetigkeit)
* [Erwerbstätige am Arbeitsort in Berlin und Brandenburg – Vierteljahresergebnisse](/a-vi-16-vj)

Erwerbstätige am Arbeitsort **–**
---------------------------------

Vierteljahresergebnisse
-----------------------

#### 1. Vj 2008 bis 1. Vj 2024, Berechnungsstand: Mai 2024, vierteljährlich

###### Hier finden Sie vierteljährliche Ergebnisse zur Zahl der Erwerbstätigen am Arbeitsort in Berlin und Brandenburg aus der Erwerbstätigenrechnung des Arbeitskreises „Erwerbstätigenrechnung der Länder“ (AK ETR) nach ausgewählten Wirtschaftsbereichen für das 1. Quartal 2008 bis 1. Quartal 2024.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: Mai 2024)
#### **Zum Statistischen Bericht – Berechnungsstand: Mai** 2024

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a9bd2e13ae86113d/b95a07ee7cbd/SB_A06-16-00_2024q01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/39aaf3ad99d30f2b/6e14fe9cec78/SB_A06-16-00_2024q01_BE.pdf)

**Erwerbstätigenanstieg in Berlin setzt sich mit weiter nachlassender Dynamik fort**

Im 1. Quartal 2024 waren in Berlin 2.185.600 Personen erwerbstätig. Gegenüber dem Vorjahresquartal erhöhte sich die Erwerbstätigkeit um 9.100 Personen bzw. 0,4 %. Damit setzte sich der seit dem 2. Quartal 2021 andauernde Aufwärtstrend der Erwerbstätigkeit in Berlin mit weiter nachlassender Dynamik fort.

Im Produzierenden Gewerbe legte die Erwerbstätigkeit um 400 Personen (+0,2 %) im Vergleich zum 1. Quartal 2023 zu. Im Teilbereich Baugewerbe waren es 1.900 Personen (–2,1 %) weniger, im Verarbeitenden Gewerbe 700 Personen (+0,7 %) mehr als vor Jahresfrist. Erstmals seit drei Jahren entwickelten sich auch die Dienstleistungen nicht mehr einheitlich positiv. Zwar gab es im gesamten Sektor ein Plus von 8.600 Personen (+0,4 %), jedoch ging die Zahl der Erwerbstätigen im Bereich „Handel, Verkehr, Gastgewerbe, Information und Kommunikation“ erstmals seit dem 1. Quartal 2021 um 3.400 Personen (–0,6 %) zurück.

### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Zahl der Erwerbstätigen in Brandenburg rückläufig**

Im 1. Quartal 2024 waren 1.139.000 Personen in Brandenburg erwerbstätig. Das waren 400 Personen weniger als im 1. Quartal 2023. Aktualisierte Berechnungen des Arbeitskreises „Erwerbstätigenrechnung der Länder“ (AK ETR) weisen bereits für das 4. Quartal 2023 einen Rückgang der Erwerbstätigkeit um 600 Personen bzw. 0,1 % gegenüber dem 4. Quartal 2022 aus. Damit wurde der seit dem 2. Quartal 2021 andauernde Aufwärtstrend der Erwerbstätigkeit in Brandenburg gestoppt.

Neben der Landwirtschaft (–1,1 %) ging die Erwerbstätigkeit auch im Produzierenden Gewerbe in Brandenburg um 2.200 Personen (–0,9 %) zurück. Hauptverantwortlich dafür war ein Rückgang im Baugewerbe um 1.700 Personen (–1,8 %). Erstmals seit dem 2. Quartal 2021 war zudem die Erwerbstätigkeit auch im Verarbeitenden Gewerbe (–0,5 %) rückläufig. In den Dienstleistungsbereichen erhöhte sich die Zahl der Erwerbstätigen insgesamt zwar um 2.100 Personen (+0,2 %). Allerdings ist dies einzig auf den hohen Zuwachs von 6.700 Personen (+1,7 %) im Bereich „Öffentliche und sonstige Dienstleister, Erziehung und Gesundheit“ zurückzuführen.

 Der Wert für die Position "Insgesamt" beträgt gerundet 0,0 %".**Quelle:** Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: Mai 2024)
#### **Zum Statistischen Bericht –****Berechnungsstand: Mai**2024

[Download XLSX](https://download.statistik-berlin-brandenburg.de/dad37ad635bc3c8a/e4e474d977ca/SB_A06-16-00_2024q01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/1ba86046aa3faca2/96cb8d135ff8/SB_A06-16-00_2024q01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erwerbstätigenrechnung (ETR) liefert ein umfassendes Bild der wirtschaftlich aktiven Bevölkerung. Auf der Grundlage einer Vielzahl erwerbsstatistischer Datenquellen wird sowohl die Zahl der Erwerbstätigen am Arbeitsort (Inlandskonzept) und Wohnort (Inländerkonzept) als auch das Arbeitsvolumen nach der Stellung im Beruf und der wirtschaftsfachlichen Gliederung ermittelt. Ergebnisse für das Bundesgebiet werden von Destatis berechnet, für die Länder sowie Landkreise und kreisfreien Städte vom Arbeitskreis „Erwerbstätigenrechnung der Länder“ (AK ETR). Die Berechnungen erfolgen nach den konzeptionellen und definitorischen Vorgaben des Europäischen Systems Volkswirtschaftlicher Gesamtrechnungen (ESVG 2010), wodurch internationale Vergleichbarkeit gewährleistet ist.

Die hier vorliegenden Zahlen sind Ergebnisse des AK ETR, die auf den Rechenstand des Statistischen Bundesamtes vom Mai 2024 abgestimmt sind. Neben der Erstberechnung der Erwerbstätigkeit im 1. Quartal 2024 wurden die Ergebnisse für das 1. bis 4. Quartal 2023 turnusmäßig überarbeitet.

Die Ergebnisse der unmittelbar zurückliegenden Quartale werden aufgrund der sich ändernden Datenbasis im Laufe der Folgequartale jeweils zu jeder Vierteljahresrechnung, die Ergebnisse der letzten vier Jahre i. d. R. jeweils im Oktober eines Jahres überarbeitet.

Nächste Aktualisierung: Aufgrund der derzeit laufenden Generalrevision 2024 in der regionalen ETR und VGR erfolgt die nächste Veröffentlichung voraussichtlich Ende des 1. Quartals 2025.

Ergebnisse aller Bundesländer Deutschlands stellt der AK ETR unter [www.statistikportal.de/de/etr](https://www.statistikportal.de/de/etr "Verknüpfung folgen") zur Verfügung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erwerbstätige**ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/b85a593b815ea440/a3de95641681/MD_13300_2023.pdf)[Archiv](/search-results?q=MD_13300&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)
