

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Ausbildungsförderung](/ausbildungsfoerderung)
* [Förderung beruflicher Aufstiegsfortbildung nach dem Aufstiegsfortbildungsförderungsgesetz (AFBG) in Berlin und Brandenburg](/k-ix-2-j)

Förderung beruflicher Aufstiegsfortbildung nach dem Aufstiegsfortbildungsförderungsgesetz (AFBG)
------------------------------------------------------------------------------------------------

#### 2023, jährlich

###### In der Statistik erfasst werden detaillierte Angaben zum sozialen und finanziellen Hintergrund der Geförderten und ihrer Ehegatten sowie die Höhe und Zusammensetzung des finanziellen Bedarfs der Geförderten und der errechneten Förderungsbeträge.

BerlinBrandenburgMethodik
### Berlin

\* Abweichungen der Gesamtförderung durch Rundungen der Förderungsbeträge**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/39c53edd068699d8/21bbad8d030d/SB_K09-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/05b500759536f32c/4fad9d7667d2/SB_K09-02-00_2023j01_BE.pdf)

**Mehr Förderleistungen in Berlin**

Im Jahr 2023 haben insgesamt 2.468 Personen Förderleistungen im Rahmen des Aufstiegsfortbildungsförderungsgesetzes (Aufstiegs-BAföG) bewilligt bekommen. Das sind 4,8 % weniger als im Vorjahr (2.593). Mit dem Aufstiegs-BAföG werden Teilnehmerinnen und Teilnehmer an Maßnahmen der beruflichen Aufstiegsfortbildung durch Beiträge zu den Kosten der Bildungsmaßnahme und zum Lebensunterhalt finanziell unterstützt.

### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Mehr Förderleistungen in Brandenburg**

Im Jahr 2023 haben insgesamt 6.267 Personen Förderleistungen im Rahmen des Aufstiegsfortbildungsförderungsgesetzes (Aufstiegs-BAföG) bewilligt bekommen. Das sind 1,9 % mehr als im Vorjahr (6.150). Mit dem Aufstiegs-BAföG werden Teilnehmerinnen und Teilnehmer an Maßnahmen der beruflichen Aufstiegsfortbildung durch Beiträge zu den Kosten der Bildungsmaßnahme und zum Lebensunterhalt finanziell unterstützt.

\* Abweichungen der Gesamtförderung durch Rundungen der Förderungsbeträge**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7686b9ccae62cc9b/f63496fbf964/SB_K09-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/f68a365cda0d2b05/ae4c375126d8/SB_K09-02-00_2023j01_BB.pdf)
### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Zur Ausbildungsförderung werden derzeit jährlich zwei Bundesstatistiken als Sekundärstatistik durchgeführt:

* Statistik nach dem Bundesausbildungsförderungsgesetz (BAföG)
* Statistik nach dem Aufstiegsfortbildungsförderungsgesetz (AFBG)

Beide Gesetze werden im Auftrag des Bundes von den Ländern umgesetzt, die die dafür zuständigen Behörden bestimmt haben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der
Ausbildungsförderung (AFBG/„Meister-BAföG“)**  
ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/17bd18aac6d522c6/6fa451e91311/MD_21421_2019.pdf)[Archiv](/search-results?q=21421&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-ix-2-j)


