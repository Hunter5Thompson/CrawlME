

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Bevölkerungsstand](/bevoelkerung/demografie/bevoelkerungsstand)
* [Bevölkerungsstand in Berlin und Brandenburg – Monatsergebnisse](/a-i-7-a-ii-3-a-iii-3-m)

Bevölkerungsstand
-----------------

#### August 2024, monatlich, Basis: Zensus 2011

###### In der Bevölkerungsfortschreibung wird der Bevölkerungsbestand einer Region rechnerisch ermittelt, indem Geburten und Zuzüge addiert und Sterbefälle und Fortzüge abgezogen werden.

BerlinBrandenburgMethodik
### Berlin

 Basis: Zensus 2011**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/38b892b98d9beb2b/0cabf9b3073e/SB_A01-07-00_2024m08_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/44e6017420f77b96/9337688a680d/SB_A01-07-00_2024m08_BE.pdf)

**Berliner Bevölkerung sinkt im August 2024**

Am 31.08.2024 lebten 3.789.646 Menschen in Berlin, –1.026 weniger als im Vormonat. Sowohl die Zahl der deutschen (–864) als auch der ausländischen Bevölkerung (–162) sank. Der Anteil der deutschen Bevölkerung an der Gesamtbevölkerung blieb gleich bei 76,3 %.

Berlin registrierte im August 2.757 Lebendgeborene und 2.879 Gestorbene und verzeichnete damit einen Sterbeüberschuss (–122). Der Bezirk Friedrichshain‑Kreuzberg verzeichnete den größten Geburtenüberschuss(+81) und der Bezirk Steglitz-Zehlendorf (–111) den höchsten Sterbeüberschuss.

Der Bevölkerungsrückgang wurde hauptsächlich durch die geringen Wanderungsströme ausgelöst. Der Zuzugsüberschuss aus dem Ausland (+2.412) konnte den Fortzugsüberschuss der Deutschen (–3.286) nicht ausgleichen. Berlin verzeichnete einen Wanderungsverlust(–874). Dieser setzt sich aus den Auslandswanderungen (+2.039) und den Wanderungen innerhalb des Bundesgebiets (–2.913) zusammen.

Bis auf Mitte und Charlottenburg-Wilmersdorf verzeichneten alle Bezirke einen Fortzugsüberschuss der Außenwanderung. Der Bezirk Reinickendorf muss mit seinem hohen Zuzugsüberschuss (+821) extra betrachtet werden, weil sich dort für Berlin das Ankunftszentrum für Asylsuchende befindet.

### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Brandenburger Bevölkerung **steigt 2024****

Brandenburg wies zum 31.08.2024 einen Bevölkerungsbestand von 2.583.730 Personen aus.  
Der Bevölkerungsanstieg um insgesamt 863 Personen wurde durch das Wachstum der ausländischen (+627) und der deutschen Bevölkerung (+236) erreicht.

Im August registrierte die kreisfreie Stadt Frankfurt (Oder) (–148) die höchste Bevölkerungsabnahme und der Landkreis Teltow-Fläming (+207) die größte Bevölkerungszunahme. Der Wanderungsgewinn betrug +2.413, der Sterbeüberschuss –1.524 Personen.

In Brandenburg wurden im August 1.250 Lebendgeborene und 2.774 Gestorbene registriert. Alle kreisfreien Städte und Landkreise verzeichneten einen Sterbeüberschuss.

Dahingegen fanden im August 8.529 Zuzüge und 6.116 Fortzüge über die Landesgrenze statt. Den höchsten Zuzugsüberschuss erlangte Brandenburg aus Berlin (+1.902) sowie aus dem Ausland (+556).

Bis auf die kreisfreien Städte Frankfurt (Oder) und Potsdam verzeichneten alle kreisfreien Städte bzw. Landkreise einen Wanderungsgewinn. Den höchsten Zuzugsüberschuss erzielten die Landkreise Havelland (+307), Teltow-Fläming (+281) und Potsdam‑Mittelmark (+280).

Der Landkreis Oder‑Spree muss mit einem Zuzugsüberschuss der Außenwanderung von +575 separat betrachtet werden, weil sich in Eisenhüttenstadt die Zentrale Aufnahmestelle für Asylbewerber im Land Brandenburg befindet, die zur Zentralen Ausländerbehörde gehört.

 Basis: Zensus 2011**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – August 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7a5ef90bb8165b21/d60f3053c172/SB_A01-07-00_2024m08_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/ad6d823052bcb4e4/77e44bf8ecde/SB_A01-07-00_2024m08_BB.pdf)
### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der Bevölkerungsstand wird monatlich ermittelt und ist eine Berechnungsgröße.

Die Ergebnisse der jeweils letzten Volkszählung (Zensus 2011) werden mit den Ergebnissen der Statistiken der Bevölkerungsbewegungen (Wanderungen, Geburten, Sterbefälle, Eheschließungen) sowie mit Angaben zu Staatsangehörigkeitswechseln und Lösungen von Ehen und Lebenspartnerschaften fortgeschrieben.

Die monatlichen demografischen Merkmale liegen in unterschiedlicher regionaler Gliederungstiefe vor:

Geschlecht und Staatsangehörigkeit (deutsch/nicht-deutsch) liegen bis auf Gemeindeebene vor. Der Familienstand wird auf der Kreisebene und einzelne Staatsangehörigkeiten werden auf der Landesebene bereitgestellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Fortschreibung des Bevölkerungstandes (2023)**](https://download.statistik-berlin-brandenburg.de/2983d8b717d04a9f/76a8bde3d1e7/MD_12411_2023.pdf)**|[Archiv](/search-results?q=MD_12411&searchMethodik=true&pageNumber=1&sortBy=date-desc)**

**[Statistik der Eheschließungen (2023)](https://download.statistik-berlin-brandenburg.de/bb9e60988fc6fafb/2ec30e059d7c/MD_12611_2023.pdf)** | [Archiv](/search-results?q=MD_12611&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[**Statistik der Geburten (2023)**](https://download.statistik-berlin-brandenburg.de/19ba785be203d4e8/291737a3e031/MD_12612_2023.pdf) | [Archiv](/search-results?q=MD_12612&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[**Statistik der Sterbefälle (2023)**](https://download.statistik-berlin-brandenburg.de/5742db59b3f3980d/12ea30fbcdba/MD_12613_2023.pdf) | [Archiv](/search-results?q=MD_12613&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[**Wanderungsstatistik****(2023)**](https://download.statistik-berlin-brandenburg.de/290017d5108fc3db/9dcac94c0213/MD_12711_2023.pdf)| [Archiv](/search-results?q=MD_12711&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-i-7-m-a-ii-3-m-a-iii-3-m)
