

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Zu- und Fortzüge](/bevoelkerung/demografie/zu-und-fortzuege)

Zu- und Fortzüge
================

Die Statistik der Wanderungen beziehungsweise der Zu- und Fortzüge weist monatlich die räumliche Mobilität der Bevölkerung nach. Sie liefert Grunddaten nach demografischen Merkmalen für die Berechnung der Fortschreibung des Bevölkerungsstandes, für demografische Analysen und Vorausberechnungen.   
Erhebungsgrundlage sind die in den Meldeämtern nach den melderechtlichen Vorschriften erfassten An- und Abmeldungen, die bei einem erfolgten Wohnungswechsel stattfinden.

Informationen zu den Zu- und Fortzügen der Kommunalstatistik Berlin auf kleinräumiger Ebene finden Sie [hier](/kommunalstatistik/wanderungen-berlin).

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Wanderungen in Berlin und Brandenburg, jährlich (AIII2-j)](/a-iii-2-j)[Bevölkerungsstand in Berlin und Brandenburg, monatlich (AI7-m, AII3-m, AIII3-m)](/a-i-7-a-ii-3-a-iii-3-m)

Zeitreihen
----------

1 über die Grenze der Region, ohne Wanderungen zwischen Berlin und Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 über die Grenze der Region, ohne Wanderungen zwischen Berlin und Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 einschließlich Bestandskorrekturen**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/0d316376b5d79d3c/b82a4be2f137/Zu-und-Fortzuege_Zeitreihe.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/175842f75d2a2206/de13a36d915e/zu-und-fortzuege-wanderungen-lange-reihe.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Berlin 2023

#### Saldo aus Zu- und Fortzügen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburg 2023

#### Saldo aus Zu- und Fortzügen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=statistic&levelindex=0&levelid=1714041722870&code=12711#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/bevoelkerung)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1714044595945&code=12711#abreadcrumb)
#### StatIS-BBB

![](https://download.statistik-berlin-brandenburg.de/78324daa1d8c4302/8f3a5e8bad38/v/4b6c25f57664/statis-bbb-schmuckbild.jpg)

Im Statistischen Informationssystem lassen sich individuelle Auswertungen auf Basis von regional tief gegliederten Daten erstellen und exportieren.

[Zu StatIS-BBB](https://statis.statistik-berlin-brandenburg.de/webapi/jsf/dataCatalogueExplorer.xhtml)

Haben Sie Fragen?
-----------------

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Iris Hoßmann-Büttner

Bevölkerungs- und Kommunalstatistik

#### Iris Hoßmann-Büttner

Bevölkerungs- und Kommunalstatistik

* [0331 8173-3624](tel:0331 8173-3624)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Myga Grobert

Bevölkerungsstatistiken

#### Myga Grobert

Bevölkerungsstatistiken

* [0331 8173-3378](tel:0331 8173-3378)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / Drazen Zigic](https://download.statistik-berlin-brandenburg.de/1f4bd0b328c65464/aa6eefbbc205/v/d9b968ddb0d7/bevoelkerung-gesellschaft-closeup-of-unrecognizable-delivery-man-with-cardboard-box-picture-id1186577710.jpg "iStock.com / Drazen Zigic")](/100-2024)**Wanderungsstatistik 2023 Brandenburg**[#### Hoher Wanderungsgewinn durch Zuzug aus Berlin und dem Ausland](/100-2024)

Pressemitteilung Nr. 100 Wie das Amt für Statistik Berlin-Brandenburg mitteilt, verzeichnete das Land Brandenburg im Jahr 2023 96.078 Zuzüge und 66.292 Fortzüge. Damit wurde ein Wanderungsgewinn von...

[![iStock.com / Lordn](https://download.statistik-berlin-brandenburg.de/1cc6e412ad9be15b/d77fc1a922b8/v/9a17bf6f9a6f/bevoelkerung-demographie-umzuege-move-cardboard-boxes-and-cleaning-things-for-moving-into-a-new-home-picture-id658680974.jpg "iStock.com / Lordn")](/099-2024)**Wanderungsstatistik 2023 Berlin**[#### Hoher Wanderungsgewinn für die Hauptstadt](/099-2024)

Pressemitteilung Nr. 99 Wie das Amt für Statistik Berlin-Brandenburg mitteilt, verzeichnete Berlin im Jahr 2023 187.971 Zuzüge und 155.206 Fortzüge. Der Wanderungsgewinn von 32.765 Personen geht auf...

[![iStock-1223072133.jpg](https://download.statistik-berlin-brandenburg.de/2b90434c5fad7f33/e7435346bdb0/v/d95945521be6/wohnanlage-1.jpg "iStock-1223072133.jpg")](/141-2023)**Wanderungsstatistik 2022 für Brandenburg**[#### Wachstum durch Zuzug](/141-2023)

Pressemitteilung Nr. 141 Im Land Brandenburg wurden 2022 insgesamt 119 806 Zuzüge und 64 285 Fortzüge gezählt, teilt das Amt für Statistik Berlin-Brandenburg mit. Es ergab sich ein Wanderungsgewinn...

[Zu unseren News](/news)

[* Wanderungen](/search-results?q=tag%3AWanderungen)[* Binnenwanderungen](/search-results?q=tag%3ABinnenwanderungen)[* Außenwanderungen](/search-results?q=tag%3AAußenwanderungen)[* Wanderungen über die Gemeindegrenze](/search-results?q=tag%3AWanderungen  über die Gemeindegrenze
)[* Zuzug](/search-results?q=tag%3AZuzug)[* Fortzug](/search-results?q=tag%3AFortzug)[* Räumliche Bevölkerungsbewegung](/search-results?q=tag%3ARäumliche Bevölkerungsbewegung
)[* Herkunftsland](/search-results?q=tag%3AHerkunftsland)
