

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Arbeitnehmerentgelt und Bruttolöhne und -gehälter in den kreisfreien Städten und Landkreisen in Brandenburg](/p-i-7-j)

Arbeitnehmerentgelt und Bruttolöhne und -gehälter in den kreisfreien Städten und Landkreisen in Brandenburg
-----------------------------------------------------------------------------------------------------------

#### 2000 bis 2022, jährlich

###### Die volkswirtschaftlichen Gesamtrechnungen haben die Aufgabe, ein möglichst umfassendes, übersichtliches, hinreichend gegliedertes, quantitatives Gesamtbild des wirtschaftlichen Geschehens zu geben, in das alle inländischen Wirtschaftseinheiten mit ihren wesentlichen Tätigkeiten einbezogen werden.

BrandenburgMethodik
### Brandenburg

**Höhere Arbeitnehmereinkommen in allen Landkreisen und kreisfreien Städten**

Das Arbeitnehmerentgelt pro Person stieg im Jahr 2022 in den Brandenburger Landkreisen um 4,8 % und in den kreisfreien Städten um 4,1 %. Mit 45.633 EUR war es in den kreisfreien Städten um fast 11 % höher als in den Landkreisen mit 41.133 EUR.

Innerhalb des Landes bestanden deutliche Unterschiede in Niveau und Entwicklung der durchschnittlichen Arbeitnehmerentgelte, da diese von der Wirtschaftsstruktur und jeweiligen Arbeitszeit der Arbeitnehmerinnen und Arbeitnehmer beeinflusst werden. Für Potsdam wurde mit 48.561 EUR das höchste, für den Landkreis Prignitz mit 37.852 EUR das geringste Arbeitnehmerentgelt pro Person ermittelt.

Gegenüber dem Vorjahr ist das durchschnittliche Arbeitnehmerentgelt in allen Landkreisen und kreisfreien Städten gestiegen. Die Veränderungsraten bewegten sich zwischen + 3,0 % in Brandenburg an der Havel und + 6,2 % im Landkreis Dahme-Spreewald.

**Quelle:** Volkswirtschaftliche Gesamtrechnungen der Länder; Berechnungsstand: August 2023
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/252844e1e07b7179/8329a9f64b39/SB_P01-07-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7236c8f459759287/c3eeb63a7706/SB_P01-07-00_2022j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das Arbeitnehmerentgelt umfasst die Bruttolöhne und -gehälter sowie tatsächliche und unterstellte Sozialbeiträge der Arbeitgeber. Es spiegelt die Kosten wider, die Arbeitgeber für die Beschäftigung der Arbeitnehmerinnen und Arbeitnehmer aufwenden. Dabei ist zu unterscheiden zwischen dem Arbeitnehmerentgelt am Wohnort (Inländer) und am Arbeitsort (Inland). Die hier veröffentlichten Daten beziehen sich auf das Arbeitnehmerentgelt am Arbeitsort.

Die Ergebnisse der kreisfreien Städte und Landkreise sind auf das Ergebnis des Landes Brandenburg abgestimmt. Sie werden von den jeweiligen statistischen Ämtern der Länder nach im Arbeitskreis „Volkswirtschaftliche Gesamtrechnungen der Länder“ abgestimmter einheitlicher Methoden für das eigene Land berechnet.

Ergebnisse für alle Landkreise und kreisfreien Städte Deutschlands und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/p-i-1-j)
