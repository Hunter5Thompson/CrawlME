

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)
* [Adoptionen, Pflegschaften, Vormundschaften, Beistandschaften, Pflegeerlaubnis, Sorgerecht sowie Maßnahmen des Familiengerichts in Berlin und Brandenburg](/k-v-3-j)

Adoptionen, Pflegschaften, Vormundschaften, Beistandschaften, Pflegeerlaubnis, Sorgerecht sowie Maßnahmen des Familien­gerichts
-------------------------------------------------------------------------------------------------------------------------------

#### 2023, jährlich

###### Die Statistik der Adoptionen stellt Daten zu den Adoptionen, den adoptierten Kindern und Jugendlichen sowie zur Situation der abgebenden und der annehmenden Familien bereit.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/72366168b513e6c1/ecd150fd301f/SB_K05-03-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/5aa1f2a244653b0a/92a22dc8eff7/SB_K05-03-00_2023j01_BE.pdf)

**Adoptionen in Berlin**

Im Jahr 2023 wurden in Berlin 92 Kinder und Jugendliche adoptiert, wobei 75 Kinder zum Zeitpunkt der Adoption noch keine sechs Jahre alt waren. Darunter 61 Kinder noch keine drei Jahre.

Jedes zweite Kind bzw. Jugendlicher wurden von einem Stiefelternteil oder von Verwandten adoptiert.

Am Jahresende 2023 waren 44 Kinder und Jugendliche zur Adoption vorgemerkt. Demgegenüber lagen den Jugendämtern in Berlin 128 Adoptionsbewerbungen vor. 67 Kinder und Jugendliche waren zur Adoptionspflege untergebracht.

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Adoptionen in Brandenburg**

127 Kinder und Jugendliche wurden im Land Brandenburg im Jahr 2023 adoptiert. Zum Zeitpunkt der Adoption waren 86 Kinder noch keine sechs Jahre alt, darunter 69 Kinder noch keine drei Jahre.

76 % der in Brandenburg adoptierten Kinder und Jugendlichen wurden von einem Stiefelternteil oder von Verwandten adoptiert.

25 Kinder und Jugendliche waren am Jahresende 2023 zur Adoption vorgemerkt. Demgegenüber lagen den Jugendämtern in Brandenburg 113 Adoptionsbewerbungen vor. Zur Adoptionspflege waren 84 Kinder und Jugendliche untergebracht.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ba9276fbb3271779/80faa7e95131/SB_K05-03-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/410cacbf3a61007e/b03476f5f902/SB_K05-03-00_2023j01_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik der Adoptionen ist eine jährliche Statistik und erstreckt sich auf alle Kinder und Jugendliche, die im Berichtsjahr adoptiert wurden, sowie auf den Bereich der Adoptionsvermittlung.

Die Adoptionsvermittlung beinhaltet ausgesprochene und aufgehobene Adoptionen, abgebrochene Adoptionspflegen, vorgemerkte Adoptionsbewerbungen, zur Adoption vorgemerkte Kinder und Jugendliche und in Adoptionspflege untergebrachte Kinder und Jugendliche.

In die Erhebung der Pfleg-, Vormund- Beistandschaften, Pflegeerlaubnis, Sorgerechts sowie Maßnahmen des Familiengerichts werden die Zahl der Pflegekinder am Jahresende, für die eine Pflegeerlaubnis erteilt wurde sowie die Gesamtzahlen der Kinder und Jugendlichen unter gesetzlicher und bestellter Amtsvormundschaft, bestellter Amtspflegschaft sowie unter Beistandschaft einbezogen. Ferner erfasst die Statistik für das abgelaufene Jahr die Zahl der Kinder und Jugendlichen, für die  
sorgerechtliche Maßnahmen eingeleitet wurden.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Statistik der Adoptionen  
(2023)**](https://download.statistik-berlin-brandenburg.de/59da0bc682c39785/86a094f6a9fc/MD_22521_2023.pdf) | [Archiv](/search-results?q=22521&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Statistik der Pflegeerlaubnis, Pfleg-,   
Vormund-, Beistandschaften, Sorgerecht,  
Sorgeerklärungen  
(2023)](https://download.statistik-berlin-brandenburg.de/70e68957e379c022/edf24e5ab827/MD_22522_2023.pdf)**| [Archiv](/search-results?q=22522&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-v-3-j)
