

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [WZ-Nachweis](/wirtschaftsnachweis)

**WZ-Schwerpunktnachweis**
==========================

Die Klassifikation der Wirtschaftszweige, aktuelle Ausgabe 2008 (WZ 2008), ist ausschließlich für statistische Zwecke geschaffen worden. Sie soll als strukturierende/klassifikatorische Grundlage für die statistische Arbeit dienen. Wenn diese Klassifikation von anderen Behörden als Grundlage für Entscheidungen herangezogen wird, geschieht dies grundsätzlich außerhalb des Verantwortungsbereichs der Statistischen Ämter des Bundes und der Länder.

**Sie benötigen einen Nachweis über den wirtschaftlichen Schwerpunkt Ihres Unternehmens (WZ‑Nachweis) für Carbon Leakage nach** [**BECV**](https://www.gesetze-im-internet.de/becv/)**, für Förderanträge, die Beantragung von Investitionszulagen oder andere Zwecke?**

Das Amt für Statistik Berlin-Brandenburg kann Ihnen einen Nachweis darüber ausstellen, welchem Wirtschaftszweig (WZ 2008) Ihr Unternehmen im Unternehmensregister für statistische Verwendungszwecke (Statistikregister) zugeordnet ist.

  


Nachweis für Carbon LeakageNachweis für andere Zwecke

**Anfragen zu Carbon Leakage Nachweisen richten Sie bitte** **mit dem Betreff „WZ-Nachweis nach BECV“ an folgende E-Mailadresse:**

[verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)

**Bitte beachten Sie folgende Besonderheiten für eine Bescheinigung nach BECV:**

* Entscheidend für die Ausstellung des WZ-Nachweises durch ein Statistisches Landesamt ist das Bundesland des Unternehmenssitzes. Wenn Ihr Unternehmen seinen Sitz außerhalb dieser Bundesländer hat, wenden Sie sich bitte an das jeweils zuständige [Statistische Amt der Länder](https://www.statistikportal.de/de/statistische-aemter).
* Voraussetzung für die Ausstellung eines Nachweis der beihilfeberechtigten Sektoren oder Teilsektoren (Tabellen 1 und 2 des Anhangs zum BECV) ist die aktive Berichtspflicht im Rahmen folgender Statistiken: „Monatliche Produktionserhebung im Verarbeitenden Gewerbe sowie im Bergbau und in der Gewinnung von Steinen und Erden“ oder „Vierteljährliche Produktionserhebung im Bereich Verarbeitendes Gewerbe, Bergbau und Gewinnung von Steinen und Erden“. Sollten Sie hierzu nicht berichten, so sind keine Nachweise seitens des Amtes für Statistik möglich.
* Um als Unternehmen selbst einen Nachweis zu den beihilfeberechtigten Sektoren oder Teilsektoren (produzierter Güter) Ihrer Niederlassung beizubringen, können Sie für die Meldungen zu den genannten Statistiken ein PDF-Dokument der IDEV-Quittung Ihrer versendeten Angaben generieren und diese als Beleg bei Ihrer Antragstellung einreichen. Dort ist nachgewiesen, wann und für welchen Berichtszeitraum Sie die Daten an uns verschickt haben. Das dient Ihnen als Nachweis, welche Güter Sie herstellen und kann durch Sie eigenständig dem Antrag zur Carbon Leakage Verordnung beigelegt werden.
* Eine Anfrage kann grundsätzlich nur auf schriftlichem bzw. elektronischem Wege erfolgen. Telefonische Anfragen bzw. Auskünfte sind aus datenschutzrechtlichen Gründen nicht möglich.

Ihre Anfrage sollte **folgende Informationen** enthalten:

* vollständiger **Name und Anschrift**des **Unternehmens****/Betriebes** mit Angabe Ihrer Ident-Nummer
* vollständiger Name und **E-Mail-Adresse** eines Ansprechpartners
* eine aktuelle **IDEV-Quittung** Ihrer Meldung zur Produktionserhebung

**Was ist zu tun, wenn der nachgewiesene Wirtschaftszweig aus Ihrer Sicht nicht zutreffend ist?**

Sofern Sie die mitgeteilte Wirtschaftszweig-Klassifikation für nicht zutreffend erachten, können Sie dies im Antrag gegenüber der jeweiligen Behörde, d. h. dem Umweltbundesamt zum Ausdruck bringen und hiervon abweichende Angaben machen. Die entscheidende Behörde (hier das Umweltbundesamt) ist nicht an die aus dem Statistikregister mitgeteilte WZ-Zuordnung gebunden, sondern kommt eigenständig zu einer Entscheidung. Die Einordnung im Statistikregister hat also keine präjudizierende Wirkung, sondern dient lediglich als eine von vielen möglichen Anhaltspunkten.

**Können auch externe Dritte wie Steuerberaterinnen, Steuerberater, Wirtschaftsprüferinnen und Wirtschaftsprüfer, eine Anfrage stellen?**  
Wenn dieser Personenkreis im Auftrag des jeweiligen Unternehmens handelt, können auch externe Beauftragte einen Nachweis anfordern, wenn eine entsprechende schriftliche Vollmacht bei uns vorliegt.


