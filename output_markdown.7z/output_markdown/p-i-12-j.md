

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Bruttonationaleinkommen und Volkseinkommen in Berlin und Brandenburg](/p-i-12-j)

Bruttonationaleinkommen und Volkseinkommen
------------------------------------------

#### 1991 bis 2022, jährlich

###### Das Bruttonationaleinkommen misst die Einkommen der Inländer. Dazu zählen u.a. Erwerbs- und Vermögenseinkommen, Produktions- und Importabgaben (ohne Subventionen) sowie gesamtwirtschaftliche Abschreibungen. Es gilt als zentraler Einkommensindikator einer Volkswirtschaft.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Ergebnisse des Arbeitskreises "Volkswirtschaftliche Gesamtrechnungen der Länder"; Berechnungsstand: August 2022
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/16beb20edf99f30d/b4ee450a6977/SB_P01-12-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/737b18b115b8a4f3/922cba3a647c/SB_P01-12-00_2022j01_BE.pdf)

**Bruttonationaleinkommen stieg um mehr als 9 %** 

Das Bruttonationaleinkommen betrug 2022 in Berlin 168,5 Mrd. EUR, 9,3 % mehr als im Jahr zuvor. Mit 45.347 EUR je Einwohnerin bzw. Einwohner war es um 5,7 % geringer als der Bundesdurchschnitt von 48.063 EUR. Der Anteil am Bruttonationaleinkommen Deutschlands lag bei 4,2 %.

Das Volkseinkommen stieg um 5,3 % auf 122,2 Mrd. EUR. Die Summe der Arbeitnehmerentgelte nahm um 7,7 % zu, während die Unternehmens- und Vermögenseinkommen um 0,3 % zurückgingen. Damit stieg die Lohnquote, also der Anteil des Arbeitnehmerentgelts am Volkseinkommen, auf 71,1 %.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Bruttonationaleinkommen je Einwohner 20 % unter Bundesdurchschnitt**

In Brandenburg lag das Bruttonationaleinkommen 2022 bei 98,2 Mrd. EUR. Damit war es um 7,4 % höher als im Jahr zuvor und entsprach einem Anteil von 2,4 % des gesamtdeutschen Bruttonationaleinkommens. Mit 38.424 EUR je Einwohnerin bzw. Einwohner betrug das Bruttonationaleinkommen 79,9 % des Bundesdurchschnitts.

Das Volkseinkommen nahm indessen um 4,7 % auf 72,6 Mrd. EUR zu. Die Summe der Arbeitnehmerentgelte erhöhte sich um 5,7 %, die Unternehmens- und Vermögenseinkommen um 1,9 %. Die Lohnquote als Anteil des Arbeitnehmerentgelts am Volkseinkommen stieg auf 75,4 %.

**Quelle:** Ergebnisse des Arbeitskreises "Volkswirtschaftliche Gesamtrechnungen der Länder"; Berechnungsstand: August 2022
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f904ab886a945803/a69f29b85b85/SB_P01-12-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7135462f018d82ca/ee910d773079/SB_P01-12-00_2022j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das Bruttonationaleinkommen ist die umfassendste Größe für die Einkommen der Inländer. Es umfasst die Erwerbs- und Vermögenseinkommen der Einwohner eines Bundeslandes (das Volkseinkommen), die Produktions- und Importabgaben abzüglich der Subventionen sowie die gesamtwirtschaftlichen Abschreibungen. Das Bruttonationaleinkommen eines Landes unterscheidet sich vom Bruttoinlandsprodukt durch den Einkommenssaldo gegenüber dem Ausland und den anderen Bundesländern.

Auf das Volkseinkommen, die Summe des Arbeitnehmerentgelts der Arbeitnehmerinnen und Arbeitnehmer mit Wohnsitz in einer Region und der Unternehmens- und Vermögenseinkommen, entfallen etwa drei Viertel des Bruttonationaleinkommens. Die unterschiedliche Entwicklung der beiden Einkommensblöcke spiegelt sich in der Lohnquote, dem Anteil des Arbeitnehmerentgelts am Volkseinkommen, wider.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/p-i-12-j)
