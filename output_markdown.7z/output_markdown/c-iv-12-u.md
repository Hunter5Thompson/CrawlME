

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Wirtschaftsdünger, Stall- und Weidehaltung in Brandenburg](/c-iv-12-u)

Wirtschaftsdünger, Stall- und Weidehaltungin Brandenburg
--------------------------------------------------------

#### 2020, unregelmäßig

###### Die Erhebung ist Teil der Landwirtschaftszählung und informiert über das Wirtschaftsdüngermanagement landwirtschaftlicher Betriebe, gegliedert u. a. nach Ausbringungsart, Düngerart und Einarbeitungszeit.

BrandenburgMethodik
### Brandenburg

**Vergleichsweise geringer Düngereinsatz**

Von März 2019 bis Februar 2020 brachten Brandenburgs Landwirte gut 7 Millionen Kubikmeter (m³) flüssigen Wirtschaftsdünger (Gülle, Jauche oder flüssige Biogasgärreste) auf Acker- und Dauergrünland aus. Das waren rund eine Million Tonnen bzw. 12 % weniger als vier Jahre zuvor.

Pro Hektar Acker- und Dauergrünland wurden 5,4 m³ Wirtschaftsdünger ausgebracht. Mit 5,0 m³ wurde nur in Rheinland-Pfalz noch weniger flüssige Wirtschaftsdünger je Hektar auf den Feldern verteilt. Für das gesamte Bundesgebiet lag dieser Wert bei 11,5 m³ pro Hektar.

Daneben kamen Mineraldünger und feste Wirtschaftsdünger (Festmist, Geflügeltrockenkot oder fester Biogasgärrest) zum Einsatz. Die Menge an ausgebrachten festen Wirtschaftsdüngern betrug in Brandenburg 1,7 Millionen Tonnen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/258b6d41c0e9b0ea/c7d1e1202821/SB_C04-12-00_2020u_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/44a06bf766c1b3ec/d80563e19ad7/SB_C04-12-00_2020u_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Landwirtschaftszählung**  
Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/023848dc8f72ca47/3f8123557a5c/MD_41141_2020.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-12-u)
