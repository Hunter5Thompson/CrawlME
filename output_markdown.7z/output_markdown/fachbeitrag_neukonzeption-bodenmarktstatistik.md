

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 10.01.2022

#### Preise

Neukonzeption der Bodenmarktstatistiken
---------------------------------------

![iStock.com / LianeM](https://download.statistik-berlin-brandenburg.de/c831f04bef43dd06/02da61c05d4f/v/d718f59c09a7/wirtschaft-preise-bodenpreise.jpg "iStock.com / LianeM")

**Mehr als 9 000 landwirtschaftlich genutzte Grundstücke sowie Baugrundstücke wechseln in Berlin und Brandenburg jährlich ihre Eigentümerin bzw. ihren Eigentümer. Dabei gibt es deutliche regionale Preisunterschiede. Statistisch erfasst werden diese mithilfe der Bodenmarktstatistiken. Durch eine Veränderung des Nutzerbedarfs der Europäischen Union erfolgte eine Neukonzeption der Statistiken, welche eine Abgrenzung der Erhebungsmerkmale, einen neuen Meldeweg und ein einheitliches Verbundprogramm sowie eine gemeinsame Geheimhaltung der erzeugten Ergebnisse für alle Bundesländer und gemeinsame Veröffentlichungstabellen umfasst. Im Folgenden werden die Neuerungen vorgestellt und die Unterschiede zum bisherigen Verfahren hervorgehoben.**

Die Bodenmarktstatistiken geben einen Überblick über den Grundstücksmarkt in Berlin und Brandenburg. Es handelt sich dabei um keine Preisstatistik im eigentlichen Sinne, sondern vielmehr um eine „Grundstückswechselstatistik“, da durchschnittliche Kaufwerte betrachtet werden und nicht die Preisentwicklung von Grundstücken gleicher Art und Güte im Vordergrund steht. Zu den Bodenmarktstatistiken gehören die Kaufwerte für landwirtschaftliche Grundstücke (KWL) und die Kaufwerte für Bauland (KWB), welche in der derzeitigen Form bereits seit mehreren Jahrzehnten bestehen. Zu beachten ist, dass Landwirtschaft in Berlin nahezu nicht existent ist und aus diesem Grund auf die Erhebung von landwirtschaftlichen Grundstücken in Berlin verzichtet wird. Genutzt werden die Bodenmarktstatistiken von unterschiedlichen Stellen. Die KWL-Statistik wird auf internationaler Ebene durch die Europäische Kommission sowie national durch verschiedene Ressorts und landwirtschaftliche Verbände genutzt. Die KWB-Statistik wird ebenfalls von verschiedenen nationalen Ressorts sowie durch Wirtschafts- und Interessenverbände verwendet.

In der Vergangenheit wurden kaum Änderungen an den Bodenmarktstatistiken vorgenommen. Zu der nun erfolgten Neukonzeption führte die Ankündigung einer europäischen Rechtsverordnung zu Statistiken über landwirtschaftliche Betriebsmittel und die landwirtschaftliche Erzeugung (SAIO: Statistics on agricultural inputs and outputs), welche Landwirtschaftspreise und damit verbunden auch Kaufwerte für landwirtschaftliche Grundstücke einschließt. Dadurch wird nicht nur die Grundlage der Flächen neu definiert, sondern auch die Kauffallabgrenzung neu festgelegt. Das Inkrafttreten der Rechtsverordnung war für 2021 vorgesehen. Inwieweit dies realisierbar ist, bleibt abzuwarten. Aufgrund der geänderten europäischen Vorgaben entwickelten die Statistischen Ämter des Bundes und der Länder unter Federführung des Statistischen Bundesamtes ein Konzept, das nicht nur dem neuen Bedarf der landwirtschaftlich zu erfassenden Grundstücke gerecht wird, sondern auch die Kaufwerte für Bauland einschließt. Eine wichtige Voraussetzung, um dem veränderten Bedarf gerecht zu werden, wurde mit der Novellierung des [Preisstatistikgesetzes](https://www.gesetze-im-internet.de/preisstatg/index.html) 2020 geschaffen, indem in § 7 PreisStatG die zu erfassenden Merkmale aufgeführt wurden.

Mit der Neukonzeption wurden die zu erfassenden Merkmale angepasst, die Meldewege der Bodenmarktstatistiken überarbeitet sowie ein neues Fachverfahren entwickelt. Darüber hinaus wurde eine länderübergreifende Geheimhaltung der erzeugten Ergebnisse für alle Bundesländer etabliert.
###### Anpassung der zu erhebenden Merkmale

**Kaufwerte für landwirtschaftliche Grundstücke (KWL)**

Bisher wurde in der KWL-Statistik die Fläche der landwirtschaftlichen Nutzung als zentrales Merkmal erhoben. Diese umfasste lediglich Ackerland und Grünland. Gartenbauflächen wurden nicht berücksichtigt. Ab dem Berichtsjahr 2021 wird nun die landwirtschaftlich genutzte Fläche aufgenommen, die beispielsweise Gartenbauflächen einschließt.

Als Informationen über die Veräußernden beziehungsweise den Erwerbenden wurde bislang lediglich die Rechtsform erfragt, welche nach natürlicher Person sowie juristischer Person des öffentlichen Rechts und juristischer Person des privaten Rechts unterteilt wurde. Als neues Merkmal wird nun die familiäre Beziehung zwischen den Vertragsparteien erhoben. Darüber hinaus wird die geplante Nutzung des Grundstücks erfragt. Eine weitere Änderung besteht darin, dass ungewöhnliche Geschäftsverkehre¹ gemeldet werden. Bisher wurden diese von den Meldenden ausgeschlossen.

Gleich bleibt die Mindestgröße des veräußerten Grundstücks, so werden weiterhin nur Grundstücke einbezogen, die mindestens 0,1 Hektar umfassen.

**Kaufwerte für Bauland (KWB)**

Die KWB-Statistik erfuhr in erster Linie begriffliche Anpassungen und Vereinfachungen. Die Rechtsformen der Veräußernden und Erwerbenden wurden zu natürlichen beziehungsweise juristischen Personen des öffentlichen oder privaten Rechts zusammengefasst. Das Verwandtschaftsverhältnis wurde bei dieser Statistik bereits erfasst. Es wird nun um die Veräußerung an Eheleute erweitert und unter dem Merkmal „Familiäre Beziehung“ subsumiert.

Eine begriffliche Vereinheitlichung wurde durch die Umbenennung des Merkmals „Art des Baugebiets“ in „Art der Baufläche“ erreicht, welches nun analog der [Baunutzungsverordnung](https://www.gesetze-im-internet.de/baunvo/) benannt ist. Diese beinhaltet anstatt fünf nur noch vier Unterrubriken. Es wird nicht mehr nach Industrieland untergliedert, sondern nach wirtschaftlich genutztem Bauland gefragt. Zu diesem zählen Flächen, welche als Arbeits- und Lagerflächen bereits einem Gewerbe dienen oder zur Erweiterung eines Betriebes vorrätig gehalten werden. Zu den sonstigen Flächen zählen nun unter anderem Freiflächen und Land für Verkehrszwecke.

Eine weitere Neuerung fand bei der **Übermittlung des Kaufpreises** statt. Bisher wurde ausschließlich der Kaufpreis als solches erfragt. Mit der Neukonzeption der Statistik kann dieser nun als Vertragspreis analog des Kaufvertrags und/oder als bereinigter Preis, das heißt als reiner Grundstückspreis ohne enthaltene Wertgegenstände, Rechte oder Pflichten erhoben werden. Sollten die Preise eine außerordentliche Struktur aufweisen, zum Beispiel extrem niedrig oder auffällig hoch sein, können der beitrags- und abgabenrechtliche Zustand und der Bodenrichtwert als zusätzliche Merkmale einbezogen werden, die jetzt ebenfalls erfasst werden.

Ungewöhnliche Geschäftsverkehre wurden in der Vergangenheit analog zu der KWL-Statistik nicht erfasst. Ab dem Berichtsjahr 2021 werden auch diese mit einbezogen. Keine Änderung erfolgt bei der Grundstücksfläche. Diese muss weiterhin eine Mindestgröße von 100 m² betragen.

¹ Eigentumsübergänge aufgrund von Abfindungen, unentgeltlicher Zuteilung von Land, Flurbereinigungsverfahren, beschleunigten Zusammenlegungsverfahren, Landtauschverfahren, Zwangsversteigerungen, Erbschaften,  Erbbauauseinandersetzungen, Schenkungen, Auflösung eines Treuhandverhältnisses, Liebhaberpreisen, Veräußerungen innerhalb eines Dienstverhältnisses, Baulasten, Grunddienstbarkeiten, Notverkauf, Insolvenzverfahren, Konkurs, Zukauf, Ersatzlandkauf, Enteignung, für das jeweilige Grundstück besonderen preisbeeinflussenden Zuschnitten und Bodenlasten.

  


###### Neuer Online-Meldeweg

Ein wichtiges Anliegen bei der Neukonzeption bestand darin, einen einheitlichen und standardisierten Online-Meldeweg zu etablieren. Bisher erhielten die Statistischen Ämter der Länder die Daten auf unterschiedlichen Wegen, teilweise in Form von Papiermeldungen.

Diese unterschiedlichen Meldewege sind unter anderem darin begründet, dass die Statistischen Ämter die Daten entweder von den Gutachterausschüssen für Grundstückswerte (GAA) oder den Finanzämtern des jeweiligen Bundeslandes erhalten. Da jeder Kauffall gemäß § 311 b des [Bürgerlichen Gesetzbuches](https://www.gesetze-im-internet.de/bgb/) notariell beurkundet und anschließend eine Kopie an die zuständigen Finanzämter und GAA gesendet wird, können sowohl die Finanzämter als auch die GAA die Daten an die Statistischen Ämter übermitteln. Darüber hinaus können beide Institutionen die Erhebungsfälle durch weitere Erkenntnisse, beispielsweise aus Bebauungsplänen, ergänzen.

In Berlin werden die Daten seit dem Erhebungsjahr 2008 von den zuständigen GAA übermittelt, in Brandenburg bereits seit 1995. In Berlin erfolgt dies direkt; in Brandenburg erfassen insgesamt 18 GAA die Daten in einer automatisierten Kaufpreissammlung. Der Oberste Gutachterausschuss in Brandenburg übermittelt quartalsweise einen Abzug der Sammlung an das Amt für Statistik Berlin-Brandenburg. Er fungiert auch als direkter Ansprechpartner.

Bis zum Berichtsjahr 2020 erfolgte die Übertragung der Daten in beiden Bundesländern mittels .csv-Dateien, welche mithilfe verschiedener Umwandlungsverfahren in eine Fachanwendung integriert wurden. In der Fachanwendung wurden die Daten auf Vollständigkeit und etwaige Fehler geprüft, um anschließend Ergebnistabellen zu erzeugen.

Der neue Meldeweg sieht eine Übermittlung über eSTATISTIK.core vor. Dabei haben die Meldenden die Möglichkeit, die Daten mittels einer fest definierten .csv-Datei über eine bestehende Webanwendung zu übersenden oder im Fall der GAA eine direkte Übermittlung aus der Kaufpreissammlung per .xml-Datei vorzunehmen. Dabei wird das Ziel verfolgt, den Aufwand der Meldenden möglichst gering zu halten, was insbesondere durch die direkte Sendung erreicht wird. Die meldenden GAA in Berlin und Brandenburg haben ihre ersten Quartalsmeldungen erfolgreich übermittelt und dafür den direkten Übertragungsweg aus der Kaufpreissammlung gewählt. Damit wird auch dem seit 2017 in Kraft getretenen [Onlinezugangsgesetz](https://www.gesetze-im-internet.de/ozg/) Rechnung getragen.

Die Meldedaten werden, nachdem sie die
Eingangsdatenbanken durchlaufen haben, direkt in das neu entwickelte
Verbundprogramm „Kaufwerte Bodenmarkt“ übertragen.
###### Das neue Verbundprogramm Kaufwerte Bodenmarkt

Bisher wurden die übertragenen Daten in unterschiedlichen Fachanwendungen bearbeitet, das heißt. es bestanden unterschiedliche Systeme zur Bearbeitung der KWL-Statistik und der KWB-Statistik. Darüber hinaus war es möglich, dass jedes Statistische Amt eigene beziehungsweise angepasste Auswertungsprozesse nutzt. Anlässlich der Neukonzeption wurde eine einheitliche Fachanwendung als Verbundprogramm entwickelt, welche die Bearbeitung beider Bodenmarktstatistiken ermöglicht. Hier werden die eingegangenen Daten hinsichtlich ihrer Plausibilität vorgeprüft. Es erfolgen sowohl Kontrollen, die die formale Korrektheit betreffen, als auch Prüfungen, die sich aus der Kombination verschiedener Merkmale ergeben. Darüber hinaus wurden Ober- und Untergrenzen zu Hektar- und Quadratmeterpreisen als Plausibilitätsprüfungen hinterlegt, welche jährlich aktualisiert werden. Die hinterlegten Prüfmechanismen weisen die Bearbeitenden auf mögliche Fehler hin und lassen es zu, gezielt Rücksprache mit den Meldenden zu halten und die Unstimmigkeit zu bereinigen.

Nach abschließender Qualitätsprüfung durch die
Bearbeitenden werden die Daten an das Statistische Bundesamt übermittelt, um
dort nach Eingang aller Landesergebnisse eine  länderübergreifende statistische Geheimhaltung
zu durchlaufen.
###### Geheimhaltung und Veröffentlichungsprogramm

Bisher oblag es den einzelnen Statistischen Ämtern zu prüfen, welche Ergebnisse nicht veröffentlicht werden und wo es einer Geheimhaltung bedarf. Dabei sind Einzelangaben, die es ermöglichen auf eine Person oder ein Unternehmen zu schließen, gemäß § 16 [BStatG](https://www.gesetze-im-internet.de/bstatg_1987/index.html) geheim zu halten. Im Fall der  Bodenmarktstatistiken betrifft dies einzelne Transaktionsfälle.

In Berlin und Brandenburg wurde die Geheimhaltung bisher mittels der Mindestfallzahlregel durchgeführt. Danach ist der Wert geheim zu halten, sofern die Anzahl der Transaktionsfälle nicht mindestens drei beträgt. Auch eine Rückrechnung anhand der weiteren veröffentlichten Werte darf nicht möglich sein.

Mit der Neukonzeption der Kaufwerte-Statistiken wurde eine koordinierte statistische primäre und sekundäre Geheimhaltung mittels maschineller Zellsperrung eingeführt. Dabei findet weiterhin die Mindestfallzahlregel Anwendung. Darüber hinaus wird eine Geheimhaltung durch die p%-Regel durchgeführt. Hierbei wird der Tabellenwert geheim gehalten, wenn die Differenz zwischen dem Tabellenwert und dem zweitgrößten Einzelwert den größten Einzelwert um weniger als einen zuvor definierten Prozentwert (p%) übersteigt. (vgl. Giessing und Dittrich 2008, S. 806) Durch Gegensperrungen werden Rückrechnungen auf Einzelwerte ausgeschlossen.

Diese Geheimhaltung findet automatisiert über das Softwarepaket τ-ARGUS statt und wird zentral vom Statistischen Bundesamt für alle Bundesländer durchgeführt. Dazu ist es erforderlich, dass die Daten aller Statistischen Ämter vorliegen und gemeinsam verarbeitet werden können. Eine spätere Integration von Daten ist nach der Veröffentlichung der Ergebnisse in den Statistischen Berichten nicht mehr möglich.

Um eine gemeinsame Geheimhaltung zu realisieren, wurde im Rahmen der Neukonzeption auch das Veröffentlichungsprogramm überarbeitet. Dieses umfasst umfangreiche  Auswertungsmöglichkeiten. So kann nun bei der KWL-Statistik auch nach Ackerland, Dauergrünland und weiteren landwirtschaftlichen Flächen unterschieden werden. Darüber hinaus kann eine Auswertung unter anderem nach Größenklassen der veräußerten Fläche sowie nach Ertragsmesszahlen erfolgen.

Bei der KWB-Statistik entstehen in erster Linie neue Kombinationsmöglichkeiten. Zukünftig könnten beispielsweise Auswertungen nach Preisklassen in Abhängigkeit der Art des Grundstücks und der Art der Bauflächen durchgeführt werden.

Inwieweit eine solche Veröffentlichungstiefe in Berlin und Brandenburg realisierbar ist, wird sich bei der ersten Jahresauswertung Mitte 2022 für das Berichtsjahr 2021 zeigen.

Ein weiterer Mehrwert der Neukonzeption stellt die leichtere
Befüllung der Regionaldatenbank dar, in der die regionalisierten Angaben für
die breite Öffentlichkeit zur Verfügung gestellt werden. Mussten die Daten
bisher aufwendig manuell generiert werden, erfolgt die Erstellung nun
maschinell über das Veröffentlichungsprogramm.
#### Fazit und Ausblick

Durch die Neukonzeption der Bodenmarktstatistiken werden einerseits die Vorgaben der Europäischen Union erfüllt, andererseits erfolgte eine Vereinheitlichung der Begrifflichkeiten und Abgrenzung der Merkmale. Darüber hinaus wurde mit eSTATISTIK.core ein neuer einheitlicher Meldeweg etabliert und ein gemeinsames Verbundprogramm geschaffen. Durch die zentrale Geheimhaltung und das neue Veröffentlichungsprogramm ist eine länderübergreifende Vergleichbarkeit möglich. Des Weiteren werden die Jahresergebnisse voraussichtlich zwei Monate früher veröffentlicht als bisher.

Hierbei ist zu beachten, dass sich erst mit der Auswertung der Ergebnisse des Berichtsjahres 2021 Mitte 2022 zeigen wird, wie umfangreich die Datenanalyse in Berlin und Brandenburg erfolgen kann. Zu vermuten ist, dass insbesondere die Berliner Werte durch ihre im Vergleich zu Brandenburg geringen Fallzahlen kaum eine tiefer gegliederte Veröffentlichung zulassen.

Darüber hinaus kann angenommen werden, dass es bedingt durch die geschärften Abgrenzungen der Merkmale zu einem „Bruch“ in der Zeitreihe hinsichtlich der Anzahl der Kauffälle kommen kann.

###### Quellen

* Giessing, Sarah; Dittrich, Stefan (2006): Tabellengeheimhaltung im statistischen Verbund – ein Verfahrensvergleich am Beispiel der Umsatzsteuerstatistik. In: Wirtschaft und Statistik. Ausgabe 8/2006.
* Diehl-Wolf, Eva-Maria (2021): Neukonzeption der Bodenmarktstatistiken. In: Wirtschaft und Statistik. Ausgabe 4/2021.
###### *Autorinnen:*

**Katja Kirchner** leitet das Referat *Preise, Verdienste, Arbeitskosten* des Amtes für Statistik Berlin-Brandenburg. **Stefanie Dobs** ist Sachbearbeiterin im Referat *Preise, Verdienste, Arbeitskosten* des Amtes für Statistik Berlin-Brandenburg und für die Umsetzung der Bodenmarktstatistiken zuständig.

Der Fachbeitrag erschien erstmals in der *Zeitschrift für amtliche Statistik
Berlin Brandenburg*. Die komplette Ausgabe 3+4/2021 lesen Sie [hier](https://download.statistik-berlin-brandenburg.de/0e2a6bd7d6fd44ce/b43aa17fd047/Zeitschrift-20210304.pdf).

### Kontakte

#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Stefanie Dobs

Preise

#### Stefanie Dobs

Preise

* [0331 8173-3523](tel:0331 8173-3523)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Nicole Dombrowski

Fachredaktion

#### Nicole Dombrowski

Fachredaktion

* [zeitschrift@statistik-bbb.de](mailto:zeitschrift@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Preise](/search-results?q=tag%3APreise)[* Bodenmarkt](/search-results?q=tag%3ABodenmarkt)[* Aufsätze und Analysen](/search-results?q=tag%3AAufsätze und Analysen)
