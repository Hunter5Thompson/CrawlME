

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Berlin](/wahlen-berlin)
* [Volksentscheid in Berlin](/volksentscheide-berlin)

Volksentscheid in Berlin
========================

Ein Volksentscheid ist ein Instrument der direkten Demokratie. Er ermöglicht es, den wahlberechtigten Bürgerinnen und Bürgern über eine Vorlage (zum Beispiel ein Gesetz) unmittelbar abzustimmen. Volksentscheide werden in unregelmäßigen Abständen durchgeführt, sofern die rechtlichen Voraussetzungen vorliegen.

Berlin 2030 klimaneutral 

Volksentscheid „Berlin 2030 klimaneutral“
-----------------------------------------

#### Endgültige Ergebnisse für Berlin

#### Die endgültigen Ergebnisse

**Alle Daten zum Volksentscheid „Berlin 2030 klimaneutral“  in interaktiver Form**

[Zu den Ergebnissen](https://www.wahlen-berlin.de/wahlen/BE2023/AFSPRAES/ve/index.html)
#### Interaktiver Wahlatlas

**Kartenansichten mit den endgültigen Ergebnissen des Volksentscheids**

[Zur Karte](https://wahlen-berlin.de/wahlen/BE2023/AFSPRAES/ve/wahlatlas.html)
#### **Alle Ergebnisse als Download**

[Stimmbezirksergebnisse (XLSX)](https://download.statistik-berlin-brandenburg.de/a377bd4631845832/b4d26bc126af/DL_BE_VE2023.xlsx)[Ergebnisbericht (PDF)](https://download.statistik-berlin-brandenburg.de/6ec9556aa7b5e74a/34ce985093d4/SB_B07-04-02_2023u00_BE.pdf)
###### Volksentscheid Berlin „Berlin 2030 klimaneutral“ 2023

#### Abstimmungsbeteiligung der Berliner Bezirke

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

**Beschlussentwurf abgelehnt**

Am 26. März 2023 fand in Berlin der Volksentscheid Berlin 2030 klimaneutral statt, der von der Trägerin Klimaneustart organisiert wurde. Für die Annahme musste die Mehrheit der Teilnehmenden und zugleich mindestens 25 % der Stimmberechtigten zustimmen.

Insgesamt waren beim Volksentscheid rund 2,43 Mio. Berlinerinnen und Berliner stimmberechtigt –35,7 % beteiligten sich daran. 50,9 % der Teilnehmenden und 18,2 % der Abstimmungsberechtigten stimmten mit Ja. Somit wurde das Quorum nicht erreicht und der Volksentscheid nicht angenommen.

Historische Daten
-----------------

##### Volksentscheide Berlin**Abstimmungsbeteiligung 2008 bis 2023**

1 Das Abgeordnetenhaus von Berlin stellte zusätzlich einen eigenen Gesetzentwurf zur Abstimmung. Dieser Gesetzentwurf wurde nicht angenommen.**Quelle:** Amt für Statistik Berlin-Brandenburg[**Endgültige Ergebnisse zu Volksentscheiden in Berlin**](/archiv/b-vii-4-2)

**Stimmbezirksergebnisse zu Volksentscheiden in Berlin**

Weiterführende Informationen
----------------------------

###### Metadaten

Unsere Metadaten liefern Informationen zu den erhobenen Daten und der angewendeten Methodik. Ergänzt werden diese durch Musterstimmzettel, Datensatzbeschreibungen und gegebenenfalls einen Qualitätsbericht.

**Volksentscheide (2023)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/0ca6207e648d6917/34165812cadf/MD_14511_2023.pdf) 

###### Link zum OpenData Portal Berlin

Geometrien, Wahllokale und weitere offene Datensätze →  [OpenData Portal Berlin](https://daten.berlin.de/datensaetze?groups=wahl&author_string=Amt+f%C3%BCr+Statistik+Berlin-Brandenburg&sort=score+desc%2C+metadata_modified+desc)

#### Der Landeswahlleiter für Berlin auf [www.berlin.de](https://www.berlin.de/wahlen/)


