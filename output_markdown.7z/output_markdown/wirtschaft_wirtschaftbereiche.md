

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
#### Überblick

Wirtschafts­bereiche
====================

Betriebe und Unternehmen der Hauptstadtregion Berlin-Brandenburg leisten einen bedeutenden Beitrag zur wirtschaftlichen Situation in Deutschland.

Die Wirtschaftsdaten umfassen beispielsweise das Verarbeitende Gewerbe mit seinen umsatzstarken Industriezweigen wie der Herstellung von pharmazeutischen Erzeugnissen sowie der Produktion von Nahrungs- und Futtermitteln. Letztgenannter Bereich ist auch von Leistungen, die durch die Land- und Forstwirtschaft erbracht werden, abhängig. Der Agrarbereich selbst hat wichtige Funktionen hinsichtlich der Versorgung der Bevölkerung mit Nahrungsmitteln sowie als Landschaftsgestalter.

Zudem werden wesentliche Informationen zu Tourismus, Handel und Gastgewerbe sowie Dienstleistungen bereitgestellt und dessen Bedeutung für eine funktionierende Wirtschaft aufgezeigt. In Zeiten einer steigenden Nachfrage nach bezahlbarem Wohnraum und einer damit zunehmenden Bautätigkeit sind belastbare Daten aus den Wirtschaftsbereichen Bauen und Handwerk von hoher Relevanz.

**Umsatz pro geleistete Arbeitsstunde im Verarbeitenden Gewerbe in der Hauptstadtregion (****Veränderung zum Vorjahr)**  
Stand: 2023

**Quelle:** Amt für Statistik Berlin-Brandenburg[Umsatz und tätige Personen
#### Handel](/wirtschaft/wirtschaftbereiche/handel)[Strukturelle und soziale Anpassungen
#### Land- und Forstwirtschaft](/land-und-forstwirtschaft)[Beherbergung und Gastronomie
#### Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)[Industriestatistiken
#### Verarbeitendes Gewerbe](/verarbeitendes-gewerbe)[Umsätze und Beschäftigte
#### Dienstleistungen](/dienstleistungen)[Baugewerbe, Bautätigkeit
#### Bauen und Wohnungen](/bauen-und-wohnungen)[Umsätze und Beschäftigte
#### Handwerk](/handwerk)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Wirtschaftsbereiche

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg1 Seit 2010 basierend auf den endgültigen Ergebnissen der Gebäude- und Wohnungszählung (Zensus 2011); Wohngebäude und Wohnungen zusammen sowie Wohnfläche einschließlich Wohnheime**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Monatsbericht für Betriebe des Verarbeitenden Gewerbes sowie Bergbau und Gewinnung von Steinen und Erden in Berlin/Brandenburg, Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Neues aus dem Bereich Wirtschaftsbereiche

Zuletzt veröffentlicht
----------------------

![iStock-1213727367.jpg](https://download.statistik-berlin-brandenburg.de/8c43b2d7bc814cc3/3e5ce1b6bb13/v/4660157d52dc/landwirtschaft-rinder.jpg)20.12.2024Statistischer Bericht[#### 3. November 2024, halbjährlich, C III 9 - hj: Rinder in Berlin und Brandenburg](/c-iii-9-hj)

Die Erhebung informiert über die Anzahl der Rinder (einschließlich Büffel/Bisons), gegliedert nach Alter, Geschlecht, Nutzungszweck und Rasse.

[Ansehen](/c-iii-9-hj)![iStock-500003996.jpg](https://download.statistik-berlin-brandenburg.de/a3673719d2d0542c/000daad3a651/v/cca1b725c6c0/wirtschaft-wirtschaftsbereiche-schweine.jpg)19.12.2024Pressemitteilung[#### Schweinebestand in Brandenburg am 3. November 2024: Leichte Erholung des Bestandes](/176-2024)

Nach dem vorläufigen Ergebnis der Erhebung der Schweinebestände zum 3. November 2024 hielten die Brandenburger Betriebe 556.400 Schweine. 

[Ansehen](/176-2024)![iStock-1134671737.jpg](https://download.statistik-berlin-brandenburg.de/c237ff5bad52c804/5b46801119ef/v/c6d1cfea4f5c/wirtschaft-wirtschaftsbereiche-logistik.jpg)19.12.2024Statistischer Bericht[#### Oktober 2024, monatlich, E I 2 -m: Monatsbericht für Betriebe im Verarbeitenden Gewerbe in Berlin und Brandenburg](/e-i-2-m)

Die Ergebnisse des Monatsberichts stellen eine kurzfristige Beurteilung der konjunkturelle Lage der Industriebetriebe ab 50 Beschäftige dar.

[Ansehen](/e-i-2-m)Mehr anzeigen


