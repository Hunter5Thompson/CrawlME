

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Steuern](/gesellschaft/staat/steuern)
* [Gewerbesteuerstatistik in Berlin und Brandenburg](/l-iv-13-j)

Gewerbesteuer in Berlin und Brandenburg
---------------------------------------

#### 2019, jährlich

###### Die Gewerbesteuerstatistik dient zur Analyse von Struktur und Wirkung der Gewerbesteuer und ihrer wirtschaftlichen Bedeutung. Darüber hinaus wird sie u. a. zur Quantifizierung des zukünftigen Aufkommens und bei geplanten Steuerrechtsänderungen verwendet.

BerlinBrandenburgMethodik
### Berlin

#### **Zum aktuellen Statistischen Bericht – 2019**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/208a285695cdd741/141758fa1765/SB_L04-13-00_2019j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/5fb103d52ad151c1/33ce579ef753/SB_L04-13-00_2019j01_BE.pdf)

**H****öchster positiven Steuermessbetrag im Bereich Erbringung von freiberuflichen, wissenschaftlichen und technischen Dienstleistungen**

Für das Jahr 2019 wurden in Berlin mehr als 244.000 steuerpflichtige Gewerbebetriebe erfasst. Für 29 % dieser Unternehmen wurden durch die Finanzverwaltungen positive Steuermessbeträge in Höhe von 470 Mill. EUR festgesetzt. Dies entspricht einem Zuwachs von 6,1 % zum Vorjahr.

Die drei Wirtschaftsbereiche mit den höchsten positiven Steuermessbeträgen in Berlin waren der Bereich Erbringung von freiberuflichen, wissenschaftlichen und technischen Dienstleistungen, der Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugen und das Grundstücks- und Wohnungswesen.

Im Bereich Erbringung von freiberuflichen, wissenschaftlichen und technischen Dienstleistungen erwirtschafteten 9.844 Unternehmen 16,6 % des Steuermessbetrages des Landes Berlin. In den Wirtschaftsbereichen Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugenerreichten 10.981 Unternehmen einen Anteil von 13,9 % und 5.140 Unternehmen des Grundstücks- und Wohnungswesens einen Anteil von 11,5 %.

Den größten Zuwachs im Vergleich zum Vorjahr erzielte der Bereich Gesundheits- und Sozialwesen mit 96,0 %. Mit einem 55,5 % höheren Steuermessbetrag belegte die Energieversorgung den zweiten Platz.

### Kontakt

#### Andrea Urbanski

Steuern

#### Andrea Urbanski

Steuern

* [0331 8173-1224](tel:0331 8173-1224)
* [steuern@statistik-bbb.de](mailto:steuern@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Den größten Anteil des positiven Steuermessbetrags erwirtschaftete das Grundstücks- und Wohnungswesen**

Im Land Brandenburg erbrachte die Festsetzung der rund 115.500 gewerbesteuerpflichtigen Betriebe einen Steuermessbetrag von ca. 257 Mill. EUR. Hier hatten 38,0 % einen positiven Steuermessbetrag, insgesamt ist dieser im Vergleich zu 2018 um 1,4 % gewachsen.

Die drei Wirtschaftsbereiche mit den höchsten positiven Steuermessbeträgen in Brandenburg waren das Grundstücks- und Wohnungswesen, das Baugewerbe sowie der Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugen.

Das Grundstücks- und Wohnungswesen erwirtschaftete mit 2366 Unternehmen 18,0 % des Steuermessbetrags im Land. Der Anteil des Baugewerbes mit 10.980 Unternehmen betrug 12,8 %. Im Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugen wurden mit 7844 Unternehmen 12,4 % erreicht.

Den größten Zuwachs im Vergleich zum Vorjahr erzielte der Bereich Information und Kommunikation mit 49,8 % gefolgt vom Bergbau und Gewinnung von Steinen und Erden mit 29,6 %.

#### Z**um aktuellen Statistischen Bericht – 2019**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e4cb2f23e996ae4f/455c4ad2fabf/SB_L04-13-00_2019j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/02cb1c1f2646f79a/eb551424708c/SB_L04-13-00_2019j01_BB.pdf)
### Kontakt

#### Andrea Urbanski

Steuern

#### Andrea Urbanski

Steuern

* [0331 8173-1224](tel:0331 8173-1224)
* [steuern@statistik-bbb.de](mailto:steuern@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Gewerbesteuerstatistik dient zur Analyse von Struktur und Wirkung der Gewerbesteuer und ihrer wirtschaftlichen Bedeutung. Darüber hinaus wird sie zur Quantifizierung des zukünftigen Aufkommens, bei geplanten Steuerrechtsänderungen sowie als eine der Grundlagen bei umfangreichen Steuersimulationsmodellen verwendet. Das Bundesministerium der Finanzen, die Länderfinanzministerien sowie weitere Nutzer aus Politik und Wissenschaft sind Hauptnutzer der Statistik.

Für die Gewerbesteuerstatistik werden von den Steuerpflichtigen folgende Erhebungsmerkmale erfasst: Gewinn/Verlust des Gewerbebetriebs, Hinzurechnungsbeträge, Kürzungsbeträge, Gewerbeertrag, Freibeträge, Steuermessbetrag nach dem Gewerbeertrag mit den im Besteuerungsverfahren festgestellten Angaben, nachrichtlich: vortragsfähiger

Verlust zum 31.12. des Jahres, Sitz (Gemeinde), Rechtsform, Art der Ertragssteuerpflicht, Wirtschaftszweig, in Fällen der Zerlegung die beteiligten Gemeinden mit den Zerlegungsanteilen.

Die Gewerbesteuerstatistik wird jährlich erhoben und veröffentlicht. Ergebnisse für das Land und Bundesergebnisse liegen ca. 36 Monate nach Ende des Berichtszeitraums vor.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsboge sowie ggf. auch eine Datensatzbeschreibung.

**Gewerbesteuerstatistik**  
Metadaten 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/1e6270eb15bb6cad/1943cb61800e/MD_73511_2019.pdf)[Archiv](/search-results?q=73511&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-iv-13-j)
