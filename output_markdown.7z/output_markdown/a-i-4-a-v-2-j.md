

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Bevölkerungsstand](/bevoelkerung/demografie/bevoelkerungsstand)
* [Bevölkerungsstand in den Gemeinden Brandenburgs](/a-i-4-a-v-2-j)
### 

Bevölkerungsstand in den Gemeinden Brandenburgs
-----------------------------------------------

#### 31.12.2023, jährlich

###### In der Bevölkerungsfortschreibung wird der Bevölkerungsbestand einer Region rechnerisch ermittelt.

BrandenburgMethodik
### Brandenburg

**Bevölkerungszunahme ausschließlich durch Wanderungsgewinn**

Im Berichtsjahr 2023 gliedert sich das Land Brandenburg in 4 kreisfreie Städte und 14 Landkreise mit insgesamt 413 Gemeinden.   
Der Landkreis Elbe‑Elster verfügt über die meisten Städte (11) und der Landkreis Potsdam‑Mittelmark über die größte Bevölkerungszahl (223.531) aller kreisfreien Städte und Landkreise.

2023 beträgt die amtliche Bevölkerungszahl für das Land Brandenburg 2.581.667.   
Die Bevölkerungszunahme von 8.532 Personen beruht ausschließlich auf einem Wanderungsgewinn von 29.786.   
Das Land Brandenburg weist 2023 einen Sterbeüberschuss von 20.737 Personen auf.

Der Landkreis Teltow‑Fläming (+ 1.834) und die kreisfreie Stadt Potsdam (+ 1.369) verzeichneten die größten Bevölkerungszunahmen.

In allen Brandenburger kreisfreien Städten und Landkreisen gab es ein Geburtendefizit und einen Wanderungsgewinn.

Der Sterbeüberschuss fiel in den Landkreisen Oder-Spree (‑ 1.734), Oberhavel (‑ 1.631) und Märkisch-Oderland (- 1.619) am stärksten aus.

Im Gegensatz dazu erzielten die Landkreise Teltow‑Fläming (+ 2.970) und Barnim (+ 2.631) den höchsten Zuzugsüberschuss.

1 einschl. sonstiger Veränderungen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/62062862e6a36c93/d385e8b7871a/SB_A01-04-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/9e51ab68cd7b5ebb/cecbb7e74b68/SB_A01-04-00_2023j01_BB.pdf)
### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der Bevölkerungsstand wird monatlich ermittelt und ist eine Berechnungsgröße.

Die Ergebnisse der jeweils letzten Volkszählung (Zensus 2011) werden mit den Ergebnissen der Statistiken der Bevölkerungsbewegungen (Wanderungen, Geburten, Sterbefälle, Eheschließungen) sowie mit Angaben zu Staatsangehörigkeitswechseln und Lösungen von Ehen und Lebenspartnerschaften fortgeschrieben.

Die demografischen Merkmale liegen in unterschiedlicher regionaler Gliederungstiefe vor: Geschlecht, Alter und Staatsangehörigkeit (deutsch/nicht-deutsch) liegen bis auf Gemeindeebene vor. Der Familienstand wird auf der Kreisebene und einzelne Staatsangehörigkeiten werden auf der Landesebene bereitgestellt.

Die Fortschreibungsergebnisse gehen in die Berechnung von Kennzahlen wie Geburtenziffern, Sterbetafeln, Heiratsziffern u. ä. ein und bilden die Grundlage für die regelmäßigen amtlichen Bevölkerungsvorausberechnungen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Fortschreibung des Bevölkerungsstandes (2023)**](https://download.statistik-berlin-brandenburg.de/2983d8b717d04a9f/76a8bde3d1e7/MD_12411_2023.pdf) | [Archiv](/search-results?q=MD_12411&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Feststellung des Gebietsstands (2016)](https://download.statistik-berlin-brandenburg.de/0b86581061535082/2c85e3efabb6/MD_11111_2016.pdf)** | [Archiv](/search-results?q=MD_11111&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-i-4-a-v-2-j)
