

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Besondere Ernte- und Qualitätsermittlung in Brandenburg](/c-ii-7-j)

Besondere Ernte- und Qualitätsermittlungin Brandenburg
------------------------------------------------------

#### 2023, jährlich

###### Die Besondere Ernte- und Qualitätsermittlung liefert zusammen mit der Bodennutzungshaupterhebung und der Ernte- und Betriebsberichterstattung für Feldfrüchte und Grünland zu einem möglichst frühen Zeitpunkt objektive Angaben über Menge und Qualität der Ernte ausgewählter Fruchtarten.

BrandenburgMethodik
### Brandenburg

**Im Jahr 2023 wurden 690 Felder ausgewertet**

Im Rahmen der Besonderen Ernte- und Qualitätsermittlung wurden im Jahr 2023 nach einem Stichprobenplan 690 Felder ausgewertet. Die Probefelder umfassten insgesamt eine Fläche von 20.100 Hektar.

Winterweizen ist die anbaustärkste Getreideart in Brandenburg und war auf knapp 35 % der Getreidefläche ohne Körnermais zu ernten. Der Ertrag lag bei fast 63 Dezitonnen pro Hektar (dt/ha) und damit um 4 % unter dem des Jahres 2022. Die Bodenqualität, die auch durch die Ackerzahl wiedergegeben wird, spielt für die Erträge eine wesentliche Rolle. So wurde z. B. bei einer durchschnittlichen Ackerzahl von 22 ein Ertrag von 37,7 dt/ha Winterweizen erreicht; bei einer Ackerzahl über 45 betrug dieser im Durchschnitt 73,7 dt/ha. Die 2023 am häufigsten angebaute Winterweizensorte war ‘Ponticus‘.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c61bc8202478391b/3c4e8e701274/SB_C02-07-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/b98c7af66fe768f8/0a6f78c833f3/SB_C02-07-00_2023j01_BB.pdf)
### Kontakt

#### Regina Kurz

Ernte- und Weinstatistiken

#### Regina Kurz

Ernte- und Weinstatistiken

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Angelika Päßler

Ernte- und Weinstatistiken

#### Angelika Päßler

Ernte- und Weinstatistiken

* [0331 8173-3052](tel:0331 8173-3052)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Grundlage der Besonderen Ernte- und Qualitätsermittlung (BEE) sind die im Rahmen eines Stichprobenverfahrens auf zufällig ausgewählten Probefeldern und Probeflächen gezogenen Proben und getroffenen Gewichtsfeststellungen sowie ergänzende Ermittlungen von ertrags- und qualitätsbestimmenden Merkmalen bei den gezogenen Proben. Die Auswahl der Betriebe, Probefelder und Probeflächen erfolgt, für jede in die BEE einbezogene Fruchtart getrennt, jeweils proportional zu ihrer entsprechenden Anbaufläche im Land. Unter Verwendung der Anbauflächen aus der Bodennutzungshaupterhebung wird daraus die vorläufige und endgültige Getreide-, Kartoffel- und Winterrapsernte der Länder und des Bundesgebietes berechnet.

Die bei der Durchführung der BEE anzuwendende Erhebungsmethodik ist in der „Technischen Anleitung zur Methodik und Durchführung der Besonderen Ernte- und Qualitätsermittlung (BEE)“ geregelt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Besondere Ernte- und Qualitätsermittlung**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/a887ced045097dc6/04494686bc7a/MD_41246_2022.pdf)[Archiv](https://download.statistik-berlin-brandenburg.de/9783cd6d06a8f568/d5c52e101399/MD_41246_2021.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-ii-7-j)
