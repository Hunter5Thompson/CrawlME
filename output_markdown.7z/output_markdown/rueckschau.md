

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Über uns](/ueber-uns)
* [Rückschau](/rueckschau)
#### Rückblick auf zwei besondere Jahre 2021/2022

Wir ziehen Bilanz.
==================

In den Jahren 2021 und 2022 haben wir eine außergewöhnliche Zeit erlebt. Sie waren geprägt von der globalen Corona-Pandemie, die uns vor nie dagewesene Herausforderungen stellte. Auch der Krieg in der Ukraine und die damit verbundenen Folgen wirkten sich auf unsere Arbeit aus.

Es hat sich abermals gezeigt, wie wichtig es ist, zuverlässige und unabhängige Daten für Berlin und Brandenburg zu erheben und bereitzustellen. Wir liefern mit objektiven und neutralen Statistiken die Grundlage für eine faktenbasierte Entscheidungsfindung.

[Corona & Co.](/rueckschau#corona)[Digitalisierung](/rueckschau#digital)[Wahlen](/rueckschau#wahlen)[Nachhaltigkeit](/rueckschau#nachhaltigkeit)[Außerdem](/rueckschau#ausserdem)
#### Neue Wege gehen.

### Unser Umgang mit Corona & Co.

Bundes-, Länder- und EU-Statistiken in 2021

%
-

davon termingerecht an das Statistische Bundesamt geliefert

Pressemitteilungen in 2021 veröffentlicht

Bundes-, Länder- und EU-Statistiken in 2022

%
-

davon termingerecht an das Statistische Bundesamt geliefert

Pressemitteilungen in 2022 veröffentlicht

Die Arbeit im Homeoffice ist in den Jahren 2021 und 2022 für uns Normalität geworden. Die Pandemie zwang uns, schnell und unkompliziert neue Arbeitsweisen einzuführen und die Digitalisierung voranzutreiben. Besprechungen fanden plötzlich digital als Videokonferenzen statt. Die Eltern unter den Beschäftigten erhielten spezielle Angebote, die mit der Betreuung der Kinder zu Hause vereinbar waren. Auch auf die speziellen Bedürfnisse der Kolleginnen und Kollegen mit pflegebedürftigen Angehörigen gingen wir ein.

> **Uns war es wichtig, untereinander viel Verständnis für die individuellen Probleme im Umgang mit der Pandemie zu schaffen. Denn nur so konnten wir gemeinsam diese schwierige Zeit meistern und unseren Auftrag erfüllen.**

Wir entwickelten neben Kontakt- und Hygienekonzepten spezielle Kommunikationsformate, um uns gegenseitig auf dem Laufenden zu halten und zu motivieren. So wurde in 2021 das Format *Vorstandsinformation* geboren, in dem Jörg Fidorra (Vorstand) alle Mitarbeitenden regelmäßig in Form eines persönlichen Briefes auf dem Laufenden hielt. Das bei den Beschäftigten beliebte Format besteht bis heute und wurde mittlerweile um Podcasts ergänzt.

Gerade in diesen Krisenjahren wurde uns noch klarer, wie wichtig unser Auftrag ist, zuverlässige und unabhängige Daten für Berlin und Brandenburg zu erheben und bereitzustellen. Politische Entscheidungstragende, Vertreterinnen und Vertreter von Wirtschaftsunternehmen und Verbänden sowie die breite Öffentlichkeit haben anhand unserer objektiven Statistiken die Möglichkeit, sich eine faktenbasierte Meinung zu bilden und Entscheidungen zu treffen.

Dieses Ziel verfolgten wir auch mit unseren **Schwerpunkt-Seiten**, die anhand amtlicher Daten die Auswirkungen z. B. der Corona-Pandemie oder des Ukraine-Krieges für die Hauptstadtregion abbilden.

Schwerpunkt: Ukraine
--------------------

Anhand amtlicher Zahlen beleuchten wir die Auswirkungen und Folgen des Konflikts in der Hauptstadtregion.

[Mehr erfahren](/schwerpunkte/ukraine)

Schwerpunkt: Corona
-------------------

In den Themenbereichen Gesundheit, Gesellschaft und Wirtschaft zeigen unsere Statistiken die Folgen der Pandemie.

[Mehr erfahren](/corona)

Auch viele unserer **Auskunfgebenden** waren in den Pandemiejahren und mit dem Beginn des Ukraine-Krieges in einer herausfordernden Situation. Für viele rückte die Meldung ihrer Daten an uns in den Hintergrund. Für uns bedeutete dies, auch hier eine Lösung zu finden. Wir mussten abwägen, wie wir unseren Datenmeldenden entgegenkommen, sie entlasten und gleichzeitig alle Daten fristgerecht erhalten und bearbeiten konnten. Das war nicht immer einfach.

> **An dieser Stelle danken wir allen Auskunftgebenden, die mit ihrer Meldung dazu beitrugen, dass wir unsere Statistiken fristgerecht erstellen konnten. Damit leisteten Sie einen wichtigen Beitrag für die Gesellschaft.**

#### Wir sind digital.

### Modernisierung auf allen Ebenen

Ein für uns nicht alltägliches Projekt war die laufende Transition unserer gesamten IT in das Rechenzentrum des neuen IT-Dienstleisters GISA. Diese hochkomplexe Umstellung im Februar 2022 erforderte sorgfältige Planung und effizientes Handeln, um einen reibungslosen und lückenlosen Betrieb sicherzustellen.

*„Ich freue mich, dass alles so gut geklappt hat. Am vergangenen Freitagmittag haben wir unsere ‚alten‘ Arbeitsplätze verlassen und bereits Montag früh waren wir in der neuen, modernen IT-Welt angekommen. Meine Mitarbeitenden bereiteten diesen Wechsel seit Monaten vor. Nun haben wir den wichtigsten Meilenstein des Projektes erfolgreich und termingerecht gemeistert.“ (Jörg Fidorra, Vorstand)*

**Darüber hinaus** **treiben wir die Digitalisierung unserer Prozesse in verschiedenen Bereichen weiter voran:**

Unsere Beschaffungsstelle arbeitet komplett digital.

Wir haben ein digitales Bewerbungsmanagement.

Für Inhouse-Schulungen wurde das Format „Digitales Klassenzimmer“ eingerichtet.

Unser Befragungsservice für die Berliner und Brandenburger Behörden bietet Mitarbeiterbefragungen barrierefrei an.

Die Konferenzreihe „Messung der Preise“ wurde nach zweijähriger Corona-Pause am 8. September 2022 erstmals virtuell durchgeführt.

In der neuen digitalen Verdienserhebung setzen wir im Verbund eine künstliche Intelligenz, hier insbesondere das maschinelle Lernen, ein.

#### Wahlen & Volksentscheide

### Wir sind ein verlässlicher Partner.

2021 wurde der 20. Deutsche Bundestag gewählt. Gleichzeitig fanden in Berlin die Wahlen zum Abgeordnetenhaus und zu den Bezirksverordnetenversammlungen statt. Zusätzlich gab es einen Volksentscheid zur Vergesellschaftung der Wohnungsbestände großer Wohnungsunternehmen. In Brandenburg wurden parallel dazu zwei Landratswahlen in Märkisch-Oderland und Teltow-Fläming durchgeführt.

Wir erstellten die Wahlkreistabellen, die Vorwahl- und Strukturdaten. In der Wahlnacht arbeiteten unsere Mitarbeitenden in der Ergebniszentrale bis die letzte Stimme ausgezählt war. Bei uns liefen die Ergebnisse aller Wahllokale zusammen. Wir ermittelten und veröffentlichten das vorläufige und das amtliche Endergebnis.

> **Mit unserer Expertise und unserem Engagement trugen wir somit auch 2021 dazu bei, dass demokratische Prozesse transparent, fair und erfolgreich abliefen. Wir stehen bereit, um auch in Zukunft unseren Beitrag zur Durchführung demokratischer Wahlen in Berlin und Brandenburg zu leisten.**

###### Bundestagswahl 2021 Berlin

#### Wahlbeteiligung in den Berliner Bezirken

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Bundestagswahl 2021 Brandenburg

#### Wahlbeteiligung in den Landkreisen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### Unser Leuchtturm

### Wir verpflichten uns der Nachhaltigkeit.

Das Amt für Statistik Berlin-Brandenburg und die amtliche Statistik mögen nicht unmittelbar mit diesem Thema in Verbindung gebracht werden, doch auch wir setzen uns für Nachhaltigkeit ein. Als amtliche Statistik stellen wir Indikatoren bereit und erstellen Nachhaltigkeitsberichte. Diese liefern wichtige Daten, die für die Messung und Bewertung von Nachhaltigkeit unerlässlich sind.

Anknüpfend an die Kernindikatorenberichte zur nachhaltigen Entwicklung Berlins 2012 und 2014 wurde der Berliner Indikatorenbericht 2021 mit 40 ausgewählten Indikatoren zur Nachhaltigkeit veröffentlicht. Wir haben ihn im Auftrag und in enger Zusammenarbeit mit der Senatsverwaltung für Umwelt, Verkehr und Klimaschutz (SenUVK) erarbeitet.

Nachhaltige Entwicklung in Berlin
---------------------------------

Anhand von 40 Indikatoren, die jeweils einem der 17 internationalen Ziele für nachhaltige Entwicklung zugeordnet sind, liefert der „Indikatorenbericht 2021 – Nachhaltige Entwicklung in Berlin“ objektive Messgrößen für die Stadt.

[Mehr erfahren](https://download.statistik-berlin-brandenburg.de/feb8ab55a5e5f6f1/a389e1161ead/AfS_Nachhaltigkeitsbericht_2021_BE.pdf)
#### Wir haben eine Nachhaltigkeitsbeauftragte.

Nachhaltigkeit ist für uns ein ganzheitlicher Ansatz, der soziales Handeln, Integrität, gesellschaftliches Engagement, Kulturwandel und Weiterentwicklungsmöglichkeiten für unsere Mitarbeitenden einschließt. Bei all unseren Entscheidungen und Planungen betrachten wir nicht nur ökologische Aspekte, sondern berücksichtigen genauso soziale und ökonomische Gesichtspunkte.

**Wir stehen zu unseren Nachhaltigkeitszielen und setzten diese auch 2022 konsequent um:**

Unternehmerische Dimension | Unternehmerische Verantwortung leben

Ökonomische Dimension | Effizienter Umgang mit Ressourcen, Arbeitsplätzen und Stabilität

Soziale Dimension | Verantwortung für die Mitarbeitenden übernehmen

Ökologische Dimension | Verantwortung für Natur und Umwelt übernehmen

Soziales Engagement | Spenden im Sinne der Nachhaltigkeit

![](https://download.statistik-berlin-brandenburg.de/c9e37fce07868c8f/dda2a7e68c8d/v/fbaf5ccd55cf/foto-britt-springer.jpg)
#### Britt Springer

Nachhaltigkeitsbeauftragte

#### Britt Springer

Nachhaltigkeitsbeauftragte

* [britt.springer@statistik-bbb.de](mailto:britt.springer@statistik-bbb.de)

**Die Aufgaben der Nachhaltigkeitsbeauftragten sind vielfältig.**Sie steuert und kontrolliert die internen Nachhaltigkeitsbelange, entwickelt unsere Nachhaltigkeitsstrategie, identifiziert Ziele für wesentliche Themen und erarbeitet ein umfassendes Nachhaltigkeitsprogramm.

Mit der Einführung von Confluence und Jira in 2021 ersetzen wir zunehmend analoge durch digitale Arbeitsabläufe und optimieren so die Zusammenarbeit aller Mitarbeitenden.

Ein etabliertes Onboarding, begleitet von einem Paten, ermöglicht neuen Mitarbeitenden eine schnelle Einarbeitung und eine rasche Orientierung.

Mit flexiblen Arbeitszeitmodellen, gesundheitsfördernden Maßnahmen und Ergonomieberatungen investieren wir nachhaltig in die Gesundheit unserer Mitarbeitenden.

Mobiles Arbeiten und die Durchführung von z. B. Workshops, Seminaren oder Geschäftsterminen via Video-oder Telefonkonferenz spart Reisezeiten und -wege.

Wir setzen auf die Digitalisierung unserer Prozesse und Produkte. Wenn doch gedruckt werden muss, setzen wir auf Recyclingpapier.

Wir bieten jährlich Fahrradchecks für unsere Mitarbeitenden an, übernehmen Kosten für Leihräder und bieten ein Firmenticket für den ÖPNV.

**Wir sind stolz darauf, unseren Beitrag für die Umwelt zu leisten und freuen uns, Sie auf diese Reise in eine nachhaltige Zukunft mitzunehmen. Gemeinsam können wir Veränderungen bewirken und eine positive Wirkung erzielen.**

#### Themen, die uns außerdem bewegten.

### Eine Auswahl

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/139-2021)**Bevölkerungsvorausberechnung bis 2030 für Brandenburg** [#### Bevölkerungswachstum bis 2025](/139-2021)[![iStock.com / LianeM](https://download.statistik-berlin-brandenburg.de/c831f04bef43dd06/02da61c05d4f/v/d718f59c09a7/wirtschaft-preise-bodenpreise.jpg "iStock.com / LianeM")](/news/06-2021-hitzetote)**Hitzetote 2020**[#### Hitzbedingte Sterbefälle deutlich über dem Durchschnitt](/news/06-2021-hitzetote)[![iStock.com / 3dan3](https://download.statistik-berlin-brandenburg.de/31a3a0989d664ca9/8d97900f9d5c/v/845391179cbd/wirtschaft-wirtschaftsbvereiche-berlin-prenzlauer-berg-picture-id1157122883.jpg "iStock.com / 3dan3")](/news/07-2021-kommunalstatistik)**Berlin-Statistik**[#### Neues kommunalstatistisches Datenangebot für Berlin](/news/07-2021-kommunalstatistik)[![](https://download.statistik-berlin-brandenburg.de/3f3de7f85c2eec34/059234f2480f/v/d8e69fc66f7b/audit_bf_rz_18_1_RGB_Zuschnitt.png)](/news-Re-Auditierung)**Als familien- und lebensphasenbewusster Arbeitgeber ausgezeichnet**[#### Amt für Statistik Berlin-Brandenburg erhält erneut Zertifikat zum „audit berufundfamilie“](/news-Re-Auditierung)[![Foto Walter J. Radermacher](https://download.statistik-berlin-brandenburg.de/7c2d22e78dd2d19c/d31885f76032/v/1892e8cd31e9/Walter-Radermacher-Foto.jpg "Foto Walter J. Radermacher")](/interview-walter-radermacher)**Fachgespräch mit Dr. Walter J. Radermacher**[#### „Ich bin überzeugt, dass die amtliche Statistik heute mehr als jemals zuvor gebraucht wird.“](/interview-walter-radermacher)[![](https://download.statistik-berlin-brandenburg.de/4dc886c51feb81df/664fca7b2859/v/76ea2bfc2992/PM183-2022_Zensus2022.png)](/183-2022)**Zensus 2022 – Haushaltebefragung sowie Gebäude- und Wohnungszählung** [#### In der Hauptstadtregion 120.000 Anschriften besucht und 900.000 Schreiben versendet](/183-2022)[![](https://download.statistik-berlin-brandenburg.de/d468d88661bf0b57/1205b5813bde/v/e012b33daca2/iStock-1305998551.jpg)](/news/24-konferenz-messung-der-preise)**Konferenz-Artikel**[#### 24. Konferenz „Messung der Preise“](/news/24-konferenz-messung-der-preise)[![](https://download.statistik-berlin-brandenburg.de/659b8e15c0c434de/88376536d34e/v/031046298ba4/Jubilaum-FDZ.PNG)](/publikationen/fachbeitrag/2022/20-jahre-fdz)**20 Jahre Forschungsdatenzentrum der Statistischen Ämter der Länder**[#### Bewährtes bewahren, Neues wagen](/publikationen/fachbeitrag/2022/20-jahre-fdz)
### Immer die Fakten im Blick

#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Newsletter abonnieren](/newsletter)


