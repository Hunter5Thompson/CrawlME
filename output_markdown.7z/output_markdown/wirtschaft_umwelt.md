

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
#### Überblick

Umwelt
======

Der Bereich Umwelt umfasst die Statistiken der Abfall- und Energiewirtschaft, zur Wasserversorgung und Abwasserbeseitigung und zur Umweltökonomie. Die Gesamtrechnung bietet einen Blick auf die Wechselwirkung zwischen Umwelt und Wirtschaft. Die Energie- und CO2-Bilanz beinhaltet Daten zur Verwendung von Energieträgern sowie deren Emissionen.

BerlinBrandenburg

%
=

Anteil erneuerbarer Energien an der Stromeinspeisung  
Stand: 2023

[Umweltökonomie
#### Umweltökonomische Gesamtrechnungen](/wirtschaft/umwelt/gesamtrechnungen)[Wasserwirtschaft
#### Wasser](/wasser)[Erneuerbare und fossile Energieträger
#### Energie](/energie)[Abfälle, klimawirksame Stoffe
#### Abfall, Luftbelastungspotenzial](/luftverunreinigungen)[Umweltökonomie
#### Umweltschutzausgaben und -produkte](/umweltausgaben)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Umwelt

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg2 ohne Elektrogeräte3 Einwohner jeweils zum Jahresende**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
##### 

#### Neues aus dem Bereich Umwelt

Zuletzt veröffentlicht
----------------------

![Ein Windrad und weiter Blick in die Landschaft](https://download.statistik-berlin-brandenburg.de/2fe0c01ea1e3b28f/36c8abef068e/v/58c54355b18c/wirtschaft-preise-wind-turbine-in-the-sunset-seen-from-an-aerial-view-picture-id864427886.jpg)17.12.2024Statistischer Bericht[#### 2023, jährlich, E IV 5 – j: Energie- und CO₂-Bilanz Berlin (vorläufig)](/e-iv-5-j)

Vorläufige Ergebnisse zum Aufkommen und zur Verwendung von Energieträgern sowie zu den energiebedingten CO₂-Emissionen in Berlin.

[Ansehen](/e-iv-5-j)![iStock-968906216.jpg](https://download.statistik-berlin-brandenburg.de/de73473a84e6df5a/fd72727beb4c/v/9e312ba3eb79/gaspipeline.jpg)17.12.2024Pressemitteilung[#### Energie- und CO₂-Bilanz 2023 Berlin: Energieverbrauch und CO₂-Emissionen weiter gesunken](/169-2024)

Die vorläufigen Ergebnisse der Energie- und CO₂-Bilanz 2023 zeigen auch weiterhin einen Rückgang beim Energieverbrauch und bei den CO₂-Emissionen.

[Ansehen](/169-2024)![iStock.com / peterschreiber.media](https://download.statistik-berlin-brandenburg.de/b749a5ad8a0f4399/cd0915e8d640/v/9098cfcd5d1e/wirtschaft-preise-highvoltage-sky-background-picture-id1205564390.jpg)17.12.2024Statistischer Bericht[#### 2022, jährlich, E IV 4 – j: Energie- und CO₂-Bilanz in Berlin und Brandenburg](/e-iv-4-j)

Statistik zum Aufkommen und zur Verwendung von Energieträgern sowie zu den energiebedingten CO₂-Emissionen in Berlin und Brandenburg.

[Ansehen](/e-iv-4-j)Mehr anzeigen
#### Hintergrund

### Energie- und CO₂-Bilanzen

  
Das Amt für Statistik Berlin-Brandenburg erstellt jährlich im Auftrag der Länder Berlin und Brandenburg die Energie- und CO₂-Bilanz. Sie sowie die darauf aufbauenden Indikatoren werden nach einer im Länderarbeitskreis abgestimmten Methodik erstellt und berechnet. Mit seinem Regelwerk richtet sich der Länderarbeitskreis nach internationalen und europäischen Vorgaben und stimmt seine Vorgehensweise mit der AG Energiebilanzen zur Berechnung der Energiebilanz des Bundes ab.   


###### Was ist der Unterschied zwischen Quellen- und Verursacherbilanz?

Die Quellenbilanz stellt Emissionen aus dem Primärenergieverbrauch dar. Eine Quellenbilanz ermöglicht Aussagen über die Gesamtmenge des emittierten Kohlendioxids von der Aufkommensseite. Es werden alle Emissionen dargestellt, die auf den Verbrauch von Primärenergieträgern – z. B. Kohlen, Mineralöle – zurückgehen.

Eine Verursacherbilanz stellt Emissionen aus dem Endenergieverbrauch dar. Es fließen sowohl Primär- als auch Sekundärenergieträger – wie Wärme und Strom – in die Berechnung ein.


