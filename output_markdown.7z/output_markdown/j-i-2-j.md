

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Dienstleistungen](/dienstleistungen)
* [Dienstleistungen in Berlin und Brandenburg (jährlich)](/j-i-2-j)

Dienstleistungen
----------------

#### 2020, jährlich

###### Die jährlich durchgeführte Strukturerhebung liefert Informationen über die Struktur von Unternehmen und Einrichtungen zur Ausübung einer freiberuflichen Tätigkeit (Rechtliche Einheiten) im Bereich Dienstleistungen.

BerlinBrandenburgMethodik
### Berlin

1 Gesamtumsatz ist die Summe von Umsatz und sonstigen betrieblichen Erträgen. Umsatz aus betriebstypischer Geschäftstätigkeit und aus nicht betriebstypischen Nebengeschäften.**Quelle:** Amt für Statistik berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/2eee7d2a329a67a8/7920ed1fd8ac/SB_J01-02-00_2020j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/73ac4bb5c8119dad/4b6dda7617e9/SB_J01-02-00_2020j01_BE.pdf)

**Umsatz im Vergleich zum Vorjahr relativ konstant**

Die 75.890 rechtlichen Einheiten im Berliner Dienstleistungsbereich erzielten 2020 mit über 596.000 abhängig Beschäftigten einen Gesamtumsatz von 80,7 Milliarden EUR. Die Bruttowertschöpfung betrug 42,2 Milliarden EUR. Es wurden Bruttoanlageinvestitionen in Höhe von insgesamt 12,5 Milliarden EUR getätigt.

Die „Post-, Kurier- und Expressdienste“ steigerten ihren Gesamtumsatz im Vergleich zum Vorjahr um 92,0 % auf 1,4 Milliarden EUR.

Die „Rundfunkveranstalter“ mussten hingegen einen Rückgang des Gesamtumsatzesum fast 40 % auf 154,7 Millionen EUR hinnehmen.

Auch in folgenden Wirtschaftszweigen ging der Umsatz zurück: „Ateliers für Textil-, Schmuck-, Grafik- und ähnliche Design“ (–30,0 %), „Fotografie und Fotolabors“ (–22,5 %) sowie „Übersetzen und Dolmetschen“ (–23,3 %).

Der Wirtschaftszweig „Reisebüros, Reiseveranstalter und Erbringung sonstiger Reservierungsdienstleistungen“ musste einen deutlichen Einbruch verkraften: Die Zahl der tätigen Personen nahm um 37,4 % ab und der Gesamtumsatz sank um 74,8 % auf 409,6 Millionen EUR.

### Kontakt

#### Nadine Pierron

Dienstleistungen Struktur

#### Nadine Pierron

Dienstleistungen Struktur

* [0331 8173-1331](tel:0331 8173-1331)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Umsatz im Vergleich zum Vorjahr um 3,9 % gesunken**

Im Geschäftsjahr 2020 umfasste der Brandenburger Dienstleistungsbereich 29.042 rechtliche Einheiten mit gut 172.000 abhängig Beschäftigten. Sie erwirtschafteten einen Gesamtumsatz von 21,5 Milliarden EUR. Die Bruttowertschöpfung lag bei 10,9 Milliarden EUR, der Umfang der Bruttoanlageinvestitionen betrug 3,4 Milliarden EUR.

Die „Post-, Kurier- und Expressdienste“ erhöhten ihren Gesamtumsatz gegenüber dem Vorjahr um 20,1 % auf 325,2 Millionen EUR.

Im Wirtschaftszweig „Herstellung, Verleih und Vertrieb von Filmen und Fernsehprogrammen; Kinos; Tonstudios und Verlegen von Musik“ ging der Gesamtumsatzhingegen um 55,4 % auf 221,5 Millionen EUR zurück.

Einen Umsatzrückgang verzeichneten außerdem folgende Wirtschaftszweige: „Public-Relations- und Unternehmensberatung“ (–27,8 %), „Markt- und Meinungsforschung“ (–35,5 %), „Fotografie und Fotolabors“ (–17,1 %) sowie „Übersetzen und Dolmetschen“ (–22,1 %).

Im Wirtschaftszweig „Reisebüros, Reiseveranstalter und Erbringung sonstiger Reservierungsdienstleistungen“ nahm die Zahl der tätigen Personen um 14,6 % ab. Der Gesamtumsatz betrug 70,1 Millionen EUR, 61,8 % weniger als im Jahr zuvor.

1 Gesamtumsatz ist die Summe von Umsatz und sonstigen betrieblichen Erträgen. Umsatz aus betriebstypischer Geschäftstätigkeit und aus nicht betriebstypischen Nebengeschäften.**Quelle:** Amt für Statistik berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c4183e2f6d686899/8ec0f389abfe/SB_J01-02-00_2020j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/3623104ce59023cb/e7032a1ba5b3/SB_J01-02-00_2020j01_BB.pdf)
### Kontakt

#### Nadine Pierron

Dienstleistungen Struktur

#### Nadine Pierron

Dienstleistungen Struktur

* [0331 8173-1331](tel:0331 8173-1331)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die jährlichen Erhebungen in den Dienstleistungsbereichen liefern Informationen über die Struktur, Rentabilität und Produktivität der Unternehmen in diesem Wirtschaftsbereich. Die Ergebnisse zu Merkmalen wie Umsatz, tätige Personen, Bruttolohnsumme und Investitionen werden als absolute Werte dargestellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Dienstleistungen – Strukturerhebung im Dienstleistungsbereich**  
Metadaten ab 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/50849b4aff89927a/1b5009d5d0c3/MD_47415_2020.pdf)[Archiv](/search-results?q=MD_47415&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/j-i-2-j)
