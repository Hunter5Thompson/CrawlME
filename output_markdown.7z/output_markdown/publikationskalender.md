

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Presse](/presse)
* [Publikationskalender](/publikationskalender)

Publikationskalender
====================

Erfahren Sie, was wir für Sie geplant haben! Unser Publikationskalender bietet Ihnen einen Überblick über unsere bevorstehenden Pressemitteilungen und Statistischen Berichte für die Länder Berlin und Brandenburg. Wir freuen uns darauf, Sie mit relevanten und zuverlässigen Daten zu versorgen.

[Newsletter abonnieren](/newsletter)JanFebMrzAprMaiJunJulAugSepOktNovDez

Neueste Veröffentlichungen
--------------------------

[![iStock-1213727367.jpg](https://download.statistik-berlin-brandenburg.de/8c43b2d7bc814cc3/3e5ce1b6bb13/v/4660157d52dc/landwirtschaft-rinder.jpg "iStock-1213727367.jpg")](/c-iii-9-hj)**3. November 2024, halbjährlich, C III 9 - hj**[#### Rinder in Berlin und Brandenburg](/c-iii-9-hj)

Die Erhebung informiert über die Anzahl der Rinder (einschließlich Büffel/Bisons), gegliedert nach Alter, Geschlecht, Nutzungszweck und Rasse.

[![iStock.com / Rawf8](https://download.statistik-berlin-brandenburg.de/bb9c63d4a21d952a/78b18f7a17ff/v/85a71b6cd4c6/gesellschaft-staat-judge-gavel-and-a-laptop-wooden-background-online-auction-concept-picture-id1220820993.jpg "iStock.com / Rawf8")](/180-2024)**Strafverfolgung 2023 in Berlin und Brandenburg**[#### Abwärtstrend in Brandenburg setzt sich fort](/180-2024)

2023 nahm die Zahl der Verurteilungen in Berlin im Vergleich zum Vorjahr um 2,1 % zu, in Brandenburg ging sie um 11,1 % zurück.

[![iStock.com / Spotmatik](https://download.statistik-berlin-brandenburg.de/09fe07d2f99a71db/1fd2b255bc8f/v/d5efaa426575/gesellschaft-gesundheit-doctors-hospital-corridor-nurse-pushing-gurney-stretcher-bed-picture-id478740625.jpg "iStock.com / Spotmatik")](/179-2024)**Krankenhausdiagnosestatistik 2023 Berlin und Brandenburg**[#### Zahl der vollstationären Behandlungen steigt langsam wieder an](/179-2024)

Rund 1,25 Millionen Menschen sind 2023 in den Krankenhäusern der Metropolregion behandelt worden.

[![iStock.com / GoogolPix](https://download.statistik-berlin-brandenburg.de/1a03bedef8ab3c23/0b10aefb97c2/v/6a408397d32d/gesellschaft-verkehr-ship-on-canal-in-bavaria-picture-id666692770.jpg "iStock.com / GoogolPix")](/173-2024)**Transport auf Brandenburgs Wasserstraßen von Januar bis September 2024**[#### Mehr Güter befördert](/173-2024)

Auf den Binnenwasserstraßen Brandenburgs wurden in den ersten drei Quartalen 2024 insgesamt 1.524.600 Tonnen Güter befördert.

[![iStock.com / serts](https://download.statistik-berlin-brandenburg.de/dd6e941c8ce73a94/2daf4f79fd95/v/32cedc604422/gesellschaft-staat-statue-of-lady-justice-rmerberg-frankfurt-germany-picture-id840831682.jpg "iStock.com / serts")](/b-vi-1-j)**2023, jährlich, B VI 1 – j**[#### Abgeurteilte und Verurteilte in Berlin](/b-vi-1-j)

In dieser Statistik wird die Anzahl der Abgeurteilten und Verurteilten aus der Strafverfolgungsstatistik veröffentlicht.

[![iStock.com / Animaflora](https://download.statistik-berlin-brandenburg.de/f08f86242a9d8c45/daccc7cb7e90/v/7b54dde10b33/gesellschaft-verkehr-barges-maindanube-canal-in-bamberg-picture-id1094480316.jpg "iStock.com / Animaflora")](/172-2024)**Transport auf Berlins Wasserstraßen von Januar bis September 2024**[#### Leichter Anstieg bei der Güterbeförderung](/172-2024)

Auf den Binnenwasserstraßen Berlins wurden in den ersten drei Quartalen 2024 insgesamt 909.451 Tonnen Güter befördert.


