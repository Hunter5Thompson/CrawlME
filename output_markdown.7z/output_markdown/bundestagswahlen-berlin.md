

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Berlin](/wahlen-berlin)
* [Bundestagswahlen in Berlin](/bundestagswahlen-berlin)

Bundestagswahlen in Berlin
==========================

Die Bundestagswahlen finden alle vier Jahre statt. Wählende haben zwei Stimmen. Mit der Erststimme wird in den Wahlkreisen mit relativer Mehrheit je ein Direktmandat gewählt. Mit der Zweitstimme wird die Landesliste einer Partei gewählt. Sie ist maßgebend für die Verteilung der Gesamtzahl der Sitze auf die Parteien im Deutschen Bundestag. Es werden nur Parteien berücksichtigt, die mindestens 5 % der Zweitstimmen oder in drei Wahlkreisen ein Direktmandat erhalten.

Bundestagswahl 2021/2024Bundestagswahl 2017Endgültige ErgebnisseWahlgebieteWahlstrukturdatenRepräsentative WahlstatistikHistorie

Bundestagswahl am 11. Februar 2024
----------------------------------

#### Endgültige Ergebnisse nach der Teilwiederholungswahl (Hauptwahl vom 26. September 2021) in Berlin

#### Alle Ergebnisse in interaktiver Form

****Wahlergebnisse der Teilwiederholungswahl 2024 in 455 Wahlbezirken und der Hauptwahl 2021 in allen weiteren Wahlbezirken.****

[Zu den Ergebnissen](https://wahlen-berlin.de/wahlen/BU2024/AFSPRAES/btw/index.html)
#### **Alle Ergebnisse als Download**

[Wahlbezirksergebnisse (XLSX)](https://download.statistik-berlin-brandenburg.de/9e01e5361f54b145/1e68925d2d91/DL_BE_BU2024.xlsx)[Ergebnisbericht (PDF)](https://download.statistik-berlin-brandenburg.de/6e43f8d626d9b724/4ae4f67783ae/SB_B07-01-03_2024j04_BE.pdf)

Wahlgebietseinteilung
---------------------

![](https://download.statistik-berlin-brandenburg.de/ffd546a1b52dee06/0ec09ded66ba/v/d04c51a01778/Wahlgebiete-berlin-bundestagswahl-2021.png)
### 

#### **Wahlkreiskarten**

Berlin – **gesamt** **→**[**Download PDF**](https://download.statistik-berlin-brandenburg.de/5561f130da97c0e9/59907ea1a70d/Bundestagswahlkreise_WWTB_2024_ganz_Berlin.pdf)

75 – **Mitte →** [Download PDF](https://download.statistik-berlin-brandenburg.de/7148f2fc0ad0f4d9/34d224e221c8/Bundestagswahlkreis_WWBT_2024_075.pdf)

76 – **Pankow →**[Download PDF](https://download.statistik-berlin-brandenburg.de/c31c91717c9e196a/3d431d50259a/Bundestagswahlkreis_WWBT_2024_076.pdf)

77 – **Reinickendorf →**[**Do**wnload PDF](https://download.statistik-berlin-brandenburg.de/30be171e72c3687d/8c4492f72d6c/Bundestagswahlkreis_WWBT_2024_077.pdf)

78 – **Spandau – Charlottenburg Nord →**[Download PDF](https://download.statistik-berlin-brandenburg.de/b63223e8cc55e011/4d01a28924f7/Bundestagswahlkreis_WWBT_2024_078.pdf)

79 – **Steglitz-Zehlendorf →**[Download PDF](https://download.statistik-berlin-brandenburg.de/1c5b88cc64823969/b1efe925a167/Bundestagswahlkreis_WWBT_2024_079.pdf)

80 – **Charlottenburg-Wilmersdorf**→ [Download PDF](https://download.statistik-berlin-brandenburg.de/d669715d0c89677c/67dd2d78ad5f/Bundestagswahlkreis_WWBT_2024_080.pdf)

81 – **Tempelhof-Schöneberg** → [Download PDF](https://download.statistik-berlin-brandenburg.de/1189899615a78e11/d45c8bf00dab/Bundestagswahlkreis_WWBT_2024_081.pdf)

82 – **Neukölln →** [Download PDF](https://download.statistik-berlin-brandenburg.de/cc928d919d8d9289/d7a25e0f20cb/Bundestagswahlkreis_WWBT_2024_082.pdf)

83 – **F****riedrichshain-Kreuzberg – Prenzlauer Berg Ost**→ [Download PDF](https://download.statistik-berlin-brandenburg.de/6dd7dc79b1892a83/080aafd82b33/Bundestagswahlkreis_WWBT_2024_083.pdf)

84 – **Treptow-Köpenick** → [Download PDF](https://download.statistik-berlin-brandenburg.de/edf7b4639dad0f83/2e55fb605e36/Bundestagswahlkreis_WWBT_2024_084.pdf)

85 – **Marzahn-Hellersdorf**→ [Download PDF](https://download.statistik-berlin-brandenburg.de/d8638b504cbae012/a13ded8a36e2/Bundestagswahlkreis_WWBT_2024_085.pdf)

86 – **Lichtenberg →**[Download PDF](https://download.statistik-berlin-brandenburg.de/fa9f7cdc36110b00/4c130d9fcecb/Bundestagswahlkreis_WWBT_2024_086.pdf)

Die 12 Wahlgebietskarten umfassen jeweils einen Bundestagswahlkreis. Sie sollen Orientierung bzgl. der Berliner Bundestagswahlgebiete bieten. Weitere Informationen zur Funktionalität der Wahlkreiskarten können Sie [hier](https://download.statistik-berlin-brandenburg.de/b1313a9fcf42cab4/f69205ad44a6/2024_BTWKr_Anleitung.pdf) herunterladen.

Wahlstrukturdaten
-----------------

#### Demografische und politische Strukturen von Berlin

### Downloads

| **Vorwahldaten, Strukturdaten** | ****Umgerechnete Ergebnisse der Wahl zum Deutschen Bundestag 2017 (Zweitstimmen)**** | **Umgerechnete Ergebnisse der Wahl zum Abgeordnetenhaus 2016 (Zweitstimmen)** | **Strukturdaten auf Wahlbezirksebene** |  |
| --- | --- | --- | --- | --- |
| [XLSX](https://download.statistik-berlin-brandenburg.de/ae839a159e938d23/af2d7cdda57a/SB_B07-01-01_2024j04_BE.xlsx) [PDF](https://download.statistik-berlin-brandenburg.de/0029c060aab63e68/53517ecc3ed7/SB_B07-01-01_2024j04_BE.pdf) | [XLSX](https://download.statistik-berlin-brandenburg.de/05d3e01da1b79c09/cb4a6f9def44/DL_BE_BT2024_BT2017.xlsx) | [XLSX](https://download.statistik-berlin-brandenburg.de/abd5cf16a0b38e02/2ec164260d6d/DL_BE_BT2024_AH2016.xlsx) | [XLSX](https://download.statistik-berlin-brandenburg.de/2adeb8080a11c251/b42405d7766a/DL_BE_BTW2024_Strukturdaten_Wiederholung.xlsx) |  |
|  |  |

Repräsentative Wahlstatistik
----------------------------

#### Wer hat wie gewählt?

##### Bundestagswahl am 26. September 2021 in Berlin**Wahlbeteiligung nach Alter**

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Repräsentative Wahlstatistik als Download**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/93b37127fd93f22d/2031c92d04ce/SB_B07-01-05_2021j04_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f2f39539c3b5f599/9641d6b779f6/SB_B07-01-05_2021j04_BE.pdf)

Mit der repräsentativen Wahlstatistik werden die **Wahlbeteiligung** und die **Stimmabgabe** der Wahlberechtigten nach Geschlecht und Altersgruppen im Wege der Stichprobe untersucht.

Rechtsgrundlage für die Durchführung ist das Gesetz über die allgemeine und die repräsentative Wahlstatistik (Wahlstatistikgesetz – WStatG).

**Bei der Teilwiederholungswahl im Februar 2024 in Berlin wurde keine repräsentative Wahlstatistik durchgeführt.**

Historische Daten
-----------------

[**Endgültige Ergebnisse zu Bundestagswahlen in Berlin**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000611)[**Repräsentative Wahlstatistiken zu Bundestagswahlen in Berlin**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000650)

**Wahlbezirksergebnisse zu Bundestagswahlen in Berlin**

[**Strukturdaten, Vorwahldaten zu Bundestagswahlen in Berlin**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000392)
##### Bundestagswahlen in Berlin**Wahlbeteiligung 1994 bis 2024**

 **Quelle:** Amt für Statistik Berlin-Brandenburg

1 – Wahlergebnisse der Teilwiederholungswahl 2024.

##### **Entwicklung der Wahlergebnisse im Zeitverlauf:**

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/fef2be7da8798fcf/5cf7369c25c1/bundestagswahlen-lange-reihe.xlsx)

Weiterführende Informationen
----------------------------

###### Metadaten

Unsere Metadaten liefern Informationen zu den erhobenen Daten und der angewendeten Methodik. Ergänzt werden diese durch Musterstimmzettel, Datensatzbeschreibungen und gegebenenfalls einen Qualitätsbericht.

**Allgemeine Bundestagswahlstatistik (2021)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/9e46a1137fe0138d/d6fca48713e5/MD_14111_2021.pdf)

**Allgemeine Bundestagswahlstatistik (2017)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/55a5892fb6ce5f43/b11450513684/MD_14111_2017.pdf) 

**Repräsentative Bundestagswahlstatistik (2021)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/ad7a42cbbd45e8cf/cfc158471edd/MD_14121_2021.pdf) 
###### Link zum OpenData Portal Berlin

Geometrien, Wahllokale und weitere offene Datensätze →  [OpenData Portal Berlin](https://daten.berlin.de/datensaetze?groups=wahl&author_string=Amt+f%C3%BCr+Statistik+Berlin-Brandenburg&sort=score+desc%2C+metadata_modified+desc)

#### Der Landeswahlleiter für Berlin auf [www.berlin.de](https://www.berlin.de/wahlen/)


