

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Karriere](/karriere)
* [Aktuelle Stellenausschreibungen](/aktuelle-stellenausschreibungen)
* [Initiativbewerbung](/initiativbewerbung)
#### Werden Sie Teil unseres Teams

Initiativbewerbung
==================

#### Wenn Sie in unseren Stellenausschreibungen nicht den passenden Job gefunden haben, Sie aber genauso wie wir für Zahlen, Daten und Fakten brennen und uns kennenlernen möchten, schicken Sie uns gerne eine Initiativbewerbung.

#### 

#### Bitte füllen Sie das untenstehende Onlineformular aus und schreiben Sie uns kurz, wer Sie sind, wonach Sie suchen und was Sie von uns erwarten.

#### 

#### Nachdem wir Ihre Bewerbung erhalten haben, werden wir diese prüfen und uns zeitnah bei Ihnen melden.

#### **Ihre Ansprechpartnerin**

![](https://download.statistik-berlin-brandenburg.de/e6932197de8c8dd5/95cb0b2034e6/v/8e283cb43775/foto-christina-rambow.jpg)
#### Christina RambowTel. 0331 8173-1719[**bewerbung****@statistik-bbb.de**](mailto:bewerbung@statistik-bbb.de)

[Ab sofortInitiativbewerbung](/initiativbewerbung)[Alle offenen Stellen](/aktuelle-stellenausschreibungen)
