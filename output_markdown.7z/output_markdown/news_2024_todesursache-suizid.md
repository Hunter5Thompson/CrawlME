

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 09.09.2024

#### Zum Welttag der Suizidprävention

Die Fallzahlen steigen
----------------------

![iStock.com / mammuth](https://download.statistik-berlin-brandenburg.de/2f604837425dd414/d07c62579df7/v/ec955e84bf3b/bevoelkerung-todesfaelle-autumn-sunlight-in-the-cemetery-picture-id175381576.jpg "iStock.com / mammuth")

**Suizid, Freitod, Selbstmord oder auch vorsätzliche Selbstbeschädigung – es gibt viele Worte für eine Entscheidung, die bis heute in der Gesellschaft tabuisiert wird. Zum Welttag der Suizidprävention möchten wir für das Thema sensibilisieren und mit Zahlen der amtlichen Todesursachenstatistik einordnen. Fakt ist: Die Zahlen steigen seit 2017 wieder kontinuierlich an.**

**Menschen wählten 2022**  
**in Berlin den Freitod.**

**starben 2022 in Brandenburg**  
**durch vorsätzliche Selbstbeschädigung.**

Im Jahr 2022 nahmen sich in Berlin 297 Männer und 150 Frauen das Leben, das waren 12 Schicksale auf 100.000 Einwohnende. Trotzdem sind es fast 7 mal mehr Gestorbene als im selben Jahr durch Verkehrsunfälle umkamen (67 Fälle in der Todesursachenstatistik). In Brandenburg war die Zahl mit 275 Suiziden bei den Männern und 88 bei den Frauen insgesamt niedriger. Bezogen auf 100.000 der Bevölkerung lag der Wert mit 14,2 jedoch höher als in Berlin. Insgesamt nahmen sich Männer häufiger das Leben als Frauen. Ihr Anteil lag 2022 in Berlin bei 66,4 % und in Brandenburg sogar bei 75,7 % der Fälle.

Entgegen des Verdachts, die meisten Selbstmorde würden in der dunklen Jahreszeit passieren, zeigen die Zahlen für Brandenburg exemplarisch, dass es wohl keinen eindeutigen Zusammenhang gibt. 2020 wurden die meisten Fälle im Oktober, 2021 im August und 2022 im April und Juni registriert.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Am höchsten sind die Fallzahlen in beiden Ländern in den hohen Altersklassen ab 50 Jahre, wobei der Unterschied zu den unter 50-Jährigen in Brandenburg deutlicher ist. In Berlin sind die Fallzahlen gleichmäßiger über die Altersgruppen verteilt.

Bei den Berliner Männern fiel die Entscheidung zu diesem drastischen Schritt am häufigsten im Alter zwischen 40 bis unter 50 Jahren oder im hohen Alter zwischen 80 und 90 Jahren. In Brandenburg waren sie überwiegend zwischen 60 bis 70 Jahre oder 80 und 90 Jahre alt. Bei den Berlinerinnen nimmt die Fallzahl ab einem Alter von 60 Jahren merklich zu, bei den Brandenburgerinnen sind vor allem die 50- bis unter 60-Jährigen und ab 80-Jährigen betroffen.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Die Todesursachenstatistik gibt auch Aufschluss über die Art und Weise des Suizids. Die mit Abstand am häufigsten gewählte Methode ist die des Erhängens (Berlin: 139 Fälle; Brandenburg: 212 Fälle). In beiden Ländern setzten vor allem Männer ihrem Leben auf diesem Wege ein Ende. Bei den Berlinerinnen war die Selbstvergiftung mit 63 Gestorbenen die häufigste Todesursache bei Suizid.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
###### Sollten Sie Suizid-Gedanken hegen oder jemanden kennen, der Probleme hat, können Sie sich an die Telefonseelsorge wenden – Tag und Nacht, anonym und kostenlos: [www.telefonseelsorge.de](https://www.telefonseelsorge.de)

**Datenangebot**

Mehr Daten zu  Todesursachen in Berlin und Brandenburg stehen unter [www.statistik-berlin-brandenburg.de/todesursachen](/todesursachen) zur Verfügung.

### Kontakte

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Todesursachen](/search-results?q=tag%3ATodesursachen)[* Selbstmord](/search-results?q=tag%3ASelbstmord)[* Suizid](/search-results?q=tag%3ASuizid)
