

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Karriere](/karriere)
* [Charta der Vielfalt](/charta-der-vielfalt)
#### Für Diversity in der Arbeitswelt

Charta der Vielfalt
-------------------

Vielfalt ist ein wichtiger Bestandteil der **Unternehmenskultur** des Amtes für Statistik Berlin-Brandenburg. Mit der Unterzeichnung der Charta der Vielfalt im April 2017 bekräftigen wir diese freiwillige Selbstverpflichtung. 

Unser Ziel ist es, ein Arbeitsumfeld zu schaffen, das **frei von Vorurteilen** ist. Unsere Mitarbeiterinnen und Mitarbeiter erfahren unabhängig von Geschlecht, Nationalität, ethnischer Herkunft, Religion und Weltanschauung, Behinderung, Alter, sexueller Orientierung und Identität Wertschätzung.

[Download unterzeichnete Charta](https://download.statistik-berlin-brandenburg.de/1f8e96c82555b910/9070ad1fc1ac/charta-der-vielfalt-unterzeichnet.pdf)
### „Diversity als Chance“

Wir schaffen ein Klima von Akzeptanz, Respekt und Wertschätzung.

Wir beziehen die vielfältigen Fähigkeiten und Talente aller Mitarbeiterinnen und Mitarbeiter ein.  


Wir nutzen die Potenziale unserer Vielfalt.  


Wir akzeptieren die Vielfalt unserer Gesellschaft.  


Wir sind erfolgreich, denn wir erkennen und nutzen unsere vorhandene Vielfalt.  


### Vielfalt bedeutet für uns, dass ...

bei uns 327 Frauen und 115 Männer arbeiten.  


46 Kolleginnen und Kollegen schwerbehindert bzw. gleichgestellt sind.  


7 Frauen und Männer in Elternzeit/Mutterschutz sind.  


wir die Arbeit in Teilzeit ermöglichen.  


wir unterschiedlich alt sind, aus verschiedenen Ländern kommen und verschiedene Sprachen sprechen.  


#### **Das Amt für Statistik beim KAV Berlin Diversity Tag 2020**

In einer Gesprächsrunde tauschte sich der Kommunale Arbeitgeberverband e. V. Berlin mit ihren Mitglieder\*innen zum Berliner Landesantidiskriminierungsgesetz aus und präsentierte unter anderem mit Jörg Fidorroa, Vorstand Amt für Statistik Berlin-Brandenburg, was sich im Bereich Vielfalt bis jetzt getan hat. Hier geht’s zum Video:

[Zum Video KAV Berlin Diversity Tag](https://www.youtube.com/watch?v=bvjeJ4A9Ye4)
