

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Legehennenhaltung und Eiererzeugung in Brandenburg](/c-iii-8-vj)
* [C III 8 - vj](/archiv/c-iii-8-vj)

Archiv: Statistischer Bericht
=============================

#### Legehennenhaltung und Eiererzeugung (C III 8 - vj)


