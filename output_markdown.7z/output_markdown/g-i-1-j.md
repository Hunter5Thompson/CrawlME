

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Handel](/wirtschaft/wirtschaftbereiche/handel)
* [Umsatz und Beschäftigung im Handel in Berlin und Brandenburg – Messzahlen](/g-i-1-j)

Umsatz und Beschäftigung im Handel– Messzahlen
----------------------------------------------

#### 2016 bis 2023, jährlich

###### Dieser Bericht stellt die Ergebnisse der monatlichen Erhebungen im Handel über einen längeren Zeitraum dar. Dazu gehören der Einzelhandel, der Kraftfahrzeughandel einschließlich der -instandhaltung und -reparatur sowie der Großhandel einschließlich Handelsvermittlung.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7304ee24e1722dcd/32ae37fa6706/SB_G01-01-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/e3a2965656e304a3/59a704b25b88/SB_G01-01-00_2023j01_BE.pdf)

**KFZ-Handel und Großhandel mit Personalzuwachs gegenüber 2022**

Im Berliner Einzelhandel ist die Zahl der tätigen Personen seit 2016 um 10,7 % gestiegen. Von 2022 zu 2023 sank der Personalbestand um 0,1 %.

In den Bereichen des Kraftfahrzeughandels einschließlich Instandhaltung und Reparatur lag die Zahl der tätigen Personen um 14,2 % über dem Niveau von 2016. Im Vorjahresvergleich waren 2,6 % mehr Personen tätig.

Im Großhandel einschließlich Handelsvermittlung steig die Zahl der tätigen Personen seit 2016 um 16,6 %. Gegenüber dem Vorjahr waren hier 1,0 % mehr Personen tätig.

### Kontakt

#### Robby Trinks

Handel Konjunktur

#### Robby Trinks

Handel Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Einzelhandel meldet mehr Personal als 2022**

Im Brandenburger Einzelhandel ist der Zahl der tätigen Personen seit 2016 um 7,1 % gestiegen. Im Vergleich zum Vorjahr stieg die Zahl der tätigen Personen um 3,4 %.

In den Bereichen des Kraftfahrzeughandels einschließlich Instandhaltung und Reparatur wuchs der Personalbestand seit 2016 um 6,4 %. Im Vorjahresvergleich waren 0,1 % mehr Personen tätig.

Die Zahl der im Großhandel und in der Handelsvermittlung tätigen Personen stieg von 2016 bis 2023 um 8,4 %, wobei es im Vergleich zu 2022 zu einem Rückgang um 1,5 % kam.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/cf521bdf5389c62b/58d901c778f1/SB_G01-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/4fceaff59f81210d/f7a546ee70a5/SB_G01-01-00_2023j01_BB.pdf)
### Kontakt

#### Robby Trinks

Handel Konjunktur

#### Robby Trinks

Handel Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die monatlichen Erhebungen im Einzelhandel, in den Bereichen des Kraftfahrzeughandels, der -instandhaltung und -reparatur sowie im Großhandel (einschließlich Handelsvermittlung) liefern kurzfristige Informationen zur Beurteilung der konjunkturellen Entwicklung dieser Wirtschaftsbereiche. Erhoben werden der Nettoumsatz (ohne Umsatzsteuer) und die Zahl der tätigen Personen.

In diesem Bericht werden mehrere Jahre in monatlichen Messzahlen dargestellt.  
Alle Messzahlen des jeweils aktuellen Jahres sind vorläufig und werden monatlich rückwirkend durch nachträglich eingehende Meldungen und Korrekturen der in die Berichtskreise einbezogenen Unternehmen aktualisiert. Die Messzahlen werden in den Monatsberichten laufend fortgeschrieben.  


#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatsstatistik im Einzelhandel**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/234f59497e38e973/c2a607608b14/MD_45212_2023.pdf)[Archiv](/search-results?q=MD_45212&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-i-1-j)
