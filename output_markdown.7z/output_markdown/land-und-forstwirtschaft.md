

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)

Land- und Forstwirtschaft
=========================

Aus volkswirtschaftlicher Sicht ist die Landwirtschaft ein kleiner Sektor, umfasst aber etwa die Hälfte der deutschen Landfläche. Sie liefert einen Großteil an Lebensmitteln, trägt zur Ernährungssicherheit bei und hat Einfluss auf den Klimawandel und die Umwelt.

Amtliche Agrarstatistiken bilden die strukturellen und sozialen Anpassungen der Landwirtschaft ab und berücksichtigen die sich ändernden Rahmenbedingungen hinsichtlich des Marktes und der Agrarpolitik. Des Weiteren erfasst die Agrarstatistik Daten zur Produktion landwirtschaftlicher Produkte sowie zur Forstwirtschaft und Fischerei.

[![iStock-957868276.jpg](https://download.statistik-berlin-brandenburg.de/a1dedf4ec49a4102/f94185803a92/v/d306d1a273db/wirtschaft-wirtschaftsbereich-erdbeerernte.jpg "iStock-957868276.jpg")](/news/2024/erdbeersaison)**Fakten zur Erdbeerernte**[#### Werden heimische Früchte zum Luxusgut?](/news/2024/erdbeersaison)

Das beliebte Stängelgemüse aus Brandenburg: Zahlen zu Anbau, Ernte und Erträge von Spargel in unserer Region.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

#### Bodennutzung und Ernte

[Bodennutzung der landwirtschaftlichen Betriebe in Brandenburg – endgültiges Ergebnis, jährlich (CI1-j)](/c-i-1-j)[Bodennutzung der landwirtschaftlichen Betriebe in Brandenburg – vorläufiges Ergebnis, jährlich (CI2-j)](/c-i-2-j)[Gemüseerhebung in Brandenburg, jährlich (CI3-j)](/c-i-3-j)[Strauchbeerenerhebung in Brandenburg, jährlich (CI4-j)](/c-i-4-j)[Anbau von Blumen und Zierpflanzen zum Verkauf in Brandenburg, vierjährlich (CI6-4j)](/c-i-6-4j)[Baumschulenerhebung in Brandenburg, vierjährlich (CI7-4j)](/c-i-7-4j)[Baumobstanbau in Brandenburg, fünfjährlich (CI8-5j)](/c-i-8-5j)[Zwischenfruchtanbau in Brandenburg, dreijährlich (CI9-3j)](/c-i-9-3j)[Ernteberichterstattung über Feldfrüchte und Grünland in Brandenburg, monatlich (CII1-m)](/c-ii-1-m)[Ernteberichterstattung über Feldfrüchte und Grünland in Brandenburg – endgültiges Ergebnis, jährlich (CII2-j)](/c-ii-2-j)[Ernteberichterstattung über Baumobst in Brandenburg, jährlich (CII6-j)](/c-ii-6-j)[Besondere Ernte- und Qualitätsermittlung in Brandenburg, jährlich (CII7-j)](/c-ii-7-j)[Holzeinschlag in Brandenburg, jährlich (CV1-j)](/c-v-1-j)
#### Struktur der landwirtschaftlichen Betriebe

[Arbeitskräfte, Berufsbildung und Hofnachfolge in landwirtschaftlichen Betrieben in Brandenburg, drei- bis vierjährlich (CIV1-3j)](/c-iv-1-3j)[Betriebe mit ökologischem Landbau in Brandenburg, drei- bis vierjährlich (CIV2-3j)](/c-iv-2-3j)[Größenstruktur, sozialökonomische Betriebstypen sowie Rechtsformen der landwirtschaftlichen Betriebe in Brandenburg, drei- bis vierjährlich (CIV7-3j)](/c-iv-7-3j)[Eigentums- und Pachtverhältnisse der landwirtschaftlichen Betriebe in Brandenburg, drei- bis vierjährlich (CIV8-3j)](/c-iv-8-3j)[Betriebswirtschaftliche Ausrichtung der landwirtschaftlichen Betriebe in Brandenburg, drei- bis vierjährlich (CIV9-3j)](/c-iv-9-3j)[Ausgewählte Ergebnisse der Landwirtschaftszählung in Berlin, zehnjährlich (CIV10-u)](/c-iv-10-u)[Landwirtschaftliche Betriebe mit Gartenbau in Brandenburg, unregelmäßig (CIV13-u)](/c-iv-13-u)[Ausgewählte Ergebnisse der Agrarstrukturerhebung in Berlin, drei- bis vierjährlich (CIV14-u)](/c-iv-14-u)
#### Viehbestände und tierische Erzeugung

[Viehbestände in Brandenburg – Erhebung über Rinder, Schweine, Schafe, Ziegen und Geflügel, dreijährlich (CIII1-3j)](/c-iii-1-3j)[Viehbestände in Brandenburg am 3. Mai 2023 – Schweine, jährlich (CIII2-j)](/c-iii-2-j)[Viehbestände in Brandenburg am 3. November 2023 – Schweine, jährlich (CIII3-j)](/c-iii-3-j)[Viehbestände in Brandenburg nach Größen und Größenklassen der Tierhaltung und Flächenausstattung, dreijährlich (CIII4-3j)](/c-iii-4-3j)[Schlachtungen und Fleischerzeugung in Brandenburg, monatlich (CIII6-hj)](/c-iii-6-hj)[Legehennenhaltung und Fleischerzeugung in Brandenburg, vierteljährlich (CIII8-vj)](/c-iii-8-vj)[Rinder in Berlin und Brandenburg, halbjährlich (CIII9-hj)](/c-iii-9-hj)[Viehbestände in Brandenburg am 3. November 2022 – Schafe, jährlich (CIII10-j)](/c-iii-10-j)[Erzeugung in Aquakulturbetrieben in Brandenburg, jährlich (CIII11-j)](/c-iii-11-j)[Wirtschaftsdünger, Stall- und Weidehaltung in Brandenburg, unregelmäßig (CIV12-u)](/c-iv-12-u)

Zeitreihen
----------

BodennutzungBetriebsstrukturTierische Erzeugnisse**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Bodennutzung

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/5e1519c5b644d70f/9c2d716637b0/landwirtschaft-lange-reihe-bodennutzung.xlsx)
#### Struktur

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/44c1fd08cf02d45d/1e7888f3b292/StrukturLandwirtschaft_2023.xlsx)
#### Tierische Erzeugnisse

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/6dc518613a1f56d3/330e38ceb5a9/landwirtschaft-lange-reihe-tiere.xlsx)

Basisdaten
----------

BerlinBrandenburg

Regionaldaten
-------------

###### Landkreise und kreisfreie Städte 2023

#### Bodennutzung in Brandenburg in 1 000 ha

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Landkreise und kreisfreie Städte am 3. November 2023

#### Rinder in Brandenburg

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämter des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/land-und-forstwirtschaft)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1712218345838&code=41#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Regina Kurz

Ernte- und Weinstatistiken

#### Regina Kurz

Ernte- und Weinstatistiken

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Julia Wienke

Betriebsregister Landwirtschaft

#### Julia Wienke

Betriebsregister Landwirtschaft

* [0331 8173-3045](tel:0331 8173-3045)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-1213727367.jpg](https://download.statistik-berlin-brandenburg.de/8c43b2d7bc814cc3/3e5ce1b6bb13/v/4660157d52dc/landwirtschaft-rinder.jpg "iStock-1213727367.jpg")](/c-iii-9-hj)**3. November 2024, halbjährlich, C III 9 - hj**[#### Rinder in Berlin und Brandenburg](/c-iii-9-hj)

Die Erhebung informiert über die Anzahl der Rinder (einschließlich Büffel/Bisons), gegliedert nach Alter, Geschlecht, Nutzungszweck und Rasse.

[![iStock-500003996.jpg](https://download.statistik-berlin-brandenburg.de/a3673719d2d0542c/000daad3a651/v/cca1b725c6c0/wirtschaft-wirtschaftsbereiche-schweine.jpg "iStock-500003996.jpg")](/176-2024)**Schweinebestand in Brandenburg am 3. November 2024**[#### Leichte Erholung des Bestandes](/176-2024)

Nach dem vorläufigen Ergebnis der Erhebung der Schweinebestände zum 3. November 2024 hielten die Brandenburger Betriebe 556.400 Schweine....

[![©Mira - stock.adobe.com](https://download.statistik-berlin-brandenburg.de/69663412bc126f18/8f20586116ad/v/4d1251f0ed9e/wirtschaft-landwirtschaft-forstwirtschaft-adobestock-324821388.jpeg "©Mira - stock.adobe.com")](/177-2024)**Rinderbestand in Brandenburg am 3. November 2024**[#### Zahl der Rinder auf historischem Tiefststand](/177-2024)

Am 3. November 2024 gab es in Brandenburg 417.500 Rinder. Das waren 3,4 % weniger als im Mai dieses Jahres....

[Zu unseren News](/news)

[* Ernte](/search-results?q=tag%3AErnte)[* Bodennutzung](/search-results?q=tag%3ABodennutzung)[* Weinbestand](/search-results?q=tag%3AWeinbestand)[* Erntemenge](/search-results?q=tag%3AErntemenge)[* Viehbestand](/search-results?q=tag%3AViehbestand)[* Aquakultur](/search-results?q=tag%3AAquakultur)[* Fischerei](/search-results?q=tag%3AFischerei)[* Agrar](/search-results?q=tag%3AAgrar)[* Einhufer](/search-results?q=tag%3AEinhufer)[* Familienarbeitskräfte](/search-results?q=tag%3AFamilienarbeitskräfte)
