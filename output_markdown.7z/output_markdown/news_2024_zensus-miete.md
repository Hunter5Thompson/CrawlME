

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 21.08.2024

#### Zensus 2022 in Berlin und Brandenburg

Altbau- und Neubauwohnungen am teuersten
----------------------------------------

![](https://download.statistik-berlin-brandenburg.de/f5ba007a5ba3be71/bf2f04febdd8/v/b06aeb82d708/zensus-nettokaltmiete.png)

**Der Zensus 2022 zeigt: Sowohl in Berlin als auch in Brandenburg sind Altbau- und Neubauwohnungen die teuersten Mietobjekte. Besonders im Berliner Umland klettern die Preise auf ein Niveau, das dem der Hauptstadt nahekommt. Gleichzeitig ergibt sich ein Zusammenhang zwischen Baujahr und Mietpreis, mit stark schwankenden Mieten je nach Baualtersklasse.**

Im Zensus 2022 wurden erstmals die sogenannten Bestandsmieten erfasst. Sie spiegeln die durchschnittlichen Nettokaltmieten aller Wohnungen in Deutschland am Stichtag, dem 15. Mai 2022, wider. Da auch ältere Mietverträge berücksichtigt wurden, liegen diese Mieten oft deutlich unter den aktuell auf dem Markt angebotenen Preisen.

EUR/m²
------

**beträgt die durchschnittliche Nettokaltmiete**  
**in Berlin.**

EUR/m²
------

**beträgt die durchschnittliche Nettokaltmiete**  
**in Brandenburg.**

In Berlin liegt die durchschnittliche Bestandsmiete bei 7,67 EUR pro Quadratmeter, während sie in Brandenburg 6,21 EUR pro Quadratmeter beträgt. Zum Vergleich: Im zweiten Quartal 2022 kosteten aktuell angebotene Wohnungen in Berlin im Durchschnitt 10,50 EUR pro Quadratmeter und in Brandenburg 7,50 EUR.

#### Hohe Mietpreise auch außerhalb Berlins

Die Mietpreisentwicklung in Brandenburg wird stark von der Nähe zu Berlin und dem Baualter der Gebäude beeinflusst. Im direkten Berliner Umland, insbesondere in Neubauten nach 2010, steigen die Mietpreise teilweise auf ein ähnliches Niveau wie in der Hauptstadt. Hier werden Wohnungen im Schnitt für 10,84 EUR pro Quadratmeter vermietet, was beispielsweise über den Preisen in Spandau für Gebäude mit ähnlichem Baualter liegt. In den weiter von Berlin entfernten Gemeinden der [Hauptstadtregion](/meine-region) sind die Bestandsmieten zwar niedriger, zeigen aber eine leichte U-Form, bei der ältere und sehr neue Gebäude teurer vermietet werden als solche aus den mittleren Baualtersklassen.

 Stichtag: 15.05.2022**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022
#### **Höchste Kaltmieten Brandenburgs im Berliner Umland**

In den Brandenburger Gemeinden steigen die Preise mit zunehmender Nähe zu Berlin. Das Berliner Umland verzeichnet deutlich höhere Nettokaltmieten als die weiter entfernten Gemeinden. Die niedrigste Miete wurde in Drehnow, einer kleinen Gemeinde im Landkreis Spree-Neiße, mit nur 1,91 EUR pro Quadratmeter festgestellt. Im Gegensatz dazu liegen die Mieten in Schönefeld im Landkreis Dahme-Spreewald bei durchschnittlich 9,28 EUR pro Quadratmeter – das ist fast das Fünffache.

###### Gemeinden in Brandenburg am 15.05.2022

#### Durchschnittliche Nettokaltmiete pro Quadratmeter

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Ein weiterer Zusammenhang zeigt sich bei der Betrachtung der Baualtersklassen. Wohnungen in Gebäuden aus den 1950er bis 1980er Jahren sind im Durchschnitt etwas günstiger als Wohnungen in Altbauten aus der Zeit vor 1950 oder Neubauten nach 2010. Kleinstädte wie Rathenow oder Senftenberg zeigen ein weniger starkes Muster. In Städten wie Angermünde und Schönefeld hingegen gibt es einen fast linearen Zusammenhang: Je neuer das Gebäude, desto höher die Miete. In Schönefeld haben die Mieten bereits Berliner Niveau erreicht.

In größeren Städten Brandenburgs wie Cottbus, Bernau bei Berlin und Potsdam ähnelt die Mietpreisverteilung ebenfalls einer U-Form. Hier sind Wohnungen in Gebäuden aus der Zeit vor 1950 teurer als solche aus den mittleren Baualtersklassen, während Neubauten die höchsten Mieten aufweisen. In den Berliner Bezirken verhält es sich ähnlich.

 Stichtag: 15.05.2022**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022
#### **Höchste Nettokaltmieten Berlins in Neubauwohnungen**

In Berliner Bezirken sind die Mieten für Wohnungen in Gebäuden, die nach 2010 errichtet wurden, deutlich höher als in älteren Baualtersklassen. Der Höchstwert wird in Charlottenburg-Wilmersdorf erreicht, wo Wohnungen aus dieser Baualtersklasse durchschnittlich 16,26 EUR pro Quadratmeter kosten. Der Berliner Durchschnitt liegt in dieser Kategorie bei 12,46 EUR pro Quadratmeter.

Wohnungen in Altbauten von vor 1950, sind ebenfalls etwas teurer als solche aus den 1950er bis 1980er Jahren. Erst ab den 1990er Jahren steigen die Mieten wieder an. Für einige Bezirke sowie für Berlin insgesamt ergibt sich die U-förmige Verteilung: Im Bezirk Pankow beispielsweise liegen die Mieten für mittelalte Gebäude (1970 bis 1989) etwa 2 EUR pro Quadratmeter unter denen für Altbauten.

 Stichtag: 15.05.2022**Quelle:** Amt für Statistik Berlin-Brandenburg, Zensus 2022

Falls Sie an Auswertungen des Zensus 2022 zu anderen Merkmalen oder einer anderen räumlichen Ebene interessiert sind, kontaktieren Sie uns gern unter [info@statistik-bbb.de](mailto:info@statistik-bbb.de). Eine Übersicht der Merkmale finden Sie in der Zensusdatenbank.

#### **Datenangebot**

###### Unser Zensus-Datenangebot

Mehr Daten zum Zensus 2022 in Berlin und Brandenburg gibt’s hier:   
[www.statistik-berlin-brandenburg.de/zensus22](/zensus22)

###### Zensusdatenbank

In der [Zensusdatenbank](https://ergebnisse.zensus2022.de/datenbank/online/) können Daten für Bund, Länder, Kreise, Gemeinden und Bezirke (Berlin, Hamburg) abgerufen und mit anderen Merkmalen kombiniert ausgewertet werden. Für die Weiterverarbeitung stehen verschiedene Ausgabeformate zur Verfügung. Die Zensusdatenbank enthält den **Merkmalskatalog** und kann auch mit Programmiersprachen direkt angesprochen werden.

###### Zensus-Atlas

Der [Zensus-Atlas](https://atlas.zensus2022.de/) umfasst Ergebnisse auf Basis von Gitterzellen (10 km, 1 km und 100 m). Für die ersten vier Karten stehen Begleittabellen zum Download zur Verfügung. Die Themen sind Bevölkerung, Heizungsart, Energieträger der Heizung und Nettokaltmiete je Quadratmeter. Weitere Karten und Datensätze folgen.

###### Offizielle Website Zensus 2022

Auf der [Zensus 2022 Website](http://www.zensus2022.de) werden [Regionaltabellen](https://www.zensus2022.de/DE/Ergebnisse-des-Zensus/02-veroeffentlichung.html?nn=270470 "Veröffentlichung") zum Download bereitstellt. Sie enthalten Daten für Bund, Bundesländer, Regierungsbezirke, Stadtkreise/kreisfreie Städte/Landkreise, Gemeindeverbände sowie Gemeinden. Außerdem stehen [Podcasts, Videos und Animationen](https://www.zensus2022.de/DE/Mediathek/_inhalt.html "Mediathek")mit Hintergrundinformationen zur Verfügung.

### Kontakte

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Zensus](/search-results?q=tag%3AZensus)[* Zensus 2022](/search-results?q=tag%3AZensus 2022)[* Bestandsmiete](/search-results?q=tag%3ABestandsmiete)[* Mietpreise](/search-results?q=tag%3AMietpreise)
