

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Service](/service)
* [Informationsservice](/service/informationsservice)

Informationsservice
===================

Sie sind auf unserer Webseite nicht fündig geworden? Ihre Suche in den Datenbanken führte nicht zu den Daten, die Sie benötigen? Unser Informationsservice unterstützt Sie gerne bei der Recherche von Daten, bestellt maßgeschneiderte Produkte und Serviceleistungen für Sie.

[Alle Services
#### Übersicht](/service)[Individuelle Auskünfte
#### Informationsservice](/service/informationsservice)[Karten und Geometrien
#### Geoservice](/geoservice)[Befragungen & Analysen
#### Befragungsservice](/service/befragungsservice)[Amtliche Mikrodaten
#### Forschungsdatenzentrum](https://www.forschungsdatenzentrum.de/de)[Wissenschaftliche Spezialbibliothek
#### Unsere Bibliothek](/service#bibliothek)![](https://download.statistik-berlin-brandenburg.de/7f628cf7716adfc2/edc2c7dbc79d/schmuckbild-schnelligkeit.svg)![](https://download.statistik-berlin-brandenburg.de/553052b60e41de54/6c4f838a669e/schmuckbild-kreisdiagramm.svg)![](https://download.statistik-berlin-brandenburg.de/f3f40b5153aeb95c/1796c293204a/schmuckbild-euro.svg)

Schnell, genau, günstig
-----------------------

Der Informationsservice prüft Ihre per Kontaktformular,E-Mail oder telefonisch formulierten Datenwünsche kurzfristig. Wir beraten Sie individuell, suchen ggf. nach Alternativen oder vermitteln weiter an andere Informationsquellen.

Die Beratung ist kostenfrei. Ist der Aufwand für die Datenzusammenstellung umfangreicher, erhalten Sie vorab einen Kostenvoranschlag.

Leistungsumfang
---------------

**Unser Angebot umfasst u. a. individuelle Auswertungen und Analysen statistischer Ergebnisse für die  Länder Berlin und Brandenburg.**

Darüber hinaus übernehmen wir für Sie die Bereitstellung von Daten mehrerer oder aller Bundesländer. Diese sogenannten länderübergreifenden Koordinierungen organisieren wir für Sie, wenn Ihr Unternehmen bzw. Sie Ihren Wohnsitz in Berlin oder Brandenburg haben. Haben Sie Ihren Sitz in einem anderen Land, so vermitteln wir Ihr Anliegen an das regional zuständige Statistische Landesamt.

Die Kosten für die Serviceleistungen richten sich nach dem jeweiligen Arbeitsaufwand und werden bei der Auftragsklärung ermittelt. Außerhalb von hoheitlichen Aufgaben unterliegen die Dienstleistungen des Amtes für Statistik Berlin-Brandenburg der Mehrwertsteuerpflicht.

[Preisliste (PDF)](https://download.statistik-berlin-brandenburg.de/d291242a2c1a9f32/81ace2c39c51/entgeltliste.pdf)[AGB (PDF)](https://download.statistik-berlin-brandenburg.de/017537fff68665b7/8d3eca304ae5/allgemeine-geschaeftsbedingungen.pdf)
### Kostenübersicht

| kostenfrei | kostenpflichtig |  |
| --- | --- | --- |
| Kundenberatung | Beratung zu umfangreichen Berichten und Analysen unter Beteiligung von Expertinnen und Experten |  |
| Anfragen, die mit einem Aufwand unter 30 Minuten bearbeitet werden können | Anfragen, die mit einem Aufwand über 30 Minuten bearbeitet werden können |  |
| Unterstützung beim Auffinden von Daten auf unseren Internetseiten | Zusammenstellung von Daten aus verschiedenen Quellen mit einem Aufwand über 30 Minuten |  |
| Unterstützung beim Auffinden von Veröffentlichungen auf unseren Internetseiten | Bestellung kostenpflichtiger Veröffentlichungen |  |
|  |  |

Kontakt
-------

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)

**Der Informationsservice ist telefonisch für Sie erreichbar:**  
  
Montag bis Donnerstag 8.00 bis 15.30 Uhr,  
Freitag 8.00 Uhr bis 13.30 Uhr.

Außerhalb dieser Sprechzeiten senden Sie uns bitte eine E-Mail.

#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Wie geht es weiter?
-------------------

1
-

Ihre Anfrage ist   
**abgesendet**:

Ihre Anfrage wird von uns gelesen. Sie wird entweder in den nächsten Stunden direkt kostenfrei beantwortet, wir kontaktieren Sie mit Fragen oder wir geben sie an unsere Expertinnen und Experten weiter.

2
-

Informationsservice   
**kontaktiert** Sie:

Wir senden Ihnen ein kostenfreies oder kostenpflichtiges Angebot (Kostenvoranschlag) per E-Mail.  
  
  
  
  


3
-

Sie **beauftragen**   
uns:

Sie bestätigen uns das gewünschte Angebot, im Falle von Kostenpflicht mit Bestätigung des Kostenvoranschlages und Rechnungsadresse.  
  
  


4
-

Informationsservice   
**kontaktiert** Sie:

Wir senden Ihnen die gewünschten Daten per E-Mail. Bei kostenpflichtigen Angeboten erhalten Sie die Rechnung auf dem Postweg.  
  
  


### Sie müssen Daten melden? Hier geht's zur Hilfe.

[Daten melden](/daten-melden)
