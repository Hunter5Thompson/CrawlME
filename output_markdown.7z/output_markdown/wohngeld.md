

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Wohngeld](/wohngeld)

Wohngeld
========

Wohngeld ist ein von Bund und Ländern je zur Hälfte getragener Zuschuss zu den Wohnkosten. Dieser wird – gemäß den Vorschriften des Wohngeldgesetzes – einkommensschwachen Haushalten gewährt, damit diese die Wohnkosten für angemessenen und familiengerechten Wohnraum tragen können.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Wohngeld in Berlin und Brandenburg, jährlich (KVII1-j)](/k-vii-1-j)

Zeitreihen
----------

WohngeldWohngeldanspruch**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/fa577c1ea86c2894/9a7bb506644c/wohngeld-zeitreihe-2023.xlsx)[Lange Reihen (.XLSX)](https://download.statistik-berlin-brandenburg.de/c69bcb29e369631b/087273e5140b/wohngeld-lange-reihe-2023.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Berliner Bezirke

#### Wohngeldhaushalte 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte

#### Wohngeldhaushalte 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1715927459423&code=22311#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / ebenart](https://download.statistik-berlin-brandenburg.de/cca481be0c10bcd7/4bef0acff984/v/060d05be4693/autumn-mood-in-a-berlin-prefab-panel-housing-estate-picture-id1056705080.jpg "iStock.com / ebenart")](/181-2022)**Wohngeld 2021** [#### 3 Prozent weniger Wohngeldhaushalte in der Hauptstadtregion](/181-2022)

Pressemitteilung Nr. 181 Am Jahresende 2021 bezogen in der Hauptstadtregion rund 47 000 Haushalte Wohngeld, rund 24 500 Haushalte in Berlin und rund 22 500 in Brandenburg. Wohngeld ist ein von Bund...

[![iStock.com / hanohiki](https://download.statistik-berlin-brandenburg.de/b29702c3d0d2d6a7/661284573220/v/39622a003baa/gesellschaft-soziales-plattenbau-building-facade-picture-id645531666.jpg "iStock.com / hanohiki")](/194-2021)**Wohngeldstatistik 2020**[#### Erheblich mehr Wohngeldhaushalte in der Hauptstadtregion](/194-2021)

Pressemitteilung Nr. 194 Ende 2020 bezogen in der Hauptstadtregion über 48 500 Haushalte Wohngeld. Wie das Amt für Statistik Berlin-Brandenburg mitteilt, bedeutet das für Berlin im Vergleich zum...

[![iStock.com / ebenart](https://download.statistik-berlin-brandenburg.de/cca481be0c10bcd7/4bef0acff984/v/060d05be4693/autumn-mood-in-a-berlin-prefab-panel-housing-estate-picture-id1056705080.jpg "iStock.com / ebenart")](/194-2020)[#### Weniger Wohngeldhaushalte in Berlin und Brandenburg](/194-2020)

Pressemitteilung Nr. 194 Ende 2019 bezogen in der Hauptstadtregion über 41 000 Haushalte Wohngeld. Wie das Amt für Statistik Berlin-Brandenburg mitteilt, bedeutet das für Berlin im Vergleich zum...

[Zu unseren News](/news)

[* Wohngeld](/search-results?q=tag%3AWohngeld)[* Mietzuschuss](/search-results?q=tag%3AMietzuschuss)[* Wohngeldanspruch](/search-results?q=tag%3AWohngeldanspruch)[* Wohngeldhaushalte](/search-results?q=tag%3AWohngeldhaushalte)[* Mietenstufen](/search-results?q=tag%3AMietenstufen)[* Wohngeldempfänger](/search-results?q=tag%3AWohngeldempfänger)[* Lastenzuschuss](/search-results?q=tag%3ALastenzuschuss)
