

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Preise](/wirtschaft/preise)
* [Bodenmarkt](/bodenmarkt)
* [Kaufwerte landwirtschaftlicher Grundstücke in Brandenburg](/m-i-7-j)

Kaufwerte landwirtschaftlicher Grundstücke in Brandenburg
---------------------------------------------------------

#### 2023, jährlich

###### Die Bodenmarktstatistik gibt einen Überblick über den Grundstücksmarkt in Brandenburg. Es handelt sich dabei um keine Preisstatistik im eigentlichen Sinne, sondern vielmehr um eine „Grundstückswechselstatistik“, da durchschnittliche Kaufwerte betrachtet werden und nicht die Preisentwicklung von Grundstücken gleicher Art und Güte im Vordergrund steht.

BrandenburgMethodik
### Brandenburg

**Mehr Verkäufe zum Verkehrswert**

Im Jahr 2023 wurden in Brandenburg insgesamt 2.525 Verkäufe landwirtschaftlicher Grundstücke erfasst. Das waren 262 Grundstücke mehr als im Jahr zuvor.

Damit wechselten Grundstücke im Wert von 120 Millionen EUR in Brandenburg ihren Eigentümer bzw. ihre Eigentümerin. 2022 lag der Wert noch bei 111 Millionen EUR. Der Kaufwert je Hektar lag im Jahr 2023 bei 12.491 EUR .

  


###### 2023 in Brandenburgs Landkreisen und kreisfreien Städten

#### Verkäufe landwirtschaftlicher Grundstücke

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a22d6c7a5891d64d/44d16a49b820/SB_M01-07-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/4355fb21dc37d825/9e6d650e2f0e/SB_M01-07-00_2023j01_BB.pdf)
### Kontakt

#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Stefanie Dobs

Baupreise

#### Stefanie Dobs

Baupreise

* [0331 8173-3523](tel:0331 8173-3523)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik der Kaufwerte für landwirtschaftliche Grundstücke umfasst alle Transaktionen von landwirtschaftlichen Grundstücken in der Berichtsperiode deren landwirtschaftlich genutzte Fläche eine Größe von mindestens 0,1 ha (= 10 Ar = 1000 m²) aufweist. Ebenfalls erfasst werden Verkäufe von gewerblichen Betriebsgrundstücken im Sinne des § 99 Abs. 1 Nr. 2 des Bewertungsgesetzes (BewG).

Kauffälle, die außer landwirtschaftlich genutzten Flächen auch Flächen anderer Nutzungen bzw. Nutzungsteile oder anderer Vermögensarten umfassen, werden nur dann in die Statistik einbezogen, wenn davon ausgegangen werden kann, dass vom Wert der Gegenleistung mehr als 90 % auf die landwirtschaftliche Nutzung entfallen.

Es werden Preise und Merkmale der verkauften Grundstücke (Lage, Angaben über die Gesamtfläche und darunter Flächen des Ackerlands, des Dauergrünlands sowie sonstiger landwirtschaftlich genutzter Fläche, Ertragsmesszahl der landwirtschaftlich genutzten Fläche), des Kaufaktes (ungewöhnlicher Geschäftsverkehr), Eigenschaften der Erwerber bzw. Veräußerer (Rechtsform, Landwirt/Nicht-Landwirt, familiäres Verhältnis) sowie zur zukünftigen landwirtschaftlichen Nutzung des Grundstücks erhoben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Kaufwerte für landwirtschaftliche Grundstücke**  
Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/d82c537bf570620d/fcc7da597eee/MD_61521_2021.pdf)[Archiv](/search-results?q=MD_61521&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/m-i-7-j)
