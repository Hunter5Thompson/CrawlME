

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Insolvenzen](/insolvenzen)
* [Insolvenzen in Berlin und Brandenburg](/d-iii-2-j)

Insolvenzen
-----------

#### 2023, jährlich

###### Die Insolvenzstatistik liefert jährliche Informationen über die Anzahl der eröffneten, mangels Masse oder mit gerichtlichem Schuldenbereinigungsplan beendeten Insolvenzverfahren sowie weitere Erhebungsmerkmale (z. B. Höhe der voraussichtlichen Forderungen, Rechtsform und Wirtschaftszweig) von Unternehmen, Verbrauchern, ehemals selbstständig Tätigen und anderen natürlichen Personen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/6dedcc71972386b7/359b8acfb7a6/SB_D03-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f42e671aa10f7ad8/1ec7c311bda5/SB_D03-02-00_2023j01_BE.pdf)

**Anstieg der Unternehmensinsolvenzen in Berlin**

1.647 Insolvenzverfahren gegen Unternehmen wurden im Jahr 2023 gemeldet. Das waren 395 Verfahren mehr als im Jahr 2022. Die voraussichtlichen Forderungen stiegen um 129,9 % auf 1,7 Mrd. EUR (2022: 754,1 Mill. EUR).

3.055 Verbraucher und 1.157 ehemals selbständig Tätige beantragten im Jahr 2023 ein Insolvenzverfahren. Das waren 196 Verfahren weniger bzw. 209 Verfahren mehr als im Vorjahr.

**Sonderregelungen in den Jahren 2020 und 2021**

Beim Zeitvergleich der Insolvenzzahlen ist zu beachten, dass das Insolvenzgeschehen in den Jahren 2020 und 2021 von Sonderregelungen und neuen gesetzlichen Regelungen geprägt war. U. a. ist die Insolvenzantragspflicht für überschuldete Unternehmen von Anfang März 2020 bis Mai 2021 infolge der Corona-Pandemie ganz oder teilweise ausgesetzt worden.

### Kontakt

#### Kerstin Bortz-Franzik

Insolvenzen

#### Kerstin Bortz-Franzik

Insolvenzen

* [0331 8173-1341](tel:0331 8173-1341)
* [insolvenzen@statistik-bbb.de](mailto:insolvenzen@statistik-bbb.de)
#### Kerstin Börner

INSOLVENZEN

#### Kerstin Börner

INSOLVENZEN

* [0331 8173-1349](tel:0331 8173-1349)
* [insolvenzen@statistik-bbb.de](mailto:insolvenzen@statistik-bbb.de )
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Unternehmensinsolvenzen sinken in Brandenburg**

Im Jahr 2023 wurden in Brandenburg 346 Insolvenzverfahren gegen Unternehmen gemeldet. Ein Rückgang gegenüber dem Vorjahr um -3,1 %. Die voraussichtlichen Forderungen sanken von 261,0 Mill. EUR auf 196,9 Mill. EUR.

2.321 Verbraucher und 648 ehemals selbständig Tätige beantragten im Jahr 2023 ein Insolvenzverfahren. Das waren 13 Verfahren bzw. 46 Verfahren weniger als im Vorjahr.

**Sonderregelungen in den Jahren 2020 und 2021**

Beim Zeitvergleich der Insolvenzzahlen ist zu beachten, dass das Insolvenzgeschehen in den Jahren 2020 und 2021 von Sonderregelungen und neuen gesetzlichen Regelungen geprägt war. U. a. ist die Insolvenzantragspflicht für überschuldete Unternehmen von Anfang März 2020 bis Mai 2021 infolge der Corona-Pandemie ganz oder teilweise ausgesetzt worden.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e8e30ce1e03bfbcb/89444f36d1f4/SB_D03-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7560cb1fed206a1e/88b788d0c5d3/SB_D03-02-00_2023j01_BB.pdf)
### Kontakt

#### Kerstin Bortz-Franzik

Insolvenzen

#### Kerstin Bortz-Franzik

Insolvenzen

* [0331 8173-1341](tel:0331 8173-1341)
* [insolvenzen@statistik-bbb.de](mailto:insolvenzen@statistik-bbb.de)
#### Kerstin Börner

INSOLVENZEN

#### Kerstin Börner

INSOLVENZEN

* [0331 8173-1349](tel:0331 8173-1349)
* [insolvenzen@statistik-bbb.de](mailto:insolvenzen@statistik-bbb.de )
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Datenlieferung erfolgt durch die Brandenburger und Berliner Amtsgerichte größtenteils elektronisch.

Zur Übermittlung der Daten nutzen die Insolvenzgerichte das Onlinemeldeverfahren IDEV (Internet-Daten-Erhebung im Verbund) bzw. den postalischen Weg.

In der Insolvenzstatistik werden nur Fälle ausgewiesen, bei denen ein gerichtlicher Beschluss über die Eröffnung, die Abweisung mangels Masse oder die Bestätigung eines Schuldenbereinigungsplans erfolgte. Fälle, die bei Gericht eingehen, aber aus unterschiedlichen Gründen wieder zurückgenommen werden, sind nicht berücksichtigt. Ebenso werden mehrere Insolvenzanträge zu einem Schuldner in der Regel zu einem Hauptaktenzeichen zusammengefasst und an die Statistik übermittelt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik über beantragte Insolvenzverfahren**  
Metadaten 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/9fdff31f7d57f1b8/d78b03b48f98/MD_52411_2021.pdf)[Archiv](/search-results?q=MD_52411&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/d-iii-2-j)
