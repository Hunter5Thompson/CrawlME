

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Bodennutzung der landwirtschaftlichen Betriebe in Brandenburg – endgültiges Ergebnis](/c-i-1-j)

Bodennutzung der landwirtschaftlichen Betriebe in Brandenburg – endgültiges Ergebnis
------------------------------------------------------------------------------------

#### 2024, jährlich

###### Die Ergebnisse dienen der Erfolgskontrolle von Maßnahmen in der europäischen und nationalen Agrar-, Markt- und Preispolitik sowie der Politik der Entwicklung der ländlichen Räume, der Umwelt- und Klimapolitik und der Vorausschätzung der Agrarausgaben.

BrandenburgMethodik
### Brandenburg

**Die wichtigsten Getreidearten sind Roggen, Weizen** **und Gerste**

Auf der knapp eine Million Hektar großen Ackerfläche Brandenburgs wächst zu 48 % Getreide. Die bestimmenden Getreidearten sind Weizen, Roggen und Gerste. 27 % der auf dem Ackerland wachsenden Kulturen, wie z. B. Silomais, werden zu Futter- und Energiezwecken genutzt. Die Ernte der Ölfrüchte erfolgt auf 12 % des Ackerlandes. Hier dominiert wie in allen anderen Bundesländern der Winterraps. Des Weiteren hat Brandenburg Deutschlands größte Anbaufläche für Sonnenblumen. Hülsenfrüchte sowie Hackfrüchte wachsen auf 3 % bzw. 2 % des Ackerlandes. Erbsen und Süßlupinen sowie Kartoffeln und Zuckerrüben sind hier die wichtigsten Kulturen. Die restlichen Flächen sind mit Gartenbauerzeugnissen bestellt bzw. liegen brach.

Das Tabellenprogramm im Bericht umfasst die Nutzung der Flächen nach Hauptnutzungsarten und Nutzungszweck, Kulturarten, Pflanzengruppen, Pflanzenarten und Kulturformen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/eb087e9d8007e962/87c4bf807ad2/SB_C01-01-00_2024j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7f9361a2da19542f/fe265b75a3d7/SB_C01-01-00_2024j01_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Bodennutzungshaupterhebung ist eine dezentrale Bundesstatistik mit einem Stichprobenumfang von höchstens 80 000 Betrieben. 2010, 2016 und 2020 erfolgte sie als Vollerhebung bei allen landwirtschaftlichen Betrieben.

Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht. Die Statistischen Ämter der Länder haben gemäß [§ 93 Absatz 5 AgrStatG](https://www.gesetze-im-internet.de/agrstatg/__93.html) zudem die Möglichkeit, Verwaltungsdaten (InVeKoS = Integriertes Verwaltungs- und Kontrollsystem) für statistische Zwecke zu nutzen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Bodennutzungshaupterhebung**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/05723b6559976fb1/704419dd5b82/MD_41121_2023.pdf)[Archiv](/search-results?q=MD_41271&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-1-j)
