

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 09.07.2024

#### Tourismusatlas mit aktuellen Daten

Die Tourismusbranche ist wieder im Aufwärtstrend
------------------------------------------------

![Ausschnitt Berlin Brandenburg Tourismusatlas](https://download.statistik-berlin-brandenburg.de/4bda3785af78ba7b/9a6e6e08badc/v/aeb7b16d6157/tourismusatatlas-2023.jpg "Ausschnitt Berlin Brandenburg Tourismusatlas")

**Im Jahr 2023 lag die Zahl der Übernachtungen in deutschen Beherbergungsbetrieben mit 487,1 Millionen um 8,1 % über dem Vorjahr und damit fast wieder auf dem Rekordniveau des Jahres 2019. Die Übernachtungen von Gästen aus dem Inland erreichten dabei mit 406,2 Millionen sogar einen neuen Höchstwert.****Der aktualisierte Tourismusatlas bietet einen detaillierten Überblick über diese und andere Entwicklungen.**

Der Inlandstourismus war mit 406,2 Millionen Gästen sehr stark. Aber auch die Übernachtungszahl ausländischer Gäste war mit 80,9 Millionen um 18,8 % höher als im Jahr 2022. Damit bekam der internationale Tourismus in Deutschland wieder einen Aufschwung: Der Anteil ausländischer Gäste am gesamten Gästeaufkommen lag im deutschlandweiten Durchschnitt bei 16,6 %. Regional betrachtet differiert deren Bedeutung. So waren die Großstädte Hamburg, Berlin und München bei Gästen aus dem Ausland weiterhin sehr beliebt, während in den Urlaubsregionen an der deutschen Küste die Gäste aus dem Inland stärker dominierten. Einen bundesweiten Überblick hierzu bietet der nun um das Jahr 2023 aktualisierte und regional tief gegliederte [Tourismusatlas](https://tourismusatlas.statistikportal.de/).

#### Saisonale Muster

Ebenfalls gut erkennbar sind in den Karten des Tourismusatlas die saisonalen Muster der touristischen Nachfrage, die aufgrund der Corona-Maßnahmen in den vergangenen Jahren überlagert wurden und sich im Jahr 2023 wieder stabil zeigten. Unter dem Button „Analyse und Interpretation“ der Web-Anwendung „Tourismusatlas“ werden diese und weitere Fragestellungen näher beleuchtet.

#### Zum Datenangebot

Der Tourismusatlas ist ein Gemeinschaftsprodukt der Statistischen Ämter des Bundes und der Länder. Er visualisiert regional tief gegliedert ausgewählte Jahresergebnisse der amtlichen Tourismusstatistik in Form von interaktiven Rasterkarten. Datenbasis der Karten sind die aggregierten und georeferenzierten Angaben der geöffneten, deutschen Beherbergungsbetriebe mit zehn oder mehr Schlafgelegenheiten. Der Atlas bietet verschiedene Auswertungsmöglichkeiten zu den Jahren 2018 bis einschließlich 2023.

[Hier geht's zum Tourismusatlas.](http://tourismusatlas.statistikportal.de/)
### Kontakte

#### Monika Buchholz

Tourismus

#### Monika Buchholz

Tourismus

* [0331 8173-3329](tel:0331 8173-3329)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de)
#### Stefanie Chlebusch

Tourismus

#### Stefanie Chlebusch

Tourismus

* [0331 8173-3586](tel:0331 8173-3586)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de )
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Publikationen

Pressemitteilungen[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

[* Tourismus](/search-results?q=tag%3ATourismus)[* Atlas](/search-results?q=tag%3AAtlas)[* Gäste](/search-results?q=tag%3AGäste)[* Reiseziele](/search-results?q=tag%3AReiseziele)
