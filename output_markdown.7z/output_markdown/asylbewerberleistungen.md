

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Asylbewerberleistungen](/asylbewerberleistungen)

Asylbewerber­leistungen
=======================

Die Erhebung der Asylbewerberleistungen erstreckt sich auf die Empfängerinnen und Empfänger von Leistungen nach dem[Asylbewerberleistungsgesetz (AsylbLG)](https://www.gesetze-im-internet.de/asylblg/BJNR107410993.html).

Leistungsberechtigt sind Ausländerinnen und Ausländer, die sich tatsächlich im Bundesgebiet aufhalten und eine der Voraussetzungen nach § 1 AsylbLG erfüllen.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Empfänger von Asylbewerberleistungen sowie Ausgaben und Einnahmen nach dem Asylbewerberleistungsgesetz in Berlin und Brandenburg, jährlich (KVI2,KVI1-j)](/k-vi-1-k-vi-2-j)

Zeitreihen
----------

LeistungenEmpfänger1 im Berichtsjahr**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/91e6518109c8a7f3/af4adb7cd149/Asyl-Zeitreihe.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/c5c265146c19a429/7163f03b5eaa/Asyl-LangeReihe.xlsx)

Basisdaten
----------

Ausgaben/RegelleistungsempfängerAltersgruppen

Regionaldaten
-------------

###### Berliner Bezirke 2023

#### Empfänger von Asylbewerberleistungen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte 2023

#### Empfänger von Asylbewerberleistungen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1715088533440&code=22#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/soziales)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?language=de&sequenz=statistiken&selectionname=221%2A#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Jana Böhlke

SOZIALES

#### Jana Böhlke

SOZIALES

* [0331 8173-1134](tel:0331 8173-1134)
* [soziales@statistik-bbb.de](mailto:soziales@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Kita-Kinder basteln mit Knete](https://download.statistik-berlin-brandenburg.de/2ee06d31b9754b87/f680347bc5a1/v/f8cef1cb6e63/Soziales-Kita-AdobeStock_109933097.jpg "Kita-Kinder basteln mit Knete")](/133-2024)**Kindertagesbetreuung 2024 Berlin und Brandenburg**[#### Weniger Kita-Kinder in Berlin](/133-2024)

Am 1. März 2024 standen in der Hauptstadtregion insgesamt 4.893 Kindertageseinrichtungen mit über 424.800 genehmigten Plätzen für die Betreuung von Kindern zur Verfügung.

[![Schmuckbild Karriere](https://download.statistik-berlin-brandenburg.de/0abb31092c440f5e/c976fbd3aa51/v/0ac0a78a7a7a/mother-at-home-trying-to-work-with-child-distracting-her-picture-id1192677586.jpg "Schmuckbild Karriere")](/news/2024/adoptionen)**Adoptionen 2023 in Berlin und Brandenburg**[#### Eine neue Familie](/news/2024/adoptionen)

Während die Stiefelternadoption dominiert, adoptieren homosexuelle Paare jüngere Kinder als heterosexuelle Paare. Mehr zu Adoptionsmustern in Berlin und Brandenburg lesen Sie hier.

[![Männer aus verschiedenen Generationen liegen sich im Arm](https://download.statistik-berlin-brandenburg.de/90acd809305ce92b/2da7e740c1a1/v/1a5a1a22748a/gesellschaft-maenner-istockphoto-1954785358.jpg "Männer aus verschiedenen Generationen liegen sich im Arm")](/news/2024/herrentag)**Zum Herrentag 2024**[#### Zehn (wenig) überraschende Statistiken](/news/2024/herrentag)

Männer bestechen durch Geld und ihre Lässigkeit – das weiß nicht nur Grönemeyer. Zum Herrentag ein paar amtliche Zahlen aus der Männerwelt.

[Zu unseren News](/news)

[* Asylbewerberleistungen](/search-results?q=tag%3AAsylbewerberleistungen)[* Asylbewerber](/search-results?q=tag%3AAsylbewerber)[* AsylbLG](/search-results?q=tag%3AAsylbLG)[* Ausländer](/search-results?q=tag%3AAusländer)[* Leistungsberechtigte](/search-results?q=tag%3ALeistungsberechtigte)[* Empfänger](/search-results?q=tag%3AEmpfänger)[* Asylbewerberleistungsgesetz](/search-results?q=tag%3AAsylbewerberleistungsgesetz)[* Asyl](/search-results?q=tag%3AAsyl)
