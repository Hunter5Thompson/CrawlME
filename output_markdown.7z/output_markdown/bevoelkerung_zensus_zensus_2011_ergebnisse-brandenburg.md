

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Zensus](/bevoelkerung/zensus)
* [Zensus 2011](/bevoelkerung/zensus/zensus_2011)
* [Ergebnisdokumentation Brandenburg](/bevoelkerung/zensus/zensus_2011/ergebnisse-brandenburg)

Ergebnisdokumentation Brandenburg
---------------------------------

#### 9. Mai 2011

###### Die Gemeindeblätter präsentierendie Ergebnisse des Zensus 2011 für Brandenburg bis auf Ebene der Gemeinden zu den Themen Bevölkerung und Haushalte, Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte am 9. Mai 2011 nach Abschluss der Datenaufbereitung.

**ⓘ Sie werden über den jeweiligen Button zu den Gemeindeblättern im PDF- und Excel-Format bis auf Gemeindeebene in der Statistischen Bibliothek weitergeleitet. Zu einer bestimmten Gemeinde gelangen Sie über den Link des entsprechenden Landkreises.**

### Gemeindeblätter für Brandenburg

| Land/kreisfreie Stadt/Landkreis | Bevölkerung und Haushalte am 9. Mai 2011 | Gebäude und Wohnungen sowie Wohnverhältnisse der Haushalte am 9. Mai 2011 |  |
| --- | --- | --- | --- |
| **Land Brandenburg** |  |  |  |
| **Kreisfreie Städte** |  |  |  |
| Brandenburg an der Havel |  |  |  |
| Cottbus |  |  |  |
| Frankfurt (Oder) |  |  |  |
| Potsdam |  |  |  |
| **Landkreise/Ämter/ Gemeinden** |  |  |  |
| Barnim |  |  |  |
| Dahme-Spreewald |  |  |  |
| Elbe-Elster |  |  |  |
| Havelland |  |  |  |
| Märkisch-Oderland |  |  |  |
| Oder-Spree |  |  |  |
| Oberhavel |  |  |  |
| Oberspreewald-Lausitz |  |  |  |
| Ostprignitz-Ruppin |  |  |  |
| Potsdam-Mittelmark |  |  |  |
| Prignitz |  |  |  |
| Spree-Neiße |  |  |  |
| Teltow-Fläming |  |  |  |
| Uckermark |  |  |  |
|  |  |

#### Hinweis zur Geheimhaltung

Die Geheimhaltung wird durch das Verfahren „Sichere Anonymisierung für Einzeldaten“ (SAFE) sichergestellt. Weitere Informationen zur Geheimhaltung beim Zensus erhalten Sie auf der Zensus-Seite [www.zensus2022.de](https://www.zensus2022.de).

[Hier gelangen Sie zu den Gemeindeblättern für Berlin.](/bevoelkerung/zensus/zensus_2011/ergebnisse-berlin)
### Kontakt

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
* [0331 817330-4091](fax:0331 817330-4091)

[* Gemeindeblätter](/search-results?q=tag%3AGemeindeblätter)[* Zensus 2011](/search-results?q=tag%3AZensus 2011)[* Bevölkerung](/search-results?q=tag%3ABevölkerung)[* Haushalte](/search-results?q=tag%3AHaushalte)[* Gebäude](/search-results?q=tag%3AGebäude)[* Wohnungen](/search-results?q=tag%3AWohnungen)[* Gemeinden](/search-results?q=tag%3AGemeinden)[* Gemeindeverbände](/search-results?q=tag%3AGemeindeverbände)[* Ämter](/search-results?q=tag%3AÄmter)
