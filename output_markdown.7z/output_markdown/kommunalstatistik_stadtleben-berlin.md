

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Berlin-Statistik](/kommunalstatistik)
* [Stadtleben](/kommunalstatistik/stadtleben-berlin)

Stadtleben Berlin
=================

**Berlin ist bunt und das ist auch das Datenangebot der Kommunalstatistik.**   


In den Kategorien Kultur, Freizeit, Religion/Beisetzung und Arbeitsmarkt sowie Umwelt, Verkehr und Sicherheit finden Datennutzende ein umfangreiches Repertoire an interessanten Verwaltungs- und Geschäftsstatistiken.

[![Fussball-Fans beim Jubeln in einem Wohnzimmer](https://download.statistik-berlin-brandenburg.de/34373f395a5df526/72a06c9000cd/v/32f583b789d6/gesellschaft-menschen-fussball-iStock-1250480649.jpg "Fussball-Fans beim Jubeln in einem Wohnzimmer")](/news/2024/fussball-europameisterschaft)**Zu den Spielen der Fußball-Europameisterschaft 2024 in Berlin**[#### Wird’s laut in meinem Kiez?](/news/2024/fussball-europameisterschaft)

In fast allen Nachbarschaften Berlins leben zahlreiche Menschen mit den Nationalitäten der teilnehmenden Teams bei der Fußball-Europameisterschaft 2024.

FreizeitReligion/BeisetzungenArbeitsmarktKlimaUmweltVerkehrSicherheit

Freizeit
--------

Wie die arbeitsfreie Zeit in Berlin genutzt werden kann, zeigen die vielfältigen statistischen Daten zu Zoo und Tierpark, Sportvereinen, Kleingärten, Kinderspielplätzen und Hunden.

SportvereineZoo und TierparkKleingärten, Spielplätze, Hunde**Quelle:** Landessportbund Berlin (LSB)
#### Mehr Daten zu Sportvereinen in Berlin finden Sie hier:

[Zum Statistischen Bericht](/b-v-1-j)

Religion/Beisetzungen
---------------------

Dieser Themenkomplex widmet sich der religiösen Zugehörigkeit und den Formen der Beisetzungen. Informationen zu den Religionsgemeinschaften, Friedhöfen und Bestattungen sind hier zusammengestellt.

**Quelle:** Krematorium Berlin/ Senatsverwaltung für Mobilität, Verkehr, Klimaschutz und Umwelt1 unter anderem jüdisch, russisch-orthodox und privat**Quelle:** Amt für Statistik Berlin-Brandenburg/ Senatsverwaltung für Mobilität, Verkehr, Klimaschutz und Umwelt

Arbeitsmarkt
------------

Hier finden Sie statistische Informationen der Bundesagentur für Arbeit. Wie viele Arbeitslose gibt es in Berlin? Und wie viele leben in SGB-II-Bedarfsgemeinschaften? Weitere Daten zum Thema **Arbeit**finden Sie [hier](/gesellschaft/arbeit).

**Quelle:** Bundesagentur für Arbeit
###### 2023 in den Berliner Bezirken

#### Personen in SGB-II-Bedarfsgemeischaften

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Klima
-----

Wie hat sich das Klima in Berlin verändert? Steigen die Temperaturen? Gibt es mehr Starkregen? Hier sind statistische Klimadaten zu Niederschlagsmengen, Temperaturen sowie der Sonnenscheindauer und der Witterung in Berlin zu finden.

Temperatur, Niederschläge, SonnenscheinWitterung**Quelle:** Berliner Wetterkarte e.V.**Quelle:** Berliner Wetterkarte e.V.**Quelle:** Berliner Wetterkarte e.V.

Umwelt
------

Wie viele Straßenbäume stehen in der Hauptstadt? Welche Fischarten können in Berlin gefangen werden? Wie hoch ist die Schadstoffbelastung in Berlin? Statistische Daten zum Straßenbaumbestand in Berlin, dem Fischfang in Berliner Gewässern, den Schadstoffemissionen sowie den Grundwasser- und Pegelständen ordnen ein.

FischfangStraßenbäumeSchadstoffimmissionenGrundwasserstände**Quelle:** Fischereiamt Berlin

Verkehr
-------

Hat Berlin mehr Brücken als Venedig? Und wie viele Taxen gibt es in der Hauptstadt? Informationen zu den Themen Straßen, Brücken und Kraftfahrzeuge werden hier näher beleuchtet. Weitere Informationen zum Thema **Verkehr**finden Sie [hier](/gesellschaft/verkehr).

Pkw-BestandAntriebsartBrückenStraßenlänge
###### 2023

#### Pkw-Bestand

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Sicherheit
----------

Unter dem Themenkomplex Sicherheit werden statistische Informationen über das Personal der Polizei, den Eingang von Notrufen, den Einsätzen der Polizei sowie der Feuerwehr, Notfallrettungseinsätze und den Wasserrettungsdienst zur Verfügung gestellt.

EinsätzeNotrufePersonal1 Notfallrettung und -transporte**Quelle:** Jahresbericht der Berliner Feuerwehr1 dazu zählen unter anderem DRK, Johanniter Unfall-Hilfe, Malteser Hilfedienst, ADAC2 Berufsfeuerwehr, Freiwillige Feuerwehren, Werkfeuerwehren3 Zum Beitrag der Bundeswehr zum Rettungsdienst im Land Berlin liegen die Daten erst ab 2014 vor**Quelle:** Senatsverwaltung für Inneres und Sport Berlin

Haben Sie Fragen?
-----------------

#### Katja Niemann-Ahrendt

Kommunalstatistik

#### Katja Niemann-Ahrendt

Kommunalstatistik

* [0331 8173-3868](tel:0331 8173-3868)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Petra Dehniger

Kommunalstatistik

#### Petra Dehniger

Kommunalstatistik

* [0331 8173-3508](tel:0331 8173-3508)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Heike Stiller

Kultur, Religion, Beisetzungen, Umwelt

#### Heike Stiller

Kultur, Religion, Beisetzungen, Umwelt

* [0331 8173-3658](tel:0331 8173-3658)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Anja Rieckert

Sport, SGB II, KID

#### Anja Rieckert

Sport, SGB II, KID

* [0331 8173-3377](tel:0331 8173-3377)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Fussball-Fans beim Jubeln in einem Wohnzimmer](https://download.statistik-berlin-brandenburg.de/34373f395a5df526/72a06c9000cd/v/32f583b789d6/gesellschaft-menschen-fussball-iStock-1250480649.jpg "Fussball-Fans beim Jubeln in einem Wohnzimmer")](/news/2024/fussball-europameisterschaft)**Zu den Spielen der Fußball-Europameisterschaft 2024 in Berlin**[#### Wird’s laut in meinem Kiez?](/news/2024/fussball-europameisterschaft)

In fast allen Nachbarschaften Berlins leben zahlreiche Menschen mit den Nationalitäten der teilnehmenden Teams bei der Fußball-Europameisterschaft 2024.

[![Mädchen auf einer Schaukel im Sonnenlicht](https://download.statistik-berlin-brandenburg.de/5bd474bde5e5835e/a72ea1539dcf/v/0d94dcf8272a/istockphoto-904206258-2048x2048.jpg "Mädchen auf einer Schaukel im Sonnenlicht")](/news/2024/spielplaetze-berlin)**Kinderspielplätze 2023 in Berlin**[#### Wieviel Spielflächen bietet die Stadt?](/news/2024/spielplaetze-berlin)

Gemäß § 4 Kinderspielplatzgesetz gilt ein Richtwort von einem Quadratmeter nutzbarer Spielfläche je Einwohnende. Unsere Karte zeigt, wo in Berlin dieser Wert erreicht wird.

[![Sportverein](https://download.statistik-berlin-brandenburg.de/747cead8a54d0a95/090e9112b845/v/2a4e602f5502/AdobeStock_334674585.jpeg "Sportverein")](/099-2023)**Statistik der Sportvereine 2022 Berlin**[#### 15,9 Prozent halten sich im Vereins- und Betriebssport fit](/099-2023)

2022 sind 1 996 förderungswürdige Sportvereine und Betriebssportgemeinschaften mit insgesamt 601 323 Mitgliedern erfasst worden.

[Zu unseren News](/news)

[* Kommunalstatistik](/search-results?q=tag%3AKommunalstatistik)[* Berlin](/search-results?q=tag%3ABerlin)[* Verkehr](/search-results?q=tag%3AVerkehr)[* Umwelt](/search-results?q=tag%3AUmwelt)[* Religion](/search-results?q=tag%3AReligion)[* Arbeit](/search-results?q=tag%3AArbeit)[* Kultur](/search-results?q=tag%3AKultur)[* Freizeit](/search-results?q=tag%3AFreizeit)[* Sicherheit](/search-results?q=tag%3ASicherheit)[* Sport](/search-results?q=tag%3ASport)[* Vereine](/search-results?q=tag%3AVereine)
