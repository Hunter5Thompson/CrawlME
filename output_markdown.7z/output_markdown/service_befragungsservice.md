

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Service](/service)
* [Befragungsservice](/service/befragungsservice)

Befragungsservice
=================

Wir führen für unsere Kundinnen und Kunden Befragungen durch. Dazu zählen unter anderem Kundenbefragungen, Mitarbeitendenbefragungen und Führungskräftefeedbacks.

[Alle Services
#### Übersicht](/service)[Individuelle Auskünfte
#### Informationsservice](/service/informationsservice)[Karten und Geometrien
#### Geoservice](/geoservice)[Befragungen & Analysen
#### Befragungsservice](/service/befragungsservice)[Amtliche Mikrodaten
#### Forschungsdatenzentrum](https://www.forschungsdatenzentrum.de/de)[Wissenschaftliche Spezialbibliothek
#### Unsere Bibliothek](/service#bibliothek)
#### Mitarbeitendenbefragung zum Thema Arbeit, Gesundheit und Soziales, Führungskräftefeedbacks und individuelle Befragungen von

#### Mitarbeitenden, Kundinnen und Kunden

Wir beraten Sie bezüglich der Befragungen, unterstützen deren Organisation, erheben die Daten mithilfe eines barrierefreien Online-Tools (nach BITV 2.0) und werten diese im Anschluss statistisch für Sie aus.

Unser Angebot richtet sich insbesondere an die Verwaltungen der Länder Berlin und Brandenburg.

###### Mitarbeitendenbefragung zum Thema Arbeit, Gesundheit und Soziales

Das Amt für Statistik Berlin-Brandenburg bietet die Durchführung und statistische Auswertung von Mitarbeitendenbefragungen zum Thema Arbeit, Gesundheit und Soziales an – basierend auf dem landesweiten Berliner Standardfragebogen (4. Auflage).

Ziel der Befragung ist es, Informationen über Zustand und beeinflussende Faktoren von Gesundheit und Arbeitszufriedenheit der Mitarbeitenden, sowie vorhandene Ressourcen und die Arbeit erschwerende Belastungen zu gewinnen. Der standardisierte Fragebogen besteht aus soziodemografischen Fragen und Fragebatterien zum Thema „Arbeit, Gesundheit und Soziales“. Er eröffnet die Möglichkeit, die Bedürfnisstruktur der Beschäftigten differenziert nachzuvollziehen und daraus gesundheitsfördernde Maßnahmen abzuleiten.

Die Datenerhebung findet in Form einer anonymen Onlinebefragung statt. Hierfür werden an die potentiell teilnehmenden Personen Zugangsschlüssel verteilt, die einen zuverlässigen und einmaligen Zugang zur Befragung ermöglichen.

Der Online-Fragebogen der Mitarbeitendenbefragung wurde nach der Barrierefreien-Informationstechnik-Verordnung (BITV 2.0) geprüft und wird standardmäßig barrierefrei angeboten.

Im Anschluss an die Datenerhebung erfolgt die Datenaufbereitung und statistische Auswertung, inklusive Berichterstellung. Datenschutz hat bei uns oberste Priorität. Die Daten werden stets so aufbereitet, dass sich keine einzelnen Personen identifizieren lassen. Hierfür werden Geheimhaltungsverfahren der amtlichen Statistik eingesetzt.

Neben einem Gesamtbericht können im Anschluss der Befragung auch noch weitere Berichte, wie Gruppenberichte, Kurzberichte oder Vergleichsberichte, angefordert werden.

Sie können die Leistungen Datenerhebung und Auswertung, einschließlich Berichterstellung, gerne zusammen oder jeweils separat voneinander beauftragten.

Für weitere Informationen kontaktieren Sie uns unter [Befragung@statistik-bbb.de](mailto:Befragung@statistik-bbb.de). Wir beraten Sie gerne zur Durchführung Ihrer Mitarbeitendenbefragung und erstellen Ihnen auf Wunsch ein entsprechendes Angebot.

###### Führungskräftefeedbacks

Das Amt für Statistik Berlin-Brandenburg bietet die Datenerhebung und statistische Auswertung von 90°-Führungskräftefeedbacks an. Bei dieser Art von Befragung bewerten sowohl die Mitarbeitenden ihre Führungskraft (Fremdeinschätzung) als auch die Führungskraft ihr eigenes Führungsverhalten (Selbsteinschätzung).

Dieses Führungskräftefeedback kann insbesondere als Ergänzung der Mitarbeitendenbefragung angesehen werden. Aber auch unabhängig von dieser gewährt das Leistungspaket des 90°-Führungskräftefeedbacks einen umfassenden und informativen Einblick in das Zusammenspiel von Mitarbeitenden und Vorgesetzten.

Ziel des Führungskräftefeedbacks ist es, eine Informationsbasis zu schaffen, die es ermöglicht, die Zusammenarbeit zwischen Mitarbeitenden und Führungskraft zu optimieren. Als Grundlage der Befragung stellen wir einen bewährten Fragebogen zur Verfügung. Insgesamt umfasst dieser Fragebogen zehn unterschiedliche Themengebiete, wie beispielsweise „Führung und Zusammenarbeit“, „Förderung und Motivation“ oder die „Vereinbarkeit von Beruf und Familie“.

Weitere Informationen zum Führungskräftefeedback finden Sie auch in der [Zeitschrift für amtliche Statistik Berlin-Brandenburg](https://download.statistik-berlin-brandenburg.de/53350a5faef61890/88d88ec97465/hz_201503-06.pdf).

Die Datenerhebung findet in Form einer Onlinebefragung statt. Hierfür werden an die potentiell teilnehmenden Personen Zugangsschlüssel verteilt, die einen zuverlässigen und einmaligen Zugang zur Befragung ermöglichen. Diese werden außerdem differenziert für die Funktionen Führungskraft (Selbsteinschätzung) und deren Mitarbeitenden (Fremdeinschätzung) erzeugt.

Die Befragung wird online standardmäßig barrierefrei, nach der Barrierefreien-Informationstechnik-Verordnung (BITV 2.0), angeboten.

Jede Führungskraft erhält einen eigenen Bericht mit ihren Ergebnissen. Weitere Zusatzauswertungen, wie die Aufnahme von Benchmarks (zum Beispiel Abteilungsbenchmark) innerhalb des Berichts oder eine Auswertung über die gesamte Behörde, sind ebenfalls möglich. Datenschutz hat bei uns oberste Priorität. Die Daten werden so aufbereitet, dass sich keine einzelnen Personen identifizieren lassen. Hierfür werden auf Wunsch Geheimhaltungsverfahren der amtlichen Statistik eingesetzt.

Sie können die Leistungen Datenerhebung und Auswertung, einschließlich Berichtserstellung, gerne zusammen oder jeweils separat voneinander beauftragen.

Für weitere Informationen kontaktieren Sie uns unter [Befragung@statistik-bbb.de](mailto:Befragung@statistik-bbb.de). Wir beraten Sie gerne zur Durchführung Ihres Führungskräftefeedbacks und erstellen Ihnen auf Wunsch ein entsprechendes Angebot.

###### Individuelle Befragungen

Das Amt für Statistik Berlin-Brandenburg bietet die Entwicklung, Durchführung und statistische Auswertung von Mitarbeitenden- und Kundenbefragungen zu individuellen Themen an.

Die Datenerhebung findet in Form einer Onlinebefragung statt.  Auf Wunsch stellen wir Zugangsschlüssel bereit, die eine einmalige und sichere Teilnahme der Befragungsteilnehmenden gewährleisten.

Unter Einhaltung bestimmter Grundsätze kann die Befragung barrierefrei, nach der Barrierefreien-Informationstechnik-Verordnung (BITV 2.0), gestaltet werden.

Damit alle relevanten Fragen im Anschluss Ihrer Befragung beantwortet werden können, entwickeln wir mit Ihnen zusammen einen methodisch abgestimmten Fragebogen und wählen die passenden statistischen Verfahren für die Auswertung aus. Dabei berücksichtigen wir stets alle sozialwissenschaftlichen und datenschutzrelevanten Anforderungen.

Gerne beraten wir Sie auch zu einem bereits von Ihnen entwickelten Fragebogen oder übernehmen die Auswertung einer bereits durchgeführten Befragung.

Um die Identifizierbarkeit einzelner Personen zu verhindern, setzten wir Geheimhaltungsverfahren der amtlichen Statistik ein.

Sie können die Leistungen Beratung, Datenerhebung und statistische Auswertung inklusive Berichtserstellung, gerne einzeln oder zusammen beauftragten.

Für weitere Informationen kontaktieren Sie uns unter [Befragung@statistik-bbb.de](mailto:Befragung@statistik-bbb.de).

Ein Fachgespräch zum Thema "Mitarbeitendenbefragung in der Öffentlichen Verwaltung" finden Sie in der [Zeitschrift für amtliche Statistik Berlin Brandenburg](https://download.statistik-berlin-brandenburg.de/dfcb2c44a59cd1a9/1f96c28741ae/hz_201503-07.pdf).  


**Mehr Informationen und individuelle Anfragen unter:** [**Befragung@statistik-bbb.de**](mailto:Befragung@statistik-bbb.de)

![](https://download.statistik-berlin-brandenburg.de/03487bed028468fc/73860e24ad68/v/b0488825e1e7/schmuckbild-links-statistische-berichte.jpg)
### Sie müssen Daten melden? Hier geht's zur Hilfe.

[Daten melden](/daten-melden)

[* Befragungsservice](/search-results?q=tag%3ABefragungsservice)[* Befragungen](/search-results?q=tag%3ABefragungen)[* Umfragen](/search-results?q=tag%3AUmfragen)[* Surveys](/search-results?q=tag%3ASurveys)[* Fragebogenentwicklung](/search-results?q=tag%3AFragebogenentwicklung)[* Beratung](/search-results?q=tag%3ABeratung)[* Kunden](/search-results?q=tag%3AKunden)[* Mitarbeitenden](/search-results?q=tag%3AMitarbeitenden)[* Mitarbeiter](/search-results?q=tag%3AMitarbeiter)[* Führungskräftefeedbacks](/search-results?q=tag%3AFührungskräftefeedbacks)[* Sonderbefragung](/search-results?q=tag%3ASonderbefragung)[* individuelle Befragung](/search-results?q=tag%3Aindividuelle Befragung)[* Barrierefreie Befragung](/search-results?q=tag%3ABarrierefreie Befragung)[* Barrierefreie Umfragen](/search-results?q=tag%3ABarrierefreie Umfragen)[* Barrierefreie Surveys](/search-results?q=tag%3ABarrierefreie Surveys)
