

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 14.02.2023

#### Ledig, verheiratet oder in einer Lebenspartnerschaft

Der Beziehungsstatus der Hauptstadt
-----------------------------------

![iStock.com / DisobeyArt](https://download.statistik-berlin-brandenburg.de/dc81672f22a9f1f7/081341cde7be/v/b0ad30523314/gesellschaft-bildung-young-millennial-friends-having-fun-chatting-taking-photos-with-and-picture-id1194859007.jpg "iStock.com / DisobeyArt")

**Der Tag der Liebenden ist eine wunderbare Gelegenheit, um zu schauen, wie es um den Beziehungsstatus der Berlinerinnen und Berliner steht**. Wir haben uns den Familienstand** der mit Hauptwohnsitz in Berlin Gemeldeten angeschaut.**

Zum Stichtag 31.12.2022 hatten im Einwohnermelderegister 1 279 810 Personen den Familienstand „verheiratet“. Das entspricht einem Anteil von 33,2 Prozent. Im Bezirk Pankow war der Anteil an verheirateten Personen mit 10,0 Prozent am höchsten, in Friedrichshain-Kreuzberg mit 5,9 Prozent am niedrigsten.

In einer eingetragenen Lebenspartnerschaft lebten im vergangenen Jahr 10 345 Personen (0,3 Prozent). Mit 14,5 Prozent war ihr Anteil in Tempelhof-Schöneberg am höchsten, in Spandau mit 3,0 Prozent am niedrigsten.

Mehr als die Hälfte (52,8 Prozent) der Berliner und Berlinerinnen bevorzugen den Familienstand ledig und prägen damit u. a. das Bild der Singlehauptstadt Berlin. Von den insgesamt 2 032 924 Ledigen sind 53,1 Prozent männlichen und 46,9 Prozent weiblichen Geschlechts. Die meisten ledigen Personen lebten 2022 im Bezirk Pankow (11,9 Prozent), gefolgt von Mitte mit 11,7 Prozent. In Spandau wurden mit 5,9 Prozent die wenigsten registriert.

Wie viele von den Ledigen jedoch gerade verliebt oder in einer Beziehung sind, verrät uns die Statistik leider nicht.

1 Lebend- und Totgeborene 2 Geborene nach Ereignismonat, Schätzverfahren – monatlich revidiert3 Geborene nach Beurkundungsmonat**Quelle:** Amt für Statistik Berlin-Brandenburg[Mehr Daten zum Einwohnerbestand gibt's hier.](/kommunalstatistik/einwohnerbestand-berlin)
### Kontakte

#### Katja Niemann-Ahrendt

Kommunalstatistik

#### Katja Niemann-Ahrendt

Kommunalstatistik

* [0331 8173-3868](tel:0331 8173-3868)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen
