

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Berlin-Statistik](/kommunalstatistik)
* [Einwohnerbestand Berlin](/kommunalstatistik/einwohnerbestand-berlin)
* [Einwohnerbestand Berlin – LOR-Planungsräume](/a-i-16-hj)

Einwohnerbestand in Berlin
--------------------------

– LOR-Planungsräume
-------------------

#### 30. Juni 2024, halbjährlich

###### Die Statistik gibt einen Überblick über die wichtigsten demografischen Grunddaten auf Ebene der Berliner Lebensweltlich orientierten Räume (LOR). Dazu gehören zum Beispiel Alter, Geschlecht, Staatsangehörigkeit sowie Migrationshintergrund und ausgewählte Herkunftsgebiete.

BerlinMethodik
### Berlin

###### 30.06.2024 in Berlin am Ort der Hauptwohnung nach Planungsräumen

#### Anteil melderechtlich registrierter Ausländer/-innen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### **Zum aktuellen Statistischen Bericht – 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d0c22c0ec7d1afcf/cc74db3da6e5/SB_A01-16-00_2024h01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/276ccd2bf0fbc525/094acde7c334/SB_A01-16-00_2024h01_BE.pdf) 

**Berlins 542 lebensweltlich orientierte Räume**

Bestimmte Entwicklungen in den einzelnen Stadtteilen lassen sich statistisch nur abbilden, indem diese kleinräumig analysiert werden. Hierfür wurden 2006 die Lebensweltlich orientierten Räume gebildet. Diese Gliederung ist die wichtigste kleinräumige Planungsgrundlage für Berlin. Die insgesamt 542 Räume sind seit dem 1. Januar 2021 gültig.

Detaillierte Informationen zu Lebensweltlich orientierten Räumen und weiteren Raumbezügen Berlins finden Sie [auf dieser Seite](/meine-region/lebensweltlich-orientierte-raeume-berlin).

### Kontakt

#### Petra Dehniger

Einwohnerbestand, Haushalte, Migrationshintergrund

#### Petra Dehniger

Einwohnerbestand, Haushalte, Migrationshintergrund

* [0331 8173-3508](tel:0331 8173-3508)
* [einwohner@statistik-bbb.de](mailto:einwohner@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

In der Einwohnerregisterstatistik werden Daten über melderechtlich registrierte Einwohnende aus dem Einwohnerregister des Landesamtes für Bürger- und Ordnungsangelegenheiten (LABO) halbjährlich zum Stand 30.06. und 31.12. eines Jahres aufbereitet und ausgewertet.

Als landesspezifische Statistik dient sie vor allem dem Nachweis kleinräumiger demografischer Daten. Aus den Grunddaten werden zudem Angaben zum Migrationshintergrund und den Haushaltszusammenhängen der Einwohnenden abgeleitet.

Die Bereitstellung kleinräumiger Einwohnerdaten und deren abgeleiteten Merkmale sind wesentliche Grundlage für eine Vielzahl von sozial-, jugend-, gesundheits- und städteplanerischen Aufgaben und sozialraumorientierten Entscheidungen in Berlin.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Bestandsdaten Einwohnerregister Berlin**  
Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/10f2331ed455a647/b030aa57f92f/MD_19211_2021.pdf)[Archiv](/search-results?q=MD_19211&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true#results)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-i-16-hj)
