

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Sozialhilfe](/gesellschaft/soziales/sozialhilfe)
* [Sozialhilfe in Berlin und Brandenburg – Empfänger von Leistungen nach Kapitel 5 bis 9 SGB XII](/k-i-3-j)

Sozialhilfe – Empfänger von Leistungen nach dem 5. bis 9. Kapitel SGB XII
-------------------------------------------------------------------------

#### 2023, jährlich

###### Die Erhebung erstreckt sich auf Empfangende von Hilfen zur Gesundheit (5. Kapitel SGB XII), Hilfe zur Pflege (7. Kapitel SGB XII) sowie  Hilfe zur Überwindung besonderer sozialer Schwierigkeiten und Hilfe in anderen Lebenslagen (8. und 9. Kapitel SGB XII).

BerlinBrandenburgMethodik
### Berlin

\* Empfängerinnen und Empfänger mehrerer verschiedener Leistungen werden bei jeder Leistungsart (bzw. jedem Ort der Leistungsgewährung) gezählt.1 Ab dem Berichtsjahr 2020 wird die Eingliederungshilfe nach dem 6. Kapitel des SGB XII dem Teil 2 des SGB IX zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d5a6c78346f3e81e/abc31c14ceeb/SB_K01-03-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b8c294f0f42fae75/8249d18ed9d2/SB_K01-03-00_2023j01_BE.pdf)

**Leistungen nach dem 5. bis 9. Kapitel SGB XII in Berlin**

Am Jahresende 2023 erhielten in Berlin 21.645 Personen Leistungen nach dem 5. bis 9. Kapitel des Zwölften Buch Sozialgesetzbuch (SGB XII).

Der größte Anteil waren mit 77 % die Leistungen nach dem 7. Kapitel SGB XII – Hilfe zur Pflege. Die Hilfe zur Überwindung besonderer sozialer Schwierigkeiten und Hilfe in anderen Lebenslagen nach dem 8. und 9. Kapitel des SGB XII erhielten ca. 24 % der in dieser Statistik erfassten leistungsberechtigten Personen.

### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Leistungen nach dem 5. bis 9. Kapitel SGB XII in Brandenburg**

9.720 Personen erhielten am Jahresende 2023 in Brandenburg Leistungen nach dem 5. bis 9. Kapitel des Zwölften Buch Sozialgesetzbuch XII (SGB XII).

Mit 90 % bezog der überwiegende Teil der leistungsberechtigten Personen die Hilfe zur Pflege (Kapitel 7 SGB XII) und 10 % nahmen die Hilfe zur Überwindung besonderer sozialer Schwierigkeiten und Hilfe in anderen Lebenslagen nach dem 8. und 9. Kapitel des SGB XII in Anspruch.

\* Empfängerinnen und Empfänger mehrerer verschiedener Leistungen werden bei jeder Leistungsart (bzw. jedem Ort der Leistungsgewährung) gezählt.1 Ab dem Berichtsjahr 2020 wird die Eingliederungshilfe nach dem 6. Kapitel des SGB XII dem Teil 2 des SGB IX zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/478eb3a9be3b7d7e/d48dc8c9a405/SB_K01-03-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7608ed8eacfe60fe/a0077bdcb7f7/SB_K01-03-00_2023j01_BB.pdf)
### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Sozialhilfe soll als letztes „Auffangnetz“ vor Armut, sozialer Ausgrenzung und besonderer Belastung schützen. Sie soll den Leistungsberechtigten die Führung eines Lebens ermöglichen, das der Würde des Menschen entspricht. Leistungen nach dem 5. bis 9. Kapitel SGB XII dienen der Bewältigung besonderer Lebenssituationen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Empfänger von Leistungen nach dem 5. bis 9. Kapitel SGB XII**  
2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/a700871181870f4f/b3bbdca16429/MD_22131_2023.pdf)[Archiv](/search-results?q=22131&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-i-3-j)
