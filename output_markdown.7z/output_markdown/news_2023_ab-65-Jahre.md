

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 05.04.2023

#### Zum Tag der älteren Generation

65+ in Berlin und Brandenburg
-----------------------------

![Rentenbezugsmitteilungen](https://download.statistik-berlin-brandenburg.de/52e4289d79a31b1c/94386570241c/v/3a11966a4106/gesellschaft-staat-iStock-687574580-.jpg "Rentenbezugsmitteilungen")

**Schon 1968 begründete der Kasseler Lebensabendverband den Tag der älteren Generation. Seitdem widmen sich jedes Jahr am ersten Mittwoch im April verschiedene Vereine, Organisationen und Behörden mit verschiedenen Kampagnen und Aktionen der Lebenssituation älterer Menschen in unserer Gesellschaft.**

**Wie groß ist in der Hauptstadtregion die Generation 65+. Wo und wie leben sie? Und welche Leistungen nehmen sie in Anspruch? Wir werfen einen Blick auf die demografische Struktur der Bevölkerungsgruppe ab 65 Jahre und ihre soziale Situation.**

### Eine Bevölkerungsgruppe legt zu

Die ältere Generation ab 65 Jahre stellt bundesweit einen immer größeren Anteil unserer Bevölkerung. Im vergleichsweise jungen Berlin war der Anstieg überschaubar. Von 14 % in 1991 ist ihr Anteil innerhalb von 20 Jahren auf 19 % gestiegen. Im vergangenen Jahrzehnt stagnierte die Entwicklung praktisch und liegt weiterhin bei 19 %.

In Brandenburg ist der Bevölkerungsanteil der Älteren dagegen stetig und im Vergleich zu Berlin stärker gestiegen. Lag er 1991 mit 12 % noch unterhalb des Berliner Wertes, so stellten die ab 65-Jährigen 2021 bereits ein Viertel der Brandenburger Bevölkerung.

**Quelle:** Amt für Statistik Berlin-Brandenburg
### Welche Gemeinden sind die ältesten?

In 268 der 431 (62 %) Brandenburger Gemeinden ist mindestens ein Viertel der Bevölkerung 65 Jahre und älter. Darunter finden sich 56 (13 %) Städte und Gemeinden, deren ältere Generation mittlerweile 30 % oder mehr an der Bevölkerung ausmachen. Lediglich in 21 Gemeinden liegt der Anteil der ab 65-Jährigen unter einem Fünftel beziehungsweise unter 20 %.

###### am 31.12.2021

#### Ab 65-Jährige in Brandenburg nach Gemeinden

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

**Quelle:** Amt für Statistik Berlin-Brandenburg
### **Höheres Alter = höherer Frauenüberschuss**

In der Gesamtbevölkerung ist die Bevölkerungsverteilung zwischen Männern und Frauen in etwa ausgeglichen. Sie schwankt nur um wenige Prozentpunkte um die 50-Prozent-Marke. Im höheren Alter verschiebt sich diese Verteilung jedoch zugunsten der Frauen. In Brandenburg machen Frauen bei den ab 65-Jährigen einen Anteil von 56 % aus, in Berlin sind es 57 %.

Die Überzahl der Frauen wird nochmals deutlicher in der Gruppe der ab 80-Jährigen – sie stellen 62 % in beiden Ländern. Bei der Altersgruppe ab 90 Jahre sind es bereits 73 % in Brandenburg und 72 % in Berlin.

Trotz aller Unterschiede zwischen Hauptstadt und Flächenland ist das Muster identisch: Die deutlich höhere Lebenserwartung von Frauen führt zu einer Geschlechterverschiebung im höheren Alter zu Ungunsten der Männer. Statistisch gesehen, hatten in Berlin im Zeitraum 2019/2021 65-jährige Frauen eine verbleibende Lebenserwartung von 21,2 Jahren, Männer von 17,8 Jahren. In Brandenburg waren es ebenfalls 21,2 Jahre bei Frauen und 17,4 Jahre bei Männern des gleichen Alters.

**Quelle:** Amt für Statistik Berlin-Brandenburg 
### **Alte Liebe…**

Unterschiede zwischen älteren Männern und Frauen zeigen sich auch beim Familienstand. Von den Männern ab 65 Jahre ist die deutliche Mehrheit verheiratet – 74 % in Brandenburg und 66 % in Berlin. Frauen sind dagegen in beiden Ländern rund drei Mal so häufig verwitwet wie Männer. Neben der höheren Lebenserwartung der Frauen kommt hier die Heiratsfreudigkeit älterer Männer ins Spiel. 2021 traten in Brandenburg doppelt so viele Männer (204) ab 70 Jahren vor den Traualtar als Frauen (100) im selben Alter. In Berlin waren es sogar 271 Männer im Vergleich zu 116 Frauen der gleichen Altersgruppe.

**Quelle:** Amt für Statistik Berlin-Brandenburg
### Armutsrisiko nimmt mit dem Alter ab

Das Armutsrisiko nimmt mit zunehmendem Alter ab: Von den Berlinerinnen und Berlinern, die 65 Jahre oder älter sind, lebten 2022 insgesamt 17,9 % unterhalb der landesweiten Armutsgefährdungsschwelle, bei den über 75-Jährigen noch 16,8 %. In Brandenburg fällt die Armutsgefährdungsquote insgesamt niedriger aus. Hier waren lediglich 12,5 % der ab 65-Jährigen armutsgefährdet. Bei der Bevölkerung ab 70 Jahre lag die Quote noch einmal einen Prozentpunkt darunter (11,5 %). Die weibliche Bevölkerung ab 65 Jahren hat in beiden Ländern ein höheres Armutsrisiko als die gleichaltrige männliche Bevölkerung.

\* Anteil der Bevölkerung mit einem bedarfsgewichteten Einkommen unterhalb der landesweiten Armutsgefährdungsschwelle**Quelle:** Amt für Statistik Berlin-Brandenburg, Mikrozensus
### Arbeiten auch im Rentenalter?

7,7 % der Bevölkerung ab 65 Jahre in Berlin und 5,5 % in Brandenburg gehen auch im Rentenalter einer Erwerbstätigkeit nach. Dabei ist der Anteil der männlichen Bevölkerung in beiden Ländern mit 10,3 % (Berlin) bzw. 7,4 % (Brandenburg) beinahe doppelt so hoch wie der weibliche.

Mit steigendem Alter sinkt die Erwerbsbeteiligung. Bei den ab 70-Jährigen sind nur noch 3,8 % (Berlin) und 2,7 % (Brandenburg) erwerbstätig.

**Quelle:** Amt für Statistik Berlin-Brandenburg, Mikrozensus
### Wenn das Einkommen nicht ausreicht...

In Berlin nahmen Ende des 3. Quartals 2022 insgesamt 47 745 Menschen ab 65 Jahren Grundsicherung im Alter und bei Erwerbsminderung nach dem 4. Kapitel SGB XII in Anspruch. In Brandenburg waren es 10 685 Personen. Die Landeshaupstadt Potsdam weist die meisten Empfangenden ab dem Renteneintrittsalter nach § 41 Abs. 2 SGB XII in Brandenburg auf, gefolgt vom Landkreis Oberhavel. Die wenigsten Empfänger ab Renteneintrittsalter lebten in der Prignitz.

Ist das Geschlechterverhältnis in den jüngeren Altersgruppen ab 65 Jahre noch ausgeglichen, verschiebt es sich mit steigendem Alter zu Gunsten der weiblichen Bevölkerung. Grund ist auch hier die höhere Lebenserwartung der Frauen.

**Quelle:** Ladeinfrastruktur (LIS) in Zahlen (Bundesnetzagentur); Stand: 01. Januar 2023
###### am Ende des 3. Quartals 2022 in Brandenburg nach Verwaltungsbezirken

#### Empfänger von Grundsicherung im Alter und bei Erwerbsminderung

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

### Höheres Alter = mehr Pflegebedürftige

Die Zahl der pflegebedürftigen Menschen wird allein durch die zunehmende Alterung bis 2055 in Berlin um 47 % und in Brandenburg um 33 % zunehmen. Der deutschlandweite Zunahme liegt laut der [Pflegevorausberechnung des Statistischen Bundesamtes](https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Bevoelkerung/Bevoelkerungsvorausberechnung/Publikationen/_publikationen-innen-statistischer-bericht-pflegevorausberechnung.html) bei 37 %. Nach 2055 sind keine starken Veränderungen mehr zu erwarten, da die geburtenstarken Jahrgänge aus den 1950er und 1960er Jahren, die sogenannten Babyboomer, durch geburtenschwächere Jahrgänge im höheren Alter abgelöst werden.

**Quelle:** Statistisches Bundesamt
### Kontakte

#### Theresa Markhoff

Bevölkerungsstatistik

#### Theresa Markhoff

Bevölkerungsstatistik

* [0331 8173-3855](tel:0331 8173-3855)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Jörg Feilbach

Mikrozensus

#### Jörg Feilbach

Mikrozensus

* [0331 8173-3644](tel:0331 8173-3644)
* [mikrozensus@statistik-bbb.de](mailto:mikrozensus@statistik-bbb.de)
#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Rentner](/search-results?q=tag%3ARentner)[* Senioren](/search-results?q=tag%3ASenioren)[* Alter](/search-results?q=tag%3AAlter)[* Pflege](/search-results?q=tag%3APflege)[* Grundsicherung](/search-results?q=tag%3AGrundsicherung)
