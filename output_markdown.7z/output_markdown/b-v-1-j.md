

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Meine Region](/meine-region)
* [Berlin-Statistik](/kommunalstatistik)
* [Stadtleben](/kommunalstatistik/stadtleben-berlin)
* [Sportvereine in Berlin](/b-v-1-j)

Sportvereine in Berlin
----------------------

#### 2022, jährlich

| Die Statistik der Sportvereine informiert über die in Berlin als **förderungswürdig** eingestuften Sportvereine, Betriebssportgemeinschaften und Mitgliedsorganisationen und ihre Mitglieder. |
| --- |

BerlinMethodik
### Berlin

**Quelle:** Landessportbund Berlin (LSB)
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/78f7f067e734cea1/fad2b368bb63/SB_B05-01-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/846c1c43cf2e4d80/ee107013dbd8/SB_B05-01-00_2022j01_BE.pdf)

**15,9 % der Einwohnenden Berlins im Vereins- bzw. Betriebssport aktiv**

2022 wurden 1 996 **förderungswürdige** Sportvereine und Betriebssportgemeinschaften (BSG) mit insgesamt 601 323 Mitgliedern erfasst. Das waren 35  Vereine weniger (-1,7 %) und 18 477  mehr Mitglieder (3,2 %) als 2021. Männer (394 723) waren nahezu doppelt so häufig im Verein organisiert wie Frauen (206 600).

Die Mehrheit der förderungswürdigen Vereine in Berlin verfügt über 1 bis 100 Mitglieder (57,0 %), in denen  
7,4 % aller Sporttreibenden aktiv sind. Ein Drittel der Mitglieder sind in Großvereinen mit mehr als 3 000 Mitgliedern eingetragen. Die größten Sportvereine sind der Fußballclub Union Berlin e. V. mit 40 725 Mitgliedern, gefolgt von Hertha BSC e. V. mit 40 238 und dem Deutschen Alpenverein Sektion Berlin e. V. mit  
22 028 Mitgliedern. Die meisten Sportvereine und Betriebssportgemeinschaften waren in Treptow-Köpenick (227) eingetragen.

Gemessen an der Bevölkerung Berlins beteiligten sich 15,9 % der Einwohnenden am Vereins- und Betriebssport. In Treptow-Köpenick (28,5 %) und Charlottenburg-Wilmersdorf (28,2 %) war die Beteiligung am höchsten. Am aktivsten (im Vergleich zur Einwohnerzahl der Altersgruppe) waren Kinder und Jugendliche (7–14 Jahre: 43,4 %; 15–20 Jahre: 28,9 %).

### Kontakt

#### Anja Rieckert

Sport, SGB II, KID

#### Anja Rieckert

Sport, SGB II, KID

* [0331 8173-3377](tel:0331 8173-3377)
* [kommunalstatistik@statistik-bbb.de](mailto:kommunalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik der Sportvereine ist eine wesentliche Informationsquelle und Planungsgrundlage für die Senatsverwaltung für Inneres und Sport, die Sportämter der Bezirke, den Landessportbund Berlin, Sportverbände, Sportvereine und Betriebssportgemeinschaften. Die Erhebung wird jährlich zum Stichtag 1. Januar durchgeführt.

Im Rahmen des Berliner Sportförderungsgesetzes werden die Mitglieder der Sportorganisationen nach Alter, Geschlecht und deren Zugehörigkeit zu den Fachverbänden, Fachvereinigungen bzw. Sportverbänden erhoben. Es besteht keine Berichtspflicht, die Erhebung erfolgt auf freiwilliger Basis.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Sportvereine in Berlin**   
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/a468f52ad768ea11/dea408c4fe82/MD_29172_2023.pdf)[Archiv](/search-results?q=MD_29172&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-v-1-j)

[* Sportverein](/search-results?q=tag%3ASportverein)[* Kommunalstatistik](/search-results?q=tag%3AKommunalstatistik)[* Vereine](/search-results?q=tag%3AVereine)[* Mitglieder](/search-results?q=tag%3AMitglieder)
