

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentlicher Dienst](/oeffentlicher-dienst)
* [Personal im öffentlichen Dienst in Berlin und Brandenburg](/l-iii-2-j)

Personal im öffentlichen Dienst und der öffentlichen Einrichtungen und Unternehmen in privater Rechtsform
---------------------------------------------------------------------------------------------------------

#### Juni 2023, jährlich

###### Die Personalstandstatistik liefert Daten über die Beschäftigten der öffentlichen Arbeitgeber, die am 30. Juni eines Jahres in einem unmittelbaren Dienst- oder Arbeitsvertragsverhältnis mit der jeweiligen Einrichtung stehen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/911f7266257623dc/fafe3af17cdf/SB_L03-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f84d7bc15a3fc69f/93a3fa67512e/SB_L03-02-00_2023j01_BE.pdf)

**Geringerer Personalanstieg gegenüber dem Vorjahr**

In Berlin beschäftigte der öffentliche Dienst am 30. Juni 2023 insgesamt 225.910 Personen. Das war ein Zuwachs von 3.645 Personen (+1,6 %) gegenüber dem 30. Juni 2022. Im Vorjahr waren es 6.785 Personen (+3,1 %) mehr als am 30. Juni 2021.

Der Personalanstieg bei den Auszubildenden verringerte sich von 7,0 % (+755 Auszubildende) im Vorjahr auf 1,5 % (+170 Auszubildende) am 30.06.2023.

Die Zahl der Teilzeitbeschäftigten stieg um 4,2 % (7,7 % im Vorjahr) an. 29,0 % der Beschäftigten arbeiten in Teilzeit. Mit 72,5 % war der Großteil der Teilzeitbeschäftigten Frauen.

Am 30.06.2023 betrug das Durchschnittsalter der im öffentlichen Dienst Beschäftigten 44,0 Jahre. Wobei die Beamten im Durchschnitt etwas älter sind als die Arbeitnehmer. Bei den Beamten lag das Durchschnittsalter bei 45,2 Jahren, bei den Arbeitnehmern bei 43,6 Jahren.

### Kontakt

#### Ramona Baumert

Personalstatistiken

#### Ramona Baumert

Personalstatistiken

* [0331 8173-1251](tel:0331 8173-1251)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Anstieg der Beschäftigten**

Zum Stichtag 30. Juni 2023 gab es im Land Brandenburg gegenüber dem Vorjahr einen Anstieg um 1.840 Personen (+1,5 %) auf insgesamt 128.505 Beschäftigte im öffentlichen Dienst.

Der größte Anstieg konnte im kommunalen Bereich verzeichnet werden. Hier wurden zum Stichtag 55.990 Personen beschäftigt, 1.315 Personen mehr (+2,4 %) als am 30. Juni 2022.

In Teilzeit arbeiten 34,4 % der Beschäftigten, davon sind 84,2 % weiblich. 28,0 % der öffentlich Beschäftigten verfügte über einen Beamtenstatus. Die Zahl der Auszubildenden verringerte sich um –3,3 %.

Das Durchschnittsalter der im öffentlichen Dienst Land Brandenburg Beschäftigten betrug 45,6 Jahre. Am jüngsten mit einem Durchschnittsalter von 45,3 Jahren sind die Beschäftigten im Landesbereich. Beim kommunalen Bereich liegt das Durchschnittsalter bei 45,6 Jahren. Mit 47,3 Jahren ist das Durchschnittsalter bei den Beschäftigten im Bereich der Sozialversicherungsträger am höchsten.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/6aa2b6b9e5eace8b/57108802c57b/SB_L03-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/fcc10291caaa3c26/913c1355e4e3/SB_L03-02-00_2023j01_BB.pdf)
### Kontakt

#### Ramona Baumert

Personalstatistiken

#### Ramona Baumert

Personalstatistiken

* [0331 8173-1251](tel:0331 8173-1251)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Ergebnisse der Personalstandstatistik sind Grundlage für politische Entscheidungen zur Weiterentwicklung des Dienst-, Besoldungs-, Tarif- und Versorgungsrechts.

Die für Dienst-, Besoldungs-, Tarif- und Versorgungsrecht zuständigen Ministerien nutzen die Ergebnisse der Personalstandstatistik als Grundlage für politische Entscheidungen zur Weiterentwicklung des Dienst-, Besoldungs-, Tarif und Versorgungsrechts.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Personal des öffentlichen Dienstes und der öffentlich bestimmten Einrichtungen und Unternehmen in privater Rechtsform**  
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/10c337800ff89e3a/e0e1143079c1/MD_74111_2023.pdf)[Archiv](/search-results?q=74111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-iii-2-j)
