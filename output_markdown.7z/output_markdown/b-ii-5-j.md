

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Schulen](/gesellschaft/bildung/schulen)
* [Auszubildende und Prüfungen in Berlin und Brandenburg](/b-ii-5-j)

Berufsbildungsstatistik – Auszubildende und Prüfungsteilnahmen
--------------------------------------------------------------

#### 2023, jährlich

###### Aufgabe der Berufsbildungsstatistik ist es, aussagefähige Daten zur Situation der betrieblichen und außerbetrieblichen Berufsausbildung bereitzustellen, um Planung und Entwicklung in diesem Bereich zu ermöglichen.

BerlinBrandenburgMethodik

Berlin
------

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/cf5a419d02c54b13/740823bd42b4/SB_B02-05-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/45fda39d444b7437/c77ce8fde145/SB_B02-05-00_2023j01_BE.pdf)

**Zahl der Vertragsauflösungen steigt**

2023 absolvierten in Berlin 35.040 Auszubildende eine duale Ausbildung, davon 13.383 Frauen. Im Vergleich zum Vorjahr sind das 0,8 % weniger Auszubildende. 14.139 neue Ausbildungsverträge wurden abgeschlossen. Das ist ebenfalls ein Rückgang um 0,8 %. Vorzeitig gelöst wurden 5.985 Ausbildungsverträge, das sind 288 Vertragslösungen mehr als im Jahr 2022.

### Kontakt

#### Silke Tasler

Berufsbildung

#### Silke Tasler

Berufsbildung

* [0331 8173-1175](tel:0331 8173-1175)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Sabine Wöhl

Berufsbildung

#### Sabine Wöhl

Berufsbildung

* [+49 331 8173-1125](tel:+49 331 8173-1125)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Zahl der Auszubildenden steigt**

Am 31. Dezember 2023 befanden sich in Brandenburg 26.820 Auszubildende in einer dualen Ausbildung. 8.352 von ihnen waren Frauen. Im Vergleich zum Vorjahr nahm die Zahl der Auszubildenden um 2,0 % zu. Von den Auszubildenden haben 10.587 einen neuen Ausbildungsvertrag abgeschlossen, 4.743 von ihnen besaßen einen mittleren Schulabschluss.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/5730aa084b1c6ee4/4301e58a5346/SB_B02-05-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/3d1053dc6e659388/d3cbd1a85ef5/SB_B02-05-00_2023j01_BB.pdf)
### Kontakt

#### Silke Tasler

Berufsbildung

#### Silke Tasler

Berufsbildung

* [0331 8173-1175](tel:0331 8173-1175)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Sabine Wöhl

Berufsbildung

#### Sabine Wöhl

Berufsbildung

* [+49 331 8173-1125](tel:+49 331 8173-1125)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

In diesem Statistischen Bericht werden Ergebnisse zu Personen mit Ausbildungsvertrag, die sich zum Stichtag 31.12. in einer Ausbildung im dualen System befanden, dargestellt. Darüber hinaus gibt es Informationen zu Auszubildenden, die im Berichtsjahr ein Ausbildungsverhältnis angetreten oder vorzeitig gelöst haben sowie Teilnahmen an Abschlussprüfungen. Die Ergebnisse der Berufsbildungsstatistik dienen der Planung und Ordnung der Berufsausbildung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der beruflichen Schulen**  
Metadaten ab 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/9c9ed0901fa323b4/ea90a44d3dc6/MD_21211_2022.pdf)[Archiv](/search-results?q=21211&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-ii-5-j)
