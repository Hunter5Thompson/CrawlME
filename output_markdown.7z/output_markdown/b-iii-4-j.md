

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Hochschulen](/hochschulen)
* [Personal an Hochschulen in Berlin und Brandenburg](/b-iii-4-j)

Personal
an Hochschulen
-----------------------

#### 2023, jährlich

###### Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zum Personal zum 1. Dezember und Habilitationen im Kalenderjahr erhoben.

BerlinBrandenburgMethodik
### Berlin

1 einschließlich Verwaltungsfachhochschulen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/58c193c945c0c757/20f0dd478d11/SB_B03-04-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/923baba16225c59c/863b4628dd01/SB_B03-04-00_2023j01_BE.pdf)

**Hochschulpersonal in Berlin**

Im Jahr 2023 waren an den Berliner Hochschulen 57.093 Personen beschäftigt, davon 43.670 (76 %) an den Universitäten, 3.327 (6 %) an den Kunsthochschulen und 10.096 (18 %) an den Fachhochschulen (einschließlich Verwaltungsfachhochschulen).

Mehr als die Hälfte des Hochschulpersonals waren Frauen (57 %).

### Kontakt

#### Eike Müller

Hochschulen

#### Eike Müller

Hochschulen

* [0331 8173-1144](tel:0331 8173-1144)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Hochschulpersonal in Brandenburg**

Im Jahr 2023 waren an den Brandenburger Hochschulen 12.826 Personen beschäftigt, davon 9.121 (71,1 %) an den Universitäten, 3.085 (24,1 %) an den Fachhochschulen und 620 (4,8 %) an den Verwaltungsfachhochschulen.

Mehr als die Hälfte des Hochschulpersonals waren Frauen (51,4 %).

1 ohne Verwaltungsfachhochschulen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c514270745950b83/ed78c39ac9f9/SB_B03-04-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/472abd8f777984eb/bdf718487356/SB_B03-04-00_2023j01_BB.pdf)
### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Auskunftspflichtig sind die Hochschulverwaltungen. In die Erhebung einbezogen sind alle staatlichen und staatlich anerkannten Hochschulen. Die Statistiken werden auf der Basis der Verwaltungs­unterlagen der Auskunftspflichtigen als Totalerhebungen durchgeführt. Die Ergebnisse der Hochschulstatistiken bilden die Datenbasis für Entscheidungen im Bund, in den Ländern und in den Hochschulen selbst. Aber auch die verschiedensten öffentlichen und privaten Einrichtungen sind an den Ergebnissen stark interessiert, unter anderem die Hochschul­rektorenkonferenz, die Ständige Konferenz der Kultusminister und der Wissenschaftsrat.

Auch wenn es sich bei den Hochschulstatistiken um Bundesstatistiken handelt, so werden die Ergebnisse doch zunehmend durch Länderspezifika und Besonderheiten der Hoch­schulen beeinflusst. Zuordnungen können in den einzelnen Bundesländern voneinander abweichen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zu Stande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen, sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

**[Statistik des Personals  
(ab 2023)](https://download.statistik-berlin-brandenburg.de/bdb1671b7b6fb163/29f6ae87e9a7/MD_21341_2023.pdf)** | [Archiv](/search-results?q=21341&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Statistik der Habilitationen  
(ab 2019)](https://download.statistik-berlin-brandenburg.de/f0b964fdb231f329/ab06b8ce916b/MD_21351_2019.pdf)** | [Archiv](/search-results?q=21351&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-iii-4-j)
