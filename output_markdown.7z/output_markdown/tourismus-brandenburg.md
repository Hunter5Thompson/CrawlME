

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Tourismus in Brandenburg](/tourismus-brandenburg)

Tourismus in Brandenburg
========================

#### Entwicklung der Reisebranche 2018 bis 2023

ReisendeBranchenzahlenUrlaubsland Brandenburg[Tourismus in Berlin ➜](/tourismus-berlin)

Reisende
--------

##### 14,2 Millionen Übernachtungen von 5,2 Millionen Gästen wurden 2023 in den Brandenburger Beherbergungsbetrieben gezählt, 5,4 % mehr als 2022. Im Vergleich zu 2019 stieg die Zahl der Übernachtungen um 1,9 %. Das ist ein neuer Rekord seit Beginn der Erhebung im Jahr 1992. Alle Reisegebiete konnten bei den Übernachtungen punkten. Mit 2,2 Millionen Übernachtungen waren der Spreewald, gefolgt vom Seenland Oder-Spree (2,1 Millionen), die beliebtesten Reiseregionen. Den größten Zuwachs gegenüber 2022 verbuchte das Dahme-Seenland mit einem Plus von 15,8 %. Im Vergleich zu 2019 verzeichneten bei der Gästezahl und den Übernachtungen das Dahme-Seenland (+148.000; +227.000), der Spreewald (+23.000; +112.000) und die Prignitz (+9.000; +92.000) Zuwächse. Das Barnimer Land (+54.000), das Lausitzer Seenland (+41.000), die Stadt Potsdam (+23.000) und der Fläming (+13.000) übertrafen bei den Übernachtungen die Ergebnisse von 2019.

###### Veränderung im Vergleich zum Vorjahr

#### Übernachtungen 2023 in Brandenburgs Reisegebieten

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Branchenzahlen
--------------

##### In der Brandenburger Wirtschaft spielt das Gastgewerbe eine wichtige Rolle. Es setzt sich aus der Gastronomie und dem Beherbergungsgewerbe zusammen. 2023 gab es acht Beherbergungsbetriebe mehr als im Vorjahr. Auch bei den Gaststätten konnte ein Aufschwung verzeichnet werden, nachdem die Zahl in den Jahren der Corona-Pandemie zurückgegangen ist. Bei den Auszubildenden zeigt sich 2022 zumindest in der Gastronomie ein Aufwärtstrend. Die Zahl stieg auf 375 Auszubildende, 2021 waren es noch 345. In der Hotellerie wurden 2022 insgesamt 18 Auszubildende weniger als im Vorjahr gezählt, hier setzt sich der Negativtrend fort.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 Vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg1 2022 vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Urlaubsland Brandenburg
-----------------------

##### Unzählige Ausflugsziele und Sehenswürdigkeiten locken Gäste in die verschiedenen Reiseregionen Brandenburgs. Das Bundesland ist zu ungefähr einem Drittel mit Wald bedeckt und hat mit 3,4 % einen beachtlichen Anteil an Gewässern. Teichland hat unter allen Gemeinden mit 30,3 % den größten [Flächenanteil](/flaechennutzung) an Gewässer an der Gesamtbodenfläche. 1.824 Sonnenstunden und 70 Sommertage über 25 Grad konnten die über 5 Millionen Gäste 2023 in Brandenburg genießen, 266 Sonnenstunden weniger und einen warmen Tag mehr als im Vorjahr. Am Flughafen BER Berlin-Brandenburg wurden rund 23 Millionen Passagiere abgefertigt und damit 3 Millionen mehr als 2022.

###### Am 31.12.2022 in Brandenburger Gemeinden

#### Fläche für Gewässer

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

WasserflächeFläche Sport und Freizeit**Quelle:**  Wetterstation Potsdam, 20232 Erweiterung der Gesamtfläche 2021**Quelle:** Landesamt für Umwelt BrandenburgFlughäfen Tegel, Schönefeld und BER: Schließung des Flughafen Tegel am 08.11.2020; Eröffnung des Flughafen Berlin Brandenburg am 31.10.2020; Stilllegung des Flughafen Schönefeld am 22.2.2021**Quelle:** Statistisches Bundesamt

Publikationen zum Thema
-----------------------

[![Bedienung mit zwei Desserttellern in Restaurantküche](https://download.statistik-berlin-brandenburg.de/d3aee91e75d08b10/db8fc675bf3d/v/c09a768605ad/AdobeStock_280942571.jpg "Bedienung mit zwei Desserttellern in Restaurantküche")](/163-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Berlin**[#### Gemischte Entwicklung im Einzelhandel und Gastgewerbe](/163-2024)

Der Berliner Einzelhandel meldete im 3. Quartal 2024 ein reales Umsatzplus von 1,3 % gegenüber dem Vorjahreszeitraum.

[![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)](/164-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Brandenburg**[#### Einzelhandel wächst, Gastgewerbe schwächelt](/164-2024)

Der Brandenburger Einzelhandel meldete im 3. Quartal 2024 eine reale Umsatzsteigerung um 1,7 % gegenüber dem Vorjahreszeitraum....

[![iStock.com / Vladislav Zolotov](https://download.statistik-berlin-brandenburg.de/87f608040b23d410/f253909b08b6/v/52f2573769ca/bevoelkerung-demographie-tourismus-old-market-square-with-st-nicholas-church-and-town-hall-potsdam-picture-id1209637381.jpg "iStock.com / Vladislav Zolotov")](/156-2024)**Tourismus Januar bis September 2024 Brandenburg**[#### Weiter auf Erfolgskurs](/156-2024)

Die Brandenburger Beherbergungsbetriebe zählten von Januar bis September 2024 insgesamt 4,3 Millionen Gäste mit 11,6 Millionen Übernachtungen.

Mehr anzeigen
