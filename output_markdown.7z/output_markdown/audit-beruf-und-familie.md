

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Karriere](/karriere)
* [audit berufundfamilie](/audit-beruf-und-familie)
#### Für eine familienbewusste Personalpolitik

audit berufundfamilie
=====================

Das audit berufundfamilie unterstützt Arbeitgeber darin, die familien- und lebensphasenbewusste Personalpolitik nachhaltig zu gestalten. Es ist das zentrale Angebot der berufundfamilie Service GmbH und beruht auf einer Initiative der Gemeinnützigen Hertie-Stiftung. Mit dem audit berufundfamilie entwickeln wir nachhaltig unsere **Unternehmenskultur**weiter und sichern somit die Innovationsfähigkeit des Amtes bei seinen Personalprozessen.

### **Ziel der Re-Auditierung**

Mit dem audit berufundfamilie entwickeln wir unsere familien- und lebensweltbewusste Personalpolitik systematisch weiter. In den ersten beiden Auditierungsphasen haben wir ein umfangreiches Spektrum an Unterstützungsangeboten zur Vereinbarkeit von Beruf, Familie und Privatleben etabliert. Diesen Weg wollen wir fortsetzen und die Angebote passgenau verstetigen bzw. erweitern.

Ziel ist eine hohe Arbeitszufriedenheit und damit auch Leistungsfähigkeit unserer Beschäftigten. Nur so können wir unseren Dienstleistungsauftrag mittel- und langfristig erfüllen. Gelebte Vereinbarkeitsförderung ist in unserem Verständnis fest mit einer Vertrauenskultur verbunden, die auf gegenseitiger Wertschätzung, Verantwortung füreinander und Solidarität beruht.

Die Weiterentwicklung unserer familien- und lebensweltbewussten Führungskultur und damit auch die Erarbeitung einer gemeinsamen Haltung zu den Flexibilitäts- und Leistungsanforderungen in einer sich dynamisch entwickelnden Gesellschaft haben wir uns als Ziel für den weiteren Kulturwandel im Amt für Statistik Berlin-Brandenburg gesetzt.

![](https://download.statistik-berlin-brandenburg.de/7828e3f0d663af16/ce5fd5edfce1/v/e5ee95b4b430/audit_bf_rz_18_RGB.png)[Mehr über berufundfamilie.de](https://www.berufundfamilie.de)
### Am 30. September 2024 wurde das AfS zum dritten Mal mit dem Zertifikat „audit berufundfamilie“  ausgezeichnet.

[Download Zertifikat](https://download.statistik-berlin-brandenburg.de/aad6d36b141b958b/85c763bf56c0/Zertifikat_audit-beruf-und-familie.pdf)
### Durchgeführte Maßnahmen

Die Fortführung des Jobtickets und des Nextbike-Angebots wurden geprüft und um das Deutschlandticket-Job sowie Urban Sports erweitert.Es wurden zielgruppenspezifische Personalentwicklungsangebote zur Förderung der Digitalkompetenz entwickelt und angeboten.Die Angebote zur Vereinbarkeitsförderung wurden beim Recruiting und beim Onboarding explizit adressiert.In Jahresgesprächen werden bedarfsgerecht zusätzlich Themen wie Umsetzung flexibler Arbeitsformen, Arbeitsorganisation im Team sowie Vereinbarkeit von Beruf, Familie und Privatleben berücksichtigt.Die umfangreichen Angebote zum betrieblichen Gesundheitsmanagement wurden situativ angepasst. Beschäftigte und Führungskräfte wurden zur Inanspruchnahme ermutigt.Der Arbeitszeitrahmen wurde auf freiwilliger Basis auf Samstag erweitert.Die Umwandlungsmöglichkeiten der Jahressonderzahlung in Sonderurlaub wurden verstetigt
### Zukünftige Maßnahmen

Der Transformationsprozess führt zu neuen Haltungen. Damit werden die kulturellen Voraussetzungen geschaffen, um Veränderungen und Vereinbarkeitsthemen anzusprechen und einzufordern.Die Digitalisierung wird vorangetrieben, so dass möglichst alle Arbeitsplätze für ortsflexibles Arbeiten geeignet sind.Das betriebliche Gesundheitsmanagement wird bedarfsgerecht u. a. um E-Learning-Inhalte und gesundes Führen weiterentwickelt.Um eine verbindliche, einheitliche Haltung sowie einen verantwortungsvollen Umgang mit dem Homeoffice zu erreichen, entwickelt das Kulturwandelteam zusammen mit den Beschäftigten und Führungskräften einen Prototypen für das mobile Arbeiten.Modernes und agiles Führen wird im Rahmen des Transformationsprozesses gefördert (u. a. Curriculum zur systematischen Führungskräfteentwicklung).Die Prozesse zur Begleitung familienbedingter Freistellungen wie Eltern- oder Pflegezeit werden verschlankt.
