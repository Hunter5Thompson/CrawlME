

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 26.06.2024

#### Erfolgreich abgeschlossen

26. Konferenz „Messung der Preise“
----------------------------------

![Zwei Hände zeigen mehrere auf Geldstapel](https://download.statistik-berlin-brandenburg.de/58fe59e64c6fdbe7/36a55dc57069/v/994e168388ea/preise-geld-inflation-iStock-1454520770-web.png "Zwei Hände zeigen mehrere auf Geldstapel")

**Auch in diesem Jahr fand unsere jährliche Konferenz zur Messung der Preise statt, bei der Vertreterinnen und Vertreter der Statistischen Ämter des Bundes und der Länder, der Deutschen Bundesbank, der Europäischen Zentralbank (EZB) und der Wissenschaft zusammenkamen.**

Über zwei Tage hinweg wurden ein breites Spektrum an interessanten Themen vorgestellt und intensiv diskutiert. Der rege Austausch erwies sich erneut als zentraler Bestandteil der Zusammenarbeit, wobei viele neue Impulse und Ideen gewonnen wurden. Ein großes Thema in diesem Jahr war die Preisentwicklung im Bereich Wohnen. Dieses Thema wurde durch drei verschiedene Vorträge umfassend beleuchtet und bot reichlich Diskussionsstoff. Doch nicht nur die Vorträge, sondern auch die informellen Gespräche rund um die Konferenz trugen maßgeblich zum Erfolg der Veranstaltung bei.

#### Feedback der Teilnehmenden

**Sybille Aßmann vom Thüringer Landesamt für Statistik** betonte, wie einzigartig und wertvoll die Konferenz zur Messung der Preise (KMdP) ist: „Die KMdP ist in ihrem Format sehr gelungen. Sie widmet sich ausschließlich dem Thema der Preisentwicklung und bietet eine hohe Kontaktintensität zwischen den Teilnehmern – den Datenproduzenten und den Datennutzern. Der Austausch führt häufig zu den berühmten AHA-Effekten, wenn beide Seiten neue Erkenntnisse gewinnen. Zudem hat die Konferenz eine gewisse Exklusivität, da die Themen intensiv diskutiert und bilateral vertieft werden können.“

**Dr. Thomas Knetsch von der Deutschen Bundesbank** erläuterte, warum die Konferenz für die Bundesbank so wichtig ist: „Wir als Nutzer der Preisstatistiken schätzen den offenen und intensiven Austausch mit den Kolleginnen und Kollegen der Statistischen Ämter, anderen Behörden und der Wissenschaft. Die tiefen Einblicke in die Statistikproduktion und Informationen zu geplanten methodischen Änderungen und neuen Datenquellen sind für unsere Analysen und Prognosen der Preisentwicklung von hohem Wert. Die Konferenz bietet uns auch die Möglichkeit, unsere Anliegen zu platzieren und uns aktiv einzubringen.“

![](https://download.statistik-berlin-brandenburg.de/1a44ac5d52dcab49/c4e4b232fe0d/v/8d57b7242738/gruppenfoto-messung-der-preise-2024.jpg)

**Stephanie Hirner vom Statistischen Bundesamt** hob die Vielfalt der Vorträge und die daraus resultierenden Diskussionen hervor: „Durch die breite Mischung bei den Vorträgen ergaben sich interessante Gespräche in den Diskussionen und Pausen. Der Austausch auch außerhalb der Verbundgremien ermöglicht es uns, die Sichtweisen der Nutzenden unserer Statistiken besser zu verstehen und Denkansätze aus der Wissenschaft zu diskutieren. Die Konferenz bot viele Möglichkeiten für einen erfolgreichen Austausch.“

###### Insgesamt war die Konferenz ein voller Erfolg und zeigte einmal mehr die Bedeutung des fachlichen Austauschs und der Vernetzung zwischen den verschiedenen Institutionen und Bereichen.

###### Hier finden Sie die freigegebenen Präsentationen der Teilnehmenden als Download:

Tag 1Tag 2
### Programm am Donnerstag, 6. Juni

| **Uhrzeit** | **Thema** | **Download Präsentation** |  |
| --- | --- | --- | --- |
| 12:30 Uhr | Get-together |  |  |
| 13:00 Uhr | **Begrüßung**Violetta Kaufmann/Katja Kirchner (Amt für Statistik Berlin-Brandenburg) |  |  |
| 13:20 Uhr | **Explorative Analyse der regionalen Preise für Wohnimmobilien in Deutschland**Prof. Dr. Andreas Nastansky (Hochschule für Wirtschaft und Recht Berlin) |  |  |
| 14:10 Uhr | **Selbstgenutztes Wohnen im (harmonisierten) Verbraucherpreisindex ((H)VPI)**Christoph-Martin Mai (Statistisches Bundesamt) |  |  |
| 15:00 Uhr | Pause |  |  |
| 15:30 Uhr | **Aktualisierung der Mietenstichprobe im Verbraucherpreisindex (VPI)**Timm Behrmann (Statistisches Bundesamt) |  |  |
| 16:20 Uhr | **(Disaggregierte) Inflationsprognose aus Zentralbank-Sicht** Dr. Elisabeth Wieland (Deutsche Bundesbank) |  |  |
| 18:30 Uhr | Gemeinsames Abendessen in der „L’Osteria Potsdam“Humboldtstraße 1, 14467 Potsdam |  |  |
|  |  |

### Kontakte

#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* News](/search-results?q=tag%3ANews)[* Konferenz](/search-results?q=tag%3AKonferenz)[* Messung der Preise](/search-results?q=tag%3AMessung der Preise)[* Tagung](/search-results?q=tag%3ATagung)
