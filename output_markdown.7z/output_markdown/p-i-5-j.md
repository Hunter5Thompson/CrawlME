

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Bruttoinlandsprodukt und Bruttowertschöpfung in den kreisfreien Städten und Landkreisen in Brandenburg](/p-i-5-j)

Bruttoinlandsprodukt und Bruttowert­schöpfung in den kreisfreien Städten und Land­kreisen Brandenburgs
------------------------------------------------------------------------------------------------------

#### 1992 und 1994 bis 2022, jährlich

###### Das Bruttoinlandsprodukt (BIP) misst alle im Inland produzierten Güter und Dienstleistungen abzüglich der Vorleistungen. Dabei drückt die Veränderungsrate des preisbereinigten BIP die wirtschaftliche Entwicklung einer Region aus und wird auch als Wirtschaftswachstum bezeichnet.

BrandenburgMethodik
### Brandenburg

**Stärkstes Wachstum in Oder-Spree**

Das Bruttoinlandsprodukt (BIP) in jeweiligen Preisen stieg 2022 gegenüber dem Vorjahr in den kreisfreien Städten um 5,3 % und in den Landkreisen um 10,9 % auf 17.822 Millionen EUR bzw. 70.905 Millionen EUR. Die Veränderungsraten des BIP gegenüber dem Vorjahr bewegten sich in den Kreisen zwischen +4,0 % im Landkreis Oberspreewald-Lausitz und +23,2 % im Landkreis Oder-Spree.

Die kreisfreien Städte steigerten sich beim BIP je erwerbstätige Person um 4,5 % und die Landkreise um 9,7 % gegenüber dem Vorjahr. Die Landkreise erwirtschafteten über 10.000 EUR mehr je erwerbstätige Person als die kreisfreien Städte. Spitzenreiter beim BIP je erwerbstätige Person war Spree-Neiße mit 123.023 EUR. Das war fast doppelt so viel wie in Frankfurt (Oder) mit 64.817 EUR.

**Quelle:** Volkswirtschaftliche Gesamtrechnungen der Länder; Berechnungsstand: August 2023
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/b9abb994ec460f58/dca04bd0eb8f/SB_P01-05-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/2d3766f1db7d5434/315222dfd3f8/SB_P01-05-00_2022j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das BIP umfasst den Wert aller innerhalb eines Wirtschaftsgebietes während einer bestimmten Periode produzierten Waren und Dienstleistungen. Es entspricht der BWS aller Wirtschaftsbereiche zuzüglich der Gütersteuern und abzüglich der Gütersubventionen. Die BWS ergibt sich aus der Differenz der Produktionswerte und der Vorleistungen in den einzelnen Wirtschaftsbereichen.

Die Kreisergebnisse sind auf das Ergebnis des Landes Brandenburg, das am 30. März veröffentlicht wurde, abgestimmt und werden von den jeweiligen statistischen Ämtern der Länder nach im Arbeitskreis „Volkswirtschaftliche Gesamtrechnungen der Länder“ abgestimmter einheitlicher Methoden für das eigene Land berechnet.

Ergebnisse für alle Kreise Deutschlands und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/p-i-5-j)
