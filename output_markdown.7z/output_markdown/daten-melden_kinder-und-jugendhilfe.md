

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Daten melden](/daten-melden)
* [Kinder- und Jugendhilfe](/daten-melden/kinder-und-jugendhilfe)
#### Daten melden

Kinder- und Jugendhilfe
=======================

### Kinder- und Jugendhilfe

| **Statistik** | **IDEV bzw. andere Online-Meldewege** | | **eSTATISTIK.core** | **Musterformular** |  |
| --- | --- | --- | --- | --- | --- |
|  | Berlin | Brandenburg | Berlin/Brandenburg |  |  |
| Statistik der erzieherischen Hilfe, der Eingliederungshilfe für seelisch Behinderte und der Hilfe für junge Volljährige | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik über den Schutzauftrag bei Kindeswohlgefährdung | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik der Adoptionen –Adptionsvermittlung | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) |  |  |  |
| Statistik der Adoptionen –Adoptierte Kinder und Jugendliche | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) |  |  |  |
| Statistik der Pflegeerlaubnis, Pfleg-, Vormund-, Beistandschaften, Sorgeerklärungen, Maßnahmen des Familiengerichts | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) |  |  |  |
| Statistik der vorläufigen Schutzmaßnahmen | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | IDEV | .ecore |  |  |
| Statistik der Angebote der Jugendarbeit | IDEV | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik der Kinder und tätigen Personen in Tageseinrichtungen**Hinweis:** **diese Datei läuft nur unter 32bit-Office** [XLSM](https://download.statistik-berlin-brandenburg.de/ca68659971b04e01/50ac7e282a14/JHIII_1_2024.xlsm)| [Info-Material](https://download.statistik-berlin-brandenburg.de/063093d715f9dfd8/4d5e56e660f2/KITA_Info.pdf) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik der Träger der Jugendhilfe, die dort tätige Personen und deren Einrichtungen mit Ausnahme der Tageseinrichtungen  | [Info-Material](https://download.statistik-berlin-brandenburg.de/95407621146467b3/7254dc3d27cc/Infoblatt_Einrichtungen_2022.pdf) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik der Kinder und tätigen Personen in öffentlich geförderter Kindertagespflege –Kinder in Kindertagespflege |  | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik der Kinder und tätigen Personen in öffentlich geförderter Kindertagespflege –Kindertagespflegepersonen |  | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) | [.ecore](https://core.estatistik.de/core/) |  |  |
| Statistik über Personen in Großtagespflegestellen und die dort betreuten Kinder |  | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) |  |  |  |
| Statistik der Ausgaben und Einnahmen der Kinder- und Jugendhilfe –kommunales Systematik | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) |  |  |  |
| Statistik der Ausgaben und Einnahmen der Kinder- und Jugendhilfe –staatliche Systematik | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=11) | [IDEV](https://www.idev.nrw.de/idev/OnlineMeldung?inst=12) |  |  |  |
|  |  |

Wie funktioniert die Datenmeldung?
----------------------------------

1
-

**Postalische Aufforderung**

Sie haben eine postalische Aufforderung zur Datenmeldung vom Amt für Statistik Berlin-Brandenburg erhalten. Mit diesem Schreiben informieren wir Sie, zu welcher Statistik Sie meldepflichtig sind und warum. Jede Meldepflicht beruht auf einer gesetzlichen Grundlage. Sie erhalten in diesem Brief außerdem Informationen, wie und auf welchem Weg Sie uns Ihre Daten melden können.

2
-

**Unsere modernen Online-Meldewege**  


Mit modernen Online-Erhebungsverfahren bieten wir Ihnen kostengünstige und sichere Möglichkeiten zur Meldung Ihrer Daten. Sie tragen damit auch zu einer beschleunigten und kostengünstigeren Aufbereitung der Daten bei.

3
-

**Daten melden – einfach, schnell und sicher!**  


Für die elektronische Datenmeldung können unterschiedliche Verfahren (z. B. [IDEV](https://www.idev.nrw.de/), [eSTATISTIK.core](https://core.estatistik.de/core/), [Erhebungsportal](https://erhebungsportal.estatistik.de/)) und Zugänge Verwendung finden. Dies ist abhängig von der jeweiligen Erhebung, für die Sie meldepflichtig sind. Darüber hinaus erhebt beispielsweise der Mikrozensus Daten durch sogenannte Erhebungsbeauftragte. Dabei werden die Daten in einem direkten Gespräch bei Ihnen erfragt. Wenige Statistiken werden mit klassischen Papier- oder PDF-Erhebungsbögen durchgeführt.

4
-

**Was passiert mit meinen Daten?**

Sobald Sie Ihre Daten an das Amt für Statistik Berlin-Brandenburg übermittelt haben, werden diese ausgewertet. Ihre Daten werden dabei streng vertraulich behandelt und ausschließlich für statistische Zwecke verwendet. Sobald die Daten ausgewertet sind, veröffentlichen wir sie für unsere Kundinnen und Kunden. So kommen wir unserem gesetzlichen Auftrag nach, der Regierung, Wirtschaft und Öffentlichkeit Daten über die wirtschaftliche und soziale Lage, die demografische Entwicklung und die Situation der Umwelt zu liefern.  

Das IDEV-Verfahren
------------------

**IDEV steht für »Internet DatenErhebung im Verbund« und ermöglicht eine formularbasierte Eingabe von Daten und das Hochladen von Dateien. Die Daten werden verschlüsselt übertragen. Das Online-Meldeverfahren IDEV wurde in Zusammenarbeit der Statistischen Ämter des Bundes und der Länder entwickelt.**

[Mehr erfahren](/wie-funktioniert-idev)

Das VerfahreneSTATISIK.core
---------------------------

**eSTATISTIK.core steht für »Common Online Rawdata Entry« und unterstützt die automatisierte Gewinnung der statistischen Rohdaten aus den betrieblichen Daten von Unternehmen und Behörden sowie die medienbruchfreie Übermittlung an die zentrale Online-Dateneingangsstelle.**

[Mehr erfahren](/estatistikcore)
