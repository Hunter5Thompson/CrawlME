

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Familienplanung](/familienplanung)

Familienplanung
===============

Die Statistik der Schwangerschaftsabbrüche ist eine Vollerhebung von Eingriffen zur vorzeitigen Beendigung einer Schwangerschaft. Sie gibt einen Überblick über die Größenordnung, Struktur und Entwicklung der Schwangerschaftsabbrüche sowie über ausgewählte Lebensumstände der betroffenen Frauen.

Mit der Erfassung von Beratungen zu Schwangerschaftskonflikten und Schwangerschaften stehen im Land Brandenburg auch Informationen zur Anzahl der Ratsuchenden, ihrem Alter und zu sozialen Aspekten zur Verfügung.

Statistische BerichteZeitreihenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg, jährlich (AIV11-j)](/a-iv-11-j)[Schwangerschaftskonflikt-, Schwangerschaftsberatung, Familienplanung und Sexualberatung in Brandenburg, jährlich (AIV14-j)](/a-iv-14-j)

Zeitreihen
----------

Schwangerschaftsabbrüche nach WohnsitzSchwangerschaftsabbrüche je 1.000 Frauen**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/6feb17795b7f4326/9bfa82116d4f/schwangerschaft-lange-reihe-2021.xlsx)

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=statistic&levelindex=0&levelid=1716554797658&code=23311#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-911294692.jpg](https://download.statistik-berlin-brandenburg.de/b9a043893d30e706/465ecd813a37/v/46bb53e012f2/familie-schwangerschaft.jpg "iStock-911294692.jpg")](/097-2024)**Schwangerschaftsabbrüche 2023 in Berlin und Brandenburg**[#### Zahl der Abbrüche in Berlin gesunken, in Brandenburg gestiegen](/097-2024)

2023 wurden 12.673 Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg gemeldet.

[![](https://download.statistik-berlin-brandenburg.de/7667e6272d15025b/a640fc6f30aa/v/ed29ab2a10f1/schwangerschaftsabbruch-iStock-1382489025.jpg)](/a-iv-11-j)**2023, jährlich, A IV 11 – j**[#### In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg](/a-iv-11-j)

Jährliche Statistik über in Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg

[![](https://download.statistik-berlin-brandenburg.de/7667e6272d15025b/a640fc6f30aa/v/ed29ab2a10f1/schwangerschaftsabbruch-iStock-1382489025.jpg)](/087-2023)**Schwangerschaftsabbrüche 2022 in Berlin und Brandenburg**[#### Zahl der Abbrüche um mehr als 10 Prozent gestiegen](/087-2023)

Insgesamt 12 496 Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg wurden 2022 gemeldet.

[Zu unseren News](/news)

[* Schwangerschaftsabbruch](/search-results?q=tag%3ASchwangerschaftsabbruch)
