

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Tourismus in Brandenburg nach Gemeinden](/g-iv-8-m)

Tourismus in Brandenburg nach Gemeinden
---------------------------------------

#### Oktober 2024, monatlich

###### Die Erhebung informiert zu ausgewählten Tourismusdaten zu Beherbergungsbetrieben auf Gemeindeebene und für einen Kalendermonat.

BrandenburgMethodik
### Brandenburg

**Tourismusergebnisse Oktober 2024**

Die Top fünf Gemeinden mit den meisten Übernachtungen in den Beherbergungsbetrieben im Land Brandenburg im Oktober 2024 waren Potsdam (139.636), Schönefeld (74.601), Burg (Spreewald) (51.350), Rheinsberg (51.043) und Templin (42.823).

Potsdam führt mit 58 geöffneten Beherbergungsbetrieben das Ranking bei der Anzahl der Betriebe an. Spitzenreiter bei der Auslastung der Betten war die Gemeinde Buckow (Märkische Schweiz) mit 80,5 %.

Das Land Brandenburg gliedert sich in 413 Gemeinden, wovon Brandenburg an der Havel, Cottbus, Frankfurt (Oder) und die Landeshauptstadt Potsdam kreisfrei sind. Die übrigen Gemeinden gehören einem der 14 Landkreise an.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/888715a4dacb90ff/3744f8bdb799/SB_G04-08-00_2024m10_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/7737faed2dcd3293/54bc382c8861/SB_G04-08-00_2024m10_BB.pdf)
### Kontakt

#### Stefanie Chlebusch

Tourismus

#### Stefanie Chlebusch

Tourismus

* [0331 8173-3586](tel:0331 8173-3586)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de )
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Beherbergungsstätten und Campingplätze bilden zusammen die Gesamtheit der Beherbergungsbetriebe. Zu den Beherbergungsstätten zählen die Hotellerie (Hotels, Hotels garnis, Gasthöfe, Pensionen), das Sonstige Beherbergungsgewerbe (Hütten und Jugendherbergen, Erholungs-, Ferien- und Schulungsheime, Boardinghouses, Ferienzentren, Ferienhäuser und -wohnungen) sowie Vorsorge- und Rehabilitationskliniken. Hierzu zählen auch Unterkunftsstätten, die die Gästebeherbergung nicht gewerblich und/oder nur als Nebenzweck betreiben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatserhebung im Tourismus**  
Metadaten ab 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/55944d847fb1b217/29a451146908/MD_45412_2024.pdf)[Archiv](/search-results?q=MD_45412&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-iv-8-m)
