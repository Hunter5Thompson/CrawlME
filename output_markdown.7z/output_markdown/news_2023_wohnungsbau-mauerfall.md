

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 29.09.2023

#### Historisches

Im Jahr des Mauerfalls rund 20.000 Wohnungen in Berlin gebaut
-------------------------------------------------------------

![iStock.com / hanohiki](https://download.statistik-berlin-brandenburg.de/b29702c3d0d2d6a7/661284573220/v/39622a003baa/gesellschaft-soziales-plattenbau-building-facade-picture-id645531666.jpg "iStock.com / hanohiki")

**In der Rubrik *Bautätigkeit und Wohnungen* des ersten Statistischen Taschenbuchs [1] für Gesamt-Berlin nach dem Mauerfall finden sich Statistiken zu Wohnungen, Wohnfläche und Baufertigstellungen. Neben einer Vielzahl von Indikatoren zur Wohnungsversorgung im Jahr 1989 wird die Wohnungssituation für Berlin-Ost und -West sowie für die Bezirke vorgestellt.**

Die meisten Einwohnerinnen und Einwohner Berlins lebten 1989 in Mietwohnungen im Geschosswohnungsbau, der durchschnittlich 2,5 Wohnräume je Wohnung aufwies und zu einem Drittel vor 1919 entstand. Mit einem Wohnungsbestand von 1.728.082 Wohnungen kamen auf 1.000 Einwohnerinnen und Einwohner 506 Wohnungen. Rund drei Jahrzehnte später hat sich der Wohnungsbestand auf 2.014.562  Wohnungen erhöht, sodass 536 Wohnungen je 1.000 Einwohnerinnen und Einwohner zur Verfügung standen.

###### Wohnfläche in Berlin-Ost deutlich geringer als in Berlin-West

Dieser Zuwachs ging gleichzeitig mit einem größeren Zuschnitt der Wohnungen einher: 2022 war eine Berliner Wohnung im Schnitt 73,2 m2 groß. [2] Mit 61,3 m2 war die durchschnittliche Wohnfläche in Berlin-Ost 1989 rund 12 m2 kleiner – auch gegenüber Berlin-West mit einer durchschnittlichen Fläche von 69,5 m2. Diese Unterschiede spiegeln sich auch in der Wohnfläche je Person wider: 1989 lag diese im Westteil der Stadt bei 37,4 m2, im Ostteil bei 30,4 m2. Besonders die vom Wohnungsneubau geprägten Bezirke in Berlin-Ost wiesen eine geringere Wohnfläche je Person gegenüber den bürgerlichen Wohnbauten der Gründerzeit auf: So reichte die Wohnfläche je Person auf Ebene der Bezirke von 24,3 m2 in Marzahn bis 43,8 m2 in Wilmersdorf. 

**Quelle:** Statistisches Landesamt Berlin (1990): Berliner Bezirke. Statistisches Taschenbuch. Kulturbuch-Verlag GmbH.
###### 1989 Wohnungsneubau fast ausschließlich in den östlichen Randbezirken

Deutliche Unterschiede zwischen dem Ost- und dem Westteil Berlins zeigten sich ebenfalls in den Baufertigstellungen des Jahres 1989. Während bis weit in die 1980er Jahre hinein in den Randbezirken von Berlin-Ost Wohngebäude in Plattenbauweise entstanden, lag der Bau der Großwohnsiedlungen in Berlin-West, wie das Märkische Viertel im Bezirk Reinickendorf und Gropiusstadt im Bezirk Neukölln, bereits mehr als ein Jahrzehnt zurück.

So wurden 1989 in Berlin-West mit 4 883 Wohnungen beziehungsweise 2,3 Wohnungen je 1.000 Einwohnerinnen und Einwohner deutlich weniger Wohnungen als in Berlin-Ost fertiggestellt. In Berlin-Ost wurden im gleichen Jahr dreimal so viele Wohnungen (14.867) gebaut, sodass auf 1 000 Einwohnerinnen und Einwohner 11,6 neue Wohnungen kamen. Fast drei Jahrzehnte später liegt die Zahl an Baufertigstellungen neuer Wohnungen unter dem Niveau von 1989: 2022 konnten 17.310 Wohnungen fertiggestellt werden [3] – dies entspricht 4,6 Wohnungen je 1.000 Einwohnerinnen und Einwohnern. 

###### Plattenbauwohnungen boten Komfort

Die enorme Bautätigkeit in Berlin-Ost konzentrierte sich 1989 hauptsächlich auf den östlichen Randbezirk Hellersdorf: 67,6 % (10.054) aller Wohnungen im Ostteil wurden hier gebaut. Auf 1.000 Einwohnerinnen und Einwohner kamen 91,8 Neubauwohnungen. Die Plattenbauwohnungen waren zur Zeit ihrer Entstehung begehrt, da diese Wohnungen im Gegensatz zu den damaligen Altbauwohnungen mit standardisiertem Komfort wie fließendem warmen und kalten Wasser, Zentralheizung, Toilette in der Wohnung und Badewanne ausgestattet waren. In Hellersdorf gehörte zu 95,8 % aller Wohnungen ein Bad oder eine Dusche – im Ostberliner Bezirk Friedrichshain traf dies nur auf 73,0 % der Wohnungen zu, da es sich in dem Bezirk vorrangig um Wohnungen mit unsanierter Altbausubstanz handelte.

###### Hintergrund

Anlässlich der Wiedereinigung Deutschlands im Jahr 1990 taten sich das Statistische Landesamt Berlin (West) und das Statistische Amt der Stadt Berlin (Ost), vormals Staatliche Zentralverwaltung für Statistik – Bezirksstelle Berlin, zusammen, um eine gemeinsame Veröffentlichung über alle Berliner Bezirke herauszubringen. Ergebnis war das seit langem erste Gesamtberliner Statistische Taschenbuch, das einerseits Ost und West gegenüberstellte und andererseits eine Zusammenführung der statistischen Angaben zu Gesamtberlin zuließ.

###### Quellen

[1] Statistisches Landesamt Berlin (1990): Berliner Bezirke. Statistisches Taschenbuch. Kulturbuch-Verlag GmbH.   
[2] [Amt für Statistik Berlin-Brandenburg (2018): Statistiken. Bauen und Wohnungen. Basisdaten Bautätigkeit.](/bauen-und-wohnungen)  
[3] [Amt für Statistik Berlin-Brandenburg (2019): Baufertigstellungen, Bauüberhang und Bauabgang in Berlin 2018. Statistischer Bericht F II 2 – j/22.](/f-ii-2-j)

Der Artikel erschien erstmals in der [*Zeitschrift für amtliche Statistik Berlin Brandenburg, Ausgabe 4/20**19*](https://www.statistischebibliothek.de/mir/receive/BBHeft_mods_00040749)und wurde hier um aktuelle Zahlen für das Jahr 2022 ergänzt.

### Kontakte

#### Iris Hoßmann-Büttner

Bevölkerungs- und Kommunalstatistik

#### Iris Hoßmann-Büttner

Bevölkerungs- und Kommunalstatistik

* [0331 8173-3624](tel:0331 8173-3624)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Historisches](/search-results?q=tag%3AHistorisches)[* Wohnungsbau](/search-results?q=tag%3AWohnungsbau)[* Wohngebäude](/search-results?q=tag%3AWohngebäude)[* Wohnungsgröße](/search-results?q=tag%3AWohnungsgröße)[* Wiedervereinigung](/search-results?q=tag%3AWiedervereinigung)
