

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Zensus](/bevoelkerung/zensus)
* [Zensus 2022](/zensus22)

Zensus 2022
===========

Der Zensus 2022  ist eine Bevölkerungsbefragung und aktuell das größte Projekt der amtlichen Statistik in Deutschland. Diese ermittelt, wie viele Menschen in Deutschland zum Stichtag 15. Mai 2022 lebten und wie sie wohnten und arbeiteten. Die Ergebnisse des Zensus 2022 liefern wichtige Daten und Informationen für Politik, Wirtschaft und Gesellschaft.

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)](/news/2024/zensus-generation-alpha)**Zensus 2022 in Berlin und Brandenburg**[#### So wächst die Generation Alpha auf](/news/2024/zensus-generation-alpha)

Der Zensus 2022 gibt Einblicke in die Einwanderungsgeschichte der Generation Alpha in Berlin und Brandenburg.

DashboardKleinräumige DatenBasistabellenWeitere DatenangeboteWeitere Informationen

Dashboard
---------

#### Interaktiver Überblick zu den wichtigsten Zahlen des Zensus 2022.

BerlinBrandenburgBevölkerung nach BezirkenGebäude und Wohnen nach BezirkenLaden...
###### Die Daten zum Dashboard **Bevölkerung** für Berlin können Sie hier herunterladen.

Kleinräumige Daten für Berlin bis auf Blockebene
------------------------------------------------

Ergebnisse zu Bevölkerung, Familien und Haushalten, Gebäuden und Wohnungen für Bezirksregionen, Planungsräume und Blockebenen

[Mehr erfahren](/zensus22/lokale-daten-berlin)

Kleinräumige Daten für Brandenburg bis auf Ebene der Ortsteile
--------------------------------------------------------------

Ergebnisse zu Bevölkerung, Familien und Haushalten, Gebäuden und Wohnungen für Gemeinden mit mindestens 30.000 Einwohnenden

[Mehr erfahren](/zensus22/lokale-daten-brandenburg)
###### Für den Zensus 2022 stehen **Basistabellen**zu den Themengebieten **Demografie, Gebäude, Wohnungen und Haushalte** zum Download bereit. Es handelt sich dabei um Ergebnisse auf Bezirksebene für Berlin sowie Landkreis- und Gemeindeebene für Brandenburg.

[Basistabellen Zensus 2022 Berlin](https://download.statistik-berlin-brandenburg.de/a9cf3ac18d95cdc0/d6af0d4cfde4/Zensus2022_Basistabelle_Berlin.xlsx)[Basistabellen Zensus 2022 Einwohnerzahlen Brandenburg](https://download.statistik-berlin-brandenburg.de/73bc575734573cbf/5b36f096055c/Zensus2022_Basistabelle_Bevoelkerung_Brandenburg.xlsx)[Basistabellen Zensus 2022 Demografie Brandenburg](https://download.statistik-berlin-brandenburg.de/94ac67cbc06c2f2a/c4e20c8f78b5/Zensus2022_Basistabelle_Demografie_Brandenburg.xlsx)[Basistabellen Zensus 2022 Haushalte Brandenburg](https://download.statistik-berlin-brandenburg.de/e138ed382a175d65/2351b87fb5f2/Zensus2022_Basistabelle_Haushalte_Brandenburg.xlsx)[Basistabellen Zensus 2022 Gebäude und Wohnungen Brandenburg](https://download.statistik-berlin-brandenburg.de/c49aec6b31f78518/4ccd2e04ec69/Zensus2022_Basistabelle_Gebaeude_Wohnungen_Brandenburg.xlsx)[Basistabellen Zensus 2022 Bildung und Erwerbstätigkeit Brandenburg](https://download.statistik-berlin-brandenburg.de/4652eb217951ed31/7926e03127b7/Zensus2022_Basistabelle_Bildung_Erwerbstaetigkeit_Brandenburg.xlsx)

Weitere Datenangebote
---------------------

#### Offizielle Website Zensus 2022

![](https://download.statistik-berlin-brandenburg.de/1d5abcf23464824e/ed5ef0a03a9a/v/5c148be7d084/zensus-website.jpg)

Auf der Zensus-Webseite finden Sie Informationen zu Methodik und Geheimhaltung. Außerdem stehen Podcasts, Videos und Animationen mit Hintergrundinformationen zur Verfügung.  
  


[Zur Webseite](https://www.zensus2022.de)
#### Zensus-Atlas

![](https://download.statistik-berlin-brandenburg.de/f8966f757dd9dfc6/b7442d5c4518/v/8ea009fced54/zensusatlas.PNG)

Die interaktive Anwendung umfasst Ergebnisse des Zensus 2011 und Zensus 2022 zu Bevölkerung, Gebäuden und Wohnungen und bietet kleinräumige Daten auf Gitterzellen-Basis (10 km, 1 km und 100 m) an – auch über Gemeindegrenzen hinaus.

[Zum Zensus-Atlas](https://atlas.zensus2022.de/)
#### Zensusdatenbank

![](https://download.statistik-berlin-brandenburg.de/01f175f9181d6f6a/fff06ec0b163/v/dfed144dd029/zensusdatenbank.PNG)

Die Datenbank enthält Ergebnisse des Zensus 2011 und Zensus 2022 zu Bevölkerung, Bildung und Erwerb, Haushalten, Familien, Gebäuden und Wohnungen bis auf Gemeindeebene. Verschiedene Ausgabeformate stehen zur Verfügung.

[Zur Zensusdatenbank](https://ergebnisse.zensus2022.de/)

Weitere Informationen
---------------------

#### Gesetzliche Grundlagen

###### EU-Verordnung

Die [EU-Verordnung 763/2008](https://eur-lex.europa.eu/LexUriServ/LexUriServ.do?uri=OJ%3AL%3A2008%3A218%3A0014%3A0020%3ADE%3APDF) verpflichtet die Mitgliedstaaten zur Erfassung von Bevölkerungs­ergebnissen.

###### Zensusvorbereitungsgesetz 2022

Den rechtlichen Rahmen für die vorbereitenden Arbeiten in Deutschland bildet das [Gesetz zur Vorbereitung eines registergestützten Zensus einschließlich einer Gebäude- und Wohnungszählung 2022](http://www.gesetze-im-internet.de/zensvorbg_2021/) (Zensus­vorbereitungs­gesetz 2022 – ZensVorbG 2022).

###### Zensusgesetz 2022

Die konkrete Durchführung des Zensus wird durch das [Gesetz zur Durchführung des Zensus im Jahr 2022](http://www.gesetze-im-internet.de/zensg_2021/index.html) (Zensusgesetz 2022 – ZensG 2022) geregelt. Mit dem Inkrafttreten des Gesetzes zur Verschiebung des Zensus am 10. Dezember 2020 steht als neuer Stichtag der 15. Mai 2022 fest. Die Ver­schiebung erfolgt aufgrund der Einschränkungen durch die Corona-Pandemie, die auch die Vorbereitungen des Zensus in der öffentlichen Verwaltung betreffen.

Weitere Informationen zu den gesetzlichen Grundlagen erhalten Sie auf der offiziellen [Zensus-Seite](https://www.zensus2022.de/DE/Was-ist-der-Zensus/Gesetze/_inhalt.html).

###### Gesetz zur Ausführung des Zensusgesetzes 2022 im Land Berlin

Die Durchführung des Zensus 2022 im **Land Berlin** regelte das am 14. September 2021 vom Abgeordnetenhaus von Berlin beschlossene [Gesetz zur Ausführung des Zensus­gesetzes 2022 im Land Berlin](https://gesetze.berlin.de/perma?d=jlr-ZensG2022AGBErahmen "Verknüpfung folgen") (GVBl. 77. Jahrgang Nr. 70).  
Dieses Gesetz trat am 25. September 2021 in Kraft und tritt am 31. Dezember 2031 außer Kraft.

###### Verordnung zur Durchführung des Zensus im Jahr 2022 im Land Brandenburg

Die Durchführung des Zensus 2022 im **Land Brandenburg** regelte die am 17. März 2021 von der Landesregierung des Landes Brandenburg beschlossene [Verordnung zur Durchführung des Zensus im Jahr 2022 im Land Brandenburg](https://bravors.brandenburg.de/verordnungen/zensv_2022 "Verknüpfung folgen") (Zensusverordnung 2022 – ZensV 2022) (GVBl. II/21,  
Nr. 29).  
Diese Verordnung trat am 24.03.2021 in Kraft und tritt   
am 31. Dezember 2030 außer Kraft. Diese regelt die Durchführung des Zensus 2022 im Land Brandenburg und die Aufgaben und Einrichtung der Zensus-Erhebungsstellen in den Landkreisen und kreisfreien Städten.

#### Datenschutz

Entsprechend [unseres Leitbildes](/ueber-uns#auftrag) ist der Schutz und die Vertraulichkeit der Daten eines der obersten Ziele. Als führender Informationsdienstleister für amtliche Statistik in Berlin und Brandenburg legen wir höchstes Augenmerk auf Sicherheitsvorkehrungen, die die Geheimhaltung Ihrer Daten garantieren.

Hinweise zum Datenschutz im Amt für Statistik Berlin-Brandenburg finden Sie [hier](/datenschutz).

Weitere Informationen zum Datenschutz im Projekt Zensus erhalten Sie auf der offiziellen [Zensus-Seite](https://www.zensus2022.de/DE/Wie-funktioniert-der-Zensus/Datenschutz-mehr-als-Pflicht.html?nn=442732).

#### Erhobene Merkmale

Die Ergebnisse des Zensus 2022 zeigen, wie die Menschen in Deutschland am 15. Mai 2022 lebten, wohnten und arbeiteten. Öffentlich zugänglich sind dabei die im Merkmalskatalog beschriebenen Merkmale.

[Zum Merkmalskatalog 2022](https://ergebnisse.zensus2022.de/datenbank/online/variables)

Haben Sie Fragen?
-----------------

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
#### Nutzen Sie auch das **Kontaktformular der****offiziellen [Zensus-Seite](https://www.zensus2022.de/DE/Service/Kontakt_Intelligent/_Kontakt.html)**.

Die FAQ-Suche hilft bei der Beantwortung Ihrer Frage.

#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![Schmuckbild Zensus 2022 Heizung und Gebäude](https://download.statistik-berlin-brandenburg.de/6566e7c034d35542/dc5b764f0d2f/v/9c28a2322780/Zensus.png "Schmuckbild Zensus 2022 Heizung und Gebäude")](/168-2024)**Zensus 2022 für Berlin und Brandenburg**[#### Zensusdaten ermöglichen Analysen unterhalb der Gemeindeebene](/168-2024)

Das Amt für Statistik Berlin-Brandenburg bietet ab sofort Auswertungen unterhalb der Gemeindeebene an.

[![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)](/news/2024/zensus-generation-alpha)**Zensus 2022 in Berlin und Brandenburg**[#### So wächst die Generation Alpha auf](/news/2024/zensus-generation-alpha)

Der Zensus 2022 gibt Einblicke in die Einwanderungsgeschichte der Generation Alpha in Berlin und Brandenburg.

[Zu unseren News](/news)

[* Zensuserhebung](/search-results?q=tag%3AZensuserhebung)[* Volkszählung](/search-results?q=tag%3AVolkszählung )[* Melderegister](/search-results?q=tag%3AMelderegister )[* Einwohnerzahlen](/search-results?q=tag%3AEinwohnerzahlen)[* Erhebungsbeauftragte](/search-results?q=tag%3AErhebungsbeauftragte )[* Haushaltebefragung](/search-results?q=tag%3AHaushaltebefragung )[* Registerzensus](/search-results?q=tag%3ARegisterzensus )[* Bevölkerungsbefragung](/search-results?q=tag%3ABevölkerungsbefragung )[* Interviewer](/search-results?q=tag%3AInterviewer)[* Zensus 2022](/search-results?q=tag%3AZensus 2022)
