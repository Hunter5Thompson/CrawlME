

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Verkehr](/gesellschaft/verkehr)
* [Personenverkehr](/personenverkehr)

Personenverkehr
===============

In der Verkehrswirtschaft werden Daten zur Personenbeförderung im Schienennahverkehr und im gewerblichen Omnibusverkehr erhoben.   
Alle fünf Jahre findet eine Vollerhebung statt, die jährlich und vierteljährlich   
durch Teilerhebungen unter den größten Unternehmen ergänzt wird.

Erhebungsinhalte sind Fahrgäste, Beförderungsleistung, Beförderungsangebot, Fahrleistungen und Einnahmen im Linienverkehr. Bei der 5-jährlichen Erhebung werden zusätzlich Infrastrukturangaben, Linienfahrzeuge und Beschäftigte erfragt.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg, fünfjährlich (HI5-5j)](/h-i-5-5j)[Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg, jährlich (HI6-j)](/h-i-6-j)

Zeitreihen
----------

**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/c1636c30db159655/4601b2d30cf4/Personenverkehr_Zeitreihe_2022_Berlin-Brandenburg.xlsx)

Basisdaten
----------

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=statistic&levelindex=0&levelid=1715161184085&code=46181#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/transport-und-verkehr)

Haben Sie Fragen?
-----------------

#### Viola Schulz

Verkehr

#### Viola Schulz

Verkehr

* [0331 8173-3269](tel:0331 8173-3269)
* [verkehr@statistik-bbb.de](mailto:verkehr@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Tram fährt über den Alexanderplatz](https://download.statistik-berlin-brandenburg.de/e12648f979ec67ea/1c8e62a04b67/v/15ac24a82ee9/gesellschaft-verkehr-blurred-motion-of-defocused-yellow-tram-on-berlin-streets-picture-id618551254.jpg "Tram fährt über den Alexanderplatz")](/h-i-6-j)**2023, jährlich, H I 6 – j**[#### Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg](/h-i-6-j)

Die jährliche Erhebung gibt Auskunft über das Angebot von Eisen- und Straßenbahnen im Nahverkehr bzw. Bussen im Nah- und Fernverkehr sowie Fahrgastzahlen und Einnahmen.

[![iStock-523278879.jpg](https://download.statistik-berlin-brandenburg.de/d113c81c0491995a/593bb5d7cbb7/v/f04a9deb8086/gesellschaft-verkehr-innenstadtverkehr.jpg "iStock-523278879.jpg")](/publikationen/fachbeitrag/2021/corona-verkehr)**Auswirkungen der Corona-Pandemie in der Region**[#### Fahrgäste im Liniennahverkehr und Unfallgeschehen](/publikationen/fachbeitrag/2021/corona-verkehr)

Corona-Beschränkungen wirkten sich auf die Mobilität der Bürgerinnen und Bürger und damit massiv auf den Straßen- und Linienverkehr aus....

[![Schmuckbild Kompaktseite](https://download.statistik-berlin-brandenburg.de/694065619520738d/21344150fa05/v/4b5fd1224575/schmuckbild-kompaktseite.jpg "Schmuckbild Kompaktseite")](/h-i-5-5j)**2019 fünfjährlich, H I 5 – 5j**[#### Personenverkehr mit Bussen und Bahnen in Berlin und Brandenburg](/h-i-5-5j)

Personenverkehr mit Bussen und Bahnen 2019, fünfjährlich Ergänzend zur jährlichen Erhebung infomieren die Strukturdaten über Linienlängen und Zahl der Linien, Schienenfahrzeuge und Omnibusse sowie...

[Zu unseren News](/news)

[* ÖPNV](/search-results?q=tag%3AÖPNV)[* Nahverkehr](/search-results?q=tag%3ANahverkehr)[* Fernverkehr](/search-results?q=tag%3AFernverkehr)[* Linienverkehr](/search-results?q=tag%3ALinienverkehr)[* Fahrgäste](/search-results?q=tag%3AFahrgäste)[* Unternehmen](/search-results?q=tag%3AUnternehmen)[* Personen-km](/search-results?q=tag%3APersonen-km)[* Omnibus](/search-results?q=tag%3AOmnibus)[* Straßenbahn](/search-results?q=tag%3AStraßenbahn)
