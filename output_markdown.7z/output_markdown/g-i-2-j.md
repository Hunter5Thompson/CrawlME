

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Handel](/wirtschaft/wirtschaftbereiche/handel)
* [Umsatz, Beschäftigung und Investitionen im Handel und Kraftfahrzeuggewerbe in Berlin und Brandenburg](/g-i-2-j)

Umsatz, Beschäftigung und Investitionen im Handel und Kraftfahrzeuggewerbe
--------------------------------------------------------------------------

#### 2020, jährlich

###### Die jährlichen Erhebungen im Groß- und Einzelhandel sowie im Kraftfahrzeughandel, einschließlich ‑instandhaltung und ‑reparatur liefern Informationen über die Struktur, Rentabilität und Produktivität der Unternehmen in diesen Wirtschaftsbereichen. Die Ergebnisse zu den Kennziffern Umsatz, tätige Personen, Bruttolohnsumme und Investitionen werden als absolute Werte dargestellt.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7551b2aec506b42b/4bd917d28d3b/SB_G01-02-00_2020j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/87e528cda5976620/6a86829e1102/SB_G01-02-00_2020j01_BE.pdf)

**Mehr als 143.000 tätige Personen im Einzelhandel**

Der Berliner Einzelhandel setzte im Geschäftsjahr 2020 rund 31 Milliarden EUR um. Mehr als 143.000 Personen waren in den Geschäften, an Marktständen und für den Onlinehandel tätig. Die ausgezahlten Bruttolöhne und -gehälter betrugen 3,2 Milliarden EUR. Insgesamt investierten die Einzelhändler mehr als 1 Milliarde EUR.

Der Kraftfahrzeughandel verbuchte Umsätze in Höhe von 7,7 Milliarden EUR. Die Autohäuser, Kfz-Werkstätten sowie der Handel mit Kfz-Teilen zählten mehr als 22.000 Mitarbeitende. Es wurden 650 Millionen EUR Bruttoentgelte gezahlt.

Die knapp 40.000 im Großhandel tätigen Personen erwirtschafteten rund 27 Milliarden EUR Umsatz. Die Bruttoentgelte beliefen sich auf 1,7 Milliarden EUR.

### Kontakt

#### Nadine Pierron

Handel Struktur

#### Nadine Pierron

Handel Struktur

* [0331 8173-1331](tel:0331 8173-1331)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Großhandelsumsatz übertrifft Einzelhandel**

Der 2020 im Brandenburger Einzelhandel erwirtschaftete Umsatz betrug 15,2 Milliarden EUR. Im stationären Einzelhandel und Onlinehandel arbeiteten gut 82.000 Personen. Es wurden mehr als 1,5 Milliarden EUR Bruttoentgelte gezahlt. Indessen investierten die Einzelhändler rund 240 Millionen EUR.

Der Kraftfahrzeughandel einschließlich Kfz-Werkstätten und Handel mit Kfz-Teilen meldete 5,2 Milliarden EUR Umsatz. In diesen Bereichen waren knapp 22.000 Personen tätig. Die Höhe der Bruttoentgelte lag bei 520 Millionen EUR.

Die Großhandelsumsätze übertrafen mit 15,7 Milliarden EUR die des Einzelhandels. Die Mitarbeitendenzahl war hingegen mit knapp über 25.000 Personen vergleichsweise gering. Für Bruttolöhne und -gehälter wurden 760 Millionen EUR aufgewendet.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c6f24b64483870cc/49ea9c9968ba/SB_G01-02-00_2020j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/9c29ca58e8c70763/fc9bf1674159/SB_G01-02-00_2020j01_BB.pdf)
### Kontakt

#### Nadine Pierron

Handel Struktur

#### Nadine Pierron

Handel Struktur

* [0331 8173-1331](tel:0331 8173-1331)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die jährlichen Erhebungen im Groß- und Einzelhandel sowie im
Kraftfahrzeughandel, der ‑instandhaltung und ‑reparatur liefern
Informationen über die Struktur, Rentabilität und Produktivität der
Unternehmen in diesen Wirtschaftsbereichen. Die Ergebnisse zu den
Kennziffern Umsatz, tätige Personen, Bruttolohnsumme und Investitionen
werden als absolute Werte dargestellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Jahresstatistik im Handel (einschl. Instandhaltung und Reparatur von Kfz)**  
Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/d34172b132333bc9/5d8b850f9ee8/MD_45341_2020.pdf)[Archiv](/search-results?q=MD_52111&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-i-2-j)
