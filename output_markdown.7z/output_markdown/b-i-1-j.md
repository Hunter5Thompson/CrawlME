

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Schulen](/gesellschaft/bildung/schulen)
* [Allgemeinbildende Schulen in Brandenburg](/b-i-1-j)

Allgemeinbildende Schulen in Brandenburg
----------------------------------------

#### Schuljahr 2023/2024, jährlich

###### Der Bericht informiert über allgemeinbildende Schulen, Schülerinnen und Schüler, Schulanfängerinnen und -anfänger, Klassenfrequenzen u.a. nach Schulform, Jahrgang, Geschlecht oder Staatsangehörigkeit sowie Lehrkräfte.

BrandenburgMethodik
### Brandenburg

**Weiter steigende Schülerzahlen**

Im Schuljahr 2023/24 lernen 278.103 Schülerinnen und Schüler an den allgemeinbildenden Schulen Brandenburgs. Davon hatten 253.041 die deutsche und 25.062 eine ausländische Staatsbürgerschaft. Damit setzt sich der Trend steigender Schülerzahlen fort. Gegenüber dem Schuljahr 2022/23 waren es 2,2 % bzw. 5.952 Schülerinnen und Schüler mehr. Dieser Anstieg ergibt sich aus 3.784 deutschen und 2.168 ausländischen Schülerinnen und Schülern.

130.308 Schülerinnen und Schüler besuchen die Grundschulen, 27.065 die Gesamtschulen, 49.791 die Oberschulen, 56.099 die Gymnasien, 4.073 das berufliche Gymnasium, 9.466 die Förderschulen und 1.301 die Schulen und Einrichtungen des Zweiten Bildungsweges.

 **Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023/24**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/da0112f36bf598a1/061540a22a49/SB_B01-01-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/42fc3ed6e1101ec6/ca0a111b51e0/SB_B01-01-00_2023j01_BB.pdf)
### Kontakt

#### Ramona Klasen

Schulen

#### Ramona Klasen

Schulen

* [0331 8173-1146](tel:0331 8173-1146)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Matthias Gebhard

Schulen

#### Matthias Gebhard

Schulen

* [0331 8173-1103](tel:0331 8173-1103)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der statistische Bericht enthält Ergebnisse über Schulen, Schülerinnen und Schüler, Absolventinnen und Absolventen, Abgängerinnen und Abgänge, und Lehrkräfte an beruflichen Schulen im Land Brandenburg im Berichtsjahr und nach Verwaltungsbezirken und staatlichen Schulämtern. Die Ergebnisse sind nach Ländersystematik aufbereitet und für Ländervergleiche nur bedingt geeignet.

Die Erhebung der Statistik der allgemeinbildenden und beruflichen Schulen (Schulstatistik) wird jährlich zu Schuljahresbeginn bzw. zum Schuljahresende, als koordinierte Länderstatistik durchgeführt. Auswertungen der erhobenen Daten werden in der regionalen Gliederung bis auf die Ebene der Verwaltungsbezirke auf der Basis des Schulstandortes vorgenommen. Diese Statistik wird als Totalerhebung mit Auskunftspflicht aller allgemeinbildenden und beruflichen Schulen des Landes Brandenburg in öffentlicher und freier Trägerschaft durchgeführt.

Zum Erhebungsprogramm der Schulstatistik gehören Angaben über Schulen, Klassen, Schülerinnen und Schüler, Absolventinnen und Absolventen, Abgänge­rinnen und Abgänger sowie Lehrkräfte. Die Schulstatistik liefert jährlich detaillierte Informationen u.a. über die Entwicklung der Schülerzahlen nach Bildungsgängen, zu Absolventinnen und Absolventen nach Abschlussarten und zu Lehrkräften.

Hauptnutzer sind das Ministerium für Bildung, Jugend und Sport, das Bundesministerium für Bildung und Forschung, die KMK, Eurostat, wissenschaftliche Einrichtungen und die interessierte Öffentlichkeit.

Im Land Brandenburg werden Individualdaten erhoben. Die Erhebungsmerkmale werden vom MBJS des Landes Brandenburg in Anlehnung an den Kerndatensatz der KMK festgelegt. Die regionale Zuordnung erfolgt nach dem Hauptstandort der Schule. Das berufliche Gymnasium wird dem allgemeinbildenden Bereich des Schulwesens zugeordnet.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der allgemeinbildenden Schulen**2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/e91e9c7ac0d00ba5/55737a005e78/MD_21111_2023.pdf)[Archiv](/search-results?q=22111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-i-1-j)
