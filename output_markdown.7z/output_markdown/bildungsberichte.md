

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Publikationen](/publikationen)
* [Bildungsberichte](/bildungsberichte)

Bildungsbericht­erstattung
==========================

Mit den Bildungsberichten für Berlin und Brandenburg wird eine Bestandsaufnahme zentraler Aspekte der Bildungssysteme beider Länder vorgelegt.

Die Zusammenstellung relevanter und empirisch gesicherter Daten und Informationen leistet einen Beitrag für eine sachliche Grundlage von Diskussionen und Entscheidungen im Bildungsbereich, der maßgeblichen Einfluss auf die Leistungsfähigkeit einer Gesellschaft und auf die Lebenschancen von Individuen hat.

### Regionale Bildungsberichte

**Seit 2008 veröffentlicht das Amt für Statistik Berlin-Brandenburg in unregelmäßigen Abständen regionale Bildungsberichte für Berlin und Brandenburg, beginnend bei der vorschulischen Bildung. Zentrale Sachverhalte der verschiedenen Bildungsphasen in Berlin und Brandenburg werden anhand eines Sets an Indikatoren und Kennzahlen näher beschrieben und grafisch aufbereitet.**

Die Reihe der regionalen Bildungsberichte ist so konzipiert, dass sie an den alle zwei Jahre erscheinenden Bericht Bildung in Deutschland, die jährlich erscheinenden internationalen Bildungsindikatoren im Ländervergleich sowie an die internationale Berichterstattung der OECD anschlussfähig ist, zugleich aber die regionalen Aspekte in den Mittelpunkt stellt.

![](https://download.statistik-berlin-brandenburg.de/d0a8e45e3ca8004b/5d53ced40224/v/897e56450ee6/gesellschaft-bildung-gesellschaft-bildung-audience-raising-hands-up-while-businessman-is-speaking-in-training-picture-id1041740040.jpg)
###### Vorschulische Bildung

![](https://download.statistik-berlin-brandenburg.de/e4b4b31d85cd0522/7718c0bd62f6/v/3f6e3c0c033c/vorschulische-Bildung-bericht-bild.PNG)

Anknüpfend an die Veröffentlichung „[Bildung in Deutschland 2016](https://www.bildungsbericht.de/de/bildungsberichte-seit-2006/bildungsbericht-2016/bildung-in-deutschland-2016)“ wird mit dem Bericht „**Vorschulische Bildung in Berlin 2016**“ die Phase der vorschulischen Bildung in der Hauptstadt eingehend analysiert.

[Vorschulische Bildung in Berlin 2016 – Bericht](https://download.statistik-berlin-brandenburg.de/371b4f9bd1e7a133/2c69507ab1ac/SP_VorschulischeBildung-000-000_DE_2016_BE.pdf)
###### Ältere Bildungsberichte

[Vorschulische Bildung 2012](https://download.statistik-berlin-brandenburg.de/f277fbad2a28c62e/7a6a52654051/SP_VorschulischeBildung-000-000_DE_2012_BBB.pdf)
###### Berufliche Bildung

![](https://download.statistik-berlin-brandenburg.de/c3fc81aeda427d26/bce06f8e150b/v/c5362eb2cfa0/berufliche-bildung-bild.PNG)

Mit „**Berufliche Bildung 2016**“wird die Phase der beruflichen Bildung in Berlin und Brandenburg einer eingehenden Analyse unterzogen.

[Berufliche Bildung 2016 – Bericht](https://download.statistik-berlin-brandenburg.de/667172ff79ae138b/d66349a7b2b2/SP_BeruflicheBildung_00_00_DE_2016_BBB.pdf)
###### Hochschule

![](https://download.statistik-berlin-brandenburg.de/9fcac1edcd0af0c9/f4bc0786b6fd/v/055946ef0796/Bild-Hochschule-2017.PNG)

Mit „**Hochschule 2017**“ werden die Themen Studienanfängerquote und Absolventinnen und Absolventen nach Abschlussarten ebenso aufgegriffen wie die soziale und wirtschaftliche Lage der Studierenden, die Beschäftigungsformen des Hochschulpersonals und die Finanzen der Hochschulen.

[Hochschulen 2017 – Bericht](https://download.statistik-berlin-brandenburg.de/f832bc5474aec609/667442dbeb1e/SP-Hochschulen_2017.pdf)[Hochschulen 2017 – Tabellen](https://download.statistik-berlin-brandenburg.de/89ea4bd087921e38/9775075816a5/SP_Hochschule_Tabellen_00-00_DE_2018_BBB.xlsx)![](https://download.statistik-berlin-brandenburg.de/b178bf6123b22346/ffe21ad777a7/v/0ad620fb067b/gesellschaft-bildung-group-of-kids-go-to-the-school-back-view-picture-id1176554634.jpg)
### Bildungsbericht Berlin-Brandenburg

**Der Bildungsbericht für die Metropolregion Berlin-Brandenburg ist ein vom Amt für Statistik Berlin-Brandenburg und dem [Institut für Schulqualität der Länder Berlin und Brandenburg e.V.](https://www.isq-bb.de) veröffentlichte indikatorengestützte Bildungsbericht.**

Er behandelt das gesamte Bildungsspektrum von der frühkindlichen Bildung bis zur Weiterbildung im Erwachsenenalter, womit er als regionales Pendant zum nationalen Bildungsbericht betrachtet werden kann.

###### Bildungsbericht 2013

![Cover Bildungsbericht 2013](https://download.statistik-berlin-brandenburg.de/9cf62441f00bbfc4/42e8ab9e4415/v/3ecc95008993/Bildungsbericht_2013.PNG)

Mit dem **Bildungsbericht Berlin-Brandenburg 2013** liegt der vom Amt für Statistik Berlin-Brandenburg und dem Institut für Schulqualität der Länder Berlin und Brandenburg  e. V. veröffentlichte indikatorengestützte Bildungsbericht in dritter Auflage vor.

[Bildungsbericht 2013 – Bericht](https://download.statistik-berlin-brandenburg.de/347172166bfdab6a/e0c6f012e158/bildungsbericht_2013.pdf)[Bildungsbericht 2013 – Tabellenband](https://download.statistik-berlin-brandenburg.de/54b8469bb7fd16da/f2486398f262/Bildungsbericht_2013_Tabellen.pdf)
###### Bildungsbericht 2010

![Cover Bildungsbericht 2010](https://download.statistik-berlin-brandenburg.de/eb57505e5dc0e5cb/47a6310518c6/v/0b4fc32c0995/Bildungsbericht_2010.PNG)

Mit dem **Bildungsbericht Berlin-Brandenburg 2010** liegt der inzwischen zweite vom Amt für Statistik Berlin-Brandenburg und dem Institut für Schulqualität der Länder Berlin und Brandenburg e. V. veröffentlichte indikatorengestützte Bildungsbericht vor. Wieder wird das gesamte Bildungsspektrum von der frühkindlichen Bildung bis zur Weiterbildung im Erwachsenenalter behandelt

[Bildungsbericht 2010 – Bericht](https://download.statistik-berlin-brandenburg.de/c271d2e96c9c13e6/4bae6fd36af3/bildungsbericht_2010.pdf)[Bildungsbericht 2010 – Tabellenband](https://download.statistik-berlin-brandenburg.de/68be1b8cd7fc77a7/1aa2947cfcdb/bildungsbericht-2010-tabellen.pdf)[Bildungsbericht 2010 – Expertenbeiträge](https://download.statistik-berlin-brandenburg.de/f3d970656b46caa8/0bc337bb5204/bildungsbericht-2010-expertenbeitraege2010.pdf)
###### Bildungsbericht 2008

![Cover Bildungsbericht 2008](https://download.statistik-berlin-brandenburg.de/0dec0d13cca156e6/1de5243922ad/v/97bbf2bf2396/Bildungsbericht_2008.PNG)

Der **Bildungsbericht Berlin-Brandenburg 2008** ist der erste Bildungsbericht des Amtes für Statistik Berlin-Brandenburg in Zusammenarbeit mit dem Institut für Schulqualität der Länder Berlin und Brandenburg e. V. Der Bericht ist eine Fokusierung des nationalen Billdungsberichts auf regionaler Ebene und bildet das gesamte Bildungsspektrum, vom Elementar- bis zum Weiterbildungsbereich ab.

[Bildungsbericht 2008](https://download.statistik-berlin-brandenburg.de/03c1029cb5d28b21/0d29a0bc25a3/bildungsbericht_2008.pdf)[Bildungsbericht 2008 – Tabellenband](https://download.statistik-berlin-brandenburg.de/9f92d053fcb8a1ad/f889ff24eb24/Bildungsbericht-2008-tabellen.pdf)[Bildungsbericht 2008 – Expertenbeiträge](https://download.statistik-berlin-brandenburg.de/4573ac4ca1282231/e8e81a79f600/bildungsbericht-2008-expertenbeitraege.pdf)
###### Aktuelle regionale Bildungsdaten

### Kommunale Bildungsdatenbank

**Die Kommunale Bildungsdatenbank der Statistischen Ämter des Bundes und der Länder stellt ein umfassendes Angebot an regionalen Bildungsdaten aus verschiedenen Bereichen der amtlichen Statistik bereit.**

Auf der Ebene der Landkreise und kreisfreien Städte können Daten der Kinder- und Jugendhilfestatistik, der Schulstatistik, der Berufsbildungsstatistik und der Hochschulstatistik unentgeltlich abgerufen werden. Zusätzlich stehen Daten zu den Rahmenbedingungen, in denen Bildungsprozesse stattfinden, zur Verfügung.

[Zur Bildungsdatenbank](http://www.bildungsmonitoring.de/)![](https://download.statistik-berlin-brandenburg.de/91beeeb6e590c889/36d3d6d3469a/v/721d0345eca4/schmuckbild-bildungsdatenbank1.png)![](https://download.statistik-berlin-brandenburg.de/489644ad85d9c1c7/e28ba03c12f4/v/3f73e773cd1a/gesellschaft-bildung-helping-hand-of-older-colleague-greyhaired-artisan-holding-while-picture-id662983082.jpg)
### Nationaler Bildungsbericht

**Der 10. Nationale Bildungsbericht 2024 stellt das Bildungsgeschehen Deutschlands dar – von der frühen Bildung bis zur Weiterbildung im Erwachsenenalter. Er analysiert die Rahmenbedingungen für den Bildungserwerb mit den Aspekten demografische und wirtschaftliche Entwicklung, Erwerbstätigkeit sowie Familien und Lebensformen.**  
  
Erstellt wurde der Bericht  von einer unabhängigen Gruppe von Wissenschaftlerinnen und Wissenschaftlern unter der Federführung des Leibniz-Institut für Bildungsforschung und Bildungsinformation. Wir vertreten dabei das Team der Autorinnen und Autoren sowie die amtliche Statistik in Deutschland.

[Zur Website](https://www.bildungsbericht.de/de) 

[* Bildung](/search-results?q=tag%3ABildung)[* Bildungsberichterstattung](/search-results?q=tag%3ABildungsberichterstattung)[* Bildungsbericht](/search-results?q=tag%3ABildungsbericht)
