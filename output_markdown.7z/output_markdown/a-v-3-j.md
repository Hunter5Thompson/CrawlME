

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Flächennutzung](/flaechennutzung)
* [Flächenerhebung nach Art der tatsächlichen Nutzung in Berlin und Brandenburg](/a-v-3-j)

Flächenerhebung nach Art der tatsächlichen Nutzung in Berlin und Brandenburg
----------------------------------------------------------------------------

#### 31.12.2023, jährlich

###### Die Flächenerhebung nach Art der tatsächlichen Nutzung erfasst alle Flächen und deren Nutzung in den Gemeinden Brandenburgs sowie den Bezirken Berlins. Die Ergenisse sind Grundlageninformationen für raumordnungs- und umweltrelevante Entscheidungen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/1fd21ab3e3557047/4789a2367840/SB_A05-03-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/c9e8fa16242c6368/c47c371c954c/SB_A05-03-00_2023j01_BE.pdf)

**Nutzungsart „Vegetation“ fehlt in Mitte**

Die Flächenerhebung zum 31.12.2023 hat für Berlin ergeben, dass im Bezirk Mitte keine Flächen zum Nutzungsartenbereich „Vegetation“ zählen, d.h. landwirtschaftlich genutzt werden oder z. B. von Wald bedeckt sind. Dass solche Flächen fehlen, ist jedoch für das Zentrum einer Großstadt nicht ungewöhnlich.

Der Berliner Tiergarten gehört zur Nutzungsart „Grünanlagen“, die insgesamt 640 Hektar bzw. 16,2 % der Fläche des Bezirkes Mitte umfasst. Nur im Bezirk Neukölln ist der Anteil der Grünanlagen mit 19,0 % noch größer. Diese Grünanlagen gehören zum Nutzungsartenbereich ‚Siedlung‘. Hierunter fallen neben Wohnbauflächen, Industrie- und Gewerbeflächen und z. B. Flächen besonderer funktionaler Prägung auch Friedhöfe und Grünanlagen.

### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Brandenburg ist fünftgrößtes Bundesland**

Brandenburg ist mit 2.965.436 Hektar das größte der neuen Bundesländer und gleichzeitig das fünftgrößte deutsche Bundesland. Größer sind nur noch Bayern, Niedersachsen, Baden-Württemberg und Nordrhein-Westfalen.

Gut 199.500 Hektar werden der Nutzungsart Siedlung zugerechnet. Diese bedeckt damit 6,7 % der Landesfläche. Mit fast 69.700 Hektar entfällt ein Großteil der Siedlungsfläche auf die Wohnbaufläche. Weitere 42.900 Hektar werden zur Industrie- und Gewerbefläche gezählt.

Über 104.700 Hektar werden als Verkehrsfläche ausgewiesen. Der Anteil an der Gesamtfläche Brandenburgs liegt damit bei 3,5 %. Größte Positionen sind hier die Flächen für den Straßenverkehr und die Wege, auf die 59.200 Hektar bzw. 30.900 Hektar entfallen.

Die mit Abstand flächengrößte Nutzungsart in Brandenburg ist die Vegetation. Auf sie entfallen mit 2.558.200 Hektar 86,3 % der Landesfläche. Von den Vegetationsflächen sind die Nutzungsarten Landwirtschaft mit 1.411.800 Hektar und Wald mit 1.038.600 Hektar die größten.

Weitere 103.000 Hektar Brandenburgs zählen zur Nutzungsart Gewässer. Der Anteil an der Landesfläche liegt hier bei 3,5 %. Mit 69.000 Hektar entfallen etwa zwei Drittel der Gewässerfläche auf stehende Gewässer und mit 34.000 Hektar etwa ein Drittel auf Fließgewässer.

Der für die Nachhaltigkeitsstrategie der Bundesregierung wichtige Indikator Siedlungs- und Verkehrsfläche setzt sich aus den beiden Nutzungsarten Siedlung und Verkehr abzüglich der Nutzungsarten Bergbaubetrieb sowie Tagebau, Grube, Steinbruch zusammen. Auf sie entfielen 2023 in Brandenburg 292.500 Hektar.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/5825886d6808137c/b66119f41cde/SB_A05-03-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/13bf57fc2246ba2b/95bcdf210251/SB_A05-03-00_2023j01_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Flächenerhebung nach Art der tatsächlichen Nutzung erfasst alle Flächen und Flächennutzungen der Gemeinden des Landes Brandenburg sowie der Bezirke des Landes Berlin. Die Ergebnisse für Brandenburg werden für das Land, die Kreise, die Gemeinden, die siedlungsstrukturellen Kreistypen sowie die Gemeindegrößenklassen dargestellt. Für Berlin erfolgt die Ausweisung der Ergebnisse für das Land und die Bezirke.

Die Zuordnung der Flächennutzungen erfolgt seit 2016 nach dem AdV-Nutzungsartenkatalog (Grundlage: GeoInfoDok Version 6.0.1). Dabei werden die Nutzungsartenbereiche Siedlung (10000), Verkehr (20000), Vegetation (30000) und Gewässer (40000) unterschieden und untergliedert.

Die Daten sind eine wesentliche Grundlage für regional- und stadtplanerische Vorhaben. Darüber hinaus sind die Ergebnisse der Flächenerhebung eine Messgröße für die Nachhaltigkeitsstrategie der Bundesregierung, welche das Ziel hat, die Inanspruchnahme neuer Flächen für Siedlungs- und Verkehrszwecke bis zum Jahr 2030 auf unter 30 Hektar pro Tag in Deutschland zu begrenzen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Flächenerhebung nach Art der tatsächlichen Nutzung**  
Metadaten ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/17d2a1075e2719c1/a5b95def37b4/MD_33111_2023.pdf)[Archiv](/search-results?q=MD_33111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-v-3-j)
