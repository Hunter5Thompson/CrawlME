

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Karriere](/karriere)
* [Aktuelle Stellenausschreibungen](/aktuelle-stellenausschreibungen)

Aktuelle Stellenausschreibungen
===============================

[![iStock.com / Grafner](https://download.statistik-berlin-brandenburg.de/9aa00320c7d90f97/c0ca52f7f8a3/v/b12e76723d9f/gesellschaft-arbeit-finance-business-euro-stock-background-picture-id670891402.jpg "iStock.com / Grafner")](/erhebungsbeauftragte-preise-eisenhuettenstadt)**Für Seelow und Eisenhüttenstadt**[#### Preiserheber/-innen gesucht](/erhebungsbeauftragte-preise-eisenhuettenstadt)

Als Preiserheberin oder Preiserheber besuchen Sie bestimmte Geschäfte und Dienstleistungsfirmen, um dort die Preisentwicklung ausgewählter Waren und Dienstleistungen zu beobachten.

**Keine passende Stelle dabei?**
--------------------------------

#### **Schicken Sie uns gerne Ihre Initiativbewerbung!**

[Zum Bewerbungsformular](/initiativbewerbung)![](https://download.statistik-berlin-brandenburg.de/1dc05c2064aab4b8/4f2ff2a89588/v/14f5a32058d4/iStock-1066424862.jpg)![Junge Frau im Büro mit Kollegin](istock / fizkes)

Dein Praktikum bei uns
----------------------

#### **Wir freuen uns auf Bewerbungen!**

#### FAQs

**Sie haben noch Fragen?**
--------------------------

Hier finden Sie eine Übersicht häufig gestellter Fragen   
rund um das Amt für Statistik Berlin-Brandenburg als Arbeitgeber   
und rund um den Bewerbungsprozess.

###### Wie bewerbe ich mich im Amt für Statistik Berlin-Brandenburg?

Bitte nutzen Sie für Ihre Bewerbung unser Online-Bewerbungsformular. Hier können Sie bequem mittels weniger Angaben Ihre Bewerbungsunterlagen bis zum Ende der Bewerbungsfrist hochladen und abschicken.

Der Umwelt zuliebe bitten wir von Papierbewerbungen Abstand zu nehmen. Bewerbungsmappen senden wir aus diesem Grund nicht an den Absender zurück.

###### Welche Unterlagen muss ich mit meiner Bewerbung einreichen und welche Angaben sind verpflichtend?

Neben einem Motivationsschreiben und einem aktuellen Lebenslauf benötigen wir von Ihnen zwingend die für die Stelle relevanten (Abschluss-/Arbeits-)Zeugnisse, um die formale Voraussetzung prüfen zu können. Wenn Sie noch kein Abschlusszeugnis haben, können Sie alternativ Ihre aktuelle Notenübersicht mitschicken.

In unserem Bewerbungsformular ist gekennzeichnet, welche Angaben verpflichtend oder freiwillig sind. Um Ihre Bewerbung einer ausgeschriebenen Stelle zuordnen und dem entsprechenden Auswahlgremium zur Verfügung stellen zu können, muss Ihre Bewerbung unbedingt das Stellen-Kennzeichen beinhalten. Im Anschreiben soll auf die besonderen Erfahrungen und Kenntnisse für die angestrebte Position hingewiesen und die Motivation für Ihre Bewerbung dargelegt werden.

Die Angabe über eine vorliegende Schwerbehinderung/Gleichstellung ist freiwillig.

###### Welche Einstiegsmöglichkeiten gibt es?

Unsere Stellenausschreibungen beinhalten immer die Information, welche formale Voraussetzung für die Besetzung einer Stelle zwingend vorliegen muss. Daraus ergeben sich folgende Einstiegsmöglichkeiten:

**Mittlerer Dienst**   
 Stellenbezeichnung: z.B. Mitarbeiter (m/w/d), Assistenz (m/w/d)   
 formale Voraussetzung: erfolgreich **abgeschlossene Berufsausbildung**   
 Verdienst: je nach Tätigkeitsmerkmalen Entgeltgruppe E6 bis E9a TV-L

**Gehobener Dienst**  
 Stellenbezeichnungen: z.B. Sachbearbeiter (m/w/d), Sachgebietsleiter (m/w/d)  
 formale Voraussetzung: **erfolgreich abgeschlossenes Fachhochschul- bzw. Bachelorstudium**   
 Verdienst: je nach Tätigkeitsmerkmalen Entgeltgruppe E9b bis E12 TV-L

**Höherer Dienst**   
 Stellenbezeichnungen: z.B. Referent (m/w/d), Referatsleiter (m/w/d), Abteilungsleiter (m/w/d)  
 formale Voraussetzung: **erfolgreich abgeschlossenes Universitäts- bzw.** **Masterstudium**  
 Verdienst: je nach Tätigkeitsmerkmalen Entgeltgruppe ab E13 TV-L

**Ausbildung**  
 Formale Voraussetzung:  **erfolgreich abgeschlossenes Abitur oder Fachhochschulreife**  
 Ausbildungsberufe: Fachangestellte (m/w/d) für Markt- und Sozialforschung  
 Vergütung: Anstellung, Vergütung und Sozialleistungen richten sich nach dem Tarifvertrag für Auszubildende der Länder in Ausbildungsberufen nach dem Berufsbildungsgesetz (TVA-L BBiG)

**Duales Studium**  
 Formale Voraussetzung: **erfolgreich abgeschlossenes Abitur oder** **Fachhochschulreife**  
 Studiengänge: Wirtschaftsinformatik (in Kooperation mit der HWR Berlin)

###### Wie läuft das Bewerbungsverfahren ab?

Sobald wir Ihre Bewerbung erhalten haben, senden wir Ihnen eine Eingangsbestätigung. Sofern Sie die formale Voraussetzung erfüllen und nach Prüfung der Bewerbungsunterlagen in die Vorauswahl gekommen sind, wird in der Regel in Einzelgesprächen mittels eines strukturierten Interviews sowie einer kleinen Aufgabe/Vortragsthema geprüft, ob Sie die fachlichen und außerfachlichen Anforderungen der zu besetzenden Stelle erfüllen.

Für Positionen im höheren Dienst führen wir zusätzlich vorab einen berufsbezogenen Persönlichkeitstest (Online-Testverfahren) durch.

Nach den geführten Auswahlgesprächen erfolgt eine vorläufige Entscheidung, welche die Zustimmungen der Gremien und des Vorstandes voraussetzt. Sollte sich der Auswahlprozess verzögern, werden wir Sie in einem Zwischenbescheid darüber informieren.

**Wo finden die Auswahlgespräche statt?**  


Die Auswahlgespräche finden in unserer Zentrale in Potsdam statt.

**Wer nimmt am Auswahlgespräch teil?**  


Das Gremium eines Auswahlverfahrens setzt sich aus mehreren Personen zusammen. In der Regel werden die Gespräche vom Personalservice gemeinsam mit der/dem zukünftig direkt Vorgesetzten geführt und von den Beschäftigtenvertretungen (Personalrat, Gleichstellungsbeauftragte, Schwerbehindertenvertretung) begleitet.

###### Gibt es die Möglichkeit, im Homeoffice zu arbeiten?

Das Amt für Statistik Berlin-Brandenburg ermöglicht im Rahmen des mobilen Arbeitens eine bessere Vereinbarkeit dienstlicher und privater Verpflichtungen, indem die Erbringung der Arbeits- und Dienstleistung örtlich flexibilisiert wird und dadurch der individuellen Lebenssituation der Beschäftigten sowie den betrieblichen Interessen stärker Rechnung getragen werden kann.

###### Werden Reisekosten fürs Bewerbungsgespräch erstattet?

Leider nein. Bitte haben Sie Verständnis dafür, dass anfallende
Reisekosten für die Teilnahme an Vorstellungsgesprächen nicht erstattet werden
können.

###### Wie kann ich mich auf das Bewerbungsgespräch vorbereiten?

Unsere Auswahlgespräche finden in Form strukturierter Einzelinterviews statt. Sie sind bereits gut vorbereitet, wenn Sie sich mit der Internetpräsenz des Amtes für Statistik Berlin-Brandenburg und vor allem der Stellenausschreibung auseinandergesetzt haben.

###### Was passiert mit meinen Daten nach einer Bewerbung?

Informationen zur Datenerhebung gemäß Artikel 13 Datenschutzgrundverordnung (DS-GVO)

Das Amt für Statistik Berlin-Brandenburg erhebt Ihre Daten zum Zweck der Durchführung des Bewerbungsverfahrens und der Erfüllung eventueller vorvertraglicher Pflichten. Die Datenerhebung und -verarbeitung ist für die Durchführung des Bewerbungsverfahrens erforderlich und beruht auf Artikel 6 Abs. 1 lit b) DSGVO und § 26 Abs. 1 Brandenburgisches Datenschutzgesetz.

Eine Weitergabe der Daten an Dritte findet nicht statt. Die Daten werden gelöscht, sobald sie für den Zweck ihrer Verarbeitung nicht mehr erforderlich sind. Sie haben das Recht, Auskunft der bei uns über sie gespeicherten Daten zu beantragen sowie bei Unrichtigkeit der Daten die Berichtigung oder bei unzulässiger Datenspeicherung die Löschung der Daten zu fordern.

Unseren behördlichen Datenschutzbeauftragten erreichen Sie unter [datenschutz@statistik-bbb.de](mailto:datenschutz@statistik-bbb.de) sowie telefonisch unter 0331 8173-1880. Weiterhin steht Ihnen ein Beschwerderecht bei unserer datenschutzrechtlichen Aufsichtsbehörde der Landesbeauftragten für den Datenschutz und für das Recht auf Akteneinsicht (E-Mail: [Poststelle@LDA.Brandenburg.de](mailto:Poststelle@LDA.Brandenburg.de)) zu.

Weitere Informationen zum Datenschutz finden Sie unter [https://www.statistik-berlin-brandenburg.de/datenschutz](/datenschutz)

###### Bietet das AfS Ausbildungsplätze oder Duale Studiengänge an?

Ja, wir bilden aus und bieten Duale Studiengänge an, allerdings nicht jedes Jahr.

Die aktuellen Angebote entnehmen Sie bitte den **Stellenangeboten**.

**Ausbildungsberufe:**

Fachangestellte (m/w/d) für Markt- und Sozialforschung

**Duales Studium:**

Wirtschaftsinformatik (in Kooperation mit der HWR Berlin)


