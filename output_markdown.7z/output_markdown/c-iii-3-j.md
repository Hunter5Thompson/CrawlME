

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Viehbestände in Brandenburg am 3. November 2023 – Schweine](/c-iii-3-j)

Schweine in Brandenburg– Repräsentative Erhebung
------------------------------------------------

#### 3. November 2023


###### Die Erhebung informiert über die  Anzahl der Schweine gegliedert nach Alter, Geschlecht, Nutzungszweck, Lebendgewicht und Trächtigkeit (Zuchtsauen).

BerlinBrandenburgMethodik
### Brandenburg

**536.000 Schweine in Brandenburg**

Zum Stichtag 3. November 2023 wurden in Brandenburg nach dem vorläufigen Ergebnis der Schweineerhebung 536.000 Schweine gehalten. Der Schweinebestand nahm gegenüber dem 3. Mai 2023 um 2,0 % oder 10.500 Tiere zu. Dies ist der erste Zuwachs seit November 2021 innerhalb eines Halbjahres.

Im Vergleich zum November 2022 sank der Bestand allerdings um 10,3 % oder 61.500 Tiere.

Für die einzelnen Tierkategorien der Schweinehaltung ergibt sich ein differenziertes Bild. Der Bestand an Mastschweinen stieg im Vergleich zum Mai des Jahres um 9,1 % oder 11.800 auf 141.800 Tiere. Dagegen verringerte sich die Zahl der Zuchtsauen um 7,7 % oder 4.600 auf 55.200 Tiere. Der Bestand an Ferkeln und Jungschweinen stieg um 1,0 % oder 3.200 auf 337.800 Tiere.

Die Zahl der Betriebe mit mehr als 50 Schweinen oder mehr als 10 Zuchtsauen stieg im Vergleich zum Mai 2023 um 6 % auf 139. Im November 2022 waren es 140 Betriebe.

**Quelle:** Amt für Statitistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 3. November 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d09a0da3ea757bd1/ad5c9aff52e1/SB_C03-03-00_2023j02_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/d336ac01d22f6482/452ded89742f/SB_C03-03-00_2023j02_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Olaf Müller

Tierische Produktion

#### Olaf Müller

Tierische Produktion

* [0331 8173-3051](tel:0331 8173-3051)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung über die Schweinebestände ist eine dezentrale, repräsentative Bundesstatistik, wobei die Stadtstaaten ausgenommen sind. Erhebungsstichtage ist der 3. Mai eines jeden Jahres.

Zur Grundgesamtheit zählen alle landwirtschaftlichen Betriebe mit mindestens 50 Schweinen oder 10 Zuchtsauen. Für die Zufallsauswahl der Stichprobenbetriebe wird das Verfahren der „Kontrollierten Auswahl“ angewendet. Die Betriebe melden ihre Daten online bzw. per Erhebungsbogen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Viehbestandserhebung Schweine**Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/a6f67a4c2c975c5e/355770008fba/MD_41313_2020.pdf)[Archiv](/search-results?q=MD_41313&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-3-j)
