

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Legehennenhaltung und Eiererzeugung in Brandenburg](/c-iii-8-vj)

Legehennenhaltung und Eiererzeugungin Brandenburg
-------------------------------------------------

#### 3. Quartal 2024, vierteljährlich

###### Die Ergebnisse der Erhebung in Unternehmen mit Hennenhaltung informieren über den Umfang des Eieraufkommens, über die vorhandenen Haltungskapazitäten der Unternehmen und die Zahl der gehaltenen Legehennen.

BrandenburgMethodik
### Brandenburg

**Eierproduktion leicht gestiegen**

2023 wurden in Brandenburg 916,1 Millionen Eier für den menschlichen Verzehr erzeugt.  Das waren 2,3 Millionen Eier oder 0,3 % mehr als im vorigen Jahr. Erfasst werden Eier aus Unternehmen mit 3.000 oder mehr Haltungsplätzen.

Mit 720 Millionen entfiel der Großteil der gelegten Eier auf die Bodenhaltung. Verglichen mit dem Vorjahr waren das 2 Millionen Eier weniger, jedoch lag der Anteil der in Bodenhaltung erzeugten Eier bei knapp 79 %. Weitere 115 Millionen Eier wurden in ökologischer Haltung erzeugt. Auch hier war im Vergleich zum Vorjahr ein leichter Rückgang um 3 Millionen Eier zu verzeichnen. Der Anteil der in ökologischer Haltung erzeugten Eier lag bei knapp 13 %. In Freilandhaltung wurden 2023 gut 80 Millionen Eier erzeugt. Verglichen mit dem Vorjahr war dies ein Zuwachs um 8 Millionen Eier. Die Zahl der Haltungsplätze ist im Vergleich zum Vorjahr um 7.000 zurückgegangen. Während in der Bodenhaltung ein Minus von 22.000 auf 2,95 Millionen Haltungsplätze festzustellen war, nahm ihre Zahl sowohl in der ökologischen als auch in der Freilandhaltung zu. So war in der ökologischen Haltung ein Zuwachs um 6.000 auf 488.000 und in der Freilandhaltung ein Zuwachs von 9.000 auf 309.000 Haltungsplätze zu verzeichnen. Rein rechnerisch standen 2023 jedem der ca. 2,5 Millionen Einwohner Brandenburgs 366 Eier und damit jeden Tag ein Ei zur Verfügung. Da ein Bundesbürger im Durchschnitt 236 Eier verbrauchte, war für Brandenburg eine „Selbstversorgung“ mehr als gesichert.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 01.01. bis 30.09.2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/2d8f85eeb7d57f75/2024060c3a5f/SB_C03-08-00_2024q03_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/fa3f840720b040d3/4771ac8f40eb/SB_C03-08-00_2024q03_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung in Unternehmen mit Legehennenhaltung ist eine dezentrale monatliche Bundesstatistik. Der Erhebungsbereich umfasst alle Betriebe von Unternehmen mit mindestens 3.000 Hennenhaltungsplätzen. Die Unternehmen geben ihre Meldung untergliedert nach Betrieben ab. Unternehmen mit Betrieben in verschiedenen Bundesländern haben für jedes Bundesland, in dem sie einen Betrieb haben, gesondert zu melden.

Zum monatlichen Erhebungsprogramm gehören die Erfassung der Zahl der am letzten Kalendertag des Berichtsmonats vorhandenen Hennenhaltungsplätze bei voller Ausnutzung der Stallkapazitäten, der Zahl der Legehennen am letzten Kalendertag des Berichtsmonats sowie der Zahl der erzeugten Eier jeweils nach der Haltungsform im Berichtsmonat. Die Zahl der Legehennen beinhaltet dabei die legereifen Hennen einschließlich Hennen in der Legepause. Die Zahl der Eier umfasst die gelegten Eier einschließlich Bruch-, Knick- und Junghenneneier.

Die Ergebnisse der Erhebung dienen der Beurteilung der Marktlage für Konsumeier und der Produktionsvorausschätzung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Viehbestand und tierische Erzeugung (****Geflügelstatistik: Erhebung in Unternehmen mit Hennenhaltung)**

Metadaten 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/90316985885ad6f3/cfca17ba3b5f/MD_41323_2021.pdf)[Archiv](/search-results?q=MD_41323&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-8-vj)
