

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Wasser](/wasser)
* [Entsorgung Klärschlamm in Berlin und Brandenburg](/q-i-9-j)

Entsorgung Klärschlamm
----------------------

#### 2022, jährlich

###### Die Erhebung dient der Darstellung der Verwertungs- und Entsorgungswege des Klärschlamms im Hinblick auf den Schutz der Umwelt und insbesondere der Böden bei der Verwendung von Klärschlamm in der Landwirtschaft.

BerlinBrandenburgMethodikArchiv
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c7af55858ea07b20/5f7584ebe640/SB_Q01-09-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/819a42b9ecc99956/3112be6d8346/SB_Q01-09-00_2022j01_BE.pdf)

**Klärschlammentsorgungsmenge sinkt leicht**

Die direkte Klärschlammentsorgung aus der biologischen Abwasserbehandlung in Berlin ist seit 2021 von 51.468 Tonnen (t) Trockenmasse auf 50.184 t im Jahr 2022 gesunken. Der Entsorgungsweg bezieht sich ausschließlich auf die thermische Entsorgung. 6.425 t  Klärschlamm (Trockenmasse) wurden 2022 von einer Abwasserbehandlungsanlage aus einem anderen Bundesland bezogen.  
### Kontakt

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1282](tel:0331 8173-1282)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Rückgang der Klärschlammentsorgungsmenge**

Seit 2021 verzeichnet Brandenburg einenRückgang in der direkten Klärschlammentsorgung aus der biologischen Abwasserbehandlung – von 64.828 Tonnen (t) Trockenmasse auf 61.349 t im Jahr 2022. 44.928 t Trockenmasse wurden 2022 über thermische Mitbehandlung entsorgt. Der Landkreis Dahme-Spreewald entsorgte die höchste Menge Klärschlammtrockenmasse (18.312 t) unter allen Landkreisen bzw. kreisfreien Städten in Brandenburg.  Von den 61.349 t Klärschlamm wurden 34.934 t direkt in ein anderes Bundesland verbracht. 7.312 t wurden an andere Abwasserbehandlungsanlagen (auch nicht-öffentliche) abgegeben. **Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e9d544a878fa6392/132e28b7653f/SB_Q01-09-00_2022j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/e5b6f30958104506/9324f7d6b5c7/SB_Q01-09-00_2022j01_BB.pdf)
### Kontakt

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Petra Gliesch

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1282](tel:0331 8173-1282)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Diese Erhebung umfasst Mengenangaben über Verwertung und Verbleib des Klärschlamms aus der biologischen Abwasserbehandlung sowie Angaben zur Klärschlammbehandlung. Außerdem werden als sogenannte Bilanzdaten zusätzliche Angaben über Teilmengen des entsorgten Klärschlamms, der in ein anderes Bundesland oder ins Ausland verbracht wurde, erhoben. Darüber hinaus werden Angaben über die Mengen des Klärschlamms erfragt, die im Berichtsjahr von anderen Abwasserbehandlungsanlagen bezogen, an andere Abwasserbehandlungsanlagen abgegeben bzw. zwischengelagert wurden.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erhebung der öffentlichen Abwasserentsorgung – Klärschlamm**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/1b0fbdf0c63fd3da/f537fecc99c9/MD_32214_2022.pdf)[Archiv](/search-results?q=MD_32214&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/q-i-9-j)
