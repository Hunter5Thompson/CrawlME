

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Rechnungsergebnisse der Kernhaushalte der Gemeinden und Gemeindeverbände in Brandenburg](/l-ii-3-j)

Rechnungsergebnisse der kommunalen Kernhaushalte
------------------------------------------------

#### 2022, jährlich

###### Die jährliche Statistik der Ein- und Auszahlungen gibt einen Einblick in die Finanzwirtschaft der Gemeinden und Gemeindeverbände in Brandenburg.

BrandenburgMethodik
### Brandenburg

**Finanzmittelüberschuss von 37,4 Mio. EUR ausgewiesen**

Die bereinigten Einzahlungen der kommunalen Kernhaushalte des Landes Brandenburg beliefen sich 2022 auf eine Höhe von 10,8 Mrd. EUR (4.194 EUR je Einwohner). Gegenüber 2021 sind die Bereinigten Einzahlungen um 5,3 % gestiegen.

Die bereinigten Auszahlungen in Höhe von 10,7 Mrd. EUR (4.179 EUR je Einwohner) stiegen um 9,0 % im Vergleich zu 2021.

Die Personalauszahlungen betrugen 2,7 Mrd. EUR und für Baumaßnahmen wurden 0,9 Mrd. EUR ausgegeben.

Die Steuereinnahmequote der Kommunen lag bei 24,9 %. Sie zeigt das Verhältnis der Steuern an den gesamten Einzahlungen.

Die Investitionsquote gibt den Anteil der Investitionsauszahlungen an den Gesamtauszahlungen wieder. Im Jahr 2022 lag sie bei 14,0 %.

Der Deckungsgrad im Land Brandenburg betrug 100,3 % und stellt das Verhältnis der Einzahlungen zu den Auszahlungen dar.

1 Anteil der Investitionsauszahlungen an den Gesamtauszahlungen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a0e495c172053214/faaf90395ba9/SB_L02-03-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/98a71a03d8affab4/fb11f6542827/SB_L02-03-00_2022j01_BB.pdf)
### Kontakt

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Jahresrechnungsstatistik zeigt die Struktur der Ausgaben und Einnahmen der kommunalen Kernhaushalte und der kommunalen Zweckverbände auf. Die Rechnungsergebnisse der Kernhaushalte der Gemeinden und Gemeindeverbände fließen in den öffentlichen Gesamthaushalt und die volkswirtschaftlichen Gesamtrechnungen ein.

Aus den kommunalen Haushalten ausgegliederte Fonds, Einrichtungen und Unternehmen, die sich in der Trägerschaft der Kommunen befinden bzw. an denen die Kommunen mehrheitlich beteiligt sind, werden in der Jahresabschlussstatistik öffentlicher Fonds, Einrichtungen und Unternehmen erfasst.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Rechnungsergebnisse der kommunalen Kernhaushalte und deren kameral/doppisch buchenden Extrahaushalte und sonstigen FEU**  
Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/87004e42c9aed47c/ead27dc98fbc/MD_71717_2021.pdf)[Archiv](/search-results?q=71717&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-ii-3-j)
