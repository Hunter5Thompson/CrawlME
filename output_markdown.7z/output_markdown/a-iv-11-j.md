

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Familienplanung](/familienplanung)
* [In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg](/a-iv-11-j)

In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz
-------------------------------------------------------------------------

#### 2023, jährlich

###### Diese Statistik gibt einen Überblick über die Größenordnung, Struktur und Entwicklung der Schwangerschaftsabbrüche von Frauen mit Wohnsitz in Berlin und Brandenburg sowie über ausgewählte Lebensumstände der betroffenen Frauen.

BerlinBrandenburgMethodik
### Berlin

 Quelle: Statistisches Bundesamt, Bundesstatistik über Schwangerschaftsabbrüche 2023**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/14ef40a1288703d5/1ec326bbad9b/SB_A04-11-00-2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/92c0cb93d688d974/b7ff6c8f31d4/SB_A04-11-00-2023j01_BE.pdf)

**In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in****Berlin 2023**

Während 2021 insgesamt 16,2 % weniger Berlinerinnen als im Vorjahr einen Schwangerschaftsabbruch vornehmen ließen, waren es im Jahr darauf 14,4 % mehr. Im Jahr 2023 hingegen sank die Zahl der Abbrüche um 0,5 %.

Zum Zeitpunkt des Eingriffs waren 65,4 % der Berlinerinnen (6.103) ledig und 31,8 % (2.969) verheiratet. Knapp die Hälfte (47,2 %) der Frauen, die einen Schwangerschaftsabbruch durchführen ließen, war zwischen 25 bis unter 35 Jahre alt. In der Altersgruppe der 35- bis unter 40-jährigen Frauen wurden weitere 20,1 % der Eingriffe registriert. 8,3 % der Frauen waren 40 Jahre und älter, 2,2 % jünger als 18 Jahre.

96,7 % (9.021 Fälle) der Berlinerinnen ließen einen Schwangerschaftsabbruch unter dem rechtlichen Aspekt der Beratungsregelung durchführen.

Mit einem Anteil von 95,0 % wurden auch 2023 die meisten Eingriffe bei Frauen mit Wohnsitz in Berlin in gynäkologischen Praxen beziehungsweise OP-Zentren vorgenommen.

### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**In Deutschland gemeldete Schwangerschaftsabbrüche von Frauen mit Wohnsitz in****Brandenburg 2023**

Bei den Brandenburgerinnen wurden 2021 insgesamt 6,8 % weniger Eingriffe als im Jahr zuvor gezählt. 2022 waren es mit einem Minus von 0,8 % erneut weniger Abbrüche. Im Jahr 2023 wiederum wurden 7,3 % mehr Schwangerschaftsabbrüche gemeldet.

Von den betroffenen Brandenburgerinnen waren zum Zeitpunkt des Eingriffs 63,6 % (2.124) ledig und 34,2 % (1.141) verheiratet. Weniger als die Hälfte (41,0 %) der Frauen war im Alter von 25 bis unter 35 Jahren. In der Altersgruppe der 35- bis unter 40-jährigen Frauen wurden weitere 24,3 % der Schwangerschaftsabbrüche gezählt. 10,1 % der Frauen war 40 Jahre und älter, 4,1 % unter 18 Jahre alt.

97,1 % (3.245 Fälle) der Frauen mit Wohnsitz in Brandenburg ließen einen Schwangerschaftsabbruch unter dem rechtlichen Aspekt der Beratungsregelung durchführen.

Bei 57,2 % der Brandenburgerinnen wurden die Eingriffe in gynäkologischen Praxen beziehungsweise OP-Zentren vorgenommen, weitere 40,5 % der Abbrüche wurden ambulant in einem Krankenhaus durchgeführt.

 Quelle: Statistisches Bundesamt, Bundesstatistik über Schwangerschaftsabbrüche 2023**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a529145cfe3e3f10/ab885dd0ec06/SB_A04-11-00-2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/5875750cd36da9d0/3addace2b0b2/SB_A04-11-00-2023j01_BB.pdf)
### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Bei der Statistik über Schwangerschaftsabbrüche handelt es sich um eine zentrale Bundesstatistik, die vierteljährlich zum Quartalsende vom Statistischen Bundesamt durchgeführt und aufbereitet wird. Auskunftspflichtig für diese Totalerhebung sind die Inhaberinnen und Inhaber der Arztpraxen sowie die Leitung der Krankenhäuser, in denen innerhalb von zwei Jahren vor dem Quartalsende Schwangerschaftsabbrüche durchgeführt wurden. Das Statistische Bundesamt fasst die Quartalsergebnisse zu Jahresergebnissen zusammen. Die tiefste regionale Gliederung ist die Ebene der Bundesländer.

Mit dieser Statistik werden wichtige Informationen im Zusammenhang mit den Hilfen für Schwangere in Konfliktsituationen sowie über Maßnahmen zum Schutz des ungeborenen Lebens zur Verfügung gestellt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Schwangerschaftsabbrüche**ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/360e574f775e8a33/fa8528536861/MD_23311_2021.pdf)[Archiv](/search-results?q=23311&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-11-j)
