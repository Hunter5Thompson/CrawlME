

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 18.11.2024

#### Zensus 2022 in Berlin und Brandenburg

So wächst die Generation Alpha auf
----------------------------------

![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)

**D******ie Generation Alpha umfasst die Kinder, die zwischen 2010 und 2025 geboren wurden bzw. werden. Diese Generation wird stark von der zunehmenden Digitalisierung, politischen Umbrüchen, den Auswirkungen der Corona-Pandemie und den Herausforderungen des Klimawandels geprägt. Dank der Daten des Zensus 2022 können nun erstmals auch Einblicke in die Einwanderungsgeschichte dieser jungen Menschen in Berlin und Brandenburg gewonnen werden****.****

Der Zensus mit dem Stichtag 15. Mai 2022 ermöglicht eine nähere Betrachtung der Generation Alpha. Berücksichtigt werden hier alle Kinder, die zu diesem Zeitpunkt maximal 12 Jahre alt waren. Diese Gruppe macht 12,5 % der Berliner Bevölkerung aus, was 449.081 Personen entspricht. Die Ergebnisse zeigen, dass besonders viele Kinder bis 12 Jahre in den Bezirken Pankow, Spandau, Marzahn-Hellersdorf und Lichtenberg leben. Hier beträgt der Anteil an der Bevölkerung jeweils etwa 13,5 %.

###### am 15.05.2022 in den Berliner Bezirken

#### Kinder im Alter bis 12 Jahre

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Der Blick nach Brandenburg zeigt ein ähnliches Bild. 295.196 Kinder bis zu 12 Jahren machen einen Anteil von 11,7 % der Brandenburger Gesamtbevölkerung aus. Die Landeshauptstadt Potsdam hat mit 13,2 % anteilig die meisten Kinder in dieser Altersgruppe. Frankfurt (Oder) verfügt hingegen mit 10,4 % über den geringsten Anteil. Die beiden anderen kreisfreien Städte, Brandenburg an der Havel und Cottbus, liegen mit 11,1 % und 11,2 % fast im landesweiten Durchschnitt.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Große Unterschiede in der Einwanderungsgeschichte im Ländervergleich

Ein neues Merkmal beim Zensus 2022 ist die Einwanderungsgeschichte der Haushalte. Erstmals wird hier die Lebensgeschichte eines Menschen betrachtet. So müssen entweder die Person selbst oder beide Elternteile seit 1950 auf das heutige Gebiet Deutschlands zuge­zogen sein. Dann gelten sie als Einge­wanderte beziehungs­weise als in Deutschland geborene Nach­kommen von Einge­wanderten. Diese neue Methode erlaubt es, Haushalte in drei Kategorien einzuteilen: ohne, mit teilweiser oder mit vollständiger Einwanderungsgeschichte.

Die Ergebnisse zeigen, dass in Berlin rund die Hälfte der Kinder bis 12 Jahre in Haushalten lebt, die keine Einwanderungsgeschichte aufweisen. Das bedeutet im Umkehrschluss, dass rund 50 % der Kinder bis 12 Jahre in Haushalten aufwachsen, in denen mindestens eine Person eine Einwanderungsgeschichte hat. In Brandenburg dagegen lebt der überwiegende Teil der Kinder bis zu 12 Jahren in Haushalten ohne jegliche Einwanderungsgeschichte (80,9 %).

**Quelle:** Amt für Statistik Berlin-Brandenburg

Auffällig ist dabei die räumliche Verteilung: In den östlichen Bezirken Berlins wie Treptow-Köpenick, Pankow und Marzahn-Hellersdorf gibt es überdurchschnittlich viele Kinder in Haushalten ohne Einwanderungsgeschichte. Kinder in Haushalten mit vollständiger Einwanderungsgeschichte sind hingegen vor allem in den Bezirken Mitte, Spandau und Lichtenberg vertreten. Bezirke wie Charlottenburg-Wilmersdorf, Friedrichshain-Kreuzberg und Mitte weisen einen besonders hohen Anteil an Kindern bis 12 Jahren in Haushalten mit teilweise vorhandener Einwanderungsgeschichte auf.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Die vier kreisfreien Städte Brandenburgs weisen überdurchschnittlich hohe Zahlen an Kindern in Haushalten mit Einwanderungsgeschichte auf, jedoch sind diese immer noch niedriger als in den Berliner Bezirken. In der Grenzstadt Frankfurt (Oder) leben 23,1 % der Kinder bis zu 12 Jahren in Haushalten, in denen alle Personen außerhalb Deutschlands geboren wurden. Das ist der höchste Wert unter den kreisfreien Städten. In Brandenburg an der Havel beträgt der Anteil der Kinder bis 12 Jahre in Haushalten ohne Einwanderungsgeschichte 79,4 %. Das liegt knapp unter dem Brandenburger Durchschnitt.

**Quelle:** Amt für Statistik Berlin-Brandenburg

**Was bedeutet Einwanderungsgeschichte?**

Das Konzept der Einwanderungsgeschichte ersetzt im Zensus 2022 das Konzept des Migrationshintergrunds aus dem Zensus 2011. Dieses Konzept wurde von der Fachkommission Integrationsfähigkeit ausgearbeitet und betrachtet nicht mehr die Staatsangehörigkeit. Eine Einwanderungsgeschichte haben Personen, die entweder selbst oder deren beide Elternteile (unabhängig von beid- oder einseitiger Einwanderungsgeschichte) seit 1950 nach Deutschland eingewandert sind.

Falls Sie an Auswertungen des Zensus 2022 zu anderen Merkmalen oder einer anderen [räumlichen Ebene](/meine-region) interessiert sind, kontaktieren Sie uns gern unter [info@statistik-bbb.de](mailto:info@statistik-bbb.de). Eine Übersicht der Merkmale finden Sie in der Zensusdatenbank.

#### **Datenangebot**

###### Unser Zensus-Datenangebot

Mehr Daten zum Zensus 2022 in Berlin und Brandenburg gibt’s hier:  
[www.statistik-berlin-brandenburg.de/zensus22](/zensus22)

###### Zensusdatenbank

In der [Zensusdatenbank](https://ergebnisse.zensus2022.de/datenbank/online/) können Daten für Bund, Länder, Kreise, Gemeinden und Bezirke (Berlin, Hamburg) abgerufen und mit anderen Merkmalen kombiniert ausgewertet werden. Für die Weiterverarbeitung stehen verschiedene Ausgabeformate zur Verfügung. Die Zensusdatenbank enthält den **Merkmalskatalog** und kann auch mit Programmiersprachen direkt angesprochen werden.

###### Zensus-Atlas

Der [Zensus-Atlas](https://atlas.zensus2022.de/) umfasst Ergebnisse auf Basis von Gitterzellen (10 km, 1 km und 100 m) zu Bevölkerung, Wohnen und Heizen. Die dem Zensus-Atlas zugrundeliegenden Daten aus dem Zensus 2022 werden auf folgender Seite hochauflösend georeferenziert in 10km-, 1km- und 100m-Gitterzellen als Zip-Dateien zum Download bereitgestellt: <https://www.zensus2022.de/DE/Aktuelles/Hinweis_Zensusatlas.html>

###### Offizielle Website Zensus 2022

Auf der [Zensus 2022 Website](http://www.zensus2022.de) werden [Regionaltabellen](https://www.zensus2022.de/DE/Ergebnisse-des-Zensus/02-veroeffentlichung.html?nn=270470 "Veröffentlichung") zum Download bereitstellt. Sie enthalten Daten für Bund, Bundesländer, Regierungsbezirke, Stadtkreise/kreisfreie Städte/Landkreise, Gemeindeverbände sowie Gemeinden. Außerdem stehen [Podcasts, Videos und Animationen](https://www.zensus2022.de/DE/Mediathek/_inhalt.html "Mediathek")mit Hintergrundinformationen zur Verfügung.

### Kontakte

#### Informationsservice

#### Informationsservice

* [0331 8173-1777](tel:0331 8173-1777)
* [info@statistik-bbb.de](mailto:info@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Zensus](/search-results?q=tag%3AZensus)[* Zensus 2022](/search-results?q=tag%3AZensus 2022)[* Berlin](/search-results?q=tag%3ABerlin)[* Bezirke](/search-results?q=tag%3ABezirke)[* Einwanderung](/search-results?q=tag%3AEinwanderung)[* Generation Alpha](/search-results?q=tag%3AGeneration Alpha)
