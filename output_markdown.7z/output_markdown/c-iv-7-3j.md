

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Größenstruktur, sozialökonomische Betriebstypen sowie Rechtsformen der landwirtschaftlichen Betriebe in Brandenburg](/c-iv-7-3j)

Größenstruktur, sozialökonomische Betriebs­typen, Rechtsformen landwirtschaftlicher Betriebe in Brandenburg
-----------------------------------------------------------------------------------------------------------

#### 2023, drei- bis vierjährlich

###### Der Bericht enthält Angaben zu ausgewählten Merkmalen der Bodennutzung und Viehhaltung nach Rechtsformen und sozialökonomischen Betriebstypen sowie landwirtschaftliche Betriebe mit Gewinnermittlung und Umsatzbesteuerung.

BrandenburgMethodik
### Brandenburg

**Großbetriebliche Strukturen in Brandenburg**

Auch 34 Jahre nach dem Übergang zur Marktwirtschaft bestimmen großbetriebliche Strukturen die Brandenburger Landwirtschaft. So verfügten 6 % der Agrarbetriebe 2023 über eine landwirtschaftliche Fläche (LF) von mindestens 1.000 Hektar. Damit bewirtschafteten rund 330 Betriebe etwa 40 % der LF.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/9ad9dc19db95363f/2cada2c2c264/SB_C04-07-00_2023j03_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/c8c03ebb5ed8dc06/33a2f95132bf/SB_C04-07-00_2023j03_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[Landwirtschaftszählung (2020)](https://download.statistik-berlin-brandenburg.de/023848dc8f72ca47/3f8123557a5c/MD_41141_2020.pdf) | [Archiv](/search-results?q=MD_41141&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[Agrarstrukturerhebung (ASE)(2016)](https://download.statistik-berlin-brandenburg.de/98f0a5ac9f823baa/392752f4b056/MD_41121_2016.pdf)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-7-3j)
