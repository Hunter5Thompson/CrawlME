

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Brandenburg](/wahlen-brandenburg)
* [Kommunalwahlen in Brandenburg](/kommunalwahlen-brandenburg)

Kommunalwahlen in Brandenburg
=============================

Bei Kommunalwahlen werden unter anderem die Kreistage der Landkreise, die Stadtverordnetenversammlungen in kreisangehörigen und kreisfreien Städten, die Gemeindevertretungen sowie die Bürgermeister in kreisangehörigen Städten und Gemeinden gewählt.

Wählende haben bis zu drei Stimmen. Die Stimmen können auf einen Wahlvorschlag gegeben (kumulieren) oder auf verschiedene Wahlvorschläge verteilt werden (panaschieren). Die Wahlperiode beträgt fünf Jahre. (Ober-)Bürgermeister werden per Mehrheitswahl für die Dauer von fünf bzw. acht Jahren gewählt.

Kommunalwahlen 2024Kommunalwahlen 2019Endgültige ErgebnisseWahlstrukturdatenHistorie

Kommunalwahlen am 09**. Juni****2024**
--------------------------------------

#### Endgültige Ergebnisse für Brandenburg

#### Die endgültigen Ergebnisse

**Alle Daten zu den Kommunalwahlen 2024 in Brandenburg in interaktiver Form**

[Zu den Ergebnissen](https://www.wahlergebnisse.brandenburg.de/wahlen/KO2019/diagramUberblick.html)[Ergebnisbericht (Gemeinden) XLSX](https://download.statistik-berlin-brandenburg.de/3b5d90e97e7f757e/08fa291f7cd5/SB_B07-03-04_2019j05_BB.xlsx)[Ergebnisbericht (Gemeinden) PDF](https://download.statistik-berlin-brandenburg.de/78adfea8b4fa20cc/e889febfde64/SB_B07-03-04_2019j05_BB.pdf)[Ergebnisse nach Wahlbezirken XLSX](https://download.statistik-berlin-brandenburg.de/71cc4e41ec4d6a2f/6aa3cf60190c/DL_BB_KW2019.xlsx)[Ergebnisse nach Landkreisen, kreisfreien Städten, Ämtern und Gemeinden XLSX](https://download.statistik-berlin-brandenburg.de/636627044e1d256b/e24d4b6bcb3a/DL_BB_2_KW2019.xlsx)

**Wahlen zu den Gemeindevertretungen:**

[Ergebnisbericht (Gemeinden) XLSX](https://download.statistik-berlin-brandenburg.de/03e424c651d5363e/1c23fce8680e/SB_B07-03-05_2019j05_BB.xlsx)[Ergebnisbericht (Gemeinden) PDF](https://download.statistik-berlin-brandenburg.de/4ba4ace6fc48bdd6/d9a293f747fc/SB_B07-03-05_2019j05_BB.pdf)[Tabelle Ergebnis nach Gemeinden XLSX](https://download.statistik-berlin-brandenburg.de/0f35d2839699a5ef/ebb64921486a/DL_BB_GV2019.xlsx)

**Bürgermeisterwahlen:**

[Ergebnisbericht XLSX](https://download.statistik-berlin-brandenburg.de/0bb804f3f6fb023e/8f312d701860/SB_B07-03-06_2019j05_BB.xlsx)[Ergebnisbericht PDF](https://download.statistik-berlin-brandenburg.de/04cafe5e2a2d4174/474f2a9fd57d/SB_B07-03-06_2019j05_BB.pdf)

Kommunalwahlen am 09**. Juni****2024**
--------------------------------------

#### Endgültige Ergebnisse für Brandenburg

###### Kreistagswahlen/Wahlen der Stadtverordneten­versammlungen der kreisfreien Städte

[Zu den Ergebnissen](https://wahlergebnisse.brandenburg.de/12/200/20240609/kreistagswahl_land/)
###### Gemeindevertretungswahl/Stadtverordnetenversammlung

[Zu den Ergebnissen](https://wahlergebnisse.brandenburg.de/12/300/20240609/gemeindevertretungswahl_land/)
###### Wahl zur Verbandsgemeinde­versammlung

[Zu den Ergebnissen](https://wahlergebnisse.brandenburg.de/625031/400/20240609/verbandsgemeindevertretungswahl_vg/)
#### **Ergebnisse****als Download**

****Wahlen der Kreistage der Landkreise und Stadtverordnetenversammlungen der kreisfreien Städte:****

[Ergebnisbericht PDF](https://download.statistik-berlin-brandenburg.de/d195e8d6bb6e3b5e/13eb46875d26/SB_B07-03-03_2024j05_BB.pdf)[Ergebnisbericht XLSX](https://download.statistik-berlin-brandenburg.de/5d572a6fc2f81449/259a5d34a4f4/SB_B07-03-03_2024j05_BB.xlsx)[Ergebnisse nach Wahlbezirken XLSX](https://download.statistik-berlin-brandenburg.de/976e9b03341a1b50/63267b67ccbf/DL_BB_KW2024.xlsx)[Ergebnisse nach Landkreisen, kreisfreien Städten, Ämtern und Gemeinden XLSX](https://download.statistik-berlin-brandenburg.de/ce4c4adabd35888e/e21672e4094b/DL_BB_2_KW2024.xlsx)

**Wahlen zu den Gemeindevertretungen:**

[Ergebnisbericht (Gemeinden) PDF](https://download.statistik-berlin-brandenburg.de/ce66ca53ac0fbeca/2ac71a3ab551/SB_B07-03-05_2024j05_BB.pdf)[Ergebnisbericht (Gemeinden) XLSX](https://download.statistik-berlin-brandenburg.de/025b18c0b70b7c32/6e857ac90471/SB_B07-03-05_2024j05_BB.xlsx)

**Bürgermeisterwahlen:**

[Ergebnisbericht PDF](https://download.statistik-berlin-brandenburg.de/8581cc6d4f141bfd/ce376c4eeaa2/SB_B07-03-06_2024j05_BB.pdf)[Ergebnisbericht XLSX](https://download.statistik-berlin-brandenburg.de/4d90450e9111a927/becbee989f88/SB_B07-03-06_2024j05_BB.xlsx)

Wahlstrukturdaten
-----------------

#### Demografische und politische Strukturen von Brandenburg

#### **Download**

[Vorwahldaten, Strukturdaten XLSX](https://download.statistik-berlin-brandenburg.de/d2b598cde5ecc92e/b4ac8178a421/SB_B07-05-01_2024j05_BB.xlsx) [Vorwahldaten, Strukturdaten PDF](https://download.statistik-berlin-brandenburg.de/1429c22ca03a9ec1/01f8e4692597/SB_B07-05-01_2024j05_BB.pdf)

Historische Daten
-----------------

**Endgültige Ergebnisse zu Kommunalwahlen in Brandenburg**

**Wahlen zu den Kreistagen (Landeswahlleitung)**

**Wahlen zu den Gemeindevertretungen**

**Wahlen zu den Kreistagen (nach Gemeinden)**

**Bürgermeisterwahlen**

  

**Ergebnisse nach Wahlbezirken, Landkreisen, kreisfreien Städten, Ämtern und Gemeinden zu Kommunalwahlen in Brandenburg**

[**Strukturdaten, Vorwahldaten zu Kommunalwahlen in Brandenburg**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00000709)
##### Kommunalwahlen in Brandenburg**Stimmenanteile für ausgewählte Parteien 1993 bis 2024**

1 Die Anzahl der gültigen Stimmen kann das dreifache der Anzahl der Wähler betragen.2 1994-2004: PDS3 2014: CDU und andere4 ab 2014: GRÜNE/B90 und andere**Quelle:** Amt für Statistik Berlin-Brandenburg

1 – 1990-2004: PDS; ab 2005: DIE LINKE  
2 – 2014: CDU und andere  
3 – ab 2014: GRÜNE/B90 und andere

##### **Entwicklung der Wahlergebnisse im Zeitverlauf:**

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/69a244354cfe4f30/bd0af3b695b0/Kommunalwahlen_Lange-Reihe_2024_Brandenburg.xlsx)

Weiterführende Informationen
----------------------------

###### Metadaten

Unsere Metadaten liefern Informationen zu den erhobenen Daten und der angewendeten Methodik. Ergänzt werden diese durch Musterstimmzettel, Datensatzbeschreibungen und gegebenenfalls einen Qualitätsbericht.

**Allgemeine Wahlstatistik, Kreistagswahlen,  Gemeinderatswahlen,  Bürgermeisterwahlen****(2024)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/0c9820d9f6d287d0/7f415d227706/MD_14411_2024.pdf)

**Allgemeine Wahlstatistik, Kreistagswahlen,  Gemeinderatswahlen,  Bürgermeisterwahlen****(2019)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/986d6c5f580a03eb/c50d20636065/MD_14411_2019.pdf) 

#### Der Landeswahlleiter für Brandenburg auf [wahlen.brandenburg.de](https://wahlen.brandenburg.de/wahlen/de/)


