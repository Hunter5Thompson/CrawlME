

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Steuern](/gesellschaft/staat/steuern)
* [Umsatzsteuerstatistik (Voranmeldungen) in Berlin und Brandenburg](/l-iv-1-j)

Umsatzsteuerstatistik (Voranmeldungen) in Berlin und Brandenburg
----------------------------------------------------------------

#### 2022, jährlich

###### Die Umsatzsteuerstatistik dient der Beurteilung der Struktur und Wirkungsweise der Umsatzsteuer und ihrer wirtschaftlichen und sozialen Bedeutung. Aus der Beobachtung der Umsätze ergeben sich wertvolle Informationen für die Haushaltsplanungen und Steuerschätzungen des Bundes und der Länder.

BerlinBrandenburgMethodik
### Berlin

1 Steuerpflichtige mit Lieferungen und Leistungen über 22 000 EUR**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/2075684335a14aed/6bae76063116/SB_L04-01-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/bc853c829b8d4f37/527f09ac7a63/SB_L04-01-00_2022j01_BE.pdf)

**Umsatzsteuereinnahmen 2022 um 16,3 % gestiegen**

In 2022 betrug die Anzahl der zur Umsatzsteuer-Voranmeldung verpflichteten Unternehmen im Land Berlin 174.313. Das waren 6,0 % mehr als im Jahr davor. Die Berliner Unternehmen konnten gegenüber dem Vorjahr ein Umsatzzuwachs von 25,6 % erwirtschaften, wie das Amt für Statistik Berlin-Brandenburg mitteilt. Rund 378 Milliarden EUR an Umsätzen aus Lieferungen und Leistungen wurden bei der Senatsverwaltung angemeldet und 10,3 Milliarden EUR Umsatzsteuer im Voraus entrichtet. Somit stiegen die Einnahmen um 16,3 %.

Die drei umsatzstärksten Wirtschaftsbereiche waren der Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugen, die Energieversorgung und das Verarbeitende Gewerbe. Sie erzielten insgesamt 57,0 % des Umsatzes (215 Milliarden EUR).

Die Berliner Unternehmen des Handels, der Instandhaltung und Reparatur von Kraftfahrzeugen waren am umsatzstärksten (97 Milliarden EUR). Das entspricht knapp 25,7 % der Umsätze in Berlin und einem Zuwachs von 30,0 % zum Vorjahr. Der Bereich mit den zweithöchsten Umsätzen war die Energieversorgung mit 62,3 Milliarden EUR. Dies entspricht einem Umsatzanteil von 16,5 % und einem Umsatzwachstum von 44,6 %. Das verarbeitende Gewerbe erwirtschaftete mit 55,7 Milliarden EUR die dritthöchsten Umsätze und 14,8 % der Gesamtumsätze. Die Umsätze in diesem Bereich steigerten sich um 23,7 %.

### Kontakt

#### Anett Sommerfeld

Steuern

#### Anett Sommerfeld

Steuern

* [0331 8173-1226](tel:0331 8173-1226)
* [steuern@statistik-bbb.de](mailto:steuern@statistik-bbb.de)
#### Andrea Urbanski

Steuern

#### Andrea Urbanski

Steuern

* [0331 8173-1224](tel:0331 8173-1224)
* [steuern@statistik-bbb.de](mailto:steuern@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Umsatzsteuereinnahmen 2022 um knapp 5 %****gestiegen**

In 2022 ist die Zahl der zur Umsatzsteuer-Voranmeldung verpflichteten Unternehmen im Land Brandenburg leicht gestiegen. Im Berichtsjahr betrug die Anzahl der Unternehmen 86.770 (+1,7 %). Die Brandenburger Unternehmen konnten gegenüber dem Vorjahr ein Umsatzzuwachs von knapp 13 % erwirtschaften, wie das Amt für Statistik Berlin-Brandenburg mitteilt. Rund 110,2 Milliarden EUR an Umsätzen aus Lieferungen und Leistungen wurden bei der Finanzverwaltung angemeldet und 3,9 Milliarden EUR Umsatzsteuer im Voraus gezahlt.

Die drei umsatzstärksten Wirtschaftsbereiche waren das Verarbeitende Gewerbe, der Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugen sowie das Baugewerbe. Hier wurden zusammen 59,2 % der Umsätze (65,2 Milliarden EUR) erbracht.

26,8 Milliarden EUR bzw. 24,3 % der Umsätze in Brandenburg erwirtschafteten die knapp 5.000 Unternehmen des Verarbeitenden Gewerbes. Diese Unternehmen steigerten ihren Umsatz um 22,5 %. Der Handel inklusive Instandhaltung und Reparatur von Kraftfahrzeugen mit seinen knapp 15.000 Voranmeldepflichtigen erzielte 25,5 Milliarden EUR Umsatz aus Lieferungen und Leistungen. Das entsprach einem Anteil von 23,1 % und einem Zuwachs von 5,1 % gegenüber dem Vorjahr. Der Umsatz der 19.000 Brandenburger Unternehmen des Baugewerbes betrug 12,9 Milliarden EUR, knapp 12,0 % des landesweiten Umsatzes und 9,6 % mehr als 2021.

  


1 Steuerpflichtige mit Lieferungen und Leistungen über 22 000 EUR**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ceb7350b3a7ee00f/ef679266c29a/SB_L04-01-00_2022j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/ba84e33b5f97cefd/59ed9c10ff5a/SB_L04-01-00_2022j01_BB.pdf)
### Kontakt

#### Anett Sommerfeld

Steuern

#### Anett Sommerfeld

Steuern

* [0331 8173-1226](tel:0331 8173-1226)
* [steuern@statistik-bbb.de](mailto:steuern@statistik-bbb.de)
#### Andrea Urbanski

Steuern

#### Andrea Urbanski

Steuern

* [0331 8173-1224](tel:0331 8173-1224)
* [steuern@statistik-bbb.de](mailto:steuern@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Umsatzsteuerstatistik dient der Beurteilung der Struktur und Wirkungsweise der Umsatzsteuer und ihrer wirtschaftlichen und sozialen Bedeutung. Aus der Beobachtung der Umsätze ergeben sich wertvolle Informationen für die Haushaltsplanungen und Steuerschätzungen des Bundes und der Länder.

Erfasst werden alle Unternehmen, die im Statistikjahr Umsatzsteuer-Voranmeldungen abgegeben haben, mit jährlichen Lieferungen und Leistungen über 22.000 EUR.

Die Umsatzsteuerstatistik (Voranmeldungen) wird jährlich erhoben und veröffentlicht. Ergebnisse für das Land und Bundesergebnisse liegen ca. 12 Monate nach Ende des Berichtszeitraums vor.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Umsatzsteuerstatistik (Voranmeldungen)**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/62c4928d63308508/df2d44921134/MD_73311_2022.pdf)[Archiv](/search-results?q=73311&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-iv-1-j)
