

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 05.07.2024

#### 10. Nationaler Bildungsbericht erschienen

Familienformen in Deutschland – zwischen Nesthockern und Alleinerziehenden
--------------------------------------------------------------------------

![iStock.com / fizkes](https://download.statistik-berlin-brandenburg.de/59ff41215e92a154/de624b8c4887/v/4dd18e6905d9/bevoelkerung-gesellschaft-young-father-playing-with-bricks-and-toys-with-little-kids-picture-id1201510270.jpg "iStock.com / fizkes")

**Der erste und oft wesentliche Ort für die Sozialisation und Persönlichkeitsbildung von Kindern ist die Familie. Hier findet ein Großteil der informellen und non-formalen Bildung statt. Der 10. Nationale Bildungsbericht „Bildung in Deutschland 2024“ betrachtet die Familie deswegen als Rahmenbedingung für Bildung und wirft einen Blick auf die regionale Verteilung und zeitliche Entwicklung der Familienformen in Deutschland.**

Aktuell lebt die Hälfte (49 %) der Bevölkerung in Deutschland in Familien mit Kindern. Hinsichtlich der Lebens- und Familienformen zeigt sich immer noch ein markanter Unterschied zwischen den beiden Landesteilen: Während in Westdeutschland rund 50 % der Bevölkerung in einem Familienzusammenhang mit Kindern leben, sind es in Ostdeutschland 44 %. Gründe für diesen Unterschied liegen in Faktoren wie dem Geburteneinbruch in Ostdeutschland in den frühen 1990er-Jahren mit der Folge einer verkleinerten Elterngeneration (Echoeffekt) sowie dem innerdeutschen Wanderungsverhalten in den Nachwendejahren. 61 % der Bevölkerung mit Einwanderungsgeschichte leben in Familien, jedoch nur 45 % der Bevölkerung ohne Einwanderungsgeschichte.

In zwei Dritteln (69 %) der Familien mit minderjährigen Kindern leben die Eltern als Ehepaar zusammen, 12 % sind Lebensgemeinschaften. Auch im Heiratsmuster unterscheiden sich West- und Ostdeutschland: In Westdeutschland ist die eheliche Form des Zusammenlebens mit rund 73 % stärker verbreitet als in Ostdeutschland mit 54 %: Dort bestehen Familien häufiger aus nichtehelichen Lebensgemeinschaften (22 % gegenüber 10 % in Westdeutschland) oder in Alleinerziehendenfamilien (24 % gegenüber 18 %), wobei vor allem in Ostdeutschland ein deutlicher Rückgang von Alleinerziehendenfamilien zu verzeichnen ist.

**Abbildung im 10. Nationalen Bildungsbericht:****Familien mit Kindern unter 18 Jahren in Deutschland nach Familienform, Einwanderungsgeschichte und Region**

![Abbildung Bildungsbericht 2022 bildungsbezogene Risikolagen](https://download.statistik-berlin-brandenburg.de/230aa1bf361846c7/9425507a0d6a/v/77701f74f5a3/familienformen.PNG "Abbildung Bildungsbericht 2022 bildungsbezogene Risikolagen")

Im Vergleich der Länder fallen außerdem die Stadtstaaten mit höheren Anteilen von Alleinerziehendenfamilien auf. In Westdeutschland hat sich der Anteil der verheirateten Elternpaare in den letzten neun Jahren praktisch nicht verändert, in Ostdeutschland stieg er leicht. Hat die Bezugsperson der Familie (erhebungstechnisch bedingt der Vater, bei gleichgeschlechtlichen Lebensgemeinschaften die ältere Person) eine Einwanderungsgeschichte, sind aktuell 75 % dieser Eltern verheiratet; dieser Anteil liegt 8 Prozentpunkte über dem von Familien ohne Einwanderungsgeschichte der Bezugsperson.

Innerhalb der letzten neun Jahre ist der Anteil der Ein-Kind-Familien bei verheirateten Eltern und Alleinerziehenden zurückgegangen, wobei die Ein-Kind-Familie bei Alleinerziehenden nach wie vor vorherrschend ist. Der Anteil der Ehepaare mit zwei und mehr Kindern ist deutschlandweit von 37 % auf 40 % gestiegen. Drei und mehr Kinder sind vorwiegend bei verheirateten Eltern in der Bevölkerungsgruppe mit Einwanderungsgeschichte verbreitet.

In Berlin herrschen mit 77 % Paarfamilien vor. 67 % aller Berliner Familien sind Paarfamilien mit einem oder zwei Kindern. Der Anteil der Paarfamilien in Brandenburg beträgt 76 %, auch hier besteht mit 69 % der überwiegende Teil der Familien aus Paaren mit ein oder zwei Kindern. In beiden Ländern liegen die Anteile der Alleinerziehendenfamilien sowohl mit einem als auch mit zwei Kindern über dem Bundesdurchschnitt.

#### Verlängertes Wohnen im Elternhaus

In Deutschland wohnt knapp die Hälfte (48 %) der jungen Erwachsenen im Ausbildungs- und Studienalter von 18 bis 27 Jahren weiter im elterlichen Haushalt, junge Männer mit 53 % häufiger als junge Frauen (43 %). In Westdeutschland liegen die Anteile um jeweils über 10 Prozentpunkte höher als in Ostdeutschland. 68 % der hier geborenen 18- bis 27-Jährigen mit zugewanderten Elternteilen wohnen noch bei den Eltern. Tiefergehende Analysen legen nahe, dass diese „Nesthocker“ öfter noch die Schule besuchen oder sich in Ausbildung befinden als gleichaltrige Personen mit eigenem Haushalt, wobei bei Letzteren Hochschulausbildung und Promotionsstudium häufiger zu finden sind. Wichtige Faktoren für diese Entwicklung könnten die in den letzten Jahren gestiegenen Kosten sowie der in vielen Regionen deutlich angespanntere Wohnungsmarkt sein.

„Bildung in Deutschland 2024“ ist der 10. Nationale Bildungsbericht. Im Bericht wird indikatorgestützt auf Grundlage von Daten der amtlichen Statistik und weiterer Datenquellen das gesamte Bildungsgeschehen im Lebensverlauf – von der frühen Bildung bis zur Weiterbildung im Erwachsenenalter – dargestellt. Eine Analyse der Rahmenbedingungen für den Bildungserwerb mit den Aspekten demografische und wirtschaftliche Entwicklung, Erwerbstätigkeit und Familien und Lebensformen vervollständigt das Bild. Viele Ergebnisse liegen auf regionaler Ebene und im internationalen Vergleich vor.

###### **Hier geht es zum 10. Nationalen Bildungsbericht für Deutschland:**

[![Titel des 10. Nationalen Bildungsberichts](https://download.statistik-berlin-brandenburg.de/90c0d53c4654339e/a22902327d1e/v/6b0f60f23a6e/Cover-Bildungsbericht.PNG "Zum 10. Nationalen Bildungsbericht")](https://www.bildungsbericht.de/de)

Der Bericht wird von einer unabhängigen Gruppe von Wissenschaftlerinnen und Wissenschaftlern unter Federführung des DIPF | Leibniz-Institut für Bildungsforschung und Bildungsinformation erstellt. Beteiligt sind das Deutsche Institut für Erwachsenenbildung – Leibniz-Zentrum für Lebenslanges Lernen (DIE), das Deutsche Jugendinstitut (DJI), das Deutsche Zentrum für Hochschul- und Wissenschaftsforschung (DZHW), das Leibniz-Institut für Bildungsverläufe (LIfBi), das Soziologische Forschungsinstitut Göttingen (SOFI) an der Georg-August-Universität sowie die Statistischen Ämter des Bundes und der Länder. Das Amt für Statistik Berlin-Brandenburg vertritt dabei die Statistischen Ämter der Länder. Die Kultusministerkonferenz (KMK) und das Bundesministerium für Bildung und Forschung (BMBF) fördern die Erarbeitung des Berichts.

### Kontakte

#### PD Dr. Holger Leerhoff

Querschnittsanalysen, EXSTAT, Geoservice

#### PD Dr. Holger Leerhoff

Querschnittsanalysen, EXSTAT, Geoservice

* [0331 8173-3675](tel:0331 8173-3675)
* [analysen@statistik-bbb.de](mailto:analysen@statistik-bbb.de)
#### Ricarda Nauenburg

Querschnittsanalysen

#### Ricarda Nauenburg

Querschnittsanalysen

* [0331 8173-3697](tel:0331 8173-3697)
* [analysen@statistik-bbb.de](mailto:analysen@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Bildung](/search-results?q=tag%3ABildung)[* Bildungsbericht](/search-results?q=tag%3ABildungsbericht)[* Risikolagen](/search-results?q=tag%3ARisikolagen)[* Chancengleichheit](/search-results?q=tag%3AChancengleichheit)[* Bildungssystem](/search-results?q=tag%3ABildungssystem)[* Einwanderungsgeschichte](/search-results?q=tag%3AEinwanderungsgeschichte)
