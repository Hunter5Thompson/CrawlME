

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Krankenhaus und Rehabilitation](/krankenhaus-und-rehabilitation)

Krankenhaus undRehabilitation
=============================

Die Krankenhausstatistik liefert wichtige Infos über die Anzahl und Arten von Behandlungen der auskunftspflichtigen Einrichtungen. Sie zeigt Zusammenhänge zwischen Morbidität und Kostenentwicklung in Krankenhäusern und gibt Auskunft darüber, wie oft die Bevölkerung stationäre Gesundheitsleistungen nutzt. Die Ergebnisse beeinflussen gesundheitspolitische Entscheidungen des Bundes und der Länder.

Die Krankenhausstatistik umfasst drei Erhebungsbereiche: Die **Grunddaten** informieren über die sachliche und personelle Ausstattung der Krankenhäuser sowie die Patientenbewegung in den Einrichtungen und ihren Fachabteilungen. Die **Diagnosedaten**geben Auskunft über die Art der Erkrankung (Hauptdiagnose) und ausgewählte soziodemografische Merkmale wie Alter, Geschlecht und Wohnort der Patientinnen und Patienten. Im Bereich **Kostennachweis**sind die Aufwendungen für Sachmittel und Personal dargestellt.

  


Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Krankenhäuser in Berlin und Brandenburg Teil I – Grunddaten, jährlich (AIV2-j)](/a-iv-2-j)[Krankenhäuser in Berlin und Brandenburg Teil II – Diagnosen der Krankenhauspatientinnen und -patienten, jährlich (AIV3-j)](/a-iv-3-j)[Krankenhäuser in Berlin und Brandenburg Teil III – Kostennachweis, jährlich (AIV4-j)](/a-iv-4-j)[Vorsorge- oder Rehabilitationseinrichtungen in Brandenburg, jährlich (AIV5-j)](/a-iv-5-j)

Zeitreihen
----------

Aufgestellte BettenVerweildauer**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/561d7d583c89ed3b/4c3d06a1da76/krankenhaus-und-rehabilitation-zeitreihe.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/7728e9a4f0dbb05b/b6afdfffde28/krankenhaus-und-rehabilitation-lange-reihe-krankenhaeuser.xlsx)

Basisdaten
----------

Einrichtungen und BettenPatient/-innenPersonal

Weitere Datenangebote
---------------------

#### Krankenhausatlas

Wie schnell erreichen Sie in der Hauptstadtregion Berlin-Brandenburg ein Krankenhaus? Das und viele weitere Informationen zur Erreichbarkeit von Krankenhäusern liefert der interaktive Krankenhausatlas der Statistischen Ämter des Bundes und der Länder.

[Zum Krankenhausatlas](https://krankenhausatlas.statistikportal.de/)
#### Krankenhausverzeichnis

Das Verzeichnis weist alle Einrichtungen zur stationären medizinischen Versorgung der Bevölkerung in Deutschland nach. Es beinhaltet ausgewählte Merkmale wie die Anzahl der aufgestellten Betten sowie Angaben zur Teilnahme an der stationären Notfallversorgung.

[Zum Krankenhausverzeichnis](https://www.statistikportal.de/de/veroeffentlichungen/krankenhausverzeichnis)![](https://download.statistik-berlin-brandenburg.de/20f1ef24a524f894/52c9d3dba474/v/6dc01f454b56/schmuckbild-krankenhausatlas-2.png)

Haben Sie Fragen?
-----------------

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / Spotmatik](https://download.statistik-berlin-brandenburg.de/09fe07d2f99a71db/1fd2b255bc8f/v/d5efaa426575/gesellschaft-gesundheit-doctors-hospital-corridor-nurse-pushing-gurney-stretcher-bed-picture-id478740625.jpg "iStock.com / Spotmatik")](/179-2024)**Krankenhausdiagnosestatistik 2023 Berlin und Brandenburg**[#### Zahl der vollstationären Behandlungen steigt langsam wieder an](/179-2024)

Rund 1,25 Millionen Menschen sind 2023 in den Krankenhäusern der Metropolregion behandelt worden.

[![iStock.com / shironosov](https://download.statistik-berlin-brandenburg.de/647f45d19854bdb2/227c037ed261/v/bb26ee51b785/gesellschaft-gesundheit-young-supportive-female-caregiver-sitting-by-senior-man-in-wheelchair-picture-id1203365703.jpg "iStock.com / shironosov")](/136-2024)**Stationäre Krankenhausbehandlungen in Berlin und Brandenburg**[#### Anzahl der Alzheimerpatientinnen und -patienten steigt](/136-2024)

Pressemitteilung Nr. 136 Wie das Amt für Statistik Berlin-Brandenburg anlässlich des Welt-Alzheimertages am 21. September mitteilt, wurden im Jahr 2022 in Berlin 871 Menschen und in Brandenburg 697...

[![iStock.com / upixa](https://download.statistik-berlin-brandenburg.de/70cad83eb120c858/1dd5af74599e/v/05ec05160379/gesellschaft-gesundheit-emergency-admission-entrance-hospital-doctor-wheelchair-picture-id1130918876.jpg "iStock.com / upixa")](/103-2024)**Stationäre Behandlungen wegen Virushepatitis**[#### Anstieg der Behandlungszahlen in Berlin und Brandenburg](/103-2024)

Pressemitteilung Nr. 103 Die Zahl der stationären Behandlungen wegen Virushepatitis, einer Virusinfektion mit überwiegender Entzündung der Leber, stieg 2022 in den Berliner Krankenhäusern gegenüber...

[Zu unseren News](/news)

[* Krankenhäuser](/search-results?q=tag%3AKrankenhäuser)[* Rehabilitationseinrichtungen](/search-results?q=tag%3ARehabilitationseinrichtungen)[* Vorsorgeeinrichtungen](/search-results?q=tag%3AVorsorgeeinrichtungen)[* Krankenhauspersonal](/search-results?q=tag%3AKrankenhauspersonal)[* Gesundheitskosten](/search-results?q=tag%3AGesundheitskosten)[* Krankenhausbetten](/search-results?q=tag%3AKrankenhausbetten)[* Patienten](/search-results?q=tag%3APatienten)
