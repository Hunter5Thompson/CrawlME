

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Betriebe mit ökologischem Landbau in Brandenburg](/c-iv-2-3j)

Betriebe mit ökologischem Landbauin Brandenburg
-----------------------------------------------

#### 2023, drei- bis vierjährlich

###### Die Daten informieren über die umgestellten und in Umstellung befindlichen ökologischen landwirtschaftlich genutzten Flächen, die Anbauflächen nach Kulturarten, Kulturformen, Pflanzengruppen, Pflanzenarten und Nutzungszweck sowie die Zahl der in die ökologische Wirtschaftsweise einbezogenen Tiere.

BrandenburgMethodik

Brandenburg
-----------

**Ökolandbau auf neuem Höchststand**

2023 wirtschafteten in Brandenburg rund 1.000 Betriebe nach den Prinzipien des ökologischen Landbaus. Dies sind 19 % der 5.400 im Rahmen der Agrarstrukturerhebung 2023 befragten Betriebe. Das ist ein neuer Höchststand im Land. 2010 waren es 690 Betriebe und 10 Jahre später wurden 821 Betriebe erfasst. Im Durchschnitt lag die Flächenausstattung der Öko-Betriebe 2023 bei 230 Hektar, während die der konventionell arbeitenden Betriebe 270 Hektar betrug.

Die Öko-Betriebe verfügten 2023 über eine Fläche von 228.400 Hektar. Bezogen auf die gesamte landwirtschaftlich genutzte Fläche entspricht dieser Wert einem Anteil von 16 %. Damit steht Brandenburg nach Bayern mit 423.000 Hektar an zweiter Stelle im Öko-Landbau, gefolgt von Mecklenburg-Vorpommern mit 199.700 Hektar.

660 Öko-Betriebe (65 %) in Brandenburg befassten sich mit der Tierhaltung. Insgesamt wurden in diesen Betrieben 79.300 Rinder (darunter 32.400 Ammen- und Mutterkühe), 8.900 Schweine, 20.200 Schafe sowie 520.600 Hühner ökologisch gehalten. Das waren 19 % der insgesamt in Brandenburg gehaltenen Rinder, darunter 40 % der Brandenburger Ammen- und Mutterkühe, 2 % der Schweine, 26 % der Schafe und 7 % der Hühner.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/5fe203be10fb00dc/8fcbab96c734/SB_C04-02-00_2023j03_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/cdb8b6673693ed24/04e2c964023f/SB_C04-02-00_2023j03_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Agrarstrukturerhebung (ASE)**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/05723b6559976fb1/704419dd5b82/MD_41121_2023.pdf)[Archiv](/search-results?q=41121&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-2-3j)
