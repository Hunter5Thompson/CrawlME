

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 28.06.2023

#### Realsteuerhebesätze 2022 jetzt online verfügbar

Schönefeld meldet niedrigsten Gewerbesteuerhebesatz
---------------------------------------------------

![iStock.com / Ralf Geithe](https://download.statistik-berlin-brandenburg.de/4ee954f5b90c0c5d/ceb6f0190487/v/4fa619ce9cbf/gesellschaft-staat-old-tab-with-the-german-word-for-taxes-picture-id945026698.jpg "iStock.com / Ralf Geithe")

**Die Hebesätze der Gewerbesteuer lagen im Jahr 2022 in nahezu allen Brandenburger Gemeinden (96,6 %) zwischen 300 % und 399 %. Gewerbetreibende fanden damit in Brandenburg gleich hohe Gewerbesteuer-Hebesätze vor wie in den meisten Gemeinden bundesweit. 8 752 der insgesamt 10 786 Gemeinden in Deutschland (81,1 %) hatten im Jahr 2022 Hebesätze der Gewerbesteuer zwischen 300 % und 399 % festgesetzt.**

Von den 413 Gemeinden in Brandenburg meldete wie im Jahr zuvor Schönefeld (Landkreis Dahme-Spreewald) mit 240 % den niedrigsten Gewerbesteuerhebesatz, die kreisfreie Stadt Potsdam mit 455 % den in Brandenburg höchsten Gewerbesteuerhebesatz. Deutschlandweit am geringsten war der Hebesatz in Langenwolschendorf im Landkreis Greiz in Thüringen (200 %).

#### Hebesätze für Grundsteuer A und B im bundesweiten Vergleich

Im bundesweiten Vergleich wiesen die Gemeinden in Brandenburg unterdurchschnittliche Hebesätze bei der Grundsteuer A auf. Während deutschlandweit nur 11,8 % der Gemeinden Hebesätze unter 300 % festgesetzt hatten, erhoben in Brandenburg 37,5 % der Gemeinden Hebesätze für land- und forstwirtschaftlich genutzte Flächen unter 300 %. Den geringsten Wert in Brandenburg mit 200 % meldeten 31 Gemeinden, den höchsten Schwielochsee im Landkreis Dahme-Spreewald (1 441 %). Bundesweit reichten die Hebesätze von 45 % in Christinenthal im Kreis Steinburg (Schleswig-Holstein) bis 1 900 Prozent in den Gemeinden Bad Herrenalb und Bad Wildbad im Landkreis Calw (Baden-Württemberg).

Bei der Grundsteuer B wiesen in Brandenburg 19 Gemeinden einen Hebesatz von 300 % aus. Den höchsten Hebesatz bei der Grundsteuer B meldete auch hier die Landeshauptstadt Potsdam mit 545 %. Deutschlandweit reichte die Spanne bei der Grundsteuer B von 45 % in Christinenthal im Kreis Steinburg (Schleswig-Holstein) bis 1 050 % in Lorch im Rheingau-Taunus-Kreis (Hessen).

In Berlin betrugen die Hebesätze bei der Grundsteuer A 150 %, bei der Grundsteuer B 810 % und bei der Gewerbesteuer 410 %.

#### Wo gibt's noch mehr Daten?

Die Gemeinschaftsveröffentlichung „Hebesätze der Realsteuern in Deutschland“ der Statistischen Ämter des Bundes und der Länder beinhaltet für die deutschen Kommunen Angaben zu den Hebesätzen der Grundsteuer A (für land- und forstwirtschaftlich genutzte Flächen), der Grundsteuer B (für sonstige Grundstücke) und der Gewerbesteuer im Jahr 2022. Einen schnellen Überblick über die Hebesätze 2022 für Gewerbesteuer und Grundsteuer in den Gemeinden liefert eine [interaktive Karte](https://www.statistikportal.de/de/karte-hebesaetze).

[Die Gemeinschaftsveröffentlichung kostenlos herunterladen.](https://www.statistikportal.de/sites/default/files/2023-06/Hebes%C3%A4tze%20der%20Realsteuern%202022.xlsx)
### Kontakte

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Publikationen

Pressemitteilungen[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

[* Gemeinschaftsveröffentlichung](/search-results?q=tag%3AGemeinschaftsveröffentlichung)[* Gewerbe](/search-results?q=tag%3AGewerbe)[* Gewerbesteuer](/search-results?q=tag%3AGewerbesteuer)[* Hebesätze](/search-results?q=tag%3AHebesätze)[* Grundsteuer](/search-results?q=tag%3AGrundsteuer)
