

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Bevölkerungsstand](/bevoelkerung/demografie/bevoelkerungsstand)
* [Bevölkerungsstand in Berlin und Brandenburg – Jahresergebnisse](/a-i-3-j)

Bevölkerungsstand
-----------------

#### 31.12.2023, jährlich

###### In der Bevölkerungsfortschreibung wird der Bevölkerungsbestand einer Region rechnerisch ermittelt.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ef7159ab8761ec15/134aa866d64c/SB_A01-03-00_2023j01_BEa.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/5819c0096285c59a/ad4103b9a6c9/SB_A01-03-00_2023j01_BEa.pdf)

**Berlins Bevölkerung wächst weiter**

Am 31.12.2023 lebten 3.662.381 Menschen in Berlin. Davon waren 49,1 % männlichen und 50,9 % weiblichen Geschlechts.

Berlin erzielte gegenüber dem Vorjahr einen Bevölkerungsgewinn von 29.528 Personen bzw. 0,8 %.   
Während die Anzahl der Deutschen auf   
2.861.882 (–20.119) Menschen sank, stieg die Zahl der Ausländer auf 800.499 (+49.647) Personen. Der Anteil der deutschen Bevölkerung an der gesamten Berliner Bevölkerung sank damit auf 78,1 % und die der ausländischen Bevölkerung stieg auf 21,9 %.

Die 30‑ bis unter 40‑Jährigen bilden die zahlenmäßig stärkste Altersgruppe.

### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Brandenburger Bevölkerung leicht gewachsen**

Brandenburg wies zum 31.12.2023 einen Bevölkerungsbestand von 2.554.464 Personen aus. Davon lebten 40,6 % der Bevölkerung im Berliner Umland und 59,4 % im Weiteren Metropolenraum.

Gegenüber dem Vorjahr erreichte das Land einen Bevölkerungsgewinn von 9.305 Personen (+0,4 %).   
Die Zahl der Deutschen sank auf 2.379.022 (–5.660), die der Ausländer stieg auf 175.442 (+14.965) Personen.   
Damit sank der Anteil der deutschen Bevölkerung an der Gesamtbevölkerung des Landes auf 93,1 %, der Anteil der ausländischen Bevölkerung stieg auf 6,9 %.

Die 55‑ bis unter 65‑Jährigen bilden bei beiden Geschlechtern die zahlenmäßig stärkste Altersgruppe.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/bfea976310e12088/a695e133ba2f/SB_A01-03-00_2023j01_BBa.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/e53fd6c7eb33ac23/9ab740238989/SB_A01-03-00_2023j01_BBa.pdf)
### Kontakt

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

#### Dr. Jochen Corthier

Bevölkerungsstatistiken

* [0331 8173-3353](tel:0331 8173-3353)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Der Bevölkerungsstand wird monatlich ermittelt und ist eine Berechnungsgröße.

Die Ergebnisse der jeweils letzten Volkszählung (Zensus 2022) werden mit den Ergebnissen der Statistiken der Bevölkerungsbewegungen (Wanderungen, Geburten, Sterbefälle, Eheschließungen) sowie mit Angaben zu Staatsangehörigkeitswechseln und Lösungen von Ehen und Lebenspartnerschaften fortgeschrieben.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

[Download PDF](https://download.statistik-berlin-brandenburg.de/d4ae0126b46dca2c/5cae390fc556/MD_12411_2024.pdf)[Archiv](/search-results?q=MD_12411&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-i-3-j)
