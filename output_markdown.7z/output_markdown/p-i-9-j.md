

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Konsumausgaben des Staates in Berlin und Brandenburg](/p-i-9-j)

Konsumausgaben des Staates
--------------------------

#### 1991 bis 2021, jährlich

###### Hier finden Sie Informationen zum Wert der Güter, die vom Staat selbst produziert werden (ohne selbsterstellte Anlagen und Verkäufe) und den sozialen Sachleistungen für die privaten Haushalte.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/90f2acdb8bf267bf/83d5169c62df/SB_P01-09-00_2021j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/39908493c4f196c0/26281e31b796/SB_P01-09-00_2021j01_BE.pdf)

**Höchster Anstieg aller Bundesländer**

Mit einer preisbereinigten Steigerung der Konsumausgaben des Staates von 3,9 % lag Berlin 2021 an der Spitze aller Bundesländer. Die Ausgaben betrugen insgesamt 40 876 Mill. Euro, was einem Anteil an den bundesweiten Ausgaben von 5,1 % entsprach.

Berlins Staatskonsum betrug 11 135 Euro pro Einwohnerin/Einwohner und war damit so hoch wie in keinem anderen Bundesland. Seit 1992 ist Berlin das Bundesland mit den jeweils höchsten Staatskonsumausgaben pro Kopf.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Staatskonsum wächst überdurchschnittlich**

Brandenburg wuchs 2021 mit einem preisbereinigten Anstieg von 3,5 % stärker als der Länderdurchschnitt (+3,1 %). Der Anteil an den bundesweiten Konsumausgaben des Staates betrug mit insgesamt 24 637 Mill. Euro 3,1 %.

Der Staatskonsum lag mit 9 721 Euro pro Einwohnerin/Einwohner in Brandenburg über dem bundesweiten Durchschnitt von 9 578 Euro.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ed6ffaea9d0f2d92/a2e1e86b476c/SB_P01-09-00_2021j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/2131de34b963fbb4/45de2e81104f/SB_P01-09-00_2021j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Konsumausgaben des Staates sind die Ausgaben der staatlichen Nichtmarktproduzenten. Sie enthalten die vom Staat selbst produzierten Güter und Dienstleistungen (ohne selbst erstellte Anlagen und Verkäufe) sowie Ausgaben für Güter, die als soziale Sachtransfers den privaten Haushalten für ihren Konsum zur Verfügung gestellt werden.

Ergebnisse für alle Bundesländer und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)
