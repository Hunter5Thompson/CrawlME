

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Außenhandel](/aussenhandel)

Außenhandel
===========

In einer globalisierten Wirtschaft liefert die monatliche Außenhandelsstatistik Daten über den grenzüberschreitenden Warenverkehr (Ein- und Ausfuhr) zwischen einem Bundesland und dem Ausland.

Für das jeweils laufende Jahr sind die Ergebnisse zunächst vorläufig und werden bis zu einem Jahr aktualisiert (endgültiges Ergebnis). Die Außenhandelsstatistik wird zentral im Statistischen Bundesamt durchgeführt. Die Einfuhren und Ausfuhren können nach Warengruppen und nach Handelspartnern aufgegliedert ausgewertet werden.

ZeitreihenBasisdatenWeitere Datenangebote

Zeitreihen
----------

Ausfuhr, EinfuhrAusfuhr nach ArtEinfuhr nach Art1 vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/2ce0da9c4a96f852/e7f2b789584f/aussenhandel-zeitreihe-2023.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/d2d1d00a594160d7/c487488f3861/aussenhandel-lange-reihen-2023.xlsx)

Basisdaten
----------

AusfuhrEinfuhr

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=statistic&levelindex=0&levelid=1713857386630&code=51000#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Stefanie Chlebusch

Außenhandel

#### Stefanie Chlebusch

Außenhandel

* [0331 8173-3586](tel:0331 8173-3586)
* [aussenhandel@statistik-bbb.de](mailto:aussenhandel@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock478081141.jpg](https://download.statistik-berlin-brandenburg.de/a941f7bf0a2c6a6b/a7e40f5c0908/v/cdb0509c65dc/wirtschaft-volkswirtschaft-container.jpg "iStock478081141.jpg")](/138-2024)**Außenhandel in Brandenburg im 1. Halbjahr 2024**[#### Export und Import gesunken](/138-2024)

Pressemitteilung Nr. 138 Die Brandenburger Ausfuhren sanken im 1. Halbjahr 2024 um 0,9 % auf 11,7 Milliarden EUR. Die Importe waren mit 12,7 Milliarden EUR höher als die Exporte, sanken aber im zur...

[![Außenhandel](https://download.statistik-berlin-brandenburg.de/2e2ac87567d4e852/dee62de72aa0/v/67ac00443443/aussenhandel-iStock-1257144699.jpg "Außenhandel")](/137-2024)**Außenhandel Berlins im 1. Halbjahr 2024**[#### Ausfuhren um 8,4 % gestiegen](/137-2024)

Pressemitteilung Nr. 137 Das Berliner Exportvolumen ist im 1. Halbjahr 2024 um 8,4 % auf rund 9 Milliarden EUR gestiegen. Die Importe fielen mit 10,2 Milliarden EUR insgesamt höher aus als die lagen...

[![iStock.com / sculpies](https://download.statistik-berlin-brandenburg.de/681e4f912bfbb7c9/1eb7bce479d1/v/cfa9bdf13995/wirtschaft-volkswirtschaft-container-terminal-with-trucks-with-freight-forwarding-managerworker-picture-id1124695331.jpg "iStock.com / sculpies")](/158-2023)**Außenhandel Brandenburgs im 1. Halbjahr 2023**[#### Ausfuhren steigen, Einfuhren sinken](/158-2023)

Pressemitteilung Nr. 158 Die Brandenburger Ausfuhren stiegen im 1. Halbjahr 2023 im Vergleich zum Vorjahreszeitraum um 2,6 Prozent auf 8,8 Mrd. EUR, während die Einfuhren um 2,9 Prozent auf 12,2 EUR...

[Zu unseren News](/news)

[* Import](/search-results?q=tag%3AImport)[* Export](/search-results?q=tag%3AExport)[* EGW](/search-results?q=tag%3AEGW)[* Warenaustausch](/search-results?q=tag%3AWarenaustausch)[* Handelspartner](/search-results?q=tag%3AHandelspartner)[* Warengruppe](/search-results?q=tag%3AWarengruppe)[* Warenverzeichnis](/search-results?q=tag%3AWarenverzeichnis)[* Güterverzeichnis](/search-results?q=tag%3AGüterverzeichnis)
