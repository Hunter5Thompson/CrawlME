

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Wahlen in Berlin](/wahlen-berlin)
* [Berliner Wahlen](/abgeordnetenhauswahlen-bvv-berlin)

Berliner Wahlen
===============

### Abgeordnetenhaus und Bezirksverordnetenversammlungen

Die Wahlen in Berlin finden alle fünf Jahre statt. Das **Abgeordnetenhaus** besteht aus mindestens 130 Abgeordneten, von denen 78 in den Wahlkreisen nach den Grundsätzen der relativen Mehrheitswahl (Erststimme) und die übrigen aus Listen gewählt werden (Zweitstimme). Es werden nur Wahlvorschläge berücksichtigt, die mindestens 5 % der Zweitstimmen oder ein Direktmandat erhalten.

Die**Bezirksverordnetenversammlungen (BVV)** in den 12 Berliner Bezirken bestehen aus jeweils 55 Mitgliedern. Neben Parteien können auch Wählergemeinschaften Listen mit Wahlvorschlägen einreichen. Jene, die weniger als 3 % der abgegebenen Stimmen erhalten haben, werden bei der Berechnung und Zuteilung der Sitze nicht berücksichtigt. Wählende der BVV haben eine Stimme.

Berliner Wahlen 2023Berliner Wahlen 2016Endgültige ErgebnisseWahlgebieteWahlstrukturdatenRepräsentative Wahlstatistik
### Wiederholungswahl am 12. Februar 2023

### (Hauptwahl vom 26. September 2021)

#### Endgültige Ergebnisse für Berlin

#### Die endgültigen Ergebnisse

**Alle Daten zur Abgeordnetenhauswahl und****BVV-Wahl 2023 in interaktiver Form**

[Zu den Ergebnissen](https://wahlen-berlin.de/wahlen/Be2023/AFSPRAES/agh/index.html)
#### Interaktiver Wahlatlas

**Kartenansichten mit den endgültigen Ergebnissen der Wahlen**

[Zur Karte](https://www.wahlen-berlin.de/wahlen/Be2023/AFSPRAES/agh/wahlatlas.html)
#### **Alle Ergebnisse als Download**

[Wahlbezirksergebnisse (XLSX)](https://download.statistik-berlin-brandenburg.de/c6fffa8361dd1404/a8cc1bc593d9/DL_BE_AGHBVV2023.xlsx)[Ergebnisbericht (XLSX)](https://download.statistik-berlin-brandenburg.de/8350493567505a9d/e69917ec7c49/SB_B07-02-03_2023j05_BE.xlsx)[Ergebnisbericht (PDF)](https://download.statistik-berlin-brandenburg.de/538210b8454f4642/99e340a74910/SB_B07-02-03_2023j05_BE.pdf)

Wahlgebietseinteilung
---------------------

![Wahlkreisgebietseinteilung Abgeordnetenhauswahl Berlin 2023](https://download.statistik-berlin-brandenburg.de/9e4d0d5e63c32da3/6869723f4339/v/03b85b849281/Abgeordnetenhauswahlkreise.PNG "Wahlkreise Abgeordnetenhauswahl Berlin 2023")[#### Alle Karten der 12 Wahlkreise sowie Adressen je Wahlbezirk im PDF-Format.

**Zur Auswahl**](/wahlkreiskarten-2023)

Wahlstrukturdaten
-----------------

#### Demografische und politische Strukturen von Berlin

### Downloads

| **Interaktiver Wahlatlas** | **Vorwahldaten, Strukturdaten** | **Umgerechnete Ergebnisse der Wahl zum Deutschen Bundestag 2017 (Zweitstimmen)** | **Umgerechnete Ergebnisse der Wahl zum Abgeordnetenhaus 2016 (Zweitstimmen)** | **Strukturdaten auf Wahlbezirksebene** |  |
| --- | --- | --- | --- | --- | --- |
| [Zur Karte](https://www.wahlen-berlin.de/wahlen/BE2023/Strukturdaten/Bericht_AH23_Wiederholungswahl_AH21/atlas.html) | [XLSX](https://download.statistik-berlin-brandenburg.de/500782cec2cb7f06/690b9d587d43/SB_B07-02-01_2023j05_BE.xlsx) [PDF](https://download.statistik-berlin-brandenburg.de/b92c90f8fa8b534e/45210729b5a5/SB_B07-02-01_2023j05_BE.pdf) | [XLSX](https://download.statistik-berlin-brandenburg.de/d030080db77ad21c/072b8c5eb8fc/DL_BE_AGH2023_BT2017.xlsx) | [XLSX](https://download.statistik-berlin-brandenburg.de/ef1e6910e83b0d60/00603a1223c4/DL_BE_AGH2023_AH2016.xlsx) | [XLSX](https://download.statistik-berlin-brandenburg.de/5e482ab26dfd51b7/00f86bb5f3c4/DL_BE_AGH2023_Strukturdaten.xlsx) |  |
|  |  |

Repräsentative Wahlstatistik
----------------------------

#### Wer hat wie gewählt?

##### Wiederholungswahl zum Abgeordnetenhaus von Berlin am 12. Februar 2023**Wahlberechtige nach Alter**

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Repräsentative Wahlstatistik als Download**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/14c528d75c186c7f/c57834e9eb16/SB_B07-02-05_2023j05_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/083bb1ae7700a00f/ea10abc673b3/SB_B07-02-05_2023j05_BE.pdf)

Mit der repräsentativen Wahlstatistik werden die **Wahlbeteiligung** und die **Stimmabgabe** der Wahlberechtigten nach Geschlecht und Altersgruppen im Wege der Stichprobe untersucht.

Rechtsgrundlage für die Durchführung ist das Gesetz über die allgemeine und die repräsentative Wahlstatistik (Wahlstatistikgesetz - WStatG). Für die Wahrung des Wahlgeheimnisses sind unter anderem folgende Maßnahmen angeordnet:

* Die Festlegung einer Mindestzahl von 400 Wahlberechtigten je Stichprobenwahlbezirk und von 400 Wählern je Stichprobenbriefwahlbezirk.
* Zusammenfassung der Geburtsjahrgänge zu Gruppen, sodass keine Rückschlüsse auf das Wahlverhalten einzelner Wähler möglich sind.
* Trennung der für die Stimmenauszählung und für die statistische Auswertung zuständigen Stellen sowie strenge Zweckbindung für die Statistikstellen hinsichtlich der ihnen zur Auswertung überlassenen Wahlunterlagen.

Die Wahlberechtigten der repräsentativen Wahlbezirke werden durch ein Plakat und die Auslage eines [Faltblatts](https://download.statistik-berlin-brandenburg.de/1268290cccb969a3/96f644794a43/BE_RWS_flyer_AGH_web.pdf) im Wahllokal, die Zusendung eines Merkblatts mit den Briefwahlunterlagen und persönliche Beantwortung von Fragen im Wahllokal informiert. Die Stimmzettel sind mit einem Unterscheidungsaufdruck [(siehe Muster)](https://download.statistik-berlin-brandenburg.de/9b4c6bb80f007fd7/d0b22bdde293/MD_14321_2021_C.pdf) versehen.

Historische Daten
-----------------

[**Endgültige Ergebnisse zu Abgeordnetenhauswahlen und  
BVV-Wahlen in Berlin**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00001102)[**Repräsentative Wahlstatistiken zu Abgeordnetenhauswahlen und  
BVV-Wahlen in Berlin**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00001142)

**Wahlbezirksergebnisse zu Abgeordnetenhauswahlen und  
BVV-Wahlen in Berlin**

[**Strukturdaten, Vorwahldaten zu Abgeordnetenhauswahlen und  
BVV-Wahlen in Berlin**](https://www.statistischebibliothek.de/mir/receive/BBSerie_mods_00001001)
##### Abgeordnetenhauswahlen in Berlin**Gültige Zweitstimmen 1990 bis 2023**

1 1990: GRÜNE/AL und B90/GR2 1990-2001: PDS; 2006: Die Linke.3 Die Wahl vom 26. September 2021 wurde durch Urteil des Landesverfassungsgerichtshofs Berlin vom 16. November 2022 für ungültig erklärt.**Quelle:** Amt für Statistik Berlin-Brandenburg

1 – 1990: GRÜNE/AL und B90/GR  
2 – 1990-2001: PDS; 2006: Die Linke  
3 – Durch Urteil des Landesverfassungsgerichtshofs Berlin vom 16. November 2022 für ungültig erklärt.

##### **Entwicklung der Wahlergebnisse im Zeitverlauf:**

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/c427aa9c4178f92d/8466ce447431/abgeordnetenhauswahlen-lange-reihe-2023-berlin.xlsx)

Weiterführende Informationen
----------------------------

###### Metadaten

Unsere Metadaten liefern Informationen zu den erhobenen Daten und der angewendeten Methodik. Ergänzt werden diese durch Musterstimmzettel, Datensatzbeschreibungen und gegebenenfalls einen Qualitätsbericht.

**Wahlen zum Abgeordnetenhaus von Berlin und zu den Bezirksverordnetenversammlungen (2023) →**[Download PDF](https://download.statistik-berlin-brandenburg.de/26db9a2b11e95ace/d48523412967/MD_14311_2023.pdf)

**Wahlen zum Abgeordnetenhaus von Berlin und zu den Bezirksverordnetenversammlungen (2016) →**[Download PDF](https://download.statistik-berlin-brandenburg.de/b51fcf28c5d2c057/9aea38d76ad7/MD_14311_2016.pdf) 

**Repräsentative Abgeordnetenhauswahlstatistik (2021)** → [Download PDF](https://download.statistik-berlin-brandenburg.de/c10beb06b2dfbce2/74a0b3a7128b/MD_14321_2021.pdf) 

###### Link zum OpenData Portal Berlin

Geometrien, Wahllokale und weitere offene Datensätze →  [OpenData Portal Berlin](https://daten.berlin.de/datensaetze?groups=wahl&author_string=Amt+f%C3%BCr+Statistik+Berlin-Brandenburg&sort=score+desc%2C+metadata_modified+desc)

#### Der Landeswahlleiter für Berlin auf [www.berlin.de](https://www.berlin.de/wahlen/)


