

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Bauen und Wohnungen](/bauen-und-wohnungen)

Bauen und Wohnungen
===================

Die Baugewerbestatistiken spiegeln die konjunkturelle Lage und die strukturelle Entwicklung der Bauwirtschaft wider. Die Bautätigkeitsstatistiken verschaffen einen Überblick über das Geschehen im Hochbau, insbesondere im Wohnungsbau.

Monatlich bis jährlich werden die Betriebe und Unternehmen des Bauhaupt- und Ausbaugewerbes u. a. hinsichtlich ihres Umsatzes, Auftragseingangs und der tätigen Personen befragt. Anhand der Statistiken zu Baufertigstellungen und Bauabgängen wird der Wohnungsbestand jährlich fortgeschrieben.

[![iStock.com / hanohiki](https://download.statistik-berlin-brandenburg.de/b29702c3d0d2d6a7/661284573220/v/39622a003baa/gesellschaft-soziales-plattenbau-building-facade-picture-id645531666.jpg "iStock.com / hanohiki")](/news/2023/wohnungsbau-mauerfall)**Historisches**[#### Im Jahr des Mauerfalls rund 20.000 Wohnungen in Berlin gebaut](/news/2023/wohnungsbau-mauerfall)

Die meisten Berlinerinnen und Berliner lebten 1989 in Mietwohnungen im Geschosswohnungsbau mit durchschnittlich 2,5 Wohnräumen je Wohnung.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

### Baugewerbe

[Baugewerbe in Berlin und Brandenburg, monatlich (EII1-EIII1-m)](/e-ii-1-e-iii-1-m)[Baugewerbe in Berlin und Brandenburg – Ergänzungserhebung, jährlich (EII2-EIII2-j)](/e-ii-2-e-iii-2-j)
### Bautätigkeit

[Fortschreibung des Wohngebäude- und Wohnungsbestandes in Berlin und Brandenburg, jährlich (FI1-j)](/f-i-1-j)[Baugenehmigungen in Berlin und Brandenburg, monatlich (FII1-m)](/f-ii-1-m)[Baufertigstellungen, Bauüberhang und Bauabgang in Berlin und Brandenburg, monatlich (FII2-j)](/f-ii-2-j)

Zeitreihen
----------

WohnungsbauWohnungsbestandBaugewerbeTätige Personen**Quelle:** Amt für Statistik Berlin-Brandenburg

**„Zeitreihen“** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von zehn Jahren wieder. Die sogenannten **„Langen Reihen“** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Bautätigkeit

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/3c84aff61105411b/4a48ce2dcfb9/bauen-wohnen-zeitreihe-2023-wohnungsbau-bautaetigkeit.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/ca42c23c85b6aecc/c7e036831631/bauen-wohnen-lange-reihe.xlsx)
#### Baugewerbe

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/de28d8bcb41abe94/4a0e065ab7be/baugewerbe-zeitreihe.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/5e9487ed2d3ef62f/21e83be79eb4/baugewerbe-lange-reihe.xlsx)

Basisdaten
----------

BaugewerbeBautätigkeit

Regionaldaten
-------------

###### Berliner Bezirke 2023

#### Gebäude und Wohnungen in Berlin\*

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Landkreise und kreisfreie Städte 2023

#### Gebäude und Wohnungen in Brandenburg

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Neubauatlas

![](https://download.statistik-berlin-brandenburg.de/4ec055ffd478458b/d7bd488d71f6/v/9e04d9dfe70d/neubauatlas-klein.png)

Die Webanwendung zeigt regional tief gegliedert die Bautätigkeit in ganz Deutschland; mit besonderem Fokus auf Baufertigstellungen.

[Zum Neubauatlas](https://gis-hsl.hessen.de/portal/apps/webappviewer/index.html?id=cf7f6bef972a489588615cc28b731ce0)
#### Zusatzerhebung Wohnsituation

![](https://download.statistik-berlin-brandenburg.de/04b68bb17710f09c/260e126662c3/v/1218707e57f5/schmuckbild-datenbanken-mikrozensus-klein.jpg)

Die Zusatzerhebung zur Wohnsituation der Haushalte erfolgt vierjährlich ergänzend zum jährlichen Grundprogramm des Mikrozensus.

[Zum Statistischen Bericht](/f-i-2-4j)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1712219212139&code=31#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Diana Geipel

Baugewerbe

#### Diana Geipel

Baugewerbe

* [0331 8173-3745](tel:0331 8173-3745)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Kerstin Wollenhaupt

Bautätigkeit

#### Kerstin Wollenhaupt

Bautätigkeit

* [0331 8173-3355](tel:0331 8173-3355)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Marlies Quägwer

Baugewerbe

#### Marlies Quägwer

Baugewerbe

* [0331 8173-3831](tel:0331 8173-3831)
* [bau@statistik-bbb.de](mailto:bau@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / WUT789](https://download.statistik-berlin-brandenburg.de/2bf91ef8d7e87e41/d8915d0aa8d2/v/2c6debffcff1/wirtschaft-preise-surveying-engineers-are-working-together-using-theodolite-on-the-picture-id1257559262.jpg "iStock.com / WUT789")](/125-2024)**Brandenburger Bauhauptgewerbe im 1. Halbjahr 2024**[#### Umsatzrückgang, aber leichte Steigerung beim Auftragseingang](/125-2024)

Pressemitteilung Nr. 125 In den Betrieben des Brandenburger Bauhauptgewerbes sanken im 1. Halbjahr 2024 die Umsätze, die Auftragseingänge stiegen hingegen leicht an. Die Zahl der tätigen Personen...

[![iStock.com / schwartstock](https://download.statistik-berlin-brandenburg.de/7d4ab4407ce3fd0b/e7dff9d39491/v/3c3ae65fca33/gesellschaft-arbeit-high-angle-view-of-workers-in-construction-site-picture-id1189235635.jpg "iStock.com / schwartstock")](/124-2024)**Berliner Bauhauptgewerbe im 1. Halbjahr 2024**[#### Weniger Umsatz und Auftragseingänge](/124-2024)

Pressemitteilung Nr. 124 Die Betriebe des Berliner Bauhauptgewerbes meldeten im 1. Halbjahr 2024 weniger Umsatz und Auftragseingänge als im 1. Halbjahr 2023, teilt das Amt für Statistik mit. Die...

[![iStock.com / Poetra Dimatra](https://download.statistik-berlin-brandenburg.de/7d92f1c2852c83fb/2de6ce0c08d3/v/ef0b253d49e8/wirtschaft-wirtschaftsbvereiche-high-rise-building-construction-picture-id1194255489.jpg "iStock.com / Poetra Dimatra")](/072-2024)**Berliner Bauhauptgewerbe im 1. Quartal 2024**[#### Weniger Umsatz und Auftragseingänge](/072-2024)

Pressemitteilung Nr. 72 Die Betriebe des Berliner Bauhauptgewerbes meldeten im 1. Quartal 2024 weniger Umsatz und Auftragseingänge als im 1. Quartal 2023, teilt das Amt für Statistik mit. Die...

[Zu unseren News](/news)

[* Investition](/search-results?q=tag%3AInvestition)[* Baugenehmigung](/search-results?q=tag%3ABaugenehmigung)[* Baufertigstellung](/search-results?q=tag%3ABaufertigstellung)[* Wohnung](/search-results?q=tag%3AWohnung)[* Neubaukosten](/search-results?q=tag%3ANeubaukosten)[* Hochbau](/search-results?q=tag%3AHochbau)[* Tiefbau](/search-results?q=tag%3ATiefbau)[* Wohnungsbau](/search-results?q=tag%3AWohnungsbau)
