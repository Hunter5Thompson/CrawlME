

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Schulen](/gesellschaft/bildung/schulen)

Schulen
=======

Im Bereich des Schulwesens verfügen die Bundesländer über die Gesetzgebungskompetenz. Grund hierfür ist das föderale System in Deutschland. Aufgabe der Schulstatistik ist es, aussagefähige Daten zur Situation und Entwicklung im Bereich der allgemeinbildenden und beruflichen Schulen bereitzustellen.

Zum Erhebungsprogramm der Schulstatistik gehören Angaben über Schulen, Klassen, Schülerinnen und Schüler, Lehrkräfte und Unterricht auf der Grundlage von Verwaltungsdaten. In der bundesweit einheitlich durchgeführten Berufsbildungsstatistik werden Merkmale zu Auszubildenden sowie Ausbildenden, Prüfungsteilnehmenden sowie zu den im Ausland erworbenen beruflichen Abschlüssen erhoben.

  


Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Allgemeinbildende Schulen in Brandenburg, jährlich (BI1-j)](/b-i-1-j)[Allgemeinbildende Schulen in Brandenburg – Ergebnisse nach Verwaltungsbezirken und staatlichen Schulämtern, jährlich (BI9-j)](/b-i-9-j)[Absolventinnen und Absolventen/Abgängerinnen und Abgänger der allgemeinbildenden Schulen in Brandenburg, jährlich (BI5-j)](/b-i-5-j)[Berufliche Schulen in Brandenburg einschließlich Ergebnisse nach Verwaltungsbezirken, jährlich (BII1-j)](/b-ii-1-j)[Auszubildende und Prüfungen in Berlin und Brandenburg, jährlich (BII5-j)](/b-ii-5-j)[Ausbildungsstätten für Fachberufe des Gesundheitswesens in Berlin und Brandenburg, jährlich (BII6-j)](/b-ii-6-j)

Zeitreihen
----------

Allgemeinbildende SchulenBerufliche SchulenAuszubildendeAusbildungsverträge1 einschließlich Zweiter Bildungsweg**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Schulbildung

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/0a0ae3e0fd2ae5d7/dee5e17e1270/Bildung_Schulen_Zeitreihe_2022_Berlin_Brandenburg.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/a5dbef83569580a7/14c83e61db02/schulen-lange-reihen-2023-bildung.xlsx)
#### Berufsbildung

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/3158cc766083772a/b15ce4990a4d/Bildung-Berufsbildung-Zeitreihe-2023.xlsx)

Basisdaten
----------

SchulenSchüler/-innen und LehrkräfteSchulabschlüsseAuszubildendeAusbildungsverträgeAbschlussprüfungen

Regionaldaten
-------------

###### Berliner³ Bezirke

#### Allgemeinbildende Schulen 2023/2024

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger³ Landkreise und kreisfreie Städte

#### Allgemeinbildende Schulen 2023/2024

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Verzeichnisse

**Verzeichnis der****allgemeinbildenden Schulen****Brandenburg**

(XLSX | 20,00 EUR)  
Adressstand: 02.07.2024, Schülerzahlen: 25.09.2023 (Schuljahr 2023/2024)

**Verzeichnis der****b****eruflichen Schulen** **Brandenburg**

(XLSX | 20,00 EUR)  
Adressstand: 02.07.2024, Schülerzahlen: 06.11.2023 (Schuljahr 2023/24), Berufe: 06.11.2023 (Schuljahr 2023/24)

[kostenpflichtig bestellen](mailto:vertrieb@statistik-bbb.de)
#### EDUGIS – Geoportal

![EDUDIS-Datenbank Desktopansicht](https://download.statistik-berlin-brandenburg.de/c0c9f02a5839dfb5/11d5c877cdfe/v/c7f831c1e86a/schmuckbild-edugis.png)

Das interaktive Kartenangebot des Ministerium für Bildung, Jugend und Sport bildet die Schullandschaft Brandenburgs ab.

[Zum Geoportal](https://schullandschaft.brandenburg.de)
#### Regionaldatenbank

![Bildschirmansicht Regionaldatenbank](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=themes&levelindex=0&levelid=1712146085311&code=21#abreadcrumb)
#### Bildungsdatenbank

![](https://download.statistik-berlin-brandenburg.de/3ff67ef262f0bb5a/0780120d8dcb/v/01f81be46925/kommunale-bildungsdatenbank-schmuckbild.png)

Umfassendes Datenangebot für Landkreise und kreisfreie Städte. Die Ergebnisse werden in Form von Indikatoren präsentiert.

[Zur Bildungsdatenbank](https://www.bildungsmonitoring.de/bildung/online?operation=previous&levelindex=0&step=0&titel=&levelid=1613122405789&acceptscookies=false)

Haben Sie Fragen?
-----------------

#### Silke Tasler

Berufsbildung

#### Silke Tasler

Berufsbildung

* [0331 8173-1175](tel:0331 8173-1175)
* [berufsbildung@statistik-bbb.de](mailto:berufsbildung@statistik-bbb.de)
#### Matthias Gebhard

Schulen

#### Matthias Gebhard

Schulen

* [0331 8173-1103](tel:0331 8173-1103)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Ramona Klasen

Schulen

#### Ramona Klasen

Schulen

* [0331 8173-1146](tel:0331 8173-1146)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / monkeybusinessimages](https://download.statistik-berlin-brandenburg.de/30d7ef9d2ed47479/59b43a3c6bff/v/d40a1fbff86d/gesellschaft-bildung-male-and-female-students-looking-at-car-engine-on-auto-mechanic-at-picture-id1218970736.jpg "iStock.com / monkeybusinessimages")](/129-2024)**Berufsbildungsstatistik 2023 Berlin und Brandenburg**[#### In Berlin weniger, in Brandenburg mehr neue Ausbildungsverträge](/129-2024)

Pressemitteilung Nr. 129 2023 gab es in Berlin einen leichten Rückgang und in Brandenburg einen Anstieg neuer Ausbildungsverträge zu verzeichnen. Insgesamt wurden in der Hauptstadtregion 1,3 % mehr...

[![Kinder sitzen mit gepackten Koffern im offenen Kofferraum eines Autos](https://download.statistik-berlin-brandenburg.de/3cec476a062d4957/08883a8fbf00/v/61dd71e35cc6/istockphoto-1150580548-1024x1024.jpg "Kinder sitzen mit gepackten Koffern im offenen Kofferraum eines Autos")](/news/2024/schulen-ferienstart)**Sommerzeit ist Ferienzeit**[#### Fast 676.000 Schulkinder in der Hauptstadtregion machen Ferien](/news/2024/schulen-ferienstart)

In Brandenburg bekommen 278.103 Schülerinnen und Schüler an allgemeinbildenden Schulen heute ihre Zeugnisse und Beurteilungen, in Berlin sind es 397.307.

[![iStock.com / shironosov](https://download.statistik-berlin-brandenburg.de/647f45d19854bdb2/227c037ed261/v/bb26ee51b785/gesellschaft-gesundheit-young-supportive-female-caregiver-sitting-by-senior-man-in-wheelchair-picture-id1203365703.jpg "iStock.com / shironosov")](/082-2024)**Ausbildungsstätten des Gesundheitswesens 2023/24 in Berlin und Brandenburg**[#### Erster Absolventenjahrgang der generalistischen Pflegeausbildung verabschiedet (Korrektur)](/082-2024)

Pressemitteilung Nr. 82 Korrekturhinweis vom 11.07.2024: In der ersten Fassung dieser Pressemitteilung waren in der Abbildung die Werte für Abgängerinnen und Abgänger sowie Abbrecherinnen und bei...

[Zu unseren News](/news)

[* Schulen](/search-results?q=tag%3ASchulen)[* Einschulungen](/search-results?q=tag%3AEinschulungen)[* Klassen](/search-results?q=tag%3AKlassen)[* Ausbildung](/search-results?q=tag%3AAusbildung)[* Abschluss](/search-results?q=tag%3AAbschluss)[* Auszubildende](/search-results?q=tag%3AAuszubildende)[* Verzeichnis](/search-results?q=tag%3AVerzeichnis)
