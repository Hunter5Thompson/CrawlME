

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Viehbestände in Brandenburg am 3. Mai 2023 – Schweine](/c-iii-2-j)

Schweine in Brandenburg– Repräsentative Erhebung
------------------------------------------------

#### 3. Mai 2024, jährlich

###### Die Erhebung informiert über die  Anzahl der Schweine gegliedert nach Alter, Geschlecht, Nutzungszweck, Lebendgewicht und Trächtigkeit (Zuchtsauen).

BrandenburgMethodik
### Brandenburg

**Schweinebestand auf historischem Tiefststand**

Zum 3. Mai 2024 wurden in Brandenburg 517.200 Schweine gehalten. Das waren 20.600 Tiere bzw. 3,8 % weniger als im November 2023. Gleichzeitig stellt dies den geringsten Bestand an Schweinen in Brandenburg seit Neugründung des Landes 1990 dar.

Den erneuten Bestandsrückgang bewirkte hauptsächlich die Entwicklung bei den Mastschweinen. Deren Zahl verringerte sich um knapp 26.000 Tiere bzw. 18,3 % auf 115.800 Tiere. Auch dies stellt einen Tiefststand in Brandenburg seit 1990 dar.

Der Bestand an Zuchtsauen ist mit 56.900 Tieren im Vergleich zum November 2023 nahezu unverändert (+0,6 %) geblieben.

Die Zahl der Ferkel nahm im genannten Zeitraum um 10.900 Tiere bzw. 4,2 % auf 268.100 Tiere zu, während sich der Bestand an Jungschweinen um 5.800 Tiere bzw. 7,2 % auf 75.200 Tiere verringerte.

**Quelle:** Amt für Statitistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 3. Mai 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/15f94f7e4057e138/3fba946f7e7d/SB_C03-02-00_2024j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/deb24f166fd1d3e2/71bbc1f76a4c/SB_C03-02-00_2024j01_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Olaf Müller

Tierische Produktion

#### Olaf Müller

Tierische Produktion

* [0331 8173-3051](tel:0331 8173-3051)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung über die Schweinebestände ist eine dezentrale, repräsentative Bundesstatistik, wobei die Stadtstaaten ausgenommen sind. Erhebungsstichtage ist der 3. Mai eines jeden Jahres.

Zur Grundgesamtheit zählen alle landwirtschaftlichen Betriebe mit mindestens 50 Schweinen oder 10 Zuchtsauen. Für die Zufallsauswahl der Stichprobenbetriebe wird das Verfahren der „Kontrollierten Auswahl“ angewendet. Die Betriebe melden ihre Daten online bzw. per Erhebungsbogen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Viehbestandserhebung Schweine**Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/a6f67a4c2c975c5e/355770008fba/MD_41313_2020.pdf)[Archiv](/search-results?q=MD_41313&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-2-j)
