

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Abfall, Luftbelastungspotenzial](/luftverunreinigungen)
* [Abfallentsorgung in Berlin und Brandenburg](/q-ii-1-2j)

Abfallentsorgung
----------------

#### 2020, zweijährlich

###### Die Erhebung umfasst Daten von Betreibern zulassungsbedürftiger Anlagen, in denen Abfälle entsorgt werden. Jährlich werden Art, Menge, Herkunft und Verbleib der behandelten, abgelagerten und abgegebenen Abfälle erfragt.

BerlinBrandenburgMethodikArchiv
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a52a95484169d9e8/9483915994f8/SB_Q02-01-00_2020j02_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/8ef3bf2085b3ba9d/8d1103fc6e8a/SB_Q02-01-00_2020j02_BE.pdf)

**Mehr Haushaltsabfälle im Vergleich zum Vorjahr**

3.246.095 Tonnen (t) Abfall wurden 2020 in Berlin beseitigt bzw. behandelt, davon stammen 2.674.183 t aus dem eigenen Bundesland. Im Vergleich zum Vorjahr ging die Gesamtmenge der behandelten Abfälle um 94.573 t zurück. Der Großteil des Abfalls wurde in Sortierungsanlagen (855.703 t) behandelt, gefolgt von Abfallverbrennungsanlagen (773.135 t). Bei der Behandlung in Abfallentsorgungsanlagen konnten 376.214 t an Sekundärrohstoffen und Produkten gewonnen werden.

Von 1.408.279 t der im Rahmen der öffentlich-rechtlichen Entsorgung aufgekommenen Haushaltsabfälle entfielen 62,9 % auf Sperrmüll. Im Vergleich zum Vorjahr stieg die Gesamtmenge der angefallen Haushaltsabfälle um 28.130 t an.

Insgesamt sammelten 26 Unternehmen bzw. Betriebe 131.660 t Transport- und Umverpackungen sowie Verkaufsverpackungen bei gewerblichen und industriellen Endverbrauchern ein. Der Großteil entfiel auf Papier, Pappe und Karton (108.835 t).

### Kontakt

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Haushaltsabfälle im Vergleich zum Vorjahr gestiegen**

10.909.124 Tonnen (t) Abfall wurden 2020 in Brandenburg beseitigt bzw. behandelt, davon stammen 7.182.913 t aus dem eigenen Bundesland. Im Vergleich zum Vorjahr stieg die Gesamtmenge der behandelten Abfälle um 163.689 t an. Der Großteil des Abfalls wurde in Feuerungsanlagen (3.971.141 t) und Deponien (3.274.269 t) beseitigt. Aus 1.466.411 t Abfall entstanden im Jahr 2020 Sekundärrohstoffe bzw. Produkte.

Von 1.152.819 t der im Rahmen der öffentlich-rechtlichen Entsorgung aufgekommenen Haushaltsabfälle entfielen 48,4 % auf Sperrmüll. Im Vergleich zum Vorjahr stieg die Gesamtmenge der angefallen  Haushaltsabfälle um 58.095 t an.

Insgesamt sammelten 52 Unternehmen bzw. Betriebe (zwei weniger als im Vorjahr) 118.514 t Transport- und Umverpackungen sowie Verkaufsverpackungen bei gewerblichen und industriellen Endverbrauchern ein. Der Großteil davon bestand aus Papier, Pappe und Karton (73.124 t).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2020**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/d284fd8d2490c985/61b9b02bd9ff/SB_Q02-01-00_2020j02_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/5b53f7bc45f17931/d3b9df646e66/SB_Q02-01-00_2020j02_BB.pdf)
### Kontakt

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

#### Dr. Sebastian Hänke

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1285](tel:0331 8173-1285)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Ziel der Erhebungen ist es, das Aufkommen, die Verwertung und die Beseitigung von Abfällen zu dokumentieren, um Aufschlüsse über Art, Menge, Herkunft und Verbleib der entsorgten Abfälle sowie über die Art und Ausstattung der benutzten Anlagen zu erhalten.

Der In- und Output der Anlagen wird dabei nach Abfallarten entsprechend dem Abfallkatalog auf Basis des Europäischen Abfallverzeichnisses (EAV) differenziert nachgewiesen.

Die Ergebnisse fließen in die jährliche Berechnung des gesamten Abfallaufkommens Deutschlands ein und bilden eine Grundlage für umweltrelevante Analysen im Rahmen der Nachhaltigkeitsstrategien des Bund und der Länder.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erhebung der Abfallentsorgung**  
Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/117c232d103ec31f/9578f93bb0d9/MD_32111_2020.pdf)[Archiv](/search-results?q=MD_32111&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/q-ii-1-2j)
