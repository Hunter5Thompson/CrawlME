

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Menschen mit Behinderung/Eingliederungshilfe](/menschen-mit-behinderung-eingliederungshilfe)
* [Empfänger von Eingliederungshilfe sowie Ausgaben und Einnahmen nach dem SGB IX in Berlin und Brandenburg](/k-iii-2-j)

Empfänger von Eingliederungshilfe sowie Ausgaben und Einnahmen nach dem SGB IX
------------------------------------------------------------------------------

#### 2023, jährlich

###### Die Erhebung informiert über die sozialen und finanziellen Auswirkungen des Bundesteilhabegesetzes und des SGB IX sowie über den Personenkreis der Leistungsberechtigten.

BerlinBrandenburgMethodik
### Berlin

2 Personen mit den Geschlechtsangaben "divers" und "ohne Angabe" (nach § 22 Absatz 3 PStG) werden aus Gründen der statistischen Geheimhaltung per Zufallsprinzip dem männlichen oder weiblichen Geschlecht zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/a594a43bfee025c4/ba89601755e6/SB_K03-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/31d7e2d5e360fc58/0b9335fcb5ba/SB_K03-02-00_2023j01_BE.pdf)

**Zahl der Hilfebeziehenden leicht gestiegen**

Am Jahresende 2023 erhielten in Berlin 31.130 Personen Eingliederungshilfe nach dem Neunten Buch Sozialgesetzbuch (SGB IX).

Unter den Hilfebeziehenden bildeten die 40- bis unter 65-Jährigen mit 49 % die größte Gruppe, gefolgt von den 18- bis unter 40-Jährigen mit rund einem Drittel. Der Anteil der Kinder und Jugendlichen betrug 7 % und 8 % entfielen auf die Gruppe der über 65-Jährigen.

Das Durchschnittsalter aller Hilfebeziehenden betrug 43 Jahre.

### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Durchschnittsalter aller Hilfebeziehenden leicht gesunken**

Eingliederungshilfe nach dem Neunten Buch Sozialgesetzbuch (SGB IX) erhielten am Jahresende 2023 in Brandenburg 27.660 Personen.

Die 40- bis unter 65-Jährigen bildeten mit 40 % die größte Gruppe unter den Hilfebeziehenden, gefolgt von den 18- bis unter 40-Jährigen mit rund einem Drittel. 22 % der Hilfebeziehenden waren Kinder und Jugendliche, 7 % waren 65 Jahre und älter.

Das Durchschnittsalter betrug 37 Jahre.

1 Untererfassung im Landkreis Oberspreewald-Lausitz.3 Personen mit den Geschlechtsangaben "divers" und "ohne Angabe" (nach § 22 Absatz 3 PStG) werden aus Gründen der statistischen Geheimhaltung per Zufallsprinzip dem männlichen oder weiblichen Geschlecht zugeordnet.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/01782315b930c035/53b9990def20/SB_K03-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/293fddaaa2f52fa5/287016f766bf/SB_K03-02-00_2023j01_BB.pdf)
### Kontakt

#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Grundgesamtheit der Statistik sind die Empfängerinnen und Empfänger von Eingliederungshilfe nach dem Neunten Buch Sozialgesetzbuch (SGB IX).

Mit Einführung des Bundesteilhabegesetztes und die dadurch bewirkte Trennung der Leistungen zur Deckung des Lebensunterhaltes und der Fachleistung gibt es bei Bezug von Eingliederungshilfeleistungen nach Teil 2 des SGB IX ab Januar 2020 keine stationäre Einrichtung mehr. Bislang dort untergebrachte Menschen mit Behinderungen leben ab 2020 in der sogenannten besonderen Wohnform. Zugleich zählen diese Einrichtungen bzw. die Art der Unterbringung nicht mehr als "in Einrichtungen".

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zu Stande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

[**Statistik d****er Empfänger von Eingliederungshilfe nach dem SGB IX****(2023)**](https://download.statistik-berlin-brandenburg.de/8f55a2d6e4177773/165c1a9db013/MD_22161_2023.pdf)| [Archiv](/search-results?q=22161&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Statistik der Ausgaben und Einnahmen der Eingliederungshilfe nach dem SGB IX (2023)](https://download.statistik-berlin-brandenburg.de/e4a75f215fd0001c/8ed0e88fe9a0/MD_22162_2023.pdf)** | [Archiv](/search-results?q=MD_22162&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-i-5-j)
