

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Realsteuervergleich in Berlin und Brandenburg](/l-ii-7-j)

Realsteuervergleich in Berlin und Brandenburg
---------------------------------------------

#### 2023, jährlich

###### Die Daten geben Aufschluss über die Realsteueraufbringungskraft und die Steuereinnahmekraft der Gemeinden Brandenburgs bzw. für Berlin. Sie sind eine wichtige Grundlage zur Beurteilung der wirtschaftlichen und finanziellen Leistungsfähigkeit einer Gemeinde.

BerlinBrandenburgMethodik
### Berlin

 **Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7f7b79116a436227/70adaf6ddf2d/SB_L02-07-00_2023j01_BBB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/6e333e673829c22f/346e9013d6d6/SB_L02-07-00_2023j01_BBB.pdf)

**Realsteueraufbringungskraft pro Kopf stabil**

2023 betrug die Summe der Realsteuern in Berlin 4,0 Mrd. EUR. Die Realsteueraufbringungskraft stieg im Vergleich zum Vorjahr um 0,85 % auf 1.052,12 EUR pro Einwohnerin und Einwohner.

Die Steuereinnahmekraft ergibt sich aus den Realsteuern sowie den Gemeindeanteilen an der Einkommen- und Umsatzsteuer abzüglich der Gewerbesteuerumlage. Für Berlin ergab sich 2023 eine Steuereinnahmekraft in Höhe von 6,3 Mrd. EUR . Das entsprach 1.673,68 EUR pro Einwohnerin und Einwohner.

### Kontakt

#### Sandra Aßmann

REALSTEUERVERGLEICH, Kommunaler Finanzausgleich

#### Sandra Aßmann

REALSTEUERVERGLEICH, Kommunaler Finanzausgleich

* [0331 8173-1223](tel:0331 8173-1223)
* [kommunalerfinanzausgleich@statistik-bbb.de](mailto:kommunalerfinanzausgleich@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Gewerbesteuern gestiegen** 

Nachdem die Realsteuern in Brandenburg 2022 leicht gesunken waren, sind sie 2023 wieder gestiegen. Der Zuwachs der Realsteueraufbringungskraft von 21,56 % im Vergleich zum Vorjahr ist vor allem auf die Gewerbesteuer zurückzuführen. Pro Einwohnerin und Einwohner ergab sich eine Realsteueraufbringungskraft von 688,95 EUR.

Die Steuereinnahmekraft ergibt sich aus den Realsteuern sowie den Gemeindeanteilen an der Einkommen- und Umsatzsteuer abzüglich der Gewerbesteuerumlage. Für Brandenburg ergab sich 2023 eine Steuereinnahmekraft in Höhe von 2,9 Mrd. EUR. Das entsprach 1.129,61 EUR pro Einwohnerin und Einwohner.

SteuereinnahmekraftRealsteueraufbringungskraftIst-Aufkommen
###### 2023

#### Steuereinnahmekraft je Einwohner für Brandenburg

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7f7b79116a436227/70adaf6ddf2d/SB_L02-07-00_2023j01_BBB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/6e333e673829c22f/346e9013d6d6/SB_L02-07-00_2023j01_BBB.pdf)
### Kontakt

#### Sandra Aßmann

REALSTEUERVERGLEICH, Kommunaler Finanzausgleich

#### Sandra Aßmann

REALSTEUERVERGLEICH, Kommunaler Finanzausgleich

* [0331 8173-1223](tel:0331 8173-1223)
* [kommunalerfinanzausgleich@statistik-bbb.de](mailto:kommunalerfinanzausgleich@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Zweck der Erhebung ist die bundeseinheitliche Berechnung von Steuerkraftzahlen (Realsteuerkraft, gemeindliche Steuerkraft, Realsteueraufbringungskraft, Steuereinnahmekraft), die wichtige Indikatoren für die wirtschaftliche bzw. finanzielle Lage der Gemeinden darstellen. Dies ist nicht nur von allgemeinem statistischem Interesse, sondern sowohl der Bundes- als auch der Landesgesetzgeber knüpfen an die Steuerkraft finanzielle Konsequenzen, die sich im Finanzausgleich unter den Ländern bzw. im kommunalen Finanzausgleich niederschlagen. Erhebungsgrundlage des Realsteuervergleichs sind Meldungen, welche die Gemeinden und Gemeindeverbände zur vierteljährlichen kommunalen Kassenstatistik abgeben. Es handelt sich um eine sekundäre Totalerhebung.

  


#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Realsteuervergleich**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/36ed545bbf7be862/d5ef55849833/MD_71231_2023.pdf)[Archiv](/search-results?q=71231&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-ii-7-j)
