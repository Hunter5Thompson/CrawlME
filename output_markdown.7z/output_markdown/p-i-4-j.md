

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Bruttoanlageinvestitionen in Berlin und Brandenburg nach Wirtschaftsbereichen](/p-i-4-j)

Bruttoanlageinvestitionen nach Wirtschaftsbereichen
---------------------------------------------------

#### 1991 bis 2021, Berechnungsstand: August 2023

###### Die Bruttoanlageinvestitionen umfassen den Erwerb von dauerhaften und reproduzierbaren Produktionsmitteln sowie selbst erstellte Anlagen und größere Wert steigernde Reparaturen. Die Käufe neuer Anlagen, Ausrüstungen und Bauten werden gesondert ausgewiesen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:**  Ergebnisse des Arbeitskreises „Volkswirtschaftliche Gesamtrechnungen der Länder" (Berechnungsstand: August 2023)
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/856fdc5b53c6ab50/e407baa4f438/SB_P01-04-00_2021j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/2ef5adb44869f7e1/98b7401a405a/SB_P01-04-00_2021j01_BE.pdf)

**Überdurchschnittliche Investitionen in der Hauptstadt**

In Berlin sind die Bruttoanlageinvestitionen 2021 gegenüber dem Vorjahr preisbereinigt um 1,2 % gestiegen. 2020 gingen die Investitionen noch um 3,5 % zurück. Bundesweit nahmen die Investitionen 2021 um 0,1 % ab.

In jeweiligen Preisen erreichten die Investitionen in der Hauptstadt insgesamt 31.404 Mill. EUR (+6,4 %). Der Anteil an den deutschen Bruttoanlageinvestitionen betrug 4,1 %.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Weiterhin hohe Investitionen**

In Brandenburg sind die Bruttoanlageinvestitionen 2021 gegenüber dem Vorjahr preisbereinigt um 3,3 % gestiegen und lagen damit deutlich über dem bundesweiten Durchschnitt von -0,1 %. Bereits 2020 verzeichnete Brandenburg mit 2,8 % einen starken Anstieg der Investitionen.

In jeweiligen Preisen erreichten die Investitionen in Brandenburg mit insgesamt 21.011 Mill. EUR einen neuen Höchststand. Der Anteil an den deutschen Bruttoanlageinvestitionen betrug 2,7 %.

**Quelle:**  Ergebnisse des Arbeitskreises „Volkswirtschaftliche Gesamtrechnungen der Länder" (Berechnungsstand: August 2023)
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/52a7d1eea501abb8/b2bc1b8f8a95/SB_P01-04-00_2021j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/3420a4a50fd246e7/6bf89b96aa84/SB_P01-04-00_2021j01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

#### Christian Benda

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3734](tel:0331 8173-3734)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Anlageinvestitionen werden in den Volkswirtschaftlichen Gesamtrechnungen brutto nachgewiesen, das heißt vor Abzug der Abschreibungen Als Anlagen werden alle dauerhaften reproduzierbaren Produktionsmittel angesehen. Als dauerhaft gelten hier diejenigen Produktionsmittel, deren Nutzungsdauer mehr als ein Jahr beträgt und die normalerweise in der betrieblichen Buchführung aktiviert werden.

Ergebnisse für alle Bundesländer und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)
