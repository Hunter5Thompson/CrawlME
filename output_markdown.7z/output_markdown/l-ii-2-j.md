

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Gemeindefinanzen in Brandenburg](/l-ii-2-j)

Gemeindefinanzen in Brandenburg
-------------------------------

#### 2023, jährlich

###### Die vierteljährliche Kassenstatistik ist die aktuellste Statistik im Bereich der kommunalen Finanzen. Dargestellt werden die Einnahmen und Ausgaben der Gemeinden und Gemeindeverbände.

BrandenburgMethodik
### Brandenburg

**Finanzmittelüberschuss von 209,8 Mill. EUR ausgewiesen.**

Im Jahr 2023 beliefen sich die bereinigten Einzahlungen der Gemeinden und Gemeindeverbände des Landes Brandenburg auf 11,8 Mrd. EUR. Dies waren 4.574 EUR je Einwohner. Gegenüber dem Vorjahr erhöhten sie sich um 11,0 %.

Den größten Anteil an den bereinigten Einzahlungen hatten die Ausgleichsleistungen und Zuweisungen vom Land. Sie betrugen 4,4 Mrd. EUR. Eine weitere wichtige Einnahmequelle für die Gemeinden waren die Realsteuern. Diese beliefen sich auf 1,8 Mrd. EUR.

Demgegenüber standen bereinigte Auszahlungen in Höhe von 11,6 Mrd. EUR. Dies waren 4 492 EUR je Einwohner. Gegenüber dem Jahr 2022 stiegen sie um 8,4 % an.

Für Personalauszahlungen wurden 3,0 Mrd. EUR aufgewendet. Das waren 25,7 % der bereinigen Auszahlungen.

  
Einnahmen GewerbesteuerEinnahmen Einkommensteuer
###### 2023 in Brandenburg

#### Gewerbesteuereinnahmen (netto) der Gemeinden

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/b04463a174a156f6/d50612ab0d20/SB_L02-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/df1c9109bfd9255b/7117c34e9b36/SB_L02-02-00_2023j01_BB.pdf)
### Kontakt

#### Ulrike Brandes

Finanzstatistiken

#### Ulrike Brandes

Finanzstatistiken

* [0331 8173-1215](tel:0331 8173-1215)
* [finanzstatistik@statistik-bbb.de](mailto:finanzstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die vierteljährlichen Kassenergebnisse liefern wichtige Basisdaten für die Berichterstattung zur stabilitätsorientierten Finanzpolitik der EU-Mitgliedstaaten (Stabilitätspakt).

Die Statistik zeigt, welche Einnahmen den kommunalen Haushalten zugeflossen sind, welche Ausgaben sie damit finanzieren konnten und in welchem Umfang sie darüber hinaus auf Fremdmittel (Verschuldung am Kreditmarkt) oder auf Rücklagen zur Deckung des Finanzierungssaldos zurückgreifen mussten. Die Belastung der kommunalen Haushalte künftiger Jahre aus den aufgenommenen Fremdmitteln ergibt sich aus dem Schuldenstand der kommunalen Schuldenstatistik:

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Vierteljährliche Kassenergebnisse der kommunalen
Kernhaushalte und deren kameral/doppisch buchenden Extrahaushalte**  
Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/0e7fb6182a142253/b1ab1e9d2d5a/MD_71517_2021.pdf)[Archiv](/search-results?q=71517&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-ii-2-j)
