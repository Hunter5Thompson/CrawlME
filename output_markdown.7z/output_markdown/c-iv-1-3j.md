

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Arbeitskräfte, Berufsbildung und Hofnachfolge in landwirtschaftlichen Betrieben in Brandenburg](/c-iv-1-3j)

Arbeitskräfte, Berufsbildung, Hofnachfolge in landwirtschaftlichen Betrieben Brandenburgs
-----------------------------------------------------------------------------------------

#### 2023, drei- bis vierjährlich

###### Das Tabellenprogramm umfasst Angaben zur Betriebsleitung, zu den Familienarbeitskräften, den ständigen Arbeitskräften, der landwirtschaftlichen Berufsbildung sowie der Hofnachfolge in landwirtschaftlichen Betrieben.

BrandenburgMethodik
### Brandenburg

**Weniger Arbeitskräfte 2023**

2023 arbeiteten in den 5.370 landwirtschaftlichen Betrieben Brandenburgs 31.800 Personen.

Drei Jahre zuvor waren es noch 37.600 Personen. Während die Gesamtzahl der landwirtschaftlichen Arbeitskräfte in den Jahren zwischen 2010 und 2013 um rund 8 % zunahm, verringerte sich seit 2016 die Beschäftigungszahl um 18 %.

Der Anteil Vollbeschäftigter lag 2023 bei 41 % (2020: 39 %). Der Anteil der männlichen Personen an der Vollbeschäftigung betrug 76 %.

36 % der Arbeitskräfte waren weiblichen Geschlechts. 80 % der Brandenburger Landwirtschaftsbetriebe wurden von einem Mann geleitet und in den anderen 20 % der Betriebe war der Chef eine Frau.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8bd19f2986f2b23e/03ebd72efa21/SB_C04-01-00_2023j03_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/7512315791274687/a4424ba22fc1/SB_C04-01-00_2023j03_BB.pdf)
### Kontakt

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

#### Anja Burton

Strukturerhebungen, Bodennutzung, Forsten

* [0331 8173-3056](tel:0331 8173-3056)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung der Daten ist Teil der Landwirtschaftszählung. Die Organisation der Datengewinnung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Landwirtschaftszählung**  
Metadaten 2020

[Download PDF](https://download.statistik-berlin-brandenburg.de/023848dc8f72ca47/3f8123557a5c/MD_41141_2020.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iv-1-3j)
