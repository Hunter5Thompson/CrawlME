

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Justiz & Rechtspflege](/justiz-und-rechtspflege)

Justiz und
==========

Rechts­pflege
=============

Die Verwirklichung und Einhaltung des von der Volksvertretung gesetzten Rechts ist eine der wichtigsten Aufgaben eines Rechtsstaates. Die Rechtspflegestatistiken beschäftigen sich mit der   
3. Gewalt (Judikative/Rechtsprechung).   
  
Zu diesen zählen die Justizgeschäftsstatistiken, welche Geschäftsanfälle und Geschäftserledigungen der unterschiedlichen Instanzen der Gerichtsbarkeiten abbilden, und die Strafrechtspflege, welche personenbezogene Statistiken (Strafverfolgung, Strafvollzug und Bewährungshilfe) abbildet.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Abgeurteilte und Verurteilte in Berlin, jährlich (BVI1-j)](/b-vi-1-j)

Zeitreihen
----------

VerurteilteStrafgefangene und Sicherungsverwahrte**Quelle:** Amt für Statistik Berlin-Brandenburg1 14 bis unter 18 Jahre2 18 bis unter 21 Jahre3 21 Jahre und älter**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/4c7a0b3150675179/a8b3256dd12e/justiz-und-rechtspflege-lange-reihe.xlsx)

Basisdaten
----------

Erstinstanzliche VerfahrenStrafgefangeneStrafrechtlich Verurteilte

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1716452346450&code=24#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Daniel Meixner

Rechtspflege

#### Daniel Meixner

Rechtspflege

* [0331 8173-1156](tel:0331 8173-1156)
* [rechtspflege@statistik-bbb.de](mailto:rechtspflege@statistik-bbb.de )
#### Ines Quensel

Rechtspflege

#### Ines Quensel

Rechtspflege

* [0331 8173-1128](tel:0331 8173-1128)
* [rechtspflege@statistik-bbb.de](mailto:rechtspflege@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / Rawf8](https://download.statistik-berlin-brandenburg.de/bb9c63d4a21d952a/78b18f7a17ff/v/85a71b6cd4c6/gesellschaft-staat-judge-gavel-and-a-laptop-wooden-background-online-auction-concept-picture-id1220820993.jpg "iStock.com / Rawf8")](/180-2024)**Strafverfolgung 2023 in Berlin und Brandenburg**[#### Abwärtstrend in Brandenburg setzt sich fort](/180-2024)

2023 nahm die Zahl der Verurteilungen in Berlin im Vergleich zum Vorjahr um 2,1 % zu, in Brandenburg ging sie um 11,1 % zurück.

[![iStock.com / serts](https://download.statistik-berlin-brandenburg.de/dd6e941c8ce73a94/2daf4f79fd95/v/32cedc604422/gesellschaft-staat-statue-of-lady-justice-rmerberg-frankfurt-germany-picture-id840831682.jpg "iStock.com / serts")](/b-vi-1-j)**2023, jährlich, B VI 1 – j**[#### Abgeurteilte und Verurteilte in Berlin](/b-vi-1-j)

In dieser Statistik wird die Anzahl der Abgeurteilten und Verurteilten aus der Strafverfolgungsstatistik veröffentlicht.

[![iStock.com / simarik](https://download.statistik-berlin-brandenburg.de/e4a218676166e7e2/7544533f353a/v/737bb29eb13f/bevoelkerung-gesellschaft-divorce-picture-id1133419016.jpg "iStock.com / simarik")](/144-2024)**Eheschließungen und Ehescheidungen in Berlin und Brandenburg 2023**[#### Rückläufige Zahlen bei Ehen und Scheidungen](/144-2024)

Pressemitteilung Nr. 144 In Berlin und Brandenburg wurden 2023 insgesamt 23.324 Ehen geschlossen und 9.190 Ehen geschieden. Sowohl für die Eheschließungen als auch für die Ehescheidungen ist in der...

[Zu unseren News](/news)

[* Gericht](/search-results?q=tag%3AGericht)[* Urteil](/search-results?q=tag%3AUrteil)[* verurteilt](/search-results?q=tag%3Averurteilt)[* Justiz](/search-results?q=tag%3AJustiz)[* Richter](/search-results?q=tag%3ARichter)[* Anwalt](/search-results?q=tag%3AAnwalt)[* Rechtspflege](/search-results?q=tag%3ARechtspflege)[* Straftäter](/search-results?q=tag%3AStraftäter)[* Strafe](/search-results?q=tag%3AStrafe)
