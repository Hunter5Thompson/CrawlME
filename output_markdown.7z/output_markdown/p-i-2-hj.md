

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Volkswirtschaftliche Gesamtrechnungen](/wirtschaft/volkswirtschaft/gesamtrechnungen)
* [Arbeitnehmerentgelt, Bruttolöhne und -gehälter und Arbeitnehmer in Berlin und Brandenburg nach Wirtschaftsbereichen](/p-i-2-hj)

Arbeitnehmerentgelt, Bruttolöhne und -gehälter und Arbeitnehmer nach Wirtschaftsbereichen
-----------------------------------------------------------------------------------------

#### 1991 bis 2023, halbjährlich

###### Hier finden Sie Informationen zu den in Berlin und Brandenburg gezahlten Bruttolöhnen und -gehältern sowie den Arbeitnehmerentgelten am Arbeitsort, jeweils untergliedert nach Wirtschaftsbereichen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Ergebnisse der Arbeitskreise "Volkswirtschaftliche Gesamtrechnungen der Länder" und "Erwerbstätigenrechnung der Länder"; Berechnungsstand August 2023
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/dc6c44678ac0ca92/368dca1fe1e0/SB_P01-02-00_2023h01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f03cfbc91f9745d8/e844184b3a84/SB_P01-02-00_2023h01_BE.pdf)

**Arbeitnehmerentgelt pro Person in Berlin 8,5 % über dem Bundesdurchschnitt**

Im Jahr 2023 betrug das durchschnittliche Arbeitnehmerentgelt pro Person mit Arbeitsort in Berlin 55 609 EUR. Gegenüber dem Vorjahr stieg es um 5,8 %. Die durchschnittlichen Aufwendungen für die Beschäftigung einer Arbeitnehmerin bzw. eines Arbeitnehmers waren damit in Berlin um 8,5 % höher als im Bundesdurchschnitt von 51 242 Euro.

Das Arbeitnehmerentgelt je geleisteter Arbeitsstunde betrug in Berlin 42,71 EUR. Damit wurden für eine Arbeitsstunde 5,6 % mehr aufgewendet als 2022.

### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Arbeitnehmerentgelt pro Person in Brandenburg bei 87,5 % des Bundesdurchschnitts**

Das durchschnittliche Arbeitnehmerentgelt pro Person mit Arbeitsplatz in Brandenburg stieg im Jahr 2023 um 6,4 % auf 44 857 EUR. Es war um 12,5 % geringer als das Arbeitnehmerentgelt pro Person im Bundesdurchschnitt.

Das Arbeitnehmerentgelt je geleisteter Arbeitsstunde betrug in Brandenburg 33,96 EUR. Damit wurden für eine Arbeitsstunde 5,7 % mehr aufgewendet als 2022.

**Quelle:** Ergebnisse der Arbeitskreise "Volkswirtschaftliche Gesamtrechnungen der Länder" und "Erwerbstätigenrechnung der Länder"; Berechnungsstand August 2023
#### **Zum aktuellen Statistischen Bericht – 1991 bis 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/172b23ae03ac7560/3ee3e0bc405d/SB_P01-02-00_2023h01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/64aa8636a4c612e5/70175d8da3ce/SB_P01-02-00_2023h01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

#### Benjamin Gampfer

Volkswirtschaftliche Gesamtrechnungen

* [0331 8173-3904](tel:0331 8173-3904)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

#### Heike Zimmermann

Einkommens- und Verteilungsrechnung

* [0331 8173-3607](tel:0331 8173-3607)
* [vgr@statistik-bbb.de](mailto:vgr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Das Arbeitnehmerentgelt umfasst die Bruttolöhne und -gehälter sowie tatsächliche und unterstellte Sozialbeiträge der Arbeitgeber. Es spiegelt die Kosten wider, die Arbeitgeber für die Beschäftigung der Arbeitnehmerinnen und Arbeitnehmer aufwenden. Dabei ist zu unterscheiden zwischen dem Arbeitnehmerentgelt am Wohnort (Inländer) und am Arbeitsort (Inland). Die hier veröffentlichten Daten beziehen sich auf das Arbeitnehmerentgelt am Arbeitsort. Die Länderdaten sind auf die Ergebnisse des Statistischen Bundesamtes für Deutschland abgestimmt.

Ergebnisse für alle Bundesländer und weitere Informationen zur Methodik erhalten Sie unter [www.statistikportal.de/de/vgrdl](https://www.statistikportal.de/de/vgrdl "Verknüpfung folgen").

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Volkswirtschaftliche Gesamtrechnungen der Länder**  
Metadaten ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/16579f841f199475/b72e3d1250a9/MD_82000_2019.pdf)[Archiv](/search-results?q=MD_82000&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)
