

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Handel](/wirtschaft/wirtschaftbereiche/handel)

Handel
======

Zur Beobachtung der konjunkturellen Entwicklung im Einzelhandel wird monatlich ein repräsentativer Kreis rechtlicher Einheiten zum Umsatz und zu den tätigen Personen befragt. Die Ergebnisse werden hochgerechnet und als Messzahlen dargestellt.

Auch für den Kraftfahrzeughandel und den Großhandel werden monatliche Ergebnisse bereitgestellt. In den jährlichen Strukturergebnissen finden Sie weiterführende Informationen über die Rentabilität und Produktivität sowie zur Struktur der rechtlichen Einheiten. Die Ergebnisse werden hochgerechnet und als absolute Werte dargestellt.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Umsatz und Beschäftigung im Handel in Berlin und Brandenburg – Messzahlen, jährlich (GI1-j)](/g-i-1-j)[Umsatz, Beschäftigung und Investitionen im Handel und Kraftfahrzeuggewerbe in Berlin und Brandenburg, jährlich (GI2-j)](/g-i-2-j)[Umsatz und Beschäftigung im Einzelhandel in Berlin und Brandenburg – Messzahlen, monatlich (GI3-m)](/g-i-3-m)[Umsatz und Beschäftigung im Kraftfahrzeughandel einschl. Instandhaltung und Reparatur und im Großhandel in Berlin und Brandenburg, monatlich (GI5-m)](/g-i-5-m)

Zeitreihen
----------

Umsatz, Beschäftigte als MesszahlenUmsatz, Beschäftigte als Veränderung zum Vorjahr2 ab 2011 verkettet3 vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/866337cfc3551ce2/44146cd4a119/handel-lange-reihe-2023.xlsx)

Basisdaten
----------

KonjunkturerhebungStrukturerhebung

Weitere Datenangebote
---------------------

#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=statistic&levelindex=0&levelid=1713857876488&code=45212#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Eliza McGownd

Handel Konjunktur

#### Eliza McGownd

Handel Konjunktur

* [0331 8173-3534](tel:0331 8173-3534)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Ines Sawinsky

Handel Struktur

#### Ines Sawinsky

Handel Struktur

* [0331 8173-1235](tel:0331 8173-1235)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Bedienung mit zwei Desserttellern in Restaurantküche](https://download.statistik-berlin-brandenburg.de/d3aee91e75d08b10/db8fc675bf3d/v/c09a768605ad/AdobeStock_280942571.jpg "Bedienung mit zwei Desserttellern in Restaurantküche")](/163-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Berlin**[#### Gemischte Entwicklung im Einzelhandel und Gastgewerbe](/163-2024)

Der Berliner Einzelhandel meldete im 3. Quartal 2024 ein reales Umsatzplus von 1,3 % gegenüber dem Vorjahreszeitraum.

[![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)](/164-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Brandenburg**[#### Einzelhandel wächst, Gastgewerbe schwächelt](/164-2024)

Der Brandenburger Einzelhandel meldete im 3. Quartal 2024 eine reale Umsatzsteigerung um 1,7 % gegenüber dem Vorjahreszeitraum....

[![iStock.com / Denis Stankovic](https://download.statistik-berlin-brandenburg.de/86e22d1ddc6e347e/8b98196092cd/v/6a4675930ed5/gesellschaft-arbeit-waitress-at-work-picture-id1277995557.jpg "iStock.com / Denis Stankovic")](/078-2024)**Einzelhandel und Gastgewerbe 1. Quartal 2024 Berlin**[#### Einzelhandelsumsatz gesunken, Beschäftigung im Gastgewerbe gestiegen](/078-2024)

Pressemitteilung Nr. 78 Der Berliner Einzelhandel meldete im 1. Quartal 2024 einen realen Umsatzrückgang um 1,9 % gegenüber dem Vorjahreszeitraum. Das Berliner Gastgewerbe setze gegenüber dem real...

[Zu unseren News](/news)

[* Kraftfahrzeughandel](/search-results?q=tag%3AKraftfahrzeughandel)[* Kfz](/search-results?q=tag%3AKfz)[* Großhandel](/search-results?q=tag%3AGroßhandel)[* Umsatz](/search-results?q=tag%3AUmsatz)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)[* Bruttoentgelte](/search-results?q=tag%3ABruttoentgelte)[* Bruttoinvestition](/search-results?q=tag%3ABruttoinvestition)[* Konjunktur](/search-results?q=tag%3AKonjunktur)[* Einzelhandel](/search-results?q=tag%3AEinzelhandel)
