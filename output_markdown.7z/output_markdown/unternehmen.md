

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Volkswirtschaft](/wirtschaft/volkswirtschaft)
* [Unternehmen](/unternehmen)

Unternehmen
===========

Das statistische Unternehmensregister enthält Angaben zu Unternehmen, Unternehmensgruppen, Rechtlichen Einheiten und Niederlassungen, gespeist aus Verwaltungsdaten und Bereichsstatistiken.

Wichtige Merkmale sind der Schwerpunkt der wirtschaftlichen Tätigkeit, Beschäftigte und Umsatz. Zusätzlich werden Angaben zur Unternehmensdemografie, wie z. B. Gründung, Fusion, Aufspaltung oder Schließung registriert. Das Unternehmensregister dient als Auswahlgrundlage und Hochrechnungsrahmen für Erhebungen und ermöglicht eigenständige Auswertungen.

[![everythingpossible](https://download.statistik-berlin-brandenburg.de/1f2f3e090916b899/77c96ca7eb74/v/2dd56d88de33/wirtschaft-unternehmen-iStock-990087924.jpg "everythingpossible")](/publikationen/fachgespraech/2022/leonhardt-unternehmensbegriff)**Fachgespräch mit Kerstin Leonhardt**[#### „Wir wollen die Wirtschaftsstrukturen entsprechend des realen Marktgeschehens abbilden.“](/publikationen/fachgespraech/2022/leonhardt-unternehmensbegriff)

Fachgespräch zum Unternehmensbegriff der EU in den Unternehmensstatistiken

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistischer Bericht
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Rechtliche Einheiten und Niederlassungen in Berlin und Brandenburg, jährlich, (DII1-j)](/d-ii-1-j)

Zeitreihen
----------

Rechtliche EinheitenNiederlassungen**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Unternehmensregister

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/ccbac91a70b75b9d/513e2049edfd/unternehmensregister-zeitreihen-2022.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/dc77a4c01fe0fb66/6d4c0a92e3f4/unternehmensregister-lange-reihen-2022.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Bezirke 2022, Stand: 30.09.2023

#### Unternehmensregister in Berlin²

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Landkreise und kreisfreie Städte 2022, Stand: 30.09.2023

#### Unternehmensregister in Brandenburg

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### StatIS-BBB

![](https://download.statistik-berlin-brandenburg.de/78324daa1d8c4302/8f3a5e8bad38/v/4b6c25f57664/statis-bbb-schmuckbild.jpg)

Im Statistischen Informationssystem lassen sich individuelle Auswertungen auf Basis von regional tief gegliederten Daten erstellen und exportieren.

[Zu StatIS-BBB](https://statis.statistik-berlin-brandenburg.de/webapi/jsf/dataCatalogueExplorer.xhtml)
#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1712237279074&code=52111#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/unternehmen-gewerbeanzeigen-und-insolvenzen)

Haben Sie Fragen?
-----------------

#### Kerstin Leonhardt

Unternehmensregister

#### Kerstin Leonhardt

Unternehmensregister

* [0331 8173-3806](tel:0331 8173-3806)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Ole Jeran

Unternehmensregister

#### Ole Jeran

Unternehmensregister

* [0331 8173-3818](tel:0331 8173-3818)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Andreas Brachlow

Unternehmensregister

#### Andreas Brachlow

Unternehmensregister

* [0331 8173-3803](tel:0331 8173-3803)
* [unternehmen@statistik-bbb.de](mailto:unternehmen@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)
#### Solveig Schicht

Profiling

#### Solveig Schicht

Profiling

* [0331 8173-3265](tel:0331 8173-3265)
* [profiling@statistik-bbb.de](mailto:profiling@statistik-bbb.de)
* [0331 817330-4029](fax:0331 817330-4029)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / andriano_cz](https://download.statistik-berlin-brandenburg.de/eeaa36bad7da8db2/d6a85784834f/v/34c75d8aee92/wirtschaft-volkswirtschaft-filing-cabinet-with-yellow-folders-in-an-open-drawers-picture-id1044703450.jpg "iStock.com / andriano_cz")](/d-ii-1-j)**2022, jährlich, D II 1 - j**[#### Rechtliche Einheiten und Niederlassungen in Berlin und Brandenburg](/d-ii-1-j)

Das statistische Unternehmensregister ist eine aktualisierte Datenbank mit Informationen aus Verwaltungsdaten und öffentlich zugänglichen Quellen zu Niederlassungen.

[![Interaktive Karten regionale Wirtschaftsstruktur](https://download.statistik-berlin-brandenburg.de/879b9356e1230b60/b0b3f7479c80/v/72a3012fdb70/Screenshot_Unternehemsregister-1.png "Interaktive Karten regionale Wirtschaftsstruktur")](/publikationen/news/2022/karten-regionale-wirtschaftsstruktur)**Regionale Wirtschaftsstruktur in Berlin und Brandenburg**[#### Interaktive Karten bis auf Kreisebene](/publikationen/news/2022/karten-regionale-wirtschaftsstruktur)

Wo gibt es in Deutschland besonders strukturschwache und strukturstarke Regionen? Wie stellen sich die regionalen Disparitäten in der Wirtschaftsstruktur insgesamt dar? Die interaktiven Kreiskarten...

[![everythingpossible](https://download.statistik-berlin-brandenburg.de/1f2f3e090916b899/77c96ca7eb74/v/2dd56d88de33/wirtschaft-unternehmen-iStock-990087924.jpg "everythingpossible")](/publikationen/fachgespraech/2022/leonhardt-unternehmensbegriff)**Fachgespräch mit Kerstin Leonhardt**[#### „Wir wollen die Wirtschaftsstrukturen entsprechend des realen Marktgeschehens abbilden.“](/publikationen/fachgespraech/2022/leonhardt-unternehmensbegriff)

Fachgespräch zum Unternehmensbegriff der EU in den Unternehmensstatistiken

[Zu unseren News](/news)

[* Profiling](/search-results?q=tag%3AProfiling)[* Unternehmen](/search-results?q=tag%3AUnternehmen)[* Rechtliche Einheiten](/search-results?q=tag%3ARechtliche Einheiten

)[* Niederlassungen](/search-results?q=tag%3ANiederlassungen)[* Betriebe](/search-results?q=tag%3ABetriebe)[* Beschäftigte](/search-results?q=tag%3ABeschäftigte)[* Unternehmensgruppen](/search-results?q=tag%3AUnternehmensgruppen
)[* Unternehmensregister](/search-results?q=tag%3AUnternehmensregister)
