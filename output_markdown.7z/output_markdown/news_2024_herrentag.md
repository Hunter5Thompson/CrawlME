

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 08.05.2024

#### Zum Herrentag 2024

Zehn (wenig) überraschende Statistiken
--------------------------------------

![Männer aus verschiedenen Generationen liegen sich im Arm](https://download.statistik-berlin-brandenburg.de/90acd809305ce92b/2da7e740c1a1/v/1a5a1a22748a/gesellschaft-maenner-istockphoto-1954785358.jpg "Männer aus verschiedenen Generationen liegen sich im Arm")

**Männer bestechen durch Geld und ihre Lässigkeit – das weiß nicht nur Herbert Grönemeyer. Auch unsere Statistiken zeigen, dass Männer in Berlin und Brandenburg zum Beispiel hinsichtlich ihrer Verdiensthöhe und ihres Rauchverhaltens vor den Frauen liegen. Zum Herrentag haben wir ein paar Fakten zur Männerwelt aus der amtlichen Statistik herausgepickt.**

#### 1. Männer im Schnitt leicht übergewichtig

BerlinBrandenburg

**war****der durchschnittliche Body-Mass-Index  
2021 von Berliner Männern.**

Nach Ergebnissen des [Mikrozensus](/bevoelkerung/demografie/mikrozensus) verfügen Männer, die eine Angabe zu ihrem Gewicht gemacht haben, durchschnittlich über ein leichtes Übergewicht. Ihr Body-Mass-Index (BMI) liegt im Schnitt etwas über dem Normalgewicht. Das Normalgewicht befindet sich laut WHO zwischen einem BMI von 18,5 und 25. In Berlin haben 44 % der Männer einen BMI in diesem Bereich, in Brandenburg 32 %. Einen BMI über 30 besitzen 15 % der Berliner und 20 % der Brandenburger, was auf ein starkes Übergewicht bzw. Adipositas hinweist.

Die Aussagekraft ist jedoch mit Vorsicht zu genießen, da der BMI Faktoren wie das Alter, das Gewicht und den individuellen Körperbau nicht berücksichtigt.

**Quelle:** Amt für Statistik Berlin-Brandenburg, Mikrozensus 2021
#### 2. Knapp jeder fünfte Mann raucht

BerlinBrandenburg

Jahre
-----

**betrug das durchschnittliche Alter**  
**von Männern bei Rauchbeginn 2021 in Berlin.**

Männer beginnen etwas früher zu rauchen als Frauen und es rauchen auch anteilig mehr Männer. Die Ergebnisse des Mikrozensus 2021 zeigen, dass von den Männern (die eine Angabe zum Rauchverhalten gemacht haben) 24,7 % mindestens gelegentlich rauchen. In Brandenburg sind es 22,3 %. Sie beginnen auch bereits vor dem 18. Geburtstag mit dem Rauchen. Frauen griffen dagegen im Durchschnitt erst zur Zigarette, nachdem sie ihre Volljährigkeit gefeiert haben.

#### 3. Zwei Drittel aller Unfälle durch Männer verursacht

Auch beim Thema [Straßenverkehrsunfälle](/gesellschaft/verkehr) haben Männer leider die Nase vorn – sowohl in Berlin als auch in Brandenburg. Bei zwei Dritteln aller Verkehrsunfälle sind hier im Jahr 2023 Männer die Hauptverursacher.

Werden nur die Fahrradunfälle betrachtet, verändert sich das Verhältnis kaum: In Berlin wurden 63 % und in Brandenburg 65 % der Unfälle von Männern verursacht. Bei Pkw-Unfällen sind es 66 % (Berlin) und 61 % (Brandenburg).

#### 4. Männer sterben jünger

Das erhöhte Unfallaufkommen unter Männern schlägt sich auch in der [Todesursachenstatistik](/todesursachen) nieder. So zeigt sich beispielsweise, dass von verschiedenen Todesursachen wie Unfällen, bösartigen Neubildungen oder Atemwegs- sowie Verdauungserkrankungen häufiger Männer als Frauen betroffen sind. Lediglich bei Krankheiten des Kreislaufsystems überwiegt der Frauenanteil.

Insgesamt verzeichnen Männer ein früheres Sterbealter als Frauen. 2022 wurden Männer in Berlin 75,5 Jahre und Frauen knapp 81 Jahre alt. In Brandenburg verhält es sich ähnlich. Männer starben mit durchschnittlich 75,9 Jahren, Frauen genau sechs Jahre später.

#### 5. Anteilig weniger Männer in Pflegeeinrichtungen

Mit steigendem Alter erhöht sich die Wahrscheinlichkeit, auf [Pflege](/pflege) angewiesen zu sein. Möglicherweise ist das auch ein Grund für den höheren Frauenanteil an pflegebedürftigen Personen in ambulanten und stationären Pflegeeinrichtungen. Nur ungefähr ein Drittel der Pflegebedürftigen in den Einrichtungen in Berlin und Brandenburg waren im Jahr 2021 männlich.

Auch hinsichtlich der Berufswahl zieht es weniger Männer als Frauen in die Pflege – lediglich knapp ein Viertel der tätigen Personen dieser Einrichtungen in Berlin. In Brandenburg beträgt der männliche Personalanteil sogar nur 15,8 %.

BerlinBrandenburg

%
-

**der Pflegebedürftigen in Pflegeeinrichtungen  
2021 in Berlin sind Männer.**

BerlinBrandenburg
###### am 15.12.2021 in den Berliner Bezirken

#### Männer in ambulanten und stationären Pflegeeinrichtungen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

#### 6. Zahl der Gefangenen sinkt, Männeranteil leicht abnehmend

In den vergangenen Jahren ist die Zahl der [Verurteilten](/justiz-und-rechtspflege) in Berlin und Brandenburg stetig zurückgegangen. 2022 erreichte sie in Berlin mit 31.681 Verurteilten den tiefsten Stand seit mehr als 25 Jahren. Brandenburg zählte in demselben Jahr 17.131 Verurteilte. Es handelt sich hierbei überwiegend um Männer. 2022 betrug ihr Anteil in Berlin und Brandenburg zusammen 80,5 %. Im Vergleich zu 2002 ist der Anteil jedoch zurückgegangen, er lag damals noch bei 84,5 %. Bei den Strafgefangenen und Sicherungsverwahrten zeigt sich ein ähnliches Bild.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
#### 7. Verdienstunterschiede in Brandenburg geringer als in Berlin

Weit in Führung liegen Männer bekanntlich auch beim Thema Vergütung. In Berlin verdienten Männer im Jahr 2022 im Durchschnitt 5.240 EUR brutto pro Monat, während Frauen fast 900 EUR weniger erhielten. In Brandenburg ist die Verdienstlücke etwas geringer. Männer verdienten durchschnittlich 3.725 EUR pro Monat, während Frauen auf 3.517 EUR kamen.

Diese Zahlen verdeutlichen weiterhin bestehende geschlechtsspezifische Ungleichheiten am Arbeitsplatz, die oft auf strukturelle und soziale Faktoren zurückzuführen sind. Weiteres zum Gender Gap Arbeitsmarkt behandeln wir in unserer [Pressemitteilung](/030-2024).

  


1 Im Durchschnitt, inklusive Sonderzahlungen**Quelle:** Amt für Statistik Berlin-Brandenburg
#### 8. Höhere Risiken im Arbeitsumfeld für Männer

Doch die Arbeit bringt nicht nur Positives mit sich: Männer treten zum Beispiel vermehrt in Berufe ein, die mit erhöhten Risiken für Arbeitsunfälle und schwerwiegende Behinderungen einhergehen. Die [Statistik über schwerbehinderte Menschen](/menschen-mit-behinderung-eingliederungshilfe) verdeutlicht, dass wesentlich mehr Männer als Frauen eine Schwerbehinderung aufgrund von berufsbedingten Unfällen oder betriebsbedingten Krankheiten haben. Rund Dreiviertel dieser Gruppe in Berlin sind männlich, in Brandenburg vier von fünf.

Außerdem besonders auffällig: In Brandenburg gibt es insgesamt deutlich mehr Betroffene (1.120 Männer und 245 Frauen) als in Berlin (510 Männer und 155 Frauen).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### 9. Erziehung und Bildung nicht mehr nur Frauensache

Ein erfreulicher Trend zeichnet sich dagegen in „typischen“ Frauenberufen ab: So stieg der Anteil des männlichen pädagogischen Fachpersonals in Berliner Kitas von 8,4 % in 2013 auf 13,2 % in 2023. Auch Brandenburg verzeichnet eine ähnlich positive Entwicklung.

Bei Lehrkräften ist die Tendenz weniger stark ausgeprägt. Im Schuljahr 2020/2021 waren in Brandenburg 25,1 % der Lehrkräfte Männer, während es zehn Jahre zuvor noch 21,1 % waren. In Berlin ist der Anstieg minimal. Die Zahlen deuten dennoch darauf hin, dass traditionelle Geschlechterrollen in der Berufswahl langsam aufgebrochen werden und Männer vermehrt Interesse an Berufen im sozialen und pädagogischen Bereich zeigen.

1 Ohne hauswirtschaftlichen und technischen Bereich.**Quelle:** Amt für Statistik Berlin-Brandenburg
#### 10. Höhere Wahlbeteiligung unter Männern? Kommt drauf an.

Für jede Wahl ermitteln wir im Zuge der repräsentativen Wahlstatistik stichprobenartig die Ergebnisse nach Geschlecht und Altersgruppen. Bei der Wiederholungswahl zum Abgeordnetenhaus von Berlin 2023 gingen die Männer mit 64,8 % etwas häufiger wählen als die Frauen (61,2 %). Bei der letzten Landtagswahl in Brandenburg ebenso (62,9 % Männer vs. 59,9 % Frauen). Interessant ist ein Blick auf die Altersgruppen: So gab es zum Beispiel in Brandenburg bei den unter 18-Jährigen und den über 70-Jährigen eine auffällig höhere Wahlbeteiligung unter Männern.

Die letzte Europawahl im Jahr 2019 wies dagegen eine niedrigere Wahlbeteiligung von Männern auf (Berlin: 61,3 % Männer vs. 62,4 % Frauen; Brandenburg 60,1 % Männer vs. 61,2 % Frauen). Wir sind gespannt auf die Ergebnisse der kommenden Europawahl am 9. Juni 2024 in [Berlin](/europawahlen-berlin) und [Brandenburg](/europawahlen-brandenburg).

1 einschließlich divers, ohne Angabe**Quelle:** Amt für Statistik Berlin-Brandenburg
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen
