

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Soziales](/gesellschaft/soziales)
* [Kinder- und Jugendhilfe](/kinder-und-jugendhilfe)
* [Jugendhilfe in Berlin und Brandenburg – Angebote der Jugendarbeit](/k-v-6-2j)

Jugendhilfe – Angebote der Jugendarbeit
---------------------------------------

#### 2023, zweijährlich

###### Aus der Statistik der Angebote der Jugendarbeit werden Erkenntnisse über die wichtigsten Dimensionen der Kinder- und Jugendarbeit gewonnen und ein umfassender Überblick über das Spektrum und den Einsatz der Kinder- und Jugendhilfe im Sinne der Jugendarbeit dargestellt.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/dba31b34d188b84b/ec9c21ce54e6/SB_K05-06-00_2023j02_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/1d2847ae1876cd74/a6ecb5896a8b/SB_K05-06-00_2023j02_BE.pdf)

**Angebote der Jugendarbeit in Berlin**

Im Jahr 2023 wurden 2.753 öffentlich geförderte Angebote der offenen und gruppenbezogenen Jugendarbeit, Veranstaltungen und Projekte sowie Fortbildungsmaßnahmen für ehrenamtliche Mitarbeiter anerkannter Träger der Jugendhilfe von ansässigen Trägern der Berliner Jugendhilfe durchgeführt.

Die 797 offenen Angebote wurden von insgesamt 52.457 Stammbesuchern aufgesucht. An den 503 gruppenbezogenen Angeboten beteiligten sich 35.278 Kinder und Jugendliche. Weitere 106.232 Teilnehmende wurden für die 1.453 Veranstaltungen und Projekte gemeldet, darunter 13.810 Teilnehmende für 429 Fortbildungsmaßnahmen für ehrenamtliche Mitarbeitende anerkannter Träger der Jugendhilfe.

Bei der Durchführung der Angebote waren 7.770 Personen ehrenamtlich pädagogisch tätig, davon 4. 436 weibliche und 3.334 männliche Mitarbeiter.

### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Angebote der Jugendarbeit in Brandenburg**

3.406 öffentlich geförderte Angebote der offenen und gruppenbezogenen Jugendarbeit, Veranstaltungen und Projekte sowie Fortbildungsmaßnahmen für ehrenamtliche Mitarbeiter der Jugendhilfe wurden 2023 von anerkannten Trägern der Brandenburger Jugendhilfe durchgeführt.

29.038 Kinder- und Jugendliche besuchten 833 offenen Angebote. An den 448 gruppenbezogenen Angeboten beteiligten sich 9.422 Stammbesucher. Weitere 170.392 Teilnehmende wurden für die 2.125 Veranstaltungen und Projekte gemeldet, darunter 18.503 Teilnehmende für 610 Fortbildungsmaßnahmen für ehrenamtliche Mitarbeitende anerkannter Träger der Jugendhilfe.

7.274 Personen waren bei der Durchführung der Angebote ehrenamtlich pädagogisch tätig, davon 4.311 weibliche und 2.963 männliche Mitarbeiter.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/58f899f8f96de45b/ed242514a1ad/SB_K05-06-00_2023j02_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/87246d04eb5c12e8/e1eb76ad9608/SB_K05-06-00_2023j02_BB.pdf)
### Kontakt

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik der Angebote der Jugendarbeit umfasst die jeweils auf Dauer angelegten Angebote im Bereich der „Offenen Arbeit“, der „Gruppenarbeit“ und zeitlich befristete Veranstaltungen und Projekte sowie Fortbildungsmaßnahmen für ehrenamtliche Mitarbeitende anerkannter Träger der Jugendhilfe und wird zweijährlich durchgeführt.

Zur Erhebungsgesamtheit gehören alle Angebote der Jugendarbeit, die innerhalb des Berichtsjahres durchgeführt wurden, sofern sie folgende Voraussetzungen erfüllen:

* Status des Trägers: Das Angebot wurde von einem öffentlichen Träger (z.B. Jugendamt, Gemeinde) oder einem anerkannten freien Träger der Jugendhilfe (z.B. Kirche, Wohlfahrtsverband, Jugendinitiative) durchgeführt.
* Finanzierung des Angebots/Trägers: Das Angebot wurde mit öffentlichen Mitteln entweder pauschal oder angebotsbezogen gefördert oder der Angebotsträger hat eine öffentliche Förderung erhalten.
* Inhalt des Angebots: Das Angebot dient vorrangig der Förderung der jugendlichen Entwicklung oder stellt eine geförderte Mitarbeiterfortbildung bei anerkannten Trägern der Jugendarbeit dar.
#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Angebote der Jugendarbeit**2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/5dc80033d6683e57/b3f1c805dee8/MD_22531_2023.pdf)[Archiv](/search-results?q=md_22531_2019&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/k-v-6-2j)
