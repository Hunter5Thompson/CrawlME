

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Pflege](/pflege)

Pflege
======

Die Pflegestatistik erfasst Daten über Pflegeeinrichtungen, deren Personal und die zu betreuenden Pflegebedürftigen sowie Grunddaten über die Empfängerinnen und Empfänger von Pflegegeld einschließlich der Empfängerinnen und Empfänger von Kombinationsleistungen.

Die Erhebung dient der Abbildung der Entwicklungen in der pflegerischen Versorgung und den pflegerischen Angeboten sowie der Weiterentwicklung des Pflegeversicherungsgesetzes.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Ambulante und stationäre Pflegeeinrichtungen sowie Empfangende von Pflegegeldleistungen in Berlin und Brandenburg, zweijährlich (KVIII1-2j)](/k-viii-1-2j)

Zeitreihen
----------

**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/fa5360a0419dfe4e/ddea4c022607/pflege-zeitreihe-2023.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/bbafd23b14d08c24/5283dd94c3e2/pflege-lange-reihe-2023.xlsx)

Basisdaten
----------

Regionaldaten
-------------

###### Berliner Bezirke 2023

#### Empfänger ambulanter Pflege

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte 2023

#### Empfänger ambulanter Pflege

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder-, Kreis- und Gemeindeebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1716543178607&code=22411#abreadcrumb)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=themes&levelindex=0&levelid=1716542866818&code=22#abreadcrumb)
#### StatIS-BBB

![](https://download.statistik-berlin-brandenburg.de/78324daa1d8c4302/8f3a5e8bad38/v/4b6c25f57664/statis-bbb-schmuckbild.jpg)

Im Statistischen Informationssystem lassen sich individuelle Auswertungen auf Basis von regional tief gegliederten Daten erstellen und exportieren.

[Zu StatIS-BBB](https://statis.statistik-berlin-brandenburg.de/webapi/opendatabase?id=BBBPFLEGE)

Haben Sie Fragen?
-----------------

#### Annett Kusche

SOZIALES

#### Annett Kusche

SOZIALES

* [0331 8173-1165](tel:0331 8173-1165)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Madeleine Villwock

SOZIALES

#### Madeleine Villwock

SOZIALES

* [0331 8173-1133](tel:0331 8173-1133)
* [sozialeleistungen@statistik-bbb.de](mailto:sozialeleistungen@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![Alte Frau im Rollstuhl führt angenehmes Gespräch mit Tee](https://download.statistik-berlin-brandenburg.de/bce0024fa4a325f9/a8d8eb37d2d9/v/e6a5a3500058/bevoelkerung-gesellschaft-rentnerin-frau-pflege-iStock-1468292192-web.jpg "Alte Frau im Rollstuhl führt angenehmes Gespräch mit Tee")](/news/2024/hochaltrige)**Die Bevölkerungsgruppe 80+ in Berlin und Brandenburg**[#### Wie leben Hochaltrige?](/news/2024/hochaltrige)

Hochaltrige – Menschen, die das 80. Lebensjahr erreicht haben – machen in Berlin 6,3 % und in Brandenburg 8,6 % der Bevölkerung aus. Eine kleiner Anteil, der aber stetig wächst. Wir zeigen Ihnen,...

[![Rentenbezugsmitteilungen](https://download.statistik-berlin-brandenburg.de/52e4289d79a31b1c/94386570241c/v/3a11966a4106/gesellschaft-staat-iStock-687574580-.jpg "Rentenbezugsmitteilungen")](/news/2023/ab-65-Jahre)**Zum Tag der älteren Generation**[#### 65+ in Berlin und Brandenburg](/news/2023/ab-65-Jahre)

Wir werfen einen Blick auf die demografische Struktur der Bevölkerungsgruppe ab 65 Jahre und ihre soziale Situation....

[![Pflegeheim](https://download.statistik-berlin-brandenburg.de/4abd52fb70712a7d/acbea0faa590/v/9b66b36709ba/gesellschaft-gesundheit-pflege-iStock-830253154.jpg "Pflegeheim")](/235-2022)**Pflegestatistik 2021 Berlin und Brandenburg**[#### Mehr Frauen in der Hauptstadtregion von Pflege betroffen](/235-2022)

Pressemitteilung Nr. 235 Ende 2021 erhielten über 185 500 Berlinerinnen und Berliner sowie mehr als 184 600 Brandenburgerinnen und Brandenburger Leistungen nach dem Pflegeversicherungsgesetz. Laut...

[Zu unseren News](/news)

[* Pflegeheim](/search-results?q=tag%3APflegeheim)[* Pflegedienst](/search-results?q=tag%3APflegedienst)[* Pflegebedürftige](/search-results?q=tag%3APflegebedürftige)[* Pflegegeld](/search-results?q=tag%3APflegegeld)[* ambulante Pflege](/search-results?q=tag%3Aambulante Pflege
)[* stationäre Pflege](/search-results?q=tag%3Astationäre Pflege
)
