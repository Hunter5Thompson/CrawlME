

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Umsatz, Beschäftigung und Investitionen im Gastgewerbe in Berlin und Brandenburg](/g-iv-4-j)
* [G IV 4 - j](/archiv/g-iv-4-j)

Archiv: Statistischer Bericht
=============================

#### Umsatz, Beschäftigung und Investitionen im Gastgewerbe (G IV 4 - j)

![](https://download.statistik-berlin-brandenburg.de/2dd12835b35a558d/1c6fd3cf1dde/v/d3ed93e435cc/Archiv-Statistische-Berichte-klein.png)
#### Ältere Ausgaben dieses Berichts in der

### Statistischen Bibliothek

**Sie finden ältere Ausgaben dieses Statistischen Berichts jederzeit in der Statistischen Bibliothek. Alle elektronischen Veröffentlichungen der Statistischen Ämter der Länder und des Statistischen Bundesamtes werden dort auf einem gemeinsamen Publikationenserver gespeichert und sind zum kostenfreien Download verfügbar.**

[Ältere Berichte Berlin](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000896)[Ältere Berichte Brandenburg](https://www.destatis.de/GPStatistik/receive/BBSerie_serie_00000898)


