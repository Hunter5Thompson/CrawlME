

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Verarbeitendes Gewerbe](/verarbeitendes-gewerbe)
* [Produktion in Berlin und Brandenburg](/e-i-4-vj)

Verarbeitendes Gewerbe – Produktion
-----------------------------------

#### 2. Quartal 2024, vierteljährlich

###### Die Daten der Produktionsstatistiken bilden die konjunkturelle Lage des Verarbeitenden Gewerbes ab. Sie informieren über die zum Absatz bestimmte Produktion nach Menge und Wert sowie Reparatur-, Montage- und Lohnveredlungsarbeiten. Einbezogen sind alle Betriebe von rechtlichen Einheiten mit 20 und mehr Beschäftigten.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2. Quartal 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e19f2c4daccae5fa/e5e49dffdddc/SB_E01-04-00_2024q2_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/ab673cdec4dd2374/d830a4bd6436/SB_E01-04-00_2024q2_BE.pdf)

**Produktionsvolumen leicht im Aufwind**

Die Produktion der Berliner Industriebetriebe stieg im 2. Quartal 2024 im Vergleich zum Vorjahreszeitraum um 2,2 %.

Die 105 Betriebe der Nahrungs- und Futtermittelindustrie erhöhten ihr Produktionsvolumen leicht um 0,4 % auf 714,9 Millionen (Mill.) EUR. Ebenso steigerten die 30 Hersteller chemischer Erzeugnisse ihre Produktion um 12,6 % auf 236,6 Mill. EUR. In den 30 Betrieben der Gummi-und Kunststoffwaren sank die Produktion um 4,4 % auf 95,5 Mill. EUR. Ebenso verzeichneten die 81 Betriebe der Metallerzeugung ein Produktionsminus von 8,3 %, ihr Produktionsvolumen sank auf 263,8 Mill. EUR. Für die 56 Betriebe der Produzenten elektrischer Ausrüstungen ergab sich auch in diesem Quartal ein Minus von 28,9 % bei einem Volumen von 416,9 Mill. EUR.

### Kontakt

#### Jeanette Miniers

Produktion & Investition Berlin

#### Jeanette Miniers

Produktion & Investition Berlin

* [0331 8173-3805](tel:0331 8173-3805)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Produktionsvolumen steigt wieder an**

Die Produktion der Brandenburger Industriebetriebe stieg im 2. Quartal 2024 im Vergleich zum 1. Quartal 2024 um durchschnittlich 2,8 %. Das Produktionsvolumen betrug dabei 8,7 Milliarden (Mrd.) EUR. Im Vergleich zum Vorjahreszeitraum sank die Produktion allerdings um 3,1 % leicht.

Die größte Steigerung im Vergleich zum 1. Quartal 2024 ist mit 47,0 % und einem Volumen von 901,3 Millionen (Mill.) EUR bei den 193 Betrieben für Reparatur, Instandhaltung und Installation von Maschinen und Ausrüstungen (einschl. Wartung) zu verzeichnen. Die 170 Hersteller von Glas und Glaswaren, Keramik, bearbeitete Steine und Erden steigerten ihre Produktion um 27,8 % auf 337,5 Mill. EUR und die 12 Getränkehersteller meldeten eine Steigerung um 9,5 % auf 95,4 Mill. EUR.

Produktionsrückgänge im Vergleich zum Vorquartal wurden dagegen z. B. von den 10 Textilbetrieben (26,6 %), den 39 Produzenten chemischer Erzeugnisse (14,2 %) oder den 154 Herstellern von Nahrungs- und Futtermitteln (5,0 %) gemeldet.

1 vorläufige Daten **Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2****. Quartal 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ebba2d96ceae7a18/49b98d8e7102/SB_E01-04-00_2024q02_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/08135ecfacd4e8c0/7e5dc488ac41/SB_E01-04-00_2024q02_BB.pdf)
### Kontakt

#### Diana Wilde

Produktion & Investition Brandenburg

#### Diana Wilde

Produktion & Investition Brandenburg

* [0331 8173-3836](tel:0331 8173-3836)
* [verarb.gewerbe@statistik-bbb.de](mailto:verarb.gewerbe@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die vierteljährliche Produktionserhebung erfasst sämtliche im Inland gelegene Betriebe des Verarbeitenden Gewerbes sowie des Bergbaus und der Gewinnung von Steinen und Erden mit 20 und mehr Beschäftigten.

Erhoben wird die zum Absatz bestimmte Produktion, einschließlich der gesondert erhobenen Lohnarbeit (Absatzproduktion), die zur Weiterverarbeitung bestimmte Produktion und die Gesamtproduktion. Die Absatzproduktion wird im Allgemeinen nach der Menge und dem Wert (Verkaufswert) erhoben, die Weiterverarbeitungsproduktion nach der Menge.

Die Ergebnisse der Vierteljährlichen Produktionserhebung werden zur Beobachtung von Konjunkturverläufen und Strukturveränderungen in der Wirtschaft sowie zu handelspolitischen Zwecken genutzt. In Verbindung mit den Ergebnissen der Außenhandelsstatistik dienen sie der Marktbeobachtung und -analyse. Zudem werden sie für unternehmensinterne Entscheidungen und Berechnungen im Rahmen der Volkswirtschaftlichen Gesamtrechnungen herangezogen.

Zu den Hauptnutzenden der Produktionserhebungen zählen Bundes- und Länderministerien, insbesondere das Bundesministerium für Wirtschaft und Energie, sowie andere öffentliche Institutionen, Wirtschaftsverbände, Unternehmen, Forschungsinstitute und die allgemeine Öffentlichkeit.

  


#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatliche und Vierteljährliche Produktionserhebung im Bereich Verarbeitendes Gewerbe, Bergbau und Gewinnung von Steinen und Erden**  
Metadaten ab 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/4ab1766c7144d39b/d21708553166/MD_42121_2024.pdf)[Archiv](/search-results?q=MD_42121&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-i-4-vj)
