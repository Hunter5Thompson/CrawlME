

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Handel](/wirtschaft/wirtschaftbereiche/handel)
* [Umsatz und Beschäftigung im Einzelhandel in Berlin und Brandenburg – Messzahlen](/g-i-3-m)

Umsatz und Beschäftigung im Einzelhandel– Messzahlen
----------------------------------------------------

#### September 2024, monatlich

###### Die monatliche Erhebung zum Einzelhandel liefert kurzfristige Informationen zur konjunkturellen Entwicklung in diesem Bereich. Dazu zählen Daten zu Umsatz und tätigen Personen aufgegliedert nach einzelnen Branchen.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/af7a8ed191577a9a/6b23bb1c99a0/SB_G01-03-00_2024m09_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b4ff4dd273292146/111137444d5a/SB_G01-03-00_2024m09_BE.pdf)

**Umsatzplus trotz Beschäftigungsrückgang**

Im September 2024 verzeichnete der Berliner Einzelhandel eine reale (preisbereinigte) Umsatzsteigerung von 3,7 % im Vergleich zum Vorjahresmonat.

Der Umsatz im Bereich „Waren verschiedener Art“, zu dem Supermärkte, Discounter, Warenhäuser und Tankstellen zählen, stagnierte und blieb auf dem Niveau des Vorjahres. Deutlich dynamischer entwickelte sich der Einzelhandel außerhalb von Verkaufsräumen, einschließlich des Onlinehandels, wo die Umsätze um 14,1 % stiegen. Andere Segmente meldeten Umsatzrückgänge. So verzeichneten Buch-, Sport- und Spielwarengeschäfte, Drogerien und Apotheken einen leichten Rückgang um 1,1 %. Besonders deutlich fiel der Umsatzrückgang mit 9,9 % bei Elektronikfachmärkten, Bau- und Heimwerkermärkten sowie Möbelhäusern aus.

Die Zahl der Beschäftigten im Berliner Einzelhandel sank insgesamt um 5,0 % im Vergleich zum September des Vorjahres.

### Kontakt

#### Robby Trinks

Handel Konjunktur

#### Robby Trinks

Handel Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Leichter Umsatzrückgang und weniger Beschäftigte**

Im September 2024 verzeichnete der Brandenburger Einzelhandel einen realen (preisbereinigten) Umsatzrückgang von 0,5 % im Vergleich zum Vorjahresmonat.

Der Umsatz im Bereich „Waren verschiedener Art“, zu dem Supermärkte, Discounter, Warenhäuser und Tankstellen zählen, sank um 3,4 %. Ebenso mussten Buch-, Sport- und Spielwarengeschäfte sowie Drogerien und Apotheken einen Umsatzrückgang von 1,3 % hinnehmen. Im Gegensatz dazu entwickelte sich der Einzelhandel außerhalb von Verkaufsräumen, einschließlich des Onlinehandels, positiv und verzeichnete einen Umsatzanstieg von 8,3 %. Auch Elektronikmärkte, Bau- und Heimwerkermärkte sowie Möbelhäuser meldeten ein Plus von 2 %.

Insgesamt sank die Zahl der Beschäftigten im Brandenburger Einzelhandel um 3,9 % im Vergleich zum Vorjahr.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – September 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/7b84f01795652faa/15f5ff3b15ed/SB_G01-03-00_2024m09_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/4b8220eb3bee81c2/127499210e53/SB_G01-03-00_2024m09_BB.pdf)
### Kontakt

#### Robby Trinks

Handel Konjunktur

#### Robby Trinks

Handel Konjunktur

* [0331 8173-3585](tel:0331 8173-3585)
* [anfragen-referat33@statistik-bbb.de](mailto:anfragen-referat33@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die monatlichen Erhebungen im Einzelhandel liefern kurzfristige Informationen zur Beurteilung der konjunkturellen Entwicklung dieses Wirtschaftsbereiches. Erhoben werden der Nettoumsatz (ohne Umsatzsteuer) und die Zahl der tätigen Personen. Die Ergebnisse der monatlichen Statistik werden als Messzahlen und Veränderungsraten ausgewiesen.

Alle Messzahlen und Veränderungsraten sind, soweit sie Erhebungszeiträume des aktuellen Jahres und des Vorjahres betreffen, vorläufig und werden monatlich rückwirkend durch nachträglich eingehende Meldungen und Korrekturen der in die Berichtskreise einbezogenen Unternehmen aktualisiert.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatsstatistik im Einzelhandel**  
Metadaten 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/45e77d946b49d27b/113bc6c8c6ca/MD_45212_2024.pdf)[Archiv](/search-results?q=MD_45212&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-i-3-m)
