

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Bauen und Wohnungen](/bauen-und-wohnungen)
* [Baufertigstellungen, Bauüberhang und Bauabgang in Berlin und Brandenburg](/f-ii-2-j)

Baufertigstellungen, Bauüberhangund Bauabgang
---------------------------------------------

#### 2023, jährlich

###### Die Baufertigstellungs-, Bauüberhangs- und Bauabgangsstatistik bilden zusammen mit der Baugenehmigungsstatistik das System der Bautätigkeitsstatistiken. Diese liefert Ergebnisse über die Struktur, den Umfang und die Entwicklung der Bautätigkeit im Hochbau und ist somit ein wichtiger Indikator für die Beurteilung der Wirtschaftsentwicklung im Bausektor. Darüber hinaus stellt sie Daten z.B. für die Planung in den Gebietskörperschaften, für Wirtschaft, Forschung und den Städtebau bereit.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/8fca15dee88731ef/38ecf53a67a0/SB_F02-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/f04eff1e90cba9fe/699a13505dba/SB_F02-02-00_2023j01_BE.pdf)

**Lichtenberg und **Treptow-Köpenick**melden die meisten Wohnungsfertigstellungen**

Die Berliner Bauaufsichtsbehörden meldeten 2023 insgesamt 15.965 fertiggestellte Wohnungen. Das sind 7,8 % weniger als im Jahr zuvor. Dennoch lagen die Baufertigstellungsmeldungen um 967 Wohnungen über dem Durchschnittswert der letzten zehn Jahre. Die Bezirke Lichtenberg und Treptow-Köpenick meldeten die meisten Wohnungsfertigstellungen, Lichtenberg mit 3.410 Wohnungen (Vorjahr: 1.571) zugleich den prozentual höchsten Zugewinn gegenüber 2022.

Die Zahl der Wohnungen in Wohngebäuden im Bauüberhang sank zum Stichtag 31.12.2023 um 5,7 % auf 58.029. Darunter sind 50.106 Wohnungen in neuen Wohngebäuden geplant.

Es wurden 175 Abgänge ganzer Wohngebäude (Vorjahr: 238) gemeldet. In 158 Fällen war der Grund des Bauabgangs die Errichtung eines neuen Wohngebäudes. Außerdem wurde der Bauabgang von 105 ganzen Nichtwohngebäuden angezeigt. Mit 35 Bauvorhaben war auch hier der meistgenannte Grund die Errichtung eines neuen Wohngebäudes.

### Kontakt

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Zahl der Wohnungen im Bauüberhang gesunken**

11.855 Wohnungen meldeten die Bauaufsichtsbehörden Brandenburgs 2023 als fertiggestellt, 19,5 % mehr als im Vorjahr. Damit wurde der Durchschnittswert der letzten zehn Jahre um 1.096 Wohnungen überboten. Von den 10.709 gemeldeten Wohnungen in neuen Wohngebäuden sind 4.654 (Vorjahr: 4.094) im Weiteren Metropolenraum und 6.055 (Vorjahr: 4.539) im Berliner Umland entstanden.

Im gleichen Zeitraum sank die Zahl der Wohnungen in Wohngebäuden im Bauüberhang um 3,3 % auf 39.288, darunter 33.848 Wohnungen, die in neuen Wohngebäuden geplant sind.

Die Zahl der Abgänge ganzer Wohngebäude sank im Vergleich zum Vorjahr von 261 auf 223. In 82 Fällen war der Grund des Bauabgangs die Errichtung eines neuen Wohngebäudes. Es gab 393 Bauabgänge von ganzen Nichtwohngebäuden, darunter 224 Bauvorhaben, die die Nutzungsänderung in ein Wohngebäude zum Ziel hatten.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ed8f2d3a9cf09727/219c1f2b56c9/SB_F02-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/925d2beae29a2f30/ecdfd0d8c57a/SB_F02-02-00_2023j01_BB.pdf)
### Kontakt

#### Brit Boche

Bautätigkeit

#### Brit Boche

Bautätigkeit

* [0331 8173-3843](tel:0331 8173-3843)
* [bautaetigkeit@statistik-bbb.de](mailto:bautaetigkeit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Gegenstand der Bautätigkeitsstatistiken sind Baugenehmigungen und Baufertigstellungen im Hochbau, der Bauüberhang am Jahresende und Bauabgänge von Gebäuden und Gebäudeteilen im Hochbau. Die Baugenehmigungsstatistik wird monatlich und jährlich aufbereitet, die anderen Statistiken jährlich. Auch die Fortschreibung des Wohngebäude- und Wohnungsbestandes erfolgt jährlich.

Im Rahmen der Bautätigkeitsstatistiken werden die gemäß Landesbauordnungen (Berlin und Brandenburg unterschiedlich) genehmigungs- und zustimmungsbedürftigen sowie kenntnisgabe- oder anzeigepflichtigen oder einem Genehmigungsfreistellungsverfahren unterliegenden Bauvorhaben erfasst, bei denen Wohn- oder Nutzraum geschaffen bzw. verändert wird. Das geschieht überwiegend durch Neubau, aber zum Teil auch durch Baumaßnahmen an bestehenden Gebäuden, wie z. B. den Ausbau von Dachgeschossen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

###### Metadaten

**[Statistik der Baufertigstellungen (2022)](https://download.statistik-berlin-brandenburg.de/665359cd618d5f15/234789e7d419/MD_31121_2022.pdf)** | [Archiv](/search-results?q=MD_31121&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Statistik des Bauüberhangs (2022)](https://download.statistik-berlin-brandenburg.de/9f5fd3314646d171/678c31e5c580/MD_31131_2022.pdf)** | [Archiv](/search-results?q=MD_31131&searchMethodik=true&pageNumber=1&sortBy=date-desc)

**[Statistik des Bauabgangs (2022)](https://download.statistik-berlin-brandenburg.de/03f4f7b5282a66db/63ebeb4adedc/MD_31141_2022.pdf)** | [Archiv](/search-results?q=MD_31141&searchMethodik=true&pageNumber=1&sortBy=date-desc)

[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/f-ii-2-j)
