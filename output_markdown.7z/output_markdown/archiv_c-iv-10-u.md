

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Ausgewählte Ergebnisse der Landwirtschaftszählung in Berlin](/c-iv-10-u)
* [C IV 10 - u](/archiv/c-iv-10-u)

Archiv: Statistischer Bericht
=============================

#### Ausgewählte Ergebnisse der Landwirtschaftszählung in Berlin (C IV 10 - u)


