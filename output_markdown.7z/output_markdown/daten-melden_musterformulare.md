

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Daten melden](/daten-melden)
* [Musterformulare](/daten-melden/musterformulare)

Musterformulare
---------------

Dienstleistungen, HandelKinder- und JugendhilfeÖffentliche HaushalteÖffentliche Fonds, Einrichtungen und Unternehmen mit eigenem RechnungswesenVerarbeitendes GewerbeVerdiensteLand- und Forstwirtschaft
### Dienstleistungen, Handel

| **Statistik** | **Erhebungsbogen** | | **Unterrichtung** | **Informationsflyer** |  |
| --- | --- | --- | --- | --- | --- |
| Strukturstatistik im Handels- und Dienstleistungsbereich – jährlich |  |  |  |  |  |
| Monatserhebung im Handel und Dienstleistungsbereich einschließlich Gastgewerbe – Unternehmen mit einem Geschäftsfeld |  |  |  |  |  |
| Monatserhebung im Handel und Dienstleistungsbereich einschließlich Gastgewerbe – Unternehmen mit mehreren Geschäftsfeldern |  |  |  |  |  |
|  |  |

Zu Ihrer Onlinemeldung
----------------------

[#### IDEV Meldeverfahren](https://www.idev.nrw.de/idev/)[#### eStatistik.COREMeldeverfahren](https://core.estatistik.de/core/)[#### Erhebungsportalder amtlichen Statistik](https://erhebungsportal.estatistik.de/Erhebungsportal/start)


