

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Krankenhaus und Rehabilitation](/krankenhaus-und-rehabilitation)
* [Krankenhäuser in Berlin und Brandenburg Teil III – Kostennachweis](/a-iv-4-j)

Krankenhäuser
-------------

### Teil III – Kostennachweis

#### 2022, jährlich

###### Die Statistik enthält eine Übersicht über die Kosten der Krankenhäuser in Berlin und Brandenburg. Dazu zählen Personalkosten, Materialaufwand und sonstige betriebliche Aufwendungen aus Sachkosten. Sie werden unter anderem nach Trägern, Typen und Kostenarten aufgeschlüsselt.

BerlinBrandenburgMethodik
### Berlin

1 Wirtschafts- und Versorgungsdienst, technischer Dienst, Sonderdienste, klinisches Hauspersonal, sonstiges Personal, nicht zurechenbare Personalkosten**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/735ff4154ed010f0/370e6d9c9b10/SB_A04-04-00_2022j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/3c6748e645c99f8b/cfa96480077b/SB_A04-04-00_2022j01_BE.pdf)

**Mehr Kosten je Patient bzw. Patientin als 2021**

Im Jahr 2022 fielen in den 88 Berliner Krankenhäusern Gesamtkosten in Höhe von 6,9 Milliarden EUR an, das waren rund 321 Millionen EUR mehr als 2021.

Hauptbestandteil der Gesamtkosten waren die Personalkosten (3,9 Milliarden EUR) und die Sachkosten (2,9 Milliarden EUR).

Nach Abzug der Kosten für nichtstationäre Leistungen wie Ambulanzen, wahlärztliche Leistungen oder vor- und nachstationäre Behandlungen beliefen sich die Kosten für die stationäre Krankenhausversorgung im Jahr 2022 auf 5,7 Milliarden EUR.

Umgerechnet auf die Patientinnen und Patienten (748.435), die 2022 mit 5,5 Millionen Berechnungs- und Belegungstagen vollstationär im Krankenhaus behandelt wurden, lagen die stationären Krankenhauskosten je Fall bei 7.651 EUR. Das entspricht einem Anstieg um 2,7 % gegenüber dem Vorjahr.

### Kontakt

#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Gesamtkosten gegenüber dem Vorjahr gestiegen**

In den 63 Brandenburger Krankenhäusern fielen im Jahr 2022 Gesamtkosten in Höhe von 3,3 Milliarden EUR an, das waren rund 183 Millionen EUR mehr als im Vorjahr.

Hauptbestandteil der Gesamtkosten waren die Personalkosten (1,9 Milliarden EUR) und die Sachkosten (1,3 Milliarden EUR).

Nach Abzug der Kosten für nichtstationäre Leistungen wie Ambulanzen, wahlärztliche Leistungen oder vor- und nachstationäre Behandlungen beliefen sich die Kosten für die stationäre Krankenhausversorgung im Jahr 2022 auf 3,1 Milliarden EUR.

Umgerechnet auf die Patientinnen und Patienten (467.797), die 2022 mit 3,7 Millionen Berechnungs- und Belegungstagen vollstationär im Krankenhaus behandelt wurden, lagen die stationären Krankenhauskosten je Fall bei 6.624 EUR. Das entspricht einem Anstieg um ungefähr 5,9 % gegenüber 2021.

1 Wirtschafts- und Versorgungsdienst, technischer Dienst, Sonderdienste, klinisches Hauspersonal, sonstiges Personal, nicht zurechenbare Personalkosten**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2022**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f3737eb2bc11e400/a642bc8d811c/SB_A04-04-00_2022j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/e510ad424f6e1f90/602122997c6b/SB_A04-04-00_2022j01_BB.pdf)
### Kontakt

#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Bei der Erhebung zu den Kosten der Krankenhäuser handelt es sich um eine Vollerhebung. Auskunftspflichtig sind alle Krankenhäuser einschließlich deren Ausbildungsstätten nach § 1 Abs. 3 Nr. 1 Krankenhausstatistik-Verordnung (KHStatV).

Die Kostenermittlung erfolgt seit 2002 nach dem Bruttokostenprinzip auf der Grundlage der Krankenhausbuchführungsverordnung (KHBV) und umfasst alle Aufwendungen des Krankenhauses einschließlich der Aufwendungen für Leistungen, die nicht zu den allgemeinen vollstationären und teilstationären Krankenhausleistungen gehören. Die Gliederung der Kosten richtet sich nach bestimmten, in der KHBV genannten Kontengruppen. Die sachgemäße Zuordnung der Kosten regelt der Kontenrahmen für die Buchführung (Anlage 4 zur KHBV).

Die Ergebnisse dieser Erhebung bilden die statistische Basis für viele gesundheitspolitische Entscheidungen des Bundes und der Länder und dienen den an der Krankenhausfinanzierung beteiligten Institutionen als Planungsgrundlage. Die Erhebung liefert wichtige Informationen über das Kostenvolumen, die Kostenstruktur und die Kostenentwicklung in der stationären Versorgung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Kostennachweis der Krankenhäuser**ab 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/d64c526e5bff3800/de1571d21a06/MD_23121_2021.pdf)[Archiv](/search-results?q=23121&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-4-j)
