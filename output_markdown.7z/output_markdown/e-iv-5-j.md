

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Energie](/energie)
* [Energie- und CO₂-Bilanz Berlin (vorläufig)](/e-iv-5-j)

Energie- und CO₂-Bilanz Berlin (vorläufig)
------------------------------------------

#### 2023, jährlich

###### Diese Daten geben Auskunft über das Aufkommen und die Verwendung von Energieträgern sowie die energiebedingten CO₂-Emissionen im Wirtschaftsraum Berlin. Berechnungsgrundlage ist die Methodik des „Länderarbeitskreises Energiebilanzen“.

BerlinMethodik
### Berlin

1  vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/ae52b75439dcd375/96315b211979/SB_E04-05-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/292008742d4f96f3/c15ca8e53305/SB_E04-05-00_2023j01_BE.pdf)

**Rückgang beim Energieverbrauch und CO2-Emissionen**

In der vorläufigen Energie- und CO2-Bilanz 2023 für Berlin ist ein Rückgang beim Energieverbrauch und den CO2-Emissionen zu beobachten.

Der Primärenergieverbrauch sank um 1,7 %, insbesondere der Verbrauch von Steinkohlen ging stark zurück (–16,1%). Der Endenergieverbrauch sank um 0,2 % gegenüber dem Vorjahr, der Verbrauch von Strom sank um 3,1 %. Die CO2-Emissionen nach Verursacherbilanz sanken insgesamt um 4,0 %, die Emissionen aus dem Verbrauch von Strom um 15,6%.

### Kontakt

#### Mathias Geburek

Energiebilanzen

#### Mathias Geburek

Energiebilanzen

* [0331 8173-3817](tel:0331 8173-3817)
* [energiebilanzen@statistik-bbb.de](mailto:energiebilanzen@statistik-bbb.de)
* [0331 817330-4013](fax:0331 817330-4013)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Energiebilanz gibt Aufschluss über die energiewirtschaftliche Entwicklung in Berlin, mit Aussagen über den Verbrauch von Energieträgern in einzelnen Sektoren sowie deren Fluss von der Erzeugung bis zur Verwendung in den verschiedenen Umwandlungs- und Verbrauchsbereichen. Unter Energieträgern versteht man alle Quellen, aus denen direkt oder durch Umwandlung Energie gewonnen wird.

In der CO2-Bilanz wird die Gesamtmenge des emittierten Kohlendioxids, getrennt nach Energieträgern, in den Sektoren nachgewiesen. Die Bilanzierung der energiebedingten CO2-Emissionen erfolgt nach einer im Länderarbeitskreis Energiebilanzen abgestimmten Methodik. Den Berechnungen liegen die Energiebilanzen zu Grunde. Daneben werden spezifische, auf den Heizwert eines Energieträgers bezogene CO2-Faktoren benötigt, die das Umweltbundesamt zur Verfügung stellt.

Im vorläufigen Bericht wurden Daten, welche bis zum Erstellungsdatum noch nicht vorlagen, mittels eigener Berechnungen geschätzt. Die endgültigen Ergebnisse erscheinen im Bericht [E IV 4 – j](/e-iv-4-j) mit den Energie- und CO₂-Bilanzen für Berlin und Brandenburg .

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

Zu diesem Bericht sind keine Metadaten vorhanden. Mehr Informationen finden Sie auf der [**Website des Länderarbeitskreises Energiebilanzen**](https://www.lak-energiebilanzen.de).  


[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/e-iv-5-j)


