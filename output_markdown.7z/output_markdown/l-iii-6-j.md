

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Staat](/gesellschaft/staat)
* [Öffentliche Finanzen](/oeffentliche-finanzen)
* [Finanzvermögen der Kern- und Extrahaushalte des öffentlichen Gesamthaushalts in Berlin und Brandenburg](/l-iii-6-j)

Finanzvermögen der Kern- und Extrahaushalte des öffentlichen Gesamthaushalts
----------------------------------------------------------------------------

#### 2023, jährlich

###### Die Statistik über das Finanzvermögen des öffentlichen Gesamthaushalts erhebt das Finanzvermögen der öffentlichen Haushalte und deren öffentlich bestimmten Fonds, Einrichtungen und Unternehmen, soweit sie dem Sektor Staat zugerechnet werden.

BerlinBrandenburgMethodik
### Berlin

#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/632a5d00ba8b3513/823b51a5447d/SB_L03-06-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/b34363e5501a4c28/2401a5e98ff0/SB_L03-06-00_2023j01_BE.pdf)

**Finanzvermögen um 10,7 % gesunken**

Das Finanzvermögen der Kern- und Extrahaushalte des Landes und der Sozialversicherungsträger unter Landesaufsicht in Berlin belief sich 2023 auf 26,6 Mrd. EUR beim nicht-öffentlichen Bereich und auf 11,6 Mrd. EUR beim öffentlichen Bereich.

Gegenüber 2022 sank das Finanzvermögen um 4,6 Mrd. EUR (–10,7 %).

### Kontakt

#### Cathleen Faber

FinanzSTATISTIKEN

#### Cathleen Faber

FinanzSTATISTIKEN

* [0331 8173-1264](tel:0331 8173-1264)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Finanzvermögen um 8,5 % gestiegen**

Für Brandenburg belief sich das Finanzvermögen der Kern- und Extrahaushalte des Landes, der Gemeinden- und Gemeindeverbände sowie der Sozialversicherungsträger unter Landesaufsicht 2023 auf 16,6 Mrd. EUR beim nicht-öffentlichen Bereich und 3,6 Mrd. EUR beim öffentlichen Bereich.

Gegenüber 2022 stieg das Finanzvermögen um 1,6 Mrd. EUR (8,5 %).

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/47eb43e519b89d88/c2b5a5f4873a/SB_L03-06-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/2f73e7ed9a0ef81f/ea78c7d6718e/SB_L03-06-00_2023j01_BB.pdf)
### Kontakt

#### Cathleen Faber

FinanzSTATISTIKEN

#### Cathleen Faber

FinanzSTATISTIKEN

* [0331 8173-1264](tel:0331 8173-1264)
* [personalstatistik@statistik-bbb.de](mailto:personalstatistik@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Ergebnisse über das Finanzvermögen des Öffentlichen Gesamthaushalts liefern zusammen mit der Schuldenstatistik wichtige Informationen über die Finanzen des Sektors Staat. Sie bilden eine Grundlage für die Stabilitätsberichterstattung an die Europäische Kommission und erfüllen den Datenbedarf wirtschaftlicher und politischer Entscheidungsträger auf nationaler, supranationaler und internationaler Ebene.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten ggf. den Erhebungsbogen sowie eine Datensatzbeschreibung.

**Finanzvermögen der Kern- und Extrahaushalte des
öffentlichen Gesamthaushalts im Land Berlin und im Land Brandenburg**  
ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/a970143a27a175f4/3651ee503970/MD_71411_2023.pdf)[Archiv](/search-results?q=MD_71411&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/l-iii-6-j)
