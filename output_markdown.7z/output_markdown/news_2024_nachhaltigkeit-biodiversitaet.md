

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 17.09.2024

#### 10 Diagramme zu den Deutschen Aktionstagen Nachhaltigkeit

Biodiversität im Fokus
----------------------

![Ein Windrad und weiter Blick in die Landschaft](https://download.statistik-berlin-brandenburg.de/2fe0c01ea1e3b28f/36c8abef068e/v/58c54355b18c/wirtschaft-preise-wind-turbine-in-the-sunset-seen-from-an-aerial-view-picture-id864427886.jpg "Ein Windrad und weiter Blick in die Landschaft")

**Die Deutschen Aktionstage Nachhaltigkeit im September stehen unter dem Schwerpunktthema Biodiversität. Mit aktuellen Zahlen****möchten wir einen Beitrag leisten, der die Bedeutung der biologischen Vielfalt in unserer Region unterstreicht. Gleichzeitig werfen wir einen Blick auf die Entwicklung von Nachhaltigkeitsindikatoren und deren Bedeutung im Zusammenhang mit den 17 Zielen für nachhaltige Entwicklung der Vereinten Nationen.**

Die Vielfalt von Ökosystemen, Arten und genetischen Ressourcen bildet die Grundlage unseres Lebens. Sie sorgt für sauberes Wasser, fruchtbare Böden, Klimaregulierung und schützt vor den Folgen extremer Wetterereignisse. Weltweit schreitet der Verlust der biologischen Vielfalt voran. Ihr Schutz ist nicht nur für die Arten selbst, sondern auch für den globalen Klimaschutz von Bedeutung. Aus diesem Grund ist die Biodiversität eng mit den [17 Zielen der Vereinten Nationen für nachhaltige Entwicklung](https://www.bundesregierung.de/breg-de/themen/nachhaltigkeitspolitik/nachhaltigkeitsziele-erklaert-232174) (Sustainable Development Goals – SDGs) verbunden und insbesondere im Nachhaltigkeitsziel SDG 15 (Leben an Land) verankert. Dieses fordert den Schutz und die Wiederherstellung von Landökosystemen wie Wälder und Feuchtgebiete.

#### 1. Waldschäden dramatisch zugenommen

Wälder spielen eine zentrale Rolle für die Biodiversität, da sie unzähligen Tier- und Pflanzenarten Lebensraum bieten. Sie stehen im Fokus des SDG 15. In Berlin sind etwa 18 % der Landesfläche bewaldet, in Brandenburg sind es 35 %. Diese Flächenanteile sind stabil geblieben, jedoch haben die Waldschäden in beiden Bundesländern dramatisch zugenommen. 2023 waren nur noch 6,0 % der Berliner Bäume frei von Schäden, 2013 lag der Wert bei 33 %. In Brandenburg fiel der Wert von 53 % auf 8,0 % im Jahr 2022. Besonders 2018, als Europa von einer schweren Dürreperiode getroffen wurde, nahmen die Schäden rapide zu. 2023 gab es jedoch erstmal wieder eine positive Entwicklung.

1 Der Gesundheitszustand der Bäume wird durch die Begutachtung der Baumkronen während der Vegetationszeit ermittelt; Schadstufen: 0 - ohne Schadmerkmale, 1 - schwach geschädigt, 2 – 4 - deutliche Schäden**Quelle:** Waldzustandsbericht des Landes Berlin1 Der Gesundheitszustand der Bäume wird durch die Begutachtung der Baumkronen während der Vegetationszeit ermittelt; Schadstufen: 0 - ohne Schadmerkmale, 1 - schwach geschädigt, 2 – 4 - deutliche Schäden**Quelle:**  Waldzustandsbericht des Landes Brandenburg

Ähnliche Verläufe ergeben sich in der Statistik des [Holzeinschlags in Brandenburg](/c-v-1-j). Der Anteil des Holzeinschlags, der durch Schäden verursacht wurde, liegt seit 2017 auf einem höheren Niveau als in den Vorjahren. 2018 wurde mit 48,8 % (2.365.205 Kubikmeter Holz) ein Höchstwert erreicht. 2023 lag der Anteil bei 23,0 %.

#### 2. Artenvielfalt der Vögel geht zurück

Einen direkten Bezug auf die Artenvielfalt nimmt der Nachhaltigkeitsindikator Artenvielfalt der Vögel. Repräsentative Vogelarten stehen hier stellvertretend für die Bestandsentwicklung vieler anderer Arten, die Qualität von Biotopen und die Eignung der Landschaft als Lebensraum an. Der zumindest für Brandenburg erfasste Wert zeigt, dass das Vorkommen der Vogelspezies zurückgeht.

Eine positivere Entwicklung zeigt sich dagegen bei Naturschutzgebieten. In Berlin stieg der Anteil dieser Flächen von 0,3 % im Jahr 1990 auf 3,0 % im Jahr 2020. In Brandenburg stieg dieser Anteil sogar von 0,7 % auf 8,2 % (Quelle: [LIKI B3](https://www.liki.nrw.de/natur-und-landschaft/b3-naturschutzflaechen)). Diese Naturräume spielen eine wichtige Rolle beim Erhalt der Biodiversität, da sie Rückzugsorte für bedrohte Arten bieten und die Widerstandsfähigkeit von Ökosystemen stärken.

**Quelle:** Bundesamt für Naturschutz (BfN) und Länderinitiative Kernindikatoren (LIKI) B2
#### 3. Emissionen sinken deutlich – insgesamt und pro Kopf

Der Verlust an biologischer Vielfalt beschleunigt den Klimawandel, denn er beeinträchtigt die natürliche Fähigkeit der Erde, das Klima zu regulieren. Extreme Klimabedingungen setzen die Biodiversität gleichzeitig unter Druck. Wichtig ist in diesem Zusammenhang das SDG 13, das Maßnahmen zur Bekämpfung des Klimawandels fordert – wie die Reduktion von Emissionen.

Insgesamt zeigen sich in Berlin und in Brandenburg positive Entwicklungen bei den CO₂-Emissionen nach Quellenbilanz. So wurden im Jahr 2022 in Berlin 12,8 Millionen Tonnen CO₂ ausgestoßen, 1990 waren es noch 26,8 Millionen Tonnen. Das ist ein Rückgang um mehr als 52 %. In Brandenburg sind die Emissionen um 43,3 % auf 45,5 Millionen Tonnen gesunken. Jedoch sind die Emissionen sowohl insgesamt als auch pro Kopf in Brandenburg deutlich höher als in Berlin. Eine Person emittierte hier 2022 im Durchschnitt fast fünfmal so viel wie eine Person in Berlin.

 **Quelle:** Länderarbeitskreis Energiebilanzen
#### 4. Erneuerbare Energien kommen langsam

Auch nachhaltiger Konsum, wie die verstärkte Nutzung von erneuerbaren Energien und umweltfreundlicher Technologien, kann dazu beitragen, die Lebensräume von Tieren und Pflanzen zu schützen und die Belastung von Böden, Gewässern und der Atmosphäre zu verringern. Diese Themen sind u. a. im SDG 12 (nachhaltiger Konsum und Produktion) verankert.

In Brandenburg wurden 2019 bereits mehr als 30 % des Stroms aus Sonnenenergie, Windkraft und anderen erneuerbaren Quellen gewonnen. In Berlin waren es lediglich 6,0 %, jedoch zeigt sich auch hier eine langsam steigende Tendenz.

**Quelle:** Länderarbeitskreis Energiebilanzen
#### 5. Ausbau von Photovoltaik schreitet voran

Photovoltaikanlagen wandeln die Strahlung der Sonne direkt in elektrische Energie um. Die Einspeisung von Strom aus dieser Quelle ist ein entscheidender Faktor zur Senkung des CO₂-Ausstoßes und zur Förderung eines nachhaltigen Energieverbrauchs. Die [Zahl der Photovoltaikanlagen](/130-2024) ist in den letzten Monaten gestiegen. Während im Juni 2023 in Berlin 18.122 Anlagen durch den Stromnetzbetreiber erfasst wurden, waren es 2024 bereits 26.769 Anlagen. Das ist eine Zunahme um 47,7 %. In Brandenburg wurde in diesem Zeitraum eine Zunahme um 44,0 % erfasst. Der Anteil der Photovoltaik an der Gesamtstromeinspeisung ist in Berlin jedoch gering. Er lag im ersten Halbjahr 2024 bei 1,9 %. In Brandenburg betrug der Anteil 12,4 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### 6. Pkw bleibt unverzichtbares Verkehrsmittel

Pkw als Verkehrsmittel sind weiterhin unabdingbar. Die Anzahl an Pkw je 1.000 Einwohnende lag 2023 in Brandenburg mit 572 Pkw leicht unter dem Bundesdurchschnitt, sie ist aber in den vergangenen zehn Jahren leicht gestiegen. In Berlin dagegen besitzen bezogen auf die Einwohnerzahl unterdurchschnittlich viele Personen einen Pkw (330). Hier zeichnet sich sogar ein geringfügig abnehmender Trend ab.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Grundsätzlich zeugt die Beliebtheit des Pkw – bezogen auf die Nachhaltigkeitsziele – von der Notwendigkeit, auf alternative, umweltfreundliche Verkehrsmittel umzusteigen. Der Ausbau von Elektromobilität und nachhaltigen Verkehrssystemen kann zur Reduktion der Umweltbelastungen beitragen. Der Anteil an Pkw mit Elektro-Antrieb an allen zugelassenene Pkw ist in beiden Ländern noch sehr gering. 2023 lag er in Berlin bei 2,0 %, in Brandenburg bei 1,4 % (Quelle: Kraftfahrtbundesamt).

#### 7. CO₂-Emissionen im  Verkehr in Brandenburg auf Höchststand

Während die Emissionen insgesamt sinken, ist der Verkehr weiterhin eine zentraler Verursacher von CO₂-Emissionen. In Berlin sind diese viele Jahre lang vergleichsweise stabil geblieben. Brandenburg verzeichnet im Vergleich zu 1990 einen Anstieg der Emissionen im Verkehr pro Kopf. Im Coronajahr 2020 nahmen die Emissionen pro Kopf in beiden Ländern ab. Berlin weißt seither die niedrigsten Werte seit 1990 auf. In Brandenburg hingegen liegen die Emissionen im Verkehr mit 2.600 Tonnen pro Kopf im Jahr 2022 auf einem neuen Höchststand.

 **Quelle:** Länderarbeitskreis Energiebilanzen

Verkehrsemissionen belasten nicht nur die Atmosphäre, sondern auch die Lebensräume von Tieren und Pflanzen. Das Ziel besteht also darin, diese zu senken. Nachhaltige Städte und Gemeinden sind klimaresilient und schützen wertvolle natürliche Lebensräume vor weiterer Zerstörung. Diese Forderungen sind im SDG 11 (nachhaltige Städte und Gemeinden) festgehalten.

#### 8. Grünanlagen als Rückzugsorte

Besonders in dicht besiedelten Städten bieten Parks und Grünanlagen nicht nur Erholungsmöglichkeiten, sondern dienen auch der Luftreinigung, der Kühlung bei Hitzeperioden und fördern die Biodiversität. Berliner Grünflächen wie der Tiergarten oder der Volkspark Friedrichshain sind zum Beispiel wertvolle Rückzugsorte für heimische Pflanzen und Tiere. Ende 2022 verfügte Berlin insgesamt über 9.301 Hektar Grünanlagen (10,4 % der Landesfläche). Zum Vergleich: Der Anteil der Verkehrsfläche in Berlin beträgt 14,8 %.

###### Am 31.12.2022 in Berliner Bezirken

#### Fläche für Grünanlagen

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Die Grünanlagen gehören innerhalb der Statistik [Flächennutzung](/flaechennutzung) übrigens zum Nutzungsartenbereich „Siedlung“. Hierunter fallen u. a. Wohnbauflächen, Industrie- und Gewerbeflächen oder Freizeit- und Erholungsflächen, die wiederum die Grünanlagen umfassen.

#### 9. Siedlungs- und Verkehrsflächen nehmen zu

Auch die Städte in Brandenburg stehen vor Herausforderungen in Bezug auf die Artenvielfalt: In den kreisfreien Städten hat sich der Anteil der Siedlungs- und Verkehrsfläche vergrößert. Das übt Druck auf natürliche Lebensräume aus. Auch die Anzahl der Einwohnenden je Quadratkilometer Fläche wächst. 2022 lag der Wert um 4,7 % über dem Wert von 2016. Es ist eine Herausforderung für nachhaltige Städte und Gemeinden, den Bedarf an Wohn- und Verkehrsflächen langfristig mit dem Erhalt von Naturflächen in Einklang zu bringen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### 10. Brandenburg Vorreiter im Öko-Landbau

Nicht zuletzt ist auch eine nachhaltige Landwirtschaft entscheidend für den Erhalt der Biodiversität. In Brandenburg zeigt sich eine positive Entwicklung: 2023 erreichte die Zahl der ökologisch wirtschaftenden Betriebe mit 1.020 einen neuen Höchststand. Insgesamt wurden 231.400 Hektar – 19,0 % der landwirtschaftlichen Fläche – ökologisch bewirtschaftet, womit Brandenburg bundesweit nach Bayern an zweiter Stelle steht.

Ökologischer Landbau verzichtet auf Pestizide und chemische Düngemittel, die Böden und Artenvielfalt schädigen. Besonders wichtig für die Biodiversität sind Bestäuber wie Bienen, die für den Anbau von Obst und Gemüse unerlässlich sind.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Zusammenfassend zeigt sich, dass sowohl in Berlin als auch in Brandenburg Fortschritte in Richtung Nachhaltigkeit und Biodiversitätsschutz erzielt werden. Dennoch bleibt viel zu tun, um die Ziele der Vereinten Nationen vollständig zu erreichen und die Lebensgrundlagen für zukünftige Generationen zu sichern.

###### Mehr Infos und Statistiken zum Thema nachhaltige Entwicklung finden Sie im gemeinsamen [Statistikportal](https://www.statistikportal.de/de/nachhaltigkeit/ergebnisse) der Statistischen Ämter des Bundes und der Länder.

### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Nachhaltigkeit](/search-results?q=tag%3ANachhaltigkeit)[* Biodiversität](/search-results?q=tag%3ABiodiversität)[* Klimaschutz](/search-results?q=tag%3AKlimaschutz)
