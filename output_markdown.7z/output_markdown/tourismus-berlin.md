

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Tourismus in Berlin](/tourismus-berlin)

Tourismus in Berlin
===================

#### Entwicklung der Reisebranche 2018 bis 2023

ReisendeBranchenzahlenSpreemetropole Berlin[Tourismus in Brandenburg ➜](/tourismus-brandenburg)

Reisende
--------

##### Im Jahr 2023 kamen insgesamt 12,1 Millionen Gäste in die Hauptstadt, 15,9 % mehr als im Vorjahr. Auch die Übernachtungszahl stieg um 11,5 % auf 29,6 Millionen.

##### Das Niveau vor der Corona-Pandemie konnte jedoch nicht erreicht werden. Die Zahl der Gäste lag um 13,4 % unter dem Ergebnis von 2019. Es wurden 13,3 % weniger Übernachtungen registriert.

##### Aus dem Ausland kamen 4,3 Millionen Gäste an die Spree und somit 22,1 % mehr als noch 2022. Mit 11,9 Millionen Übernachtungen verweilten sie im Durchschnitt 2,8 Tage. Die meisten Gäste kamen aus dem europäischen Ausland (3,1 Millionen, +18,3 %). Spitzenreiter unter allen Ländern war das Vereinigte Königreich mit 465.341 Gästen. Im Vergleich zu 2018 ist die Zahl jedoch um knapp 25 % gesunken.

##### Die 7,8 Millionen Gäste aus dem Inland blieben mit 17,7 Millionen Übernachtungen für durchschnittlich 2,3 Tage in Berlin. Im Vergleich zum Vorjahr stieg die Zahl der Ankünfte um 12,8 %.

###### Veränderung im Vergleich zum Vorjahr

#### Übernachtungen 2023 in Berliner Bezirken

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Branchenzahlen
--------------

##### In der wirtschaftlichen Dynamik der Hauptstadt spielt das Gastgewerbe eine wichtige Rolle. Es setzt sich aus der Gastronomie und dem Beherbergungsgewerbe zusammen. 2023 verzeichnet Berlin 740 Beherbergungsbetriebe, das sind 11 Betriebe mehr als 2022, aber 58 weniger als 2018. Nachdem auch die Zahl der Gaststätten in Berlin in den Jahren der Corona-Pandemie zurückgegangen ist, ging es 2022 wieder bergauf. 2021 waren es zum Beispiel noch 4.510 Restaurant, 2022 dagegen 4.796. Damit wurde sogar der Wert von 2018 überschritten. Bei den Auszubildenden in der Gastronomie gab es 2022 ebenfalls einen leichten Zuwachs. In der Hotellerie verhält sich die Zahl der Auszubildenden insgesamt konstant zum Vorjahr.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg1 Vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg1 2023 vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg Die Daten beziehen sich jeweils auf den 31.12. des Berichtsjahres.**Quelle:** Amt für Statistik Berlin-Brandenburg Die Daten beziehen sich jeweils auf den 31.12. des Berichtsjahres.**Quelle:** Amt für Statistik Berlin-Brandenburg

Spreemetropole Berlin
---------------------

##### Die größte und einwohnerreichste Stadt Deutschlands ist seit jeher ein Besuchsmagnet und verbindet auf einzigartige Weise historisches Erbe, pulsierendes Stadtleben und eine kulturelle Szene. Die über 12 Millionen Berliner Gäste konnten sich über 1.918 Sonnenstunden freuen. Das waren zwar 270 Stunden weniger Sonnenschein als im Vorjahr, jedoch gab es mit 64 Sommertagen über 25 Grad Celsius insgesamt mehr warme Tage. 11,5 Millionen einsteigende und 11,6 Millionen aussteigende Passagiere nutzten 2023 den Flughafen BER Berlin-Brandenburg. Insgesamt wurden somit rund 23 Millionen Passagiere abgefertigt – 3 Millionen mehr als 2022.

**Quelle:**  Wetterstation Potsdam, 20231 teilweise pandemiebedingte SchließungMuseen Daten für 2021 und 2022 liegen nicht vor.**Quelle:** Filmtheater: FFA Filmförderungsanstalt; Museen: Institut für Museumsforschung; Tiergärten: Zoologische Gärten Berlin AG[Zu unseren Kulturstatistiken](/kommunalstatistik/kultur-berlin)
###### Am 31.12.2022 in Berliner Bezirken

#### Fläche für Gewässer

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

WasserflächeGrünanlagenFlughäfen Tegel, Schönefeld und BER: Schließung des Flughafen Tegel am 08.11.2020; Eröffnung des Flughafen Berlin Brandenburg am 31.10.2020; Stilllegung des Flughafen Schönefeld am 22.2.2021**Quelle:** Statistisches Bundesamt

Publikationen zum Thema
-----------------------

[![Bedienung mit zwei Desserttellern in Restaurantküche](https://download.statistik-berlin-brandenburg.de/d3aee91e75d08b10/db8fc675bf3d/v/c09a768605ad/AdobeStock_280942571.jpg "Bedienung mit zwei Desserttellern in Restaurantküche")](/163-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Berlin**[#### Gemischte Entwicklung im Einzelhandel und Gastgewerbe](/163-2024)

Der Berliner Einzelhandel meldete im 3. Quartal 2024 ein reales Umsatzplus von 1,3 % gegenüber dem Vorjahreszeitraum.

[![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)](/164-2024)**Einzelhandel und Gastgewerbe 3. Quartal 2024 Brandenburg**[#### Einzelhandel wächst, Gastgewerbe schwächelt](/164-2024)

Der Brandenburger Einzelhandel meldete im 3. Quartal 2024 eine reale Umsatzsteigerung um 1,7 % gegenüber dem Vorjahreszeitraum....

[![iStock.com / Vladislav Zolotov](https://download.statistik-berlin-brandenburg.de/87f608040b23d410/f253909b08b6/v/52f2573769ca/bevoelkerung-demographie-tourismus-old-market-square-with-st-nicholas-church-and-town-hall-potsdam-picture-id1209637381.jpg "iStock.com / Vladislav Zolotov")](/156-2024)**Tourismus Januar bis September 2024 Brandenburg**[#### Weiter auf Erfolgskurs](/156-2024)

Die Brandenburger Beherbergungsbetriebe zählten von Januar bis September 2024 insgesamt 4,3 Millionen Gäste mit 11,6 Millionen Übernachtungen.

Mehr anzeigen
