

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 12.03.2024

#### Die Bevölkerungsgruppe 80+ in Berlin und Brandenburg

Wie leben Hochaltrige?
----------------------

![Alte Frau im Rollstuhl führt angenehmes Gespräch mit Tee](https://download.statistik-berlin-brandenburg.de/bce0024fa4a325f9/a8d8eb37d2d9/v/e6a5a3500058/bevoelkerung-gesellschaft-rentnerin-frau-pflege-iStock-1468292192-web.jpg "Alte Frau im Rollstuhl führt angenehmes Gespräch mit Tee")

**Hochaltrige – Menschen, die das 80. Lebensjahr erreicht haben – machen in Berlin 6,3 % und in Brandenburg 8,6 % der Bevölkerung aus. Eine kleiner Anteil, der aber stetig wächst.****Wir zeigen Ihnen, wie sich diese Bevölkerungsgruppe entwickelt, wie die Menschen leben, wie sie wählen, wie fit sie sind und welche Bedeutung gesundheitliche Einschränkungen haben.**

#### Wir sind viele.

Wie auch im Bundesdurchschnitt nehmen sowohl der Anteil als auch die absolute Zahl der über 80-Jährigen in Berlin und Brandenburg seit einigen Jahren stark zu. Innerhalb der letzten elf Jahre ist ihre Zahl in Berlin von 142,9 Tsd. (2011) auf 237,9 Tsd. (2022) gewachsen, das entspricht einem Plus von 66,0 %. Ihr Anteil an der Berliner Bevölkerung stieg von 4,3 % in 2011 auf 6,3 % in 2022.

Die Bevölkerungsvorausberechnung (in der mittleren Variante 2) schätzt die Zahl der Berliner Hochaltrigen im Jahr 2050 auf 329,4 Tsd. bei einem Anteil von 7,8 % an der Gesamtbevölkerung.

Für Brandenburg gelten noch höhere Steigerungsraten. Lebten 2011 noch 125,9 Tsd. ab 80-Jährige in Brandenburg, waren es 2022 bereits 220,2 Tsd. Das entspricht einem Zuwachs von 75,0 %. Im Jahr 2050 soll ihre Anzahl laut Vorausberechnung bei 312,9 Tsd. liegen. Der Anteil dieser Altersgruppe an der Gesamtbevölkerung Brandenburgs stieg von 5,1 % im Jahr 2011 auf 8,6 % im Jahr 2022 und soll bis 2050 auf 12,6 % anwachsen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Wir werden immer älter.

Zum rasanten Anstieg der Zahl der über 80-Jährigen trägt auch die steigende Lebenserwartung bei. Von 1992 bis 2022 ist die Zahl der noch zu erwartenden Lebensjahre für 80-jährige Berliner von 6,3 auf 8,3 Jahre angewachsen, für gleichaltrige Berlinerinnen von 8,0 Jahre auf 9,9 Jahre.

In Brandenburg ist die verbleibende Lebenserwartung der Bevölkerung im Alter von 80 Jahren niedriger. Sie stieg trotzdem im Zeitraum von 1992 bis 2022 für Männer von 5,8 Jahre auf 7,8 Jahre, für Frauen von 7,2 Jahre auf 9,4 Jahre.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

Mit steigendem Alter nimmt auch der Anteil der Pflegebedürftigen zu. Im Jahr 2021 waren 22,7 % der Berliner und 30,4 % der Berlinerinnen im Alter von 80 bis unter 85 Jahren pflegebedürftig, bei den über 95-Jährigen waren es schon 77,1 % der Männer und 94,5 % der Frauen.

In Brandenburg mussten 27,7 % der 80- bis unter 85-jährigen Männer und 37,9 % der gleichaltrigen Frauen gepflegt werden. Bei den über 95-Jährigen ist es eher die Ausnahme, nicht pflegebedürftig zu sein.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Wir wohnen seltener allein.

Einsamkeit ist bei Hochaltrigen ein präsentes Thema. Soziale Integration und Teilhabe sind bei Älteren sowohl für die Lebensqualität als auch ihre Sicherheit wichtig. Zwar verringerte sich der Anteil der Ein-Personen-Haushalte unter den über 80-Jährigen zwischen 1996 und 2022 in Berlin und Brandenburg um jeweils rund ein Viertel. Trotzdem lebte 2022 rund die Hälfte in Berlin und ein gutes Drittel in Brandenburg allein. Die andere Hälfte  der Hochaltrigen in Berlin wohnte in einem Mehrpersonenhaushalt, also nicht alleine. In Brandenburg waren es sogar 61,2 %. Dieser Anteil ist im beobachteten Zeitraum seit 1996 stetig gestiegen.

Der Anteil, der in Gemeinschaftsunterkünften oder Altenheimen wohnt, liegt in der Gruppe der Hochaltrigen in Berlin bei 6,6 % und ist gegenüber dem Wert von 1,4 % bei den 60- bis unter 80-Jährigen vergleichsweise hoch. In Brandenburg lebten 10,2 % der Hochaltrigen in Gemeinschaftsunterkünften. Unter den 60- bis unter 80-Jährigen waren es lediglich 1,2 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Wir werden schlauer.

In den höheren Altersjahren lässt sich der Erfolg der Bildungsexpansion der Nachkriegsjahre gut ablesen. Während rund die Hälfte der über 80-Jährigen in Berlin zwischen 2005 und 2022 einen mittleren Bildungsabschluss, das heißt eine Berufsausbildung hatte, ist der der Anteil der Hochaltrigen mit einem akademischen Bildungsabschluss im selben Zeitraum von 8,1 % auf 28,3 % gestiegen. Der Anteil der Gruppe mit niedrigen Bildungsabschlüssen (keine Berufsausbildung, kein Abitur) ging gleichzeitig von 40,8 % auf 21,4 % zurück.

In Brandenburg sank der Anteil unter den Hochaltrigen mit niedrigem Bildungsabschluss von 45,0 % in 2005 auf 20,7 % im Jahr 2022. Gleichzeitig konnten Hochaltrige zuletzt mehr mittlere und hohe Bildungsabschlüsse vorweisen als noch 2005. Insbesondere der Anteil akademischer Abschlüsse verdreifachte sich.

**Quelle:** Amt für Statistik Berlin-Brandenburg 
#### Wir gehen weniger wählen.

2021 nahmen 71,8 % der über 70-Jährigen in Berlin und Brandenburg ihr Wahlrecht bei der Wahl zum Deutschen Bundestag wahr. Die durchschnittliche Wahlbeteiligung lag bei 75,2 %. Die beiden großen Volksparteien SPD und CDU standen bei den Ältesten mit Zweitstimmenergebnissen von 35,6 % (SPD) und 27,9 % (CDU) gewohnt hoch im Kurs. Dagegen gaben nur 7,5 % der über 70-jährigen Wählenden den GRÜNEN ihre Zweitstimme. Das waren viel weniger Stimmen als die GRÜNEN im Durchschnitt aller Zweitstimmen erhielten (22,4 %).

In Brandenburg nahmen die Wählenden ab 70 Jahren seltener von ihrem Wahlrecht Gebrauch als der Durchschnitt der Wahlberechtigten. Ihre Wahlbeteiligung lag 2021 bei 73,6 % gegenüber einer landesweiten Wahlbeteiligung von 75,6 %. Fast die Hälfte (47,3 %) der ältesten Wählenden gab der SPD ihre Zweitstimmen. Die CDU erhielt immerhin noch 19,0 %. Beide Anteile liegen über dem Landesschnitt. Die AfD erhielt von den Älteren insgesamt 9,7 % der Zweitstimmen, während ihr landesweites Ergebnis fast doppelt so hoch war (18,1 %). Auch FDP und GRÜNE waren mit 4,5 % bzw. 4,1 % bei den Ältesten unterdurchschnittlich erfolgreich.

Hinweis: Die repräsentative Wahlstatistik gibt Auskunft über das Wahlverhalten nach Altersgruppen und Geschlecht. Die älteste dabei erfasste Altersgruppe sind die ab 70-Jährigen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Wir kommen über die Runden.

2022 waren in Berlin 14,2 % der ab 80-Jährigen von Armut bedroht – ein neuer Höchststand. Während die „jungen Alten“ im Alter von 65 bis unter 80 Jahre Ende der 1990er Jahre weniger armutsgefährdet waren als die Hochaltrigen, hat sich das Verhältnis ab 2003 umgekehrt. Heute liegt die Armutsgefährdungsquote der 65- bis unter 80-Jährigen über dem Durchschnitt. Mit einem Blick in die Zukunft kann deswegen davon ausgegangen werden, dass die Armutsgefährdungsquote der Hochaltrigen in Berlin weiter wachsen wird.

Ältere Menschen in Brandenburg sind noch vergleichsweise wenig von Altersarmut betroffen, aber auch ihre Gruppe legte in den letzten zehn Jahren zu. Aktuell sind 10,7 % der Hochaltriger armutsgefährdet. Die Quote bei den 65- bis unter 80- Jährigen ist seit 2015 deutlich höher. Folglich wird auch in Brandenburg die Armutsgefährdung unter den Hochaltrigen steigen.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Wir werden fitter.

Jeweils rund ein Viertel der Hochaltrigen in Berlin (24,5 %) und in Brandenburg (23,9 %) gab bei der Befragung für den Mikrozensus 2021 an, in den letzten vier Wochen krank oder unfallverletzt gewesen zu sein, im Jahr 2003 war es noch knapp die Hälfte (Berlin: 45,2 %; Brandenburg 1999: 41,6 %). Auch der Anteil der über 80-jährigen Personen mit amtlich festgestellter Behinderung ging in beiden Ländern zurück – in Berlin von 41,9 % in 2013 auf 27,9 % in 2021 und in Brandenburg von 27,1 % auf 25,5 %.

Demnach ist der Anteil der gesundheitlich Eingeschränkten und Behinderten bei den Hochaltrigen zwar immer noch deutlich überdurchschnittlich, der Gesundheitszustand der ab 80-Jährigen in Berlin und Brandenburg hat sich in den letzten 20 Jahren jedoch spürbar verbessert.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg

**Datenquellen:**   
[Mikrozensus](/bevoelkerung/demografie/mikrozensus), [Pflegestatistik](/pflege), [Koordinierte Bevölkerungsvorausberechnung](https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Bevoelkerung/Bevoelkerungsvorausberechnung/_inhalt.html#sprg233978), [Repräsentative Wahlstatistik](/413f21440799bdd9)

### Kontakte

#### Ricarda Nauenburg

Querschnittsanalysen

#### Ricarda Nauenburg

Querschnittsanalysen

* [0331 8173-3697](tel:0331 8173-3697)
* [analysen@statistik-bbb.de](mailto:analysen@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Rentner](/search-results?q=tag%3ARentner)[* Senioren](/search-results?q=tag%3ASenioren)[* Hochaltrige](/search-results?q=tag%3AHochaltrige)[* Altersarmut](/search-results?q=tag%3AAltersarmut)[* Pflege](/search-results?q=tag%3APflege)
