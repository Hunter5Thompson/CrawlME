

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Strauchbeerenerhebung in Brandenburg](/c-i-4-j)

Strauchbeerenerhebung in Brandenburg
------------------------------------

#### 2023, jährlich

###### Die aus der Strauchbeerenerhebung gewonnenen Daten bieten Informationen über die Anbauflächen und Erntemengen der einzelnen Strauchbeerenarten.

BrandenburgMethodik
### Brandenburg

**Geringere Strauchbeerenernte in Brandenburg**

Strauchbeeren wuchsen 2023 in 50 Betrieben auf einer Fläche von 1.106 Hektar. Damit stieg die Anbaufläche gegenüber 2022 um 15 Hektar zurück. Rund 60 % der Brandenburger Strauchbeerenfläche wurden von 22 Betrieben nach den Prinzipien des ökologischen Landbaus bewirtschaftet. Der Anteil der Kulturheidelbeeren im ökologischen Anbau ist mit rund 10 Prozent relativ gering. Mit insgesamt rund 2.332 Tonnen konnte 2023 eine durchschnittliche Ernte erreicht werden.

Kulturheidelbeeren wurden 2023 auf 419 Hektar gepflückt. Damit stieg die Anbaufläche wieder um 17 Hektar und bleibt damit Brandenburgs wichtigste Strauchbeerenart. Die Erntemenge von 1.552 Tonnen geringer als im Erntejahr 2022 und entspricht rund zwei Drittel der gesamten Beerenernte.

Einen leichten Anbaurückgang um 4 Hektar gab es beim Sanddorn. Dieser bleibt mit einer Fläche von insgesamt 296 Hektar die zweitwichtigste Strauchbeerenart Brandenburg. Beim Sanddorn kam es aufgrund von Schädlingsbefall zu einigen Ernteausfällen. Deshalb wurden nur rund 230 Tonnen gepflückt.

Aroniabeeren, auch als Schwarze Apfelbeeren bekannt, wurden auf knapp 200 Hektar geerntet, vorzugsweise im ökologischen Anbau. Die Erntemenge belief sich auf mehr als 140 Tonnen.

 **Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4e18e6e6c604c24e/315412183be5/SB_C01-04-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/927352b8af2bf481/a87b6cfee001/SB_C01-04-00_2023j01_BB.pdf)
### Kontakt

#### Regina Kurz

Ernte- und Weinstatistiken

#### Regina Kurz

Ernte- und Weinstatistiken

* [0331 8173-3055](tel:0331 8173-3055)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

#### Jens Tischer-Lemke

Ernte- und Weinstatistiken

* [0331 8173-3054](tel:0331 8173-3054)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Strauchbeerenerhebung ist eine dezentrale Bundesstatistik. Die Organisation der Datengewinnung und -aufbereitung ist Aufgabe der Statistischen Ämter der Länder. Die Daten der Betriebe werden über einen Online-Fragebogen (IDEV) erhoben. Für die Erhebung besteht Auskunftspflicht. Auskunftspflichtig sind alle Betriebe mit einer Strauchbeerenfläche von 0,5 ha und mehr im Freiland und/oder 0,1 ha unter hohen begehbaren Schutzabdeckungen einschließlich Gewächshäusern auskunftspflichtig. Auskunftspflichtig sind immer die Inhaberinnen und Inhaber bzw. Leiterinnen und Leiter der Erhebungseinheiten.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erhebung über Strauchbeeren**  
Metadaten 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/1f078ff4b6883766/62c05fe613d9/MD_41232_2023.pdf)[Archiv](https://download.statistik-berlin-brandenburg.de/7ca0001be55f58ea/3c50e6e7e55e/MD_41232_2021.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-i-4-j)
