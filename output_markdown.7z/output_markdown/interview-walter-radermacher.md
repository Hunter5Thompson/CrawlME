

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 10.01.2022

#### Fachgespräch mit Dr. Walter J. Radermacher

„Ich bin überzeugt, dass die amtliche Statistik heute mehr als jemals zuvor gebraucht wird.“
--------------------------------------------------------------------------------------------

![Foto Walter J. Radermacher](https://download.statistik-berlin-brandenburg.de/7c2d22e78dd2d19c/d31885f76032/v/1892e8cd31e9/Walter-Radermacher-Foto.jpg "Foto Walter J. Radermacher")

*Dr. Walter J. Radermacher ist seit über 40 Jahren für die amtliche Statistik tätig. Von 2006 bis 2008 war er Präsident des Statistischen Bundesamtes, bis zu seiner Pensionierung 2016 Generaldirektor des Europäischen Statistikamtes. Er forscht am Institut für Statistikwissenschaften der Sapienza-Universität Rom und ist Präsident der Föderation der europäischen nationalen Statistikgesellschaften (FENStatS).*

**Sie waren Präsident des Statistischen Bundesamtes und Generaldirektor des Europäischen Statistikamtes. Warum braucht es eine amtliche Statistik?**

Die amtliche Statistik steht seit dem frühen 19. Jahrhundert in einer engen Wechselbeziehung mit der Entwicklung von  Nationalstaaten. In allen historischen Epochen, den guten wie den schlechten, hat es eine charakteristische Form und Ausprägung der amtlichen Statistik gegeben; ohne Statistik wäre nationalstaatliche Politik nicht möglich gewesen. Die amtliche Statistik, wie wir sie heute kennen und praktizieren, hat sich in der Vergangenheit verändert und den Gegebenheiten  angepasst, und zwar über längere Strecken langsam und stetig, manchmal aber auch abrupt. Die treibenden Kräfte dafür  waren und sind neue Daten und Methoden, vor allem aber neue gesellschaftliche Fragen und  Krisen. Dies gilt im Übrigen auch  für internationale Politik: Europa wäre ohne Statistik nicht denkbar. Statistik war eines der ersten Gebiete, das in der  Montanunion der 1950er Jahre institutionell aufgebaut wurde (geleitet von Rolf Wagenführ).

**Was heißt das für uns, die heutige Generation amtlicher Statistiker?**

Wir sollten verstehen, dass wir in einer außergewöhnlichen Epoche leben, in der alle der genannten treibenden Kräfte dabei  sind, sich grundlegend zu verändern: neue Daten, neue Methoden, neue Krisen. Wir können selbstverständlich noch nicht wissen, wie sich die Dinge insgesamt weiter entwickeln werden. Was wir aber begreifen müssen, ist, dass ein so grundsätzlicher Wandel von Technologie, von Politik, von Einstellungen, von Herausforderungen usw. an der amtlichen Statistik nicht spurlos vorbeigehen wird. Vielmehr bedarf es unserer tiefgreifenden Reflexion bezüglich einiger der uns so vertrauten Abläufe,  Strukturen, Regeln, Zielsetzungen usw., will heißen der gesamten strategischen Ausrichtung der amtlichen Statistik.

Ich bin überzeugt, dass die amtliche Statistik heute mehr als jemals zuvor gebraucht wird. In der heutigen digitalen Dynamik  bieten sich große Chancen für die Statistik. Allerdings werden wir diese Chancen nur nutzen, wenn wir uns öffnen und dynamisch, flexibel positionieren, ohne aber dabei unsere ‚Marke‘ zu beschädigen. Das ist alles andere als eine leichte Aufgabe, aber: Nur wenn wir es schaffen, der Gesellschaft, den Bürgerinnen und Bürgern, der Politik und Wirtschaft ein  attraktives Angebot von relevanten Informationen für die Bewältigung der anstehenden Krisen, für Transformationsprozesse hin zur nachhaltigen Entwicklung zu machen, werden wir in ein paar Jahren zufrieden feststellen, dass es die amtliche Statistik nach wie vor braucht.

**In welcher Position sehen Sie die Statistischen Ämter der Länder im Vergleich zu anderen Statistikproduzenten?**

Ich habe in meiner Zeit als Chefstatistiker der Europäischen Union sehr unterschiedliche Organisationsformen der Statistik auf nationaler Ebene kennengelernt, von zentralen Modellen, wie in Frankreich oder den Niederlanden, bis zu dezentralen, wie in der Schweiz, dem Vereinigten Königreich oder eben Deutschland (nicht zu vergessen die USA). Deutschland kommt eigentlich dem Europäischen Statistischen System sehr nahe, weil es souveräne Institutionen gibt, die in einem Verbund  zusammenarbeiten, dessen Governance auf einem Gesetz beruht. Insofern frage ich mich, wie dieser Verbund von  Statistikproduzenten heute dasteht und vor allem, wie er sich insgesamt in einem informationellen Ökosystem (neu)  positionieren muss.

**Muss die amtliche Statistik in Deutschland gedacht werden? Welche Vorschläge haben Sie für eine zukunftsfähige amtliche Statistik?**

Hierbei gehen mir zwei Beziehungen durch den Kopf, die wir überdenken müssen. Erstens: Wie wird die Kooperation im  Verbund organisiert und (gesetzlich) geregelt? In Deutschland handeln wir nach den Vorgaben des [BStatG](https://www.gesetze-im-internet.de/bstatg_1987/) , in Europa nach denen der[EU-Verordnung 223](https://eur-lex.europa.eu/legal-content/DE/TXT/HTML/?uri=CELEX:32009R0223&from=DE) (wobei diese auch für Deutschland verbindlich ist). Das Bundesstatistikgesetz stammt aus den 1950er Jahren und definiert Statistik auf der Input-Seite (der Erhebung); die EU-Verordnung stammt aus dem Jahr 2009 und  definiert Statistik auf der Output-Seite (dem Ergebnis). Hierin liegt ein gravierender Unterschied für das Qualitätskonzept, für die Regeln der Zusammenarbeit und vieles andere mehr. Ich halte den Ansatz einer Inputregulierung für nicht mehr zeitgemäß und das Bundesstatistikgesetz deshalb für  grundlegend überarbeitungsbedürftig. Der statistische Verbund in Deutschland hat in den vergangenen zwei Jahrzehnten viele Erfolge in der Modernisierung von Prozessen erzielen können. Jetzt bedarf es aber einer Modernisierung des gesetzlichen Rahmens, damit eine Öffnung für die Verarbeitung neuer Datenquellen und die  Entwicklung neuer Produkte schnell genug erfolgen kann. Ansonsten sind wir im Wettbewerb mit anderen massiv benachteiligt und gehandicapt. Hierbei geht es im Übrigen nicht darum, die Gesetzmäßigkeit als Prinzip der amtlichen Statistik  aufzuweichen, ganz im Gegenteil. Die gesetzlichen Vorschriften sollten aber den Anforderungen der Gegenwart entsprechen.

Und Zweitens: Wie arbeitet der Verbund mit anderen Produzenten von Statistiken vor allem im öffentlichen Bereich  zusammen? Zur Beantwortung dieser Frage bedarf es der begrifflichen Einführung einer sogenannten ‚öffentlichen Statistik‘. Bürgerinnen und Bürgern müssen auf die Qualität aller Fakten vertrauen können, die im öffentlichen Sektor erstellt werden. Hierfür sieht die EU-Verordnung in Artikel 5 a neben der amtlichen Statistik ein koordiniertes System „anderer einzelstaatlicher Stellen“ vor, allerdings zurzeit nur für den Deckungsbereich der europäischen Statistik. Mein Ansatz geht jetzt dahin, dieses Konzept, das sich bewährt hat, auch auf andere Akteure (z. B. für Statistiken der Gesundheit oder Umwelt) auszudehnen, was bedeutet, dass die amtliche Statistik (Bund sowie Länder) zusätzliche Aufgaben übernimmt, die der Koordinierung und vor allem der Qualitätssicherung dienen.

**Mit der Corona-Pandemie wurde die Forderung nach verlässlichen und belastbaren, aber auch aktuellen Daten immer lauter. Wie kann der Statistische Verbund dem nachkommen?**

Es reicht heute und in Zukunft nicht  mehr aus, die besonders hohe Zuverlässigkeit amtlicher Statistiken zu betonen, wenn diese nicht helfen, die drängenden Fragen der Zeit zu beantworten. Corona liefert hierfür ein deutliches Warnsignal. Die amtliche Statistik hat enorme Stärken und ein wertvolles Kapital in ihren Erfahrungen, den international abgestimmten Standards, ihren Mitarbeiterinnen und Mitarbeitern und vielem anderen mehr. Mit diesen ‚Assets‘ sollten wir die Zukunft meistern können. Was wir aber zusätzlich brauchen, sind mutige Anpassungen unseres Geschäftsmodells mit neuen Produkten und Dienstleistungen, neue Allianzen und Partner und die Überzeugungskraft, die aus einer positiven Vision für die Zukunft erwächst. Während wir bereits viel erreicht haben in der Prozessoptimierung, fehlt uns bislang eine vorausschauende Planung für das Produktportfolio der Zukunft. Solange wir nicht mit entsprechenden Entwicklungsarbeiten frühzeitig beginnen, werden wir wiederholt unvorbereitet sein und anderen das Feld überlassen müssen.

**Welche Rolle schreiben Sie den Forschungsdatenzentren des Bundes und der Länder auf diesem Weg zu? Was könnte hier noch verbessert werden?**

Die Forschungsdatenzentren sind zweifellos eine der Innovationen in der amtlichen Statistik, von denen wir erheblich mehr benötigen. Mit viel Energie und Kreativität wurden hier neue Wege beschritten und neue Netzwerke geknüpft, die bis dato geschlossene Türen für die Forschung geöffnet haben. Allerdings sehe ich noch weiteren Bedarf, dieses Thema weiter voranzutreiben, einmal was die Nutzung neuer (sicherer) Technologien bezüglich des Datenzugangs angeht, die das Leben der Forschenden erleichtern, zum anderen aber auch die Einbeziehung neuer Themengebiete, die über den bisherigen Schwerpunkt im Bereich Soziales und Wirtschaft hinausgehen. Schließlich frage ich mich, wie all dies mit neuen Datenquellen (Remote Sensing, Citizen Science, … ) weitergehen wird.

**Der Klimawandel ist die nächste zu stemmende Herausforderung. Wie kann es den Statistischen Ämtern des Bundes und der Länder gelingen, einen aktiven Beitrag zur Umsetzung des European Green Deal zu leisten?**

Neben dem Klimawandel gibt es noch viele andere Herausforderungen, wenn man sich die Nachhaltigkeitsstrategie der UN anschaut. Diesen ist allen gemeinsam, dass sie nach statistischen Antworten verlangen, welche die gesamte Breite des  Arbeitsprogramms (von Wirtschaft bis Umwelt) und alle Produktarten von Statistik (Basisstatistiken, Gesamtrechnungen, Indikatoren) gleichzeitig umfassen. Hierauf müssen wir uns jetzt einstellen, indem wir unsere Produkte und Prozesse überdenken und anpassen. [Trusted Smart Statistics](https://content.iospress.com/ articles/statistical-journal- of-the-iaos/sji190584) ist meiner Meinung nach ein Leitmotiv, das uns hierbei Orientierung geben kann.

**Für all diejenigen, die mehr lesen wollen, hier ein paar Hinweise:**

* [Radermacher, Dr. W. J. (2020): Wie Statistiken helfen können – über Covid-19 hinaus. In: Statistisches Bundesamt (Hrsg.): WISTA – Wirtschaft und Statistik 4/2020.](https://www.destatis.de/DE/Methoden/WISTA-Wirtschaft-und-Statistik/2020/04/wie-statistiken-helfen-042020.pdf?__blob=publicationFile)
* [Radermacher, Dr. W. J. (2021): Amtliche Statistik als Sprache für den öffentlichen Diskurs. makronom.de, 1. März 2021.](https://makronom.de/amtliche-statistik-als-sprache-fuer-den-oeffentlichen-diskurs-38542)
* [Radermacher, Dr. W. J. (2020): Official Statistics 4.0 –Verified Facts for People in the 21st Century. Springer.](https://link.springer.com/book/10.1007%252F978-3-030-31492-7)

Das Fachgespräch erschien erstmals in der *Zeitschrift für amtliche Statistik
Berlin Brandenburg*. Die komplette Ausgabe 3+4/2021 lesen Sie [hier](https://download.statistik-berlin-brandenburg.de/0e2a6bd7d6fd44ce/b43aa17fd047/Zeitschrift-20210304.pdf).

### Kontakte

#### Nicole Dombrowski

Fachredaktion

#### Nicole Dombrowski

Fachredaktion

* [zeitschrift@statistik-bbb.de](mailto:zeitschrift@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Fachgespräch](/search-results?q=tag%3AFachgespräch)[* Corona](/search-results?q=tag%3ACorona)[* Official Statistics](/search-results?q=tag%3AOfficial Statistics)[* Amtliche Statistik](/search-results?q=tag%3AAmtliche Statistik)[* Interview](/search-results?q=tag%3AInterview)
