

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
* [Hochschulen](/hochschulen)
* [Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, Teil 1: Übersicht](/b-iii-2-j)

Studierende an Hochschulen – Übersicht
--------------------------------------

#### Wintersemester 2023/24

###### Die Erhebung über die Studierenden ist ein Teil der bundeseinheitlichen Hochschulstatistik und bildet den aktuellen Studierendenbestand ab.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/fce35c89fa0a49d7/94fdc49a2c3f/SB_B03-02-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/4afdb2bdfbd2ac7b/b81c0dc94034/SB_B03-02-00_2023j01_BE.pdf)

**Mehr Studierende**

Im Wintersemester 2023/24 waren 200.440 Studierende an den Hochschulen in Berlin eingeschrieben. Das waren 847 Studierende mehr als im letzten Wintersemester. Die Frauenquote betrug 52 %.

Insgesamt waren 48.362 Studierende mit nichtdeutscher Staatsangehörigkeit immatrikuliert. Das sind erneut mehr als im letzten Wintersemester (+1.143). Damit erhöhte sich der Anteil der ausländischen Studierenden von 23,7 % auf 24,1 %.

### Kontakt

#### Eike Müller

Hochschulen

#### Eike Müller

Hochschulen

* [0331 8173-1144](tel:0331 8173-1144)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Anstieg der Studierendenzahl in Brandenburg**

Im Wintersemester 2023/24 waren 51.468 Studierende an den Hochschulen Brandenburgs eingeschrieben. Das waren 1.041 Studierende mehr als im letzten Wintersemester. Die Frauenquote betrug unverändert 51 %.  
An den brandenburgischen Hochschulen sind 12.040 ausländische Studierende immatrikuliert. Das sind erneut mehr als im letzten Wintersemester (+1.199). Damit erhöhte sich der Anteil der ausländischen Studierenden von 21,5 auf 23,4 %.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/f109de4c13ab7b35/171f91cf6aa4/SB_B03-02-00_2023j01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/75bae744c192e443/ad6ca7a350a7/SB_B03-02-00_2023j01_BB.pdf)
### Kontakt

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

#### Anja Behnisch

Hochschulen, Ausbildungsförderung

* [0331 8173-1148](tel:0331 8173-1148)
* [hochschulen@statistik-bbb.de](mailto:hochschulen@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden und Gasthörern erhoben; Studierende zu Beginn des Semesters, Gasthörer im Wintersemester.

Auskunftspflichtig sind die Hochschulverwaltungen. In die Erhebung einbezogen sind alle staatlichen und staatlich anerkannten Hochschulen. Die Statistiken werden auf der Basis der Verwaltungs­unterlagen der Auskunftspflichtigen als Totalerhebungen durchgeführt. Die Ergebnisse der Hochschulstatistiken bilden die Datenbasis für Entscheidungen im Bund, in den Ländern und in den Hochschulen selbst. Aber auch die verschiedensten öffentlichen und privaten Einrichtungen sind an den Ergebnissen stark interessiert, unter anderem die Hochschul­rektorenkonferenz, die Ständige Konferenz der Kultusminister und der Wissenschaftsrat.

Auch wenn es sich bei den Hochschulstatistiken um Bundesstatistiken handelt, so werden die Ergebnisse doch zunehmend durch Länderspezifika und Besonderheiten der Hoch­schulen beeinflusst. Zuordnungen können in den einzelnen Bundesländern voneinander abweichen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Statistik der Studenten**  
ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/2b5d23d0611028d9/865dceac877e/MD_21311_2019.pdf)[Archiv](/search-results?q=21311&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/b-iii-2-j)
