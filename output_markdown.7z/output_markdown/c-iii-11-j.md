

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Erzeugung in Aquakulturbetrieben in Brandenburg](/c-iii-11-j)

Erzeugung in Aquakulturbetriebenin Brandenburg
----------------------------------------------

#### 2023, jährlich

###### Die Erhebung erfasst die in Aquakultur erzeugten Mengen an Fisch, Laich und Jungtieren. Anhand der Ergebnisse können Aussagen zur Bedeutung der Aquakultur getroffen und Prognosen zur Entwicklung in diesem Bereich erstellt werden.

BrandenburgMethodik
### Brandenburg

**Fischproduktion rückläufig: Rund 740.000 Kilogramm Fisch erzeugt**

Im Jahr 2023 wurden in den 33 Brandenburger Betrieben mit Aquakultur gut 740.000 Kilogramm Fisch erzeugt. Das  waren 70.000 Kilogramm oder 8,6 % weniger als im Jahr 2022.

Mit gut 480.000 Kilogramm entfielen auf den Karpfen 65,0 % der Fischproduktion. Trotz eines Rückganges zum Vorjahr um fast 28.000 Kilogramm bzw. um 5,4 %, ist der Anteil des Karpfen an der gesamten Fischproduktion in Aquakultur leicht gestiegen (Vorjahr 62,8 %). Die größten Karpfenproduzenten in Deutschland sind Bayern und Sachsen.

Während die Regenbogenforelle die bedeutendste Fischart in der deutschen Aquakultur darstellt, lag sie 2023 in Brandenburg mit knapp 148.000 Kilogramm auf dem 2. Platz. Ihr Anteil an der erzeugten Fischmenge insgesamt lag bei 19,9 %. Gegenüber dem Vorjahr entspricht dies einem Rückgang um 20.000 Kilogramm bzw. um 11,9 %. Lachsforelle und Bachsaibling folgten von der erzeugten Menge her auf den Plätzen 3 und 4. So wurden gut 42.000 Kilogramm Lachsforelle und 33.000 Kilogramm Bachsaibling erzeugt. Gegenüber dem Vorjahr waren dies 10.000 (–19,3 %) bzw. 9.000 Kilogramm (–21,4 %) weniger.

In der Teichwirtschaft erzeugten 22 Brandenburger Aquakulturbetriebe knapp 500.000 Kilogramm Fisch. Weitere gut 240.000 Kilogramm wurden in Kreislaufanlagen bzw. in Becken/Fließkanälen oder Forellenteichen erzeugt.

Insgesamt wurden in Brandenburg knapp 3.000 Hektar Teichfläche bewirtschaftet. Größere Teichflächen gab es in Bayern mit fast 6.800 Hektar und in Sachsen mit 7.700 Hektar.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/0b0241bd323e828c/51e54b7e6555/SB_C03-11-00_2023j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/12ff89b2daefda51/894c312c60d0/SB_C03-11-00_2023j01_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erhebung über die Erzeugung in Aquakulturbetrieben ist eine dezentrale Bundesstatistik. Sie wird seit 2012 jährlich durchgeführt. Seit dem Berichtsjahr 2015 wird sie als Totalerhebung mit Abschneidegrenzen durchgeführt. Dabei werden Daten zur erzeugten Menge insgesamt, zur Erzeugung in Brut- und Aufzuchtanlagen sowie zur zugeführten Menge jährlich erhoben. Alle drei Jahre, beginnend 2012, werden zusätzlich Daten zur Struktur der Betriebe und zu deren Vermarktungswegen erhoben.

Zur Grundgesamtheit zählen alle Betriebe mit Erzeugung von Aquakultur im Sinne von Artikel 2 Absatz 1 Buchstabe b der Verordnung (EG) Nr. 762/2008. Soweit Betriebe nach der Fischseuchenverordnung erfasst sind, werden diese Betriebe in die Erhebung einbezogen.

Seit dem Berichtsjahr 2015 zählen alle Aquakulturbetriebe mit mindestens 0,3 Hektar Gesamtgewässerfläche der Teiche oder 200 Kubikmeter Gesamtanlagenvolumen der Forellenteiche, Becken und Fließkanäle oder einer anderen Aquakulturanlage zur Grundgesamtheit.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erhebung über die Erzeugung in Aquakulturbetrieben**  
Metadaten ab 2021

[Download PDF](https://download.statistik-berlin-brandenburg.de/f68011523d53a111/a23719d7c14f/MD_41362_2021.pdf)[Archiv](/search-results?q=MD_41362&pageNumber=1&searchMethodik=true&sortBy=date-desc&searchPdf=false&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-11-j)
