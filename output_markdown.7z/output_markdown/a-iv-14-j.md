

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Gesundheit](/gesundheit)
* [Familienplanung](/familienplanung)
* [Schwangerschaftskonflikt-, Schwangerschaftsberatung, Familienplanung und Sexualberatung in Brandenburg](/a-iv-14-j)

Schwangerschaftskonflikt-, Schwangerschaftsberatung, Familienplanung und Sexualberatung in Brandenburg
------------------------------------------------------------------------------------------------------

#### 2021, jährlich

###### Die Statistik zu Schwangerschaftskonflikten und Schwangerschaften, zur Familienplanung und Sexualberatung stellt Informationen zur Anzahl der Ratsuchenden, ihrem Alter und der Geschlechtsverteilung, zu sozialen Aspekten und dem Beratungsgrund zur Verfügung.

BrandenburgMethodik
### Brandenburg

**Beratungsstellen werden immer seltener aufgesucht**

Im Vergleich zum Vorjahr wurden erneut weniger Ratsuchende in Beratungsstellen der Schwangerschaftskonfliktberatung, Schwangerschaftsberatung, für Familienplanung und Sexualberatung in Brandenburg gezählt.

Insgesamt wurden 4.913 Ratsuchende zum Thema Schwangerschaftskonflikt beraten, das waren 1,2 % (60) weniger als im Jahr zuvor. Im Bereich Schwangerschaftsberatung war die Zahl der Ratsuchenden mit einem deutlichen Rückgang von 11,3 % geringer als im Vorjahr (874). Zu Fragen zum Thema Familienplanung und sozialrechtliche Beratung ließen sich 4.193 Ratsuchende beraten, das waren 0,1 % oder sechs Ratsuchende weniger als im Jahr zuvor. Die Zahl der Ratsuchenden zum Thema Sexualberatung und Sexualpädagogik ist mit 755 im Vorjahresvergleich um 5,7 % oder 46 Ratsuchende zurückgegangen.

#### **Zum aktuellen Statistischen Bericht – 2021**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/faad9b04a00a4a90/b407b6de5299/SB_A04-14-00_2021j01_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/6a292ab912d34304/bf4f1f470230/SB_A04-14-00_2021j01_BB.pdf)
### Kontakt

#### Katja Obst

Gesundheit

#### Katja Obst

Gesundheit

* [0331 8173-1152](tel:0331 8173-1152)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Babett Wulfert

Gesundheit

#### Babett Wulfert

Gesundheit

* [0331 8173-1126](tel: 0331 8173-1126)
* [gesundheit@statistik-bbb.de](mailto:gesundheit@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Statistik zur Schwangerschaftskonflikt-, Schwangerschaftsberatung, Familienplanung und Sexualberatung wird in Brandenburg als Geschäftsstatistik vierteljährlich bei den Trägern der vom Land geförderten anerkannten Beratungsstellen durchgeführt. Auftraggeber ist das Ministerium für Soziales, Gesundheit, Integration und Verbraucherschutz des Landes Brandenburg. Berichtspflicht besteht für alle vom Land geförderten anerkannten Beratungsstellen.

Mit der trägerübergreifenden Erfassung stehen in Brandenburg Informationen zur Anzahl der Ratsuchenden, ihrem Alter und der Geschlechtsverteilung, zu sozialen Aspekten und dem Beratungsgrund zur Verfügung. Diese Daten bilden eine Grundlage für planungsrelevante Entscheidungen auf Landesebene und dienen dem Überblick über die Beratungsarbeit der anerkannten Beratungsstellen.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Schwangerschaftskonfliktberatung in Brandenburg**  
ab 2019

[Download PDF](https://download.statistik-berlin-brandenburg.de/2f68b94aa6b4cbd0/803666d85923/MD_29321_2019.pdf)[Archiv](#)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-iv-14-j)
