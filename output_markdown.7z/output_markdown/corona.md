

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Schwerpunkte](/schwerpunkte)
* [Corona](/corona)
![](https://download.statistik-berlin-brandenburg.de/3a9a866568acf6f6/a2064502003c/v/9863b4451c5c/schmuckbild-corona-oben.png)

**Letzte Aktualisierung: 02.06.2022 (Aktualisierung eingestellt.)**

#### Schwerpunkt

Corona
======

**Für eine Einschätzung der wirtschaftlichen und sozialen Lage in Folge der  Ausbreitung des SARS-CoV-2-Virus und der dadurch verursachten Erkrankung COVID-19 seit Frühjahr 2020 sind verlässliche Zahlen unabdingbar.**   
  
Das Amt für Statistik Berlin-Brandenburg stellte 2020 für ein Dossier statistische Daten für die drei Themenbereiche Gesundheit, Gesellschaft und Wirtschaft zusammen, die sich an konkreten Fragestellungen zur Corona-Situation orientieren und hier laufend aktualisiert werden.   


BerlinBrandenburg

**Neuinfektionen und Todesfälle in Berlin**Stand: 02.06.2022, Quelle: Robert Koch-Institut

**Quelle:** Robert Koch-Institut, dl-de/by-2-0![Platzhalterbild](/assets/blindbild.abc32a225a4b567916b847eb1a3ef894.png)**Artikel**[#### Sterben die Menschen in Berlin und Brandenburg mit oder an Corona?](https://download.statistik-berlin-brandenburg.de/734c9e1d65e49bf9/ad17407e50cf/hz_202002-01.pdf)

10 Gesundheitswesen ⌜ Sterben die Menschen in Berlin und Brandenburg mit oder an Corona? von Katrin Möbius In Zeiten der COVID- - Pandemie werden unterschiedliche, teilweise kreative Theorien zu...

![Platzhalterbild](/assets/blindbild.abc32a225a4b567916b847eb1a3ef894.png)**Artikel**[#### Sterbefallzahlen schätzen für Berlin – Ein Werkstattbericht](https://download.statistik-berlin-brandenburg.de/f313b079b4178f89/adb1d6c85b5f/hz_202101-04.pdf)

22 Bevölkerung ⌜ Sterbefallzahlen schätzen für Berlin  ein Werkstattbericht von Kerstin Erfurth und Jörg Höhne Einführung Aktuelle Meldungen zu Sterbefallzahlen interessieren uns  gerade jetzt in...

![Platzhalterbild](/assets/blindbild.abc32a225a4b567916b847eb1a3ef894.png)**Artikel**[#### Corona-Übersterblichkeit in Berlin und Brandenburg. Ein Rückblick auf 2020](https://download.statistik-berlin-brandenburg.de/184c848f7a42b679/074720272cd9/hz_202101-05.pdf)

30 Bevölkerung ⌜ Corona- Übersterblichkeit in Berlin und Brandenburg: Ein Rückblick auf  von Holger Leerhoff Zum Jahresende   mit dem Ansteigen der zweiten Infektionswelle  mehrten sich die...

Zeitschrift für amtliche Statistik Berlin Brandenburg
-----------------------------------------------------

Schwerpunkt: Auswirkungen der Corona-Pandemie in der Region statistisch betrachtet

[Mehr erfahren](/news/12-2021-zeitschrift)GesundheitGesellschaftWirtschaftLinkempfehlungen![](https://download.statistik-berlin-brandenburg.de/078f59dee3cd9211/267966345dce/v/53ad06134053/schmuckbild-corona-gesundheit.png)

Gesundheit
==========

### Vorläufige Ergebnisse zu Todesursachen

**Erstmals werden vorläufige Ergebnisse der Todesursachenstatistik ab dem Berichtszeitraum Januar 2020 veröffentlicht. Damit reagiert die Statistik auf den wachsenden Bedarf an aktuellen Zahlen in der Corona-Pandemie.**

Ermöglicht wird dies durch die Auswertung vorläufiger Daten der Todesursachenstatistik zu ausgewählten Merkmalen, die die wichtigsten Diagnosegruppen und Einzeldiagnosen abbilden. Ein Fokus liegt dabei auf allen Sterbefällen im Zusammenhang mit COVID-19. Somit enthalten die Monatsberichte sowohl Sterbefälle, in denen COVID-19 die eigentliche Todesursache ist („an“ COVID-19 Verstorbene) als auch nachrichtlich jene Sterbefälle, bei denen COVID-19 eine Begleiterkrankung war („mit“ COVID-19 Verstorbene).

[**Hier**](/fachbeitrag/covid-19-sterbefaelle-todesursache)**lesen Sie mehr.**

  


###### Methodische Anmerkungen zur monatlichen Todesursachenstatistik

Die **monatlichen Berichte in der Todesursachenstatistik** stellen vorläufige Daten dar, die für ausgewählte Merkmale aufbereitet und veröffentlicht werden. Die Daten bilden den jeweiligen Bearbeitungsstand zum monatlichen Stichtag ab und können sich durch Nachmeldungen oder Korrekturen noch verändern. Die Monatsberichte der Todesursachenstatistik stellen fortlaufend revidierte und vervollständigte Ergebnisse dar, das heißt die Qualität der Berichte erhöht sich mit zunehmendem Vollständigkeitsgrad. Dennoch handelt es sich grundsätzlich weiterhin um vorläufige Daten. Endgültige Daten werden nach wie vor nur als Jahresergebnis veröffentlicht. Zeitlich verzögerte Nachmeldungen, der späte Versand von Todesbescheinigungen oder Korrekturen beispielsweise des Wohnortes oder des Geschlechts können erst mit der Zeit – also mit späteren Veröffentlichungen – integriert und korrigiert werden.

**Unterschiede zwischen Ergebnissen der Todesursachenstatistik und der Meldungen nach Infektionsschutzgesetz**

COVID-19-Sterbefälle werden auf zwei Meldewegen erfasst: Zum einen über die amtliche Todesursachenstatistik, zum anderen über die Meldepflichten nach dem Infektionsschutzgesetz (IfSG). Das Robert Koch-Institut (RKI) und die Landesgesundheitsbehörden veröffentlichen COVID-19-Sterbefallzahlen nach dem IfSG.

Die Unterschiede in den beiden Dokumentationsformen führen dazu, dass die Fallzahlen der COVID-19-Sterbefälle in beiden Statistiken nicht identisch sind.

Erstens differiert die Datenbasis in beiden Statistiken. In die Todesursachenstatistik gehen alle COVID-19-Fälle ein, die auf der Todesbescheinigung einen entsprechenden Eintrag haben. Die Todesursachenstatistik unterscheidet nach nachgewiesenen (U07.1) und Verdachtsfällen (U07.2) sowie nach Grundleiden und Begleiterkrankung. In die unikausale Jahresstatistik der Todesursachenstatistik gehen nur die Fälle mit Grundleiden ein, während in den Monatsberichten der Todesursachenstatistik auch jene Sterbefälle nachrichtlich ausgewiesen werden, bei denen COVID-19 als Begleiterkrankung auftrat.

Gesundheitsämter melden an die zuständige Landesbehörde und das RKI
COVID-19-Todesfälle gemäß §6 Absatz 1 des IfSG. Vom RKI werden nur
diejenigen COVID-19-Todesfälle publiziert, bei denen ein
laborbestätigter Nachweis von SARS-CoV-2 vorliegt und die in Bezug auf
diese Infektion verstorben sind. Die Zahl der COVID-19-Sterbefälle wäre
theoretisch dann deckungsgleich mit der Sterbefallzahl des RKI, wenn
jedem U07.1-Sterbefall der Todesursachenstatistik ein positiver
Labortest zu Grunde liegen würde. Da die Todesursachenstatistik auf den
Angaben der Ärztin/des Arztes beruht, werden all jene Fälle zu
„nachgewiesenen“ Fällen, bei denen durch die Ärztin/ den Arzt eine
COVID-19-Erkrankung auf der Todesbescheinigung vermerkt wurde. Ob diese
Gewissheit auf Grundlage eines positiven PCR-Tests besteht, ist aus der
Todesbescheinigung nicht immer ersichtlich.

Zweitens ist in der Todesursachenstatistik die Unterscheidung zwischen den an und den mit COVID-19 Verstorbenen wesentlich. In der Todesursachenstatistik wird das Grundleiden (verstorben an) anhand aller Angaben auf der Todesbescheinigung auf Basis des Regelwerks der WHO bestimmt. Jedoch kann es insbesondere bei fehlerhaften oder unvollständigen Todesbescheinigungen schwierig sein, beide Gruppen verlässlich voneinander abzugrenzen. Bei den Statistiken nach dem IfSG findet eine solche Unterscheidung nicht immer statt.

Drittens können die Datenstände zu einem jeweiligen Stichtag in den beiden Dokumentationen unterschiedlich weit aufgearbeitet sein.

Viertens sollte bei einem Vergleich der Zahlen beachtet werden, ob die Ergebnisse nach Sterbedatum, Berichtsdatum (Todesursachenstatistik) oder Meldedatum (IfSG) ausgewiesen werden.

Aufgrund
dieser Dokumentationsunterschiede kann es zwischen den beiden Statistiken somit
verfahrenstechnisch bedingt zu Diskrepanzen bezüglich der COVID-19-Sterbefälle
kommen. Ein Vergleich dieser beiden Statistiken sollte daher immer vor dem
Hintergrund dieser differierenden Datengrundlagen und Meldewege erfolgen.
### Daten zur Übersterblichkeit

**Das Amt für Statistik Berlin-Brandenburg führt mit Fokus auf eine Corona-bedingte Übersterblichkeit seit Herbst 2020 laufende Sonderauswertungen der Sterbefallzahlen durch, deren Ergebnisse auf dieser Seite präsentiert werden. Eine Aktualisierung erfolgt wöchentlich.**

Im Folgenden sehen Sie die Sterbefälle 2020/2021 im Vergleich zum Mittel der Sterbefälle in den Jahren 2016–2019. Ebenfalls in den Diagrammen enthalten sind die vom Robert Koch-Institut gemeldeten Corona-Sterbefälle.

Datenstand: 31.08.2021

Mit dem starken Rückgang der Corona-Todesfälle seit
Beginn des Sommers 2021 wird das Übersterblichkeitsmonitoring des Amtes für Statistik Berlin-Brandenburg bis
auf Weiteres eingestellt.

#### Übersterblichkeit Berlin

Sterbefälle 2020/2021 vs. Sterbefälle 2016–2019![](https://download.statistik-berlin-brandenburg.de/d29b6e971a542e3a/58c558925f1c/v/0c0379bf1e97/uebersterblichkeit-berlin.png)[Download](https://download.statistik-berlin-brandenburg.de/95f6cc792f7e0485/7cb846ff30b5/corona-uebersterblichkeit-berlin.pdf)
#### Übersterblichkeit Brandenburg

Sterbefälle 2020/2021 vs. Sterbefälle 2016–2019![](https://download.statistik-berlin-brandenburg.de/2c583701d3275bbf/59ec8ab605b2/v/d109f1b8cba7/uebersterblichkeit-brandenburg.png)[Download](https://download.statistik-berlin-brandenburg.de/51351b5cf83e76f4/8b9d35ffd68d/corona-uebersterblichkeit-brandenburg.pdf)

In **Brandenburg** lag 2020 bereits während der ersten Corona-Welle um die 15. Kalenderwoche (KW) und dann verstärkt ab der 46. KW in der zweiten Welle die Anzahl der gemeldeten Sterbefälle deutlich über der der Vorjahre. In **Berlin** konnte dieser Effekt erst in der zweiten Welle ab der 46. KW beobachtet werden.

Es muss klar festgehalten werden, dass es in Brandenburg und Berlin in
den Wochen um den Jahreswechsel 2020/2021 eine markante
Übersterblichkeit gegeben hat, die sich mindestens bis in den Februar
2021 hineinzog. Dabei ist ein grober Zusammenhang des Umfangs der
Übersterblichkeit mit den durch das Robert Koch-Institut gemeldeten, mit
Corona-Infektionen in Zusammengang stehenden Todesfällen gut zu
erkennen.
###### Methodische Anmerkungen zur Übersterblichkeit

**Übersterblichkeit** liegt dann vor, wenn die Anzahl der Sterbefälle eine bestimmte Schwelle, die sogenannte Basismortalität, überschreitet. Zur Bestimmung der Basismortalität wird hier auf die endgültigen Sterbefallzahlen 2016 bis 2019 als Referenzzeitraum zurückgegriffen. Die Abbildungen verdeutlichen, dass es zwischen den einzelnen Jahren neben den saisonalen Mustern erhebliche Schwankungen der wöchentlich registrierten Sterbefallzahlen gibt. Die blauen Flächen stellen die Bandbreite der wöchentlichen Sterbefälle der Jahre 2016 bis 2019 dar; die Schwankungen zwischen den Jahren werden durch die Heranziehung des Mittelwerts der Vorjahre (blaue Linien) für die Basismortalität aufgefangen.

Während die historischen Sterbefallzahlen der Jahre 2016 bis 2019, die zur Berechnung der Basismortalität heranzogen wurden, bereits den vollständigen Qualitätssicherungsprozess der amtlichen Statistik durchlaufen haben und damit als endgültig betrachtet werden können, ist dies bei den Sterbefallzahlen der Jahre 2020 und 2021 noch nicht der Fall. Bei ihnen handelt es sich bislang um reine Fallauszählungen aus den Standesämtern, bei denen es aus unterschiedlichen Gründen noch zu Änderungen kommen kann. Die Stabilität dieser Zahlen stellt sich in aller Regel erst nach mehreren Wochen ein, weshalb die Zahlen zum aktuellen Rand hin unsicherer sind als solche, die Monate zurückliegen. Auch kann am aktuellen Rand eine oft markante Unterzeichnung der Sterbefälle vorliegen.

Eine Analyse der Meldungen des Jahres 2020 in Berlin und Brandenburg hat ergeben, dass in Brandenburg nach 15 Tagen 95 % der Sterbefälle registriert waren, während diese Schwelle in Berlin erst nach 47 Tagen erreicht wurde. Das heißt, dass zu einem gegebenen Zeitpunkt für Brandenburg sehr zuverlässige Aussagen über das Sterbegeschehen vor rund zwei Wochen möglich sind, ein vergleichbares Niveau für Berlin jedoch erst einen Monat später vorliegt. Für die laufende Berichterstattung nahe dem aktuellen Rand kommt aus diesem Grund für Berlin ein Nowcasting-Verfahren zum Einsatz, das Werte auf Grundlage des bisherigen Meldeverhaltens der Standesämter prognostiziert.

Die Ergebnisse der Übersterblichkeitsanalyse lassen sich mit einer zweiten Quelle abgleichen: Seit Februar 2020 liefern die Gesundheitsämter der Bundesrepublik regelmäßig die Daten zu den Corona-Infektionen und -Sterbefällen an das Robert Koch-Institut (RKI). Die so gemeldeten Sterbefälle ermöglichen eine wertvolle und zeitnah vorliegende Abschätzung der Größenordnung des mit Corona-Infektionen einhergehenden Sterbegeschehens. In den Abbildungen sind diese Sterbefälle unten als rote Säulen abgetragen. Fallzahlen kleiner als 4 werden hier nicht ausgewiesen.

Weiterführende Analysen und Methodenbeschreibungen:

[Holger Leerhoff: Corona-Übersterblichkeit in Berlin und Brandenburg: Ein Rückblick auf 2020](https://download.statistik-berlin-brandenburg.de/184c848f7a42b679/074720272cd9/hz_202101-05.pdf) [Kerstin Erfurth: Sterbefallzahlen schätzen für Berlin – ein Werkstattbericht](https://download.statistik-berlin-brandenburg.de/f313b079b4178f89/adb1d6c85b5f/hz_202101-04.pdf)

### Die Lage in denKrankenhäusern

**Die Deutsche Interdisziplinäre Vereinigung für Intensiv- und Notfallmedizin (DIVI) stellt täglich neue Zahlen zu Behandlungskapazitäten in der Intensivmedizin zur Verfügung – zum Beispiel die Anzahl freier und belegter Intensivbetten.** 

Diese Daten werden von den zugelassenen Krankenhausstandorten in regelmäßigen Abständen an das Intensivregister gemeldet. Durch zeitliche Verzögerungen bei den einzelnen Meldungen kann es zu Ungenauigkeiten in den Daten kommen, die das DIVI durch eine Betrachtung der Meldungen aus den letzten sieben Tagen ausgleicht. Die Daten der Zeitreihe können somit von den tagesaktuellen Daten abweichen. Auch die Einführung von Notfallreserven im August 2020 sowie die Veränderung des Schlüssels von Pflegekräften zu Patientinnen und Patienten im Februar 2021 haben Einfluss auf die Anzahl freier Intensivbetten.

**Quelle:** Daten: DIVI-Intensivregister (www.intensivregister.de), Stand: 16.05.2022; Aufbereitung: Amt für Statistik Berlin-Brandenburg![](https://download.statistik-berlin-brandenburg.de/e6ebf1d3df78e323/4ea3ca216bbd/v/c3ca1262013a/schmuckbild-corona-gesellschaft.png)

Gesellschaft
============

### Der Einfluss auf den Liniennahverkehr

Aufgrund der verschärften Maßnahmen zur Bekämpfung und Eindämmung von Covid-19 kam es ab dem 1. Quartal 2020 zu teils drastischen Rückgängen bei der Personenbeförderung mit Bussen und Bahnen im Liniennahverkehr in Berlin und Brandenburg. So ging die Zahl der Fahrgäste im Liniennahverkehr im 2. Quartal 2020 gegenüber dem vergleichbaren Vorjahreszeitraum in Berlin um 53,3 % zurück. In absoluten Zahlen ausgedrückt war das ein Rückgang um 214 Mill. Personen auf ein Quartals-Rekordtief der letzten zehn Jahre von nur noch 188 Mill. Vom Vor-Corona-Niveau ist Berlin aktuell noch weit entfernt. In Brandenburg  fiel  die  Abnahme der Fahrgastzahlen 2020 gegenüber dem Vor-Corona-Jahr 2019 weniger deutlich aus als in Berlin. Im 2. Quartal 2020 betrug der Rückgang im Vorjahresvergleich insgesamt 21,2 %. Das entspricht einem Rückgang um 6,6 Mill. auf 24,4 Mill. Personen. Seit dem 1. Quartal 2021 ist in Brandenburg ein Anstieg der Fahrgastzahlen gegenüber 2020 und 2019 zu verzeichnen.

**Quelle:** Amt für Statistik Berlin Brandenburg
### Verkehrsunfälle nach Kalender­woche

Während des ersten Lockdowns (März bis Mai 2020) ist die Zahl der Straßenverkehrsunfälle deutlich zurückgegangen. In beiden Ländern betrug der Rückgang der Unfälle im April 2020 im Vergleich zum Vorjahresmonat rund 35 %. Im anschließenden Sommer näherten sich die Werte wieder dem Vor-Corona-Niveau. Die beginnende „zweite Welle“ und der zweite Lockdown (November 2020 bis März 2021) führten wieder zu einem Abflachen des Verkehrsunfallgeschehens, das ähnliche Werte erreichte wie im ersten Lockdown. 2021 näherten sich die Unfallzahlen in den Sommermonaten wieder dem Vor-Corona-Niveau. Die Verläufe der Unfallzahlen Berlins und Brandenburgs ähneln sich dabei sehr. Insgesamt sind die Rückgänge in Brandenburg über den gesamten Zeitraum betrachtet etwas schwächer ausgeprägt als in Berlin.

**Quelle:** Amt für Statistik Berlin-Brandenburg
### Auswirkungen auf die Mobilität

Von der Firma Apple bereitgestellte Daten ihres
Kartendienstes zeigen das relative Anfragevolumen für Wegbeschreibungen in Berlin und
Brandenburg im Vergleich zu einem Basisvolumen am 13. Januar 2020. Zu erkennen ist ein
deutlicher Rückgang der Routenanfragen Anfang
März, bereits vor der offiziellen Schließung der
Lokale und Kultureinrichtungen. Besonders stark
betroffen waren dabei die Anfragen für den
öffentlichen Nahverkehr. Die Zunahme des
relativen Anfragevolumens im Sommer
gegenüber dem 13. Januar entspricht der
normalen saisonalen Nutzung von Apple Maps.
Die Linienunterbrechungen resultieren aus
Datenlücken am 11. und 12. Mai 2020.

**Quelle:** Quelle: http://www.apple.com/covid19/mobilit, Stand: 20.01.2022; Aufbereitung: Amt für Statistik Berlin-Brandenburg ![](https://download.statistik-berlin-brandenburg.de/06f73fe4c14a69b9/03adc45027a4/v/b19e4caceec7/schmuckbild-corona-wirtschaft.png)

Wirtschaft
==========

### Bruttoinlands­produkt

Im Vergleich zur Finanz- und Wirtschaftskrise 2008/2009 traf die Corona-Pandemie Berlins Wirtschaft härter. 2009 war die Wirtschaftsleistung um 1,1 % zurückgegangen. 2020 war das  preisbereinigte Bruttoinlandsprodukt 3,3 % niedriger als im Vorjahr.

Das Bruttoinlandsprodukt in Brandenburg sank 2020 nach ersten Berechnungen preisbereinigt um 3,2 % gegenüber 2019. Damit verzeichnete Brandenburgs Wirtschaft den geringsten Rückgang aller Bundesländer.

Deutliche Spuren hinterließen die Einschränkungen in den Dienstleistungsbereichen: Hier zeigte sich ein konjunktureller Einbruch gegenüber 2019 um 4,0 % in Berlin und 3,4 % in Brandenburg .

Die nur für Deutschland insgesamt berechneten Quartalswerte des BIP zeigen jedoch bereits für die zweite Jahreshälfte 2020 eine wirtschaftliche Wiederbelebung an.   


**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Bruttoinlandsprodukt (preisbereinigt, 2015 =100): Statistisches Bundesamt (Destatis), 2021**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
### Einfluss auf Tourismus und Gastgewerbe

Absagen von Großveranstaltungen und vor allem das Verbot der Vermietung zu touristischen Zwecken sorgten für starke Rückgänge im **Berliner Beherbergungsgewerbe** 2020. Mit 4,9 Mill. Gästen kamen genauso viele Gäste in die Hauptstadt wie im Jahr 2001. Die Zahl der Übernachtungen sank gegenüber dem Vorjahr um 64,0 %. 2021 wurden insgesamt 5,1 Millionen Gäste mit fast 14 Millionen Übernachtungen gezählt. Das sind 13,7 Prozent mehr Übernachtungen als im Vorjahr. Damit erreichte die Zahl der Übernachtungen das Niveau von 2003. Gegenüber dem Jahr 2019, in dem die Pandemie noch keine Rolle spielte, ging die Zahl der Übernachtungen um 59,1 Prozent zurück.

Mit 10,1 Mill. Übernachtungen meldeten die **Brandenburger Beherbergungsbetriebe** für 2020 knapp ein Drittel weniger als im Jahr 2019 und lagen damit auf dem Stand von 2008. 2021 wurden in Brandenburg 3,2 Millionen Gäste mit 10 Millionen Übernachtungen gezählt. Gegenüber dem Jahr 2019 ging die Zahl der Übernachtungen um 27,7 Prozent zurück und fielen auf das Niveau von 2007.

Das **Berliner Beherbergungsgewerbe** meldete gegenüber November 2019 Umsatzverluste von 37,8 Prozent. Die Gastronomie verzeichnete einen Rückgang um 31,8 Prozent. Im Vergleich zum Vorjahresmonat konnten die gastgewerblichen Unternehmen eine Umsatzsteigerung um 154,8 Prozent verbuchen.

Die **gastgewerblichen Unternehmen in Brandenburg** verbuchten gegenüber November 2019 Umsatzverluste von 22,9 Prozent. Das betraf die Beherbergung und die Gastronomie gleichermaßen. Verglichen mit November 2020 erzielte das Gastgewerbe 74,6 Prozent Umsatzzuwächse.

**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg\* vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg\* vorläufige Ergebnisse**Quelle:** Amt für Statistik Berlin-Brandenburg![](https://download.statistik-berlin-brandenburg.de/e318cb5f443d53fe/86e8c017974f/v/931d744d6dae/corona-pdf.png)[Zum Dossier](https://download.statistik-berlin-brandenburg.de/d3f0fa88308c8ae0/5dad385265b2/DOSSIER_ZUR_CORONA-PANDEMIE_AfS_2020-12-14.pdf)

**Corona-Dossier**  
Letzte Aktualisierung: 14.12.2020

Weiterführende Links
--------------------

Zusätzlich zu den hier bereitgestellten Informationen möchten wir Sie mit Fokus auf die Corona-Pandemie noch
auf folgende Internet-Angebote hinweisen.

#### Offizielle regionale Informationsangebote für Berlin und Brandenburg

**Der Regierende Bürgermeister von Berlin, Senatskanzlei**

[Informationen zum Coronavirus (auch in
leichter Sprache und Gebärdensprache)](https://www.berlin.de/corona/gebaerdensprache/)

**Koordinierungszentrum Krisenmanagement  
in Brandenburg**

[Informationsangebot zur Corona Pandemie (auch in leichter, einfacher und Gebärdensprache)](https://kkm.brandenburg.de/kkm/de/corona/informationen-einfache-sprache/)

  


  


  


#### Überregionale Informationen zur Corona-Pandemie

**Robert-Koch-Institut (RKI)**  
[Informationen zur COVID-19, Dashboard mit aktuellen Daten nach Kreisen
und Bundesländern](https://experience.arcgis.com/experience/478220a4c454480e823b17327b2bf1d4/page/page_1/)  


**Bundesministerium für Gesundheit**  
[Tagesaktuelle Informationen zum Coronavirus](https://www.bundesgesundheitsministerium.de/coronavirus.html)  


**Deutsche Interdisziplinäre Vereinigung für Intensiv- und Notfallmedizin (DIVI) e.V.**[Krankenhausstandorte in Deutschland, die intensivmedizinische Behandlungskapazitäten vorhalten, differenziert in
low-care, high-care und ECMO-Versorgung](https://www.intensivregister.de/#/intensivregister)  


**Bundesagentur für Arbeit**  
[Statistische Arbeitsmarktgrößen, die den Einfluss der Corona-Pandemie
zeigen](https://statistik.arbeitsagentur.de/Navigation/Statistik/Statistik-nach-Themen/Corona/Corona-Nav.html)

#### Weitere thematisch einschlägige Angebote des Statistischen Verbunds

**Statistische Ämter des Bundes und der Länder**[Regionalstatistische Ergebnisse im Zusammenhang
mit der Corona-Pandemie (auch als Karten aufbereitet)](http://www.statistikportal.de/de/corona)  


**Statistisches Bundesamt (Destatis)**  
[Corona-Statistiken und Krisenmonitor](https://www.destatis.de/DE/Themen/Querschnitt/Corona/_inhalt.html)  


**Eurostat**[Statistisches Informationsangebot zu COVID-19 mit Fokus auf Europa](https://ec.europa.eu/eurostat/de/web/covid-19/overview)

**Weitere Informationen mit Regionalbezug finden Sie auch auf den Seiten der**   
[anderen Statistischen Ämter der Länder](https://www.statistikportal.de/de/statistische-aemter).  
  
  



