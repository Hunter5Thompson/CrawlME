

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Bevölkerung](/bevoelkerung)
* [Demografie](/bevoelkerung/demografie)
* [Einbürgerungen, Ausländer](/bevoelkerung/demografie/einbuergerungen-auslaender)
* [Einbürgerungen in Berlin und Brandenburg](/a-i-9-j)

Einbürgerungen
--------------

#### 2023, jährlich

###### Die Einbürgerungsstatistik weist die im Laufe des Berichtsjahres durch die Einbürgerungsbehörden gemeldeten vollzogenen Einbürgerungen von Ausländerinnen und Ausländern nach.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/4ff7ea59758f49aa/2260c0943272/SB_A01-09-00_2023j01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/8c40f1baef32a9f1/c391dfc1746f/SB_A01-09-00_2023j01_BE.pdf)

**Einbürgerungen in Berlin**

2023 wurden 9.041 Personen eingebürgert. Davon waren 80 % Anspruchseinbürgerungen. Die Innenstadtbezirke Friedrichhain-Kreuzberg (1.455) und Mitte (1.278) verzeichneten die meisten Einbürgerungen.

Im Durchschnitt waren die eingebürgerten Menschen 32 Jahre alt und haben zuvor rund 13 Jahre in Deutschland gelebt. Die Altersgruppe der 30- bis unter 35-Jährigen war maßgeblich an Einbürgerungen interessiert.

Die größte Gruppe der eingebürgerten Personen hatte als Heimatstaat Syrien (2.468) angegeben, gefolgt von der Türkei (618) und Iran (353).

### Kontakt

#### Kim Jenny Alderden

Bevölkerungsstatistiken

#### Kim Jenny Alderden

Bevölkerungsstatistiken

* [0331 8173-3132](tel:0331 8173-3132)
* [bevoelkerung@statistik-bbb.de](mailto: bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Einbürgerungen in Brandenburg**

2023 wurden 2.488 Menschen eingebürgert. 71,2 % davon waren Anspruchseinbürgerungen. Die kreisfreien Städte Potsdam (396) und Cottbus (217) verbuchten zahlenmäßig die meisten Einbürgerungen.

Im Durchschnitt waren die eingebürgerten Personen 29 Jahre alt und lebten zuvor bereits rund 10 Jahre in Deutschland. Vor allem der Altersgruppe der 30- bis unter 35-Jährigen war die Einbürgerung wichtig.

In Brandenburg besaßen zum Zeitpunkt der Einbürgerung 1.178 Menschen die syrische und 171 die polnische Staatsangehörigkeit, gefolgt von 142 Personen aus der Ukraine.

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – 2023**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/0e8ae426cf796ae1/42c1b7365f4a/SB_A01-09-00_2023j01_BB.xlsx) 

2., korrigierte Ausgabe

[Download PDF](https://download.statistik-berlin-brandenburg.de/acfa21f9b136bb7e/a7329516edba/SB_A01-09-00_2023j01_BB.pdf)
### Kontakt

#### Kim Jenny Alderden

Bevölkerungsstatistiken

#### Kim Jenny Alderden

Bevölkerungsstatistiken

* [0331 8173-3132](tel:0331 8173-3132)
* [bevoelkerung@statistik-bbb.de](mailto: bevoelkerung@statistik-bbb.de)
#### Regina Eck

Bevölkerungsstatistiken

#### Regina Eck

Bevölkerungsstatistiken

* [0331 8173-3878](tel:0331 8173-3878)
* [bevoelkerung@statistik-bbb.de](mailto:bevoelkerung@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Einbürgerungsstatistik wird jährlich aus den Angaben erstellt, die die Einbürgerungsbehörden dem Amt für Statistik Berlin-Brandenburg übermitteln.   
Erhoben wird die Struktur der eingebürgerten Bevölkerung hinsichtlich demografischer Merkmale, Aufenthaltsdauer, bisheriger Staatsangehörigkeit, Rechtsgrundlage der Einbürgerung und Beibehalt der bisherigen Staatsangehörigkeit.

Die Einbürgerungsstatistik bildet eine wichtige Informationsgrundlage zu Fragen des Staatsangehörigkeitsrechts und der Integration ausländischer Personen und dient somit als Entscheidungshilfe für eine Weiterentwicklung der Einbürgerungspolitik.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Einbürgerungsstatistik**  
Metadaten 2022

[Download PDF](https://download.statistik-berlin-brandenburg.de/9dc3d03dc7aff20b/f584cb097767/MD_12511_2022.pdf)[Archiv](/search-results?q=MD_12511&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/a-i-9-j)
