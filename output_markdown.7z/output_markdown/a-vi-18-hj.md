

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Erwerbstätigkeit](/erwerbstaetigkeit)
* [Erwerbstätige am Wohnort in Berlin und Brandenburg – Jahresergebnisse und Vierteljahresergebnisse](/a-vi-18-hj)

Erwerbstätige am Wohnort  –Jahres- und Vierteljahresergebnisse
--------------------------------------------------------------

#### 1991 bis 2023, halbjährlich

###### **Hier finden Sie vierteljährliche und jährliche Ergebnisse zur Erwerbstätigkeit am Wohn- und Arbeitsort in Berlin und Brandenburg aus der Erwerbstätigenrechnung des Arbeitskreises „Erwerbstätigenrechnung der Länder“, darunter Zahlen zu den Erwerbstätigen, Selbstständigen, Arbeitnehmerinnen und Arbeitnehmern sowie Ein- und Auspendelnden.**

BerlinBrandenburgMethodik

Berlin
------

**Quelle:** Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: Februar 2024)
#### Zum Statistischen Bericht – Berechnungsstand: Februar 2024

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e834efdb2163fdf2/3ec34e1ee129/SB_A06-18-00_2023h01_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/35d294763015bcd6/ca9c7f797cbc/SB_A06-18-00_2023h01_BE.pdf)

**Erwerbstätigkeit am Wohnort in Berlin im 2. Quartal 2023: Höchste Zuwachsrate aller Bundesländer**

Die Zahl der Erwerbstätigen mit Wohnort in Berlin erhöhte sich im 2. Quartal 2023 gegenüber dem Vorjahresquartal um 38.100 Personen bzw. 1,9 % auf 1.994.400. Damit setzte sich der seit dem 2. Quartal 2021 andauernde Aufwärtstrend der Erwerbstätigkeit in Berlin fort, wenn auch mit rückläufiger Dynamik: Im Vergleich zum Vorjahreszeitraum war die Zahl der Erwerbstätigen mit Wohnsitz in Berlin im 1. Quartal 2023 um 2,6 % und im Jahresdurchschnitt 2022 um 3,0 % angestiegen. Berlin verzeichnete im 2. Quartal 2023 den stärksten prozentualen Anstieg unter allen Bundesländern. Bundesweit nahm die Zahl der Erwerbstätigen am Wohnort im 2. Quartal 2023 um 0,8 % zu.

Im Vergleich zum Vorjahresquartal lag im 2. Quartal 2023 der prozentuale Anstieg der Zahl der Erwerbstätigen mit Wohnort in Berlin (+1,9 %) leicht über dem der Zahl der Erwerbstätigen mit Arbeitsort in Berlin (+1,8 %). Das resultierte aus einer im 2. Quartal 2023 gegenüber dem Vorjahresquartal stärkeren Zunahme bei der Zahl der Auspendelnden (+12.000 Personen) als bei der Zahl der Einpendelnden (+11.800 Personen). Im 2. Quartal 2023 sank daher der Einpendlerüberschuss in Berlin und betrug 196.500 Personen. Bereits im 1. Quartal 2023 war die Zahl der Auspendelnden (+16.700 Personen) gegenüber dem Vorjahresquartal stärker gestiegen als die Zahl der Einpendelnden (+14.200 Personen). Das hatte es in Berlin zuvor letztmals im 4. Quartal 2010 gegeben.

### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)

Brandenburg
-----------

**Zahl der Erwerbstätigen mit Wohnort in Brandenburg im 2. Quartal 2023 weiter gestiegen**

Im 2. Quartal 2023 waren 1.307.200 Personen mit Wohnsitz in Brandenburg erwerbstätig und somit 8.700 Personen bzw. 0,7 % mehr als im 2. Quartal 2022. Damit setzte sich die seit dem 2. Quartal 2021 andauernde positive Entwicklung der Erwerbstätigkeit in Brandenburg auf einem nahezu gleichbleibenden Niveau fort: Im Vergleich zum Vorjahreszeitraum war die Zahl der Erwerbstätigen mit Wohnsitz in Brandenburg im 1. Quartal 2023 um 0,6 % und im Jahresdurchschnitt 2022 um 0,8 % angestiegen. Brandenburgs Zuwachsrate im 2. Quartal 2023 (+0,7 %) lag leicht unter der bundesdurchschnittlichen Entwicklung (+0,8 %), jedoch über der in Ostdeutschland ohne Berlin (+0,3 %).

Die Zahl der Erwerbstätigen mit Wohnort in Brandenburg (+0,7 %) erhöhte sich im 2. Quartal 2023 etwas stärker als die Zahl der Erwerbstätigen mit Arbeitsort in Brandenburg (+0,5 %). Das ist auf einen im 2. Quartal 2023 gegenüber dem Vorjahresquartal stärkeren Anstieg bei der Zahl der Auspendelnden (+7.400 Personen) als bei der Zahl der Einpendelnden (+4.300 Personen) zurückzuführen. Der Auspendlerüberschuss in Brandenburg nahm daher im 2. Quartal 2023 auf 157.000 Personen zu. Bereits im 1. Quartal 2023 war die Zahl der Auspendelnden (+7.300 Personen) gegenüber dem Vorjahresquartal stärker gestiegen als die Zahl der Einpendelnden (+6.400 Personen). Das hatte es in Brandenburg zuvor letztmals im 4. Quartal 2020 gegeben.

**Quelle:** Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: Februar 2024)
#### Zum Statistischen Bericht – Berechnungsstand: Februar 2024

[Download XLSX](https://download.statistik-berlin-brandenburg.de/fb463123691f1c50/4534f2eb57bd/SB_A06-18-00_2023h01_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/d0bd0317ba7eb85e/6852febf1b18/SB_A06-18-00_2023h01_BB.pdf)
### Kontakt

#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Erwerbstätigenrechnung (ETR) liefert ein umfassendes Bild der wirtschaftlich aktiven Bevölkerung. Auf der Grundlage einer Vielzahl erwerbsstatistischer Datenquellen wird sowohl die Zahl der Erwerbstätigen am Arbeitsort (Inlandskonzept) und Wohnort (Inländerkonzept) als auch das Arbeitsvolumen nach der Stellung im Beruf und der wirtschaftsfachlichen Gliederung ermittelt. Ergebnisse für das Bundesgebiet werden von Destatis berechnet, für die Länder sowie Landkreise und kreisfreien Städte vom Arbeitskreis „Erwerbstätigenrechnung der Länder“ (AK ETR). Die Berechnungen erfolgen nach den konzeptionellen und definitorischen Vorgaben des Europäischen Systems Volkswirtschaftlicher Gesamtrechnungen (ESVG 2010), wodurch internationale Vergleichbarkeit gewährleistet ist.

Die hier vorliegenden Zahlen sind Ergebnisse des AK ETR, die auf den Rechenstand des Statistischen Bundesamtes vom Februar 2024 abgestimmt sind. Neben der Erstberechnung der Erwerbstätigkeit am Wohnort im 2. Quartal 2023 wurden die Ergebnisse für das 1. Quartal 2023 turnusmäßig überarbeitet.

Ergebnisse aller Bundesländer Deutschlands stellt der AK ETR unter [www.statistikportal.de/de/etr](https://www.statistikportal.de/de/etr "Verknüpfung folgen") zur Verfügung.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Erwerbstätige**ab 2023

[Download PDF](https://download.statistik-berlin-brandenburg.de/b85a593b815ea440/a3de95641681/MD_13300_2023.pdf)[Archiv](/search-results?q=MD_13300&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)
