

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Bildung](/gesellschaft/bildung)
#### Überblick

Bildung
=======

Bildung ist ein lebens­langer Prozess und ein wesentlicher Bestandteil für die ökonomische, soziale und kulturelle Entwicklung. Im Fokus der amt­lichen Bildungs­statistik stehen die Ein­rich­tungen des for­malen Bildungs­systems, wie Schu­len, Hoch­schulen, aber auch Ein­richtungen der beruf­lichen Aus- und Weiter­bildung.

**Schülerinnen/Schüler und Studierende**Schuljahr 2023/2024 bzw. Wintersemester 2023/2024

BerlinBrandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg[Schüler, Absolventen/Abgänger, Auszubildende
#### Schulen](/gesellschaft/bildung/schulen)[Studierende, Promotionen, Hochschulfinanzen
#### Hochschulen](/hochschulen)[BAföG, AFBG, Deutschlandstipendium
#### Ausbildungs-förderung](/ausbildungsfoerderung)
#### Bildungsbericht­erstattungBerlin/Brandenburg

[Zu den Berichten](/bildungsberichte)
##### 

#### Häufig nachgefragte Daten aus dem Bereich Bildung

Die wichtigsten Kennzahlen
--------------------------

**Quelle:** Amt für Statistik Berlin-Brandenburg1 ohne Zweiter Bildungsweg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg**Quelle:** Amt für Statistik Berlin-Brandenburg
#### Neues aus dem Bereich Bildung

Zuletzt veröffentlicht
----------------------

![iStock.com / Mag_Mac](https://download.statistik-berlin-brandenburg.de/87fd08d70bd6c761/8ff683cfc1de/v/34de3fb65195/gesellschaft-bildung-humboldt-university-in-berlin-germany-picture-id473452272.jpg)02.12.2024Pressemitteilung[#### Hochschulstatistik Wintersemester 2024/25 (vorläufige Angaben): Berlin hält die Zahl der Studierenden, in Brandenburg steigt sie weiter an](/167-2024)

Im Wintersemester 2024/25 sind nach vorläufigen Angaben 200.527 Studierende in Berlin und 52.216 Studierende in Brandenburg an Hochschulen eingeschrieben.

[Ansehen](/167-2024)![iStock.com / DisobeyArt](https://download.statistik-berlin-brandenburg.de/dc81672f22a9f1f7/081341cde7be/v/b0ad30523314/gesellschaft-bildung-young-millennial-friends-having-fun-chatting-taking-photos-with-and-picture-id1194859007.jpg)02.12.2024Statistischer Bericht[#### Wintersemester 2024/2025, jährlich, B III 8 – j: Studierende an Hochschulen in Berlin und Brandenburg – Wintersemester, vorläufige Angaben](/b-iii-8-j)

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden, Studienkollegiaten und Gasthörenden erhoben.

[Ansehen](/b-iii-8-j)![iStock.com / trumzz](https://download.statistik-berlin-brandenburg.de/d0a8e45e3ca8004b/5d53ced40224/v/897e56450ee6/gesellschaft-bildung-gesellschaft-bildung-audience-raising-hands-up-while-businessman-is-speaking-in-training-picture-id1041740040.jpg)18.11.2024Statistischer Bericht[#### Sommersemester 2024, jährlich, B III 6 – j: Studierende an Hochschulen in Berlin und Brandenburg – Sommersemester](/b-iii-6-j)

Im Rahmen der bundeseinheitlichen Hochschulstatistik werden Merkmale zu den Studierenden, Studienkollegiaten und Gasthörenden erhoben.

[Ansehen](/b-iii-6-j)Mehr anzeigen


