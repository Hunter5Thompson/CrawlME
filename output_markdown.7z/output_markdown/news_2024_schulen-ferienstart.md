

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 17.07.2024

#### Sommerzeit ist Ferienzeit

Fast 676.000 Schulkinder in der Hauptstadtregion machen Ferien
--------------------------------------------------------------

![Kinder sitzen mit gepackten Koffern im offenen Kofferraum eines Autos](https://download.statistik-berlin-brandenburg.de/3cec476a062d4957/08883a8fbf00/v/61dd71e35cc6/istockphoto-1150580548-1024x1024.jpg "Kinder sitzen mit gepackten Koffern im offenen Kofferraum eines Autos")

**Der Sommer kommt in die heiße Phase und damit rückt das Ende des Schuljahres 2023/24 näher. In Brandenburg bekommen insgesamt 278.103 Schülerinnen und Schüler an allgemeinbildenden Schulen heute ihre Zeugnisse und Beurteilungen, in Berlin sind es insgesamt 397.307**¹**. In beiden Ländern entspricht das einem Anstieg der Schülerzahlen um 2,2 % **im Vergleich zum letzten Jahr**.**

In Brandenburg freuen sich 149.627 Schulkinder der Primarstufe auf die anstehenden Sommerferien, 97.513 Schülerinnen und Schüler der Sekundarstufe I sowie 26.916 Schülerinnen und Schüler der Sekundarstufe II. Die Zunahme der Schülerzahlen verteilt sich übrigens auf fast alle Schulformen, lediglich die beruflichen Gymnasien und die Schulen des Zweiten Bildungsweges werden weniger „Giftzettel“ als im letzten Jahr verteilen.

**Quelle:** Amt für Statistik Berlin-Brandenburg

Für 19.976 Sechstklässler in Brandenburg geht nun die Grundschulzeit zu Ende und es folgt der Übergang in die weiterführende Schule der Sekundarstufe I. Werden auch in diesem Jahr wieder die meisten Kinder auf ein Gymnasium wechseln? Das wird uns die nächste Erhebung nach den Sommerferien zeigen. Im Schuljahr 2023/24 lag die Übergangsquote zu dieser Schulform in Brandenburg bei 40,8 %. In Berlin beginnt für 29.411 Schülerinnen und Schüler der 6. Klasse ein weiteres spannendes Kapitel ihrer Schulzeit.¹

**Quelle:** Kommunale Bildungsdatenbank

Auch für fast 12.800 Schülerinnen und Schüler der 10. Klassen an Ober- und Gesamtschulen sowie rund 5.600 Abiturientinnen und Abiturienten der Abschlussjahrgänge in Brandenburg stellt sich die Frage, wie es weitergeht – Studium oder doch besser eine Ausbildung? Entscheidend dafür ist neben der Art des Abschlusses auch der Notenschnitt. Letzteren erhebt das [Ministerium für Bildung, Jugend und Sport (MBJS)](http://mbjs.brandenburg.de "Zur Startseite: Ministerium für Bildung, Jugend und Sport (MBJS)").

**Datenangebot**

Weitere Informationen zu Schulen in Brandenburg finden Sie in unseren [Statistischen Berichten](/gesellschaft/bildung/schulen) und in der [Kommunalen Bildungsdatenbank](https://www.bildungsmonitoring.de/bildung/online). Für das Land Berlin liegt die Datenhoheit bei der [Senatsverwaltung für Bildung, Jugend und Familie](https://www.berlin.de/sen/bildung/schule/bildungsstatistik/).

###### Wir wünschen allen schöne Ferien und einen tollen Urlaub.

¹Alle hier veröffentlichten Zahlen für Berlin haben folgenden Datenquelle: [www.berlin.de/sen/bildung/schule/bildungsstatistik/](https://www.berlin.de/sen/bildung/schule/bildungsstatistik/).

### Kontakte

#### Ramona Klasen

Schulen

#### Ramona Klasen

Schulen

* [0331 8173-1146](tel:0331 8173-1146)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Matthias Gebhard

Schulen

#### Matthias Gebhard

Schulen

* [0331 8173-1103](tel:0331 8173-1103)
* [schulen-brandenburg@statistik-bbb.de](mailto:schulen-brandenburg@statistik-bbb.de)
#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")](/news/2024/jahresrueckblick)**Amtlicher Jahresrückblick 2024**[#### Das Jahr in Zahlen](/news/2024/jahresrueckblick)

Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben....

Mehr anzeigen

[* Schulform](/search-results?q=tag%3ASchulform)[* Sommer](/search-results?q=tag%3ASommer)[* Ferien](/search-results?q=tag%3AFerien)[* Urlaub](/search-results?q=tag%3AUrlaub)[* Schule](/search-results?q=tag%3ASchule)[* Schüler](/search-results?q=tag%3ASchüler)
