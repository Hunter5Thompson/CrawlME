

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Preise](/wirtschaft/preise)
* [Verbraucherpreise](/verbraucherpreise)

Verbraucherpreise
=================

Mit der Statistik der Verbraucherpreise wird monatlich die durchschnittliche Preisentwicklung aller Waren und Dienstleistungen, die von privaten Haushalten für Konsumzwecke gekauft werden, ermittelt.   
  
Die Ergebnisse werden als Indizes und Veränderungsraten dargestellt. Grundlage der Indexberechnungen ist ein statistischer Warenkorb, in dem rund 700 Güter als Preisrepräsentanten zusammengestellt sind und laufend aktualisiert werden.

[![Zwei Hände zeigen mehrere auf Geldstapel](https://download.statistik-berlin-brandenburg.de/58fe59e64c6fdbe7/36a55dc57069/v/994e168388ea/preise-geld-inflation-iStock-1454520770-web.png "Zwei Hände zeigen mehrere auf Geldstapel")](/news/2024/konferenz-messung-der-preise)**Erfolgreich abgeschlossen**[#### 26. Konferenz „Messung der Preise“](/news/2024/konferenz-messung-der-preise)

Vertreter der Statistischen Ämter des Bundes und der Länder, der Deutschen Bundesbank, der Europäischen Zentralbank (EZB) und der Wissenschaft kamen zusammen.

Statistische BerichteZeitreihenBasisdatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Verbraucherpreisindex in Berlin und Brandenburg monatlich (MI2-m)](/m-i-2-m)

Zeitreihen
----------

1 im Jahresdurchschnitt **Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/0ccf05bf7b8f1fa3/c5cedb965da4/Verbraucherpreise_Zeitreihe_2023.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/59958630e4e5680a/882c0e87daf1/Verbraucherpreise_Lange-Reihe_2023_Berlin-Brandenburg.xlsx)

Basisdaten
----------

Weitere Datenangebote
---------------------

#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/preise-verdienste-und-arbeitskosten)
#### GENESIS-Online Bund

![](https://download.statistik-berlin-brandenburg.de/1799ea6ecd2e4e5d/8356950e6e8c/v/cb208b154705/genesis-datenbank.jpg)

Die Datenbank des Statistischen Bundesamtes stellt einen laufend aktualisierten Querschnitt amtlicher Statistikdaten zur Verfügung.

[Zu GENESIS-Online](https://www-genesis.destatis.de/genesis/online?operation=find&suchanweisung_language=de&query=Verbraucherpreise#abreadcrumb)

Haben Sie Fragen?
-----------------

#### Katja Kirchner

Preise

#### Katja Kirchner

Preise

* [0331 8173-3031](tel:0331 8173-3031)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
#### Berit Nimmich

Verbraucherpreise

#### Berit Nimmich

Verbraucherpreise

* [0331 8173-3034](tel:0331 8173-3034)
* [berit.nimmich@statistik-bbb.de](mailto:berit.nimmich@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Katrin Schoenecker

Preise

#### Katrin Schoenecker

Preise

* [0331 8173-3114](tel:0331 8173-3114)
* [preise@statistik-bbb.de](mailto:preise@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Britta Kühn

Verbraucherpreise

#### Britta Kühn

Verbraucherpreise

* [0331 8173-3535](tel:0331 8173-3535)
* [britta.kühn@statistik-bbb.de](mailto:britta.kühn@statistik-bbb.de)
* [0331 817330-4026](fax:0331 817330-4026)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / JJFarquitectos](https://download.statistik-berlin-brandenburg.de/6fa6ce9b156d3d63/504c134f19e9/v/f2d4980f3df3/wirtschaft-preise-verbraucherpreise-closeup-photo-of-stylish-woman-taking-money-picture-id842875452.jpg "iStock.com / JJFarquitectos")](/m-i-2-m)**November 2024, monatlich, M I 2 – m**[#### Verbraucherpreisindex in Berlin und Brandenburg](/m-i-2-m)

Monatliche Statistik zur durchschnittlichen Preisentwicklung aller Waren und Dienstleistungen, die von privaten Haushalten für Konsumzwecke gekauft werden.

[![](https://download.statistik-berlin-brandenburg.de/a5428da79bd40607/f3301d8bdf5a/v/5f183346ceea/iStock-1216828053.jpg)](/166-2024)**Verbraucherpreise November 2024 Berlin und Brandenburg**[#### Teuerung in Berlin zieht wieder an, leichte Erhöhung auch in Brandenburg](/166-2024)

Im November 2024 erhöhten sich die Verbraucherpreise im Vergleich zum November 2023 in Berlin um 2,0 % und in Brandenburg um 1,9 %.

[![](https://download.statistik-berlin-brandenburg.de/bd041e97ea20790b/a2e43aa789f7/v/b7b2e918716c/shopping-basket-with-foods-on-the-pile-of-receipt-consumerism-and-picture-id1156063032.jpg)](/146-2024)**Verbraucherpreise Oktober 2024 Berlin und Brandenburg**[#### Teuerung zieht in beiden Ländern wieder an](/146-2024)

Im Oktober 2024 erhöhten sich die Verbraucherpreise im Vergleich zum Oktober 2023 in Berlin um 1,4 % und in Brandenburg um 1,8 %.

[Zu unseren News](/news)

[* Verbraucherpreise](/search-results?q=tag%3AVerbraucherpreise)[* Nettokaltmieten](/search-results?q=tag%3ANettokaltmieten)[* Nahrungsmittel](/search-results?q=tag%3ANahrungsmittel)[* Preisentwicklung](/search-results?q=tag%3APreisentwicklung)[* Preisveränderung](/search-results?q=tag%3APreisveränderung)[* Inflation](/search-results?q=tag%3AInflation)
