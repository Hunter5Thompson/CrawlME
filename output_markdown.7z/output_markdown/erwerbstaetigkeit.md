

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Gesellschaft](/gesellschaft)
* [Arbeit](/gesellschaft/arbeit)
* [Erwerbstätigkeit](/erwerbstaetigkeit)

Erwerbstätigkeit
----------------

Zahlen zur Erwerbstätigkeit liefert sowohl der Mikrozensus in Form von stichprobenbasierten Befragungsergebnissen als auch die Erwerbstätigenrechnung. Sie beruht auf vielen verschiedenen erwerbsstatistischen Datenquellen. Aufgrund der unterschiedlichen Methodik kommt es zu abweichenden Ergebnissen.

###### Erwerbstätigenrechnung

Die Erwerbstätigenrechnung liefert ein umfassendes Gesamtbild der Erwerbstätigkeit. Es wird sowohl die Zahl der Erwerbstätigen am Arbeits- und Wohnort als auch das Arbeitsvolumen nach Berufsgruppen und Wirtschaftsbereichen ermittelt. Ergebnisse werden bis hin zur Kreisebene ermittelt.

###### Mikrozensus

Im Gegensatz zur Erwerbstätigenrechnung liegen aus dem Mikrozensus für Berlin auch repräsentative Ergebnisse auf Bezirksebene vor. Diese können unter den **Regionaldaten** mit Brandenburger Kreisergebnissen aus dem Mikrozensus verglichen werden.

Weitere Ergebnisse aus dem Mikrozensus zu Berlin und Brandenburg finden Sie auf der [Themenseite „Mikrozensus“](/bevoelkerung/demografie/mikrozensus).

###### Beschäftigungsstatistik der Bundesagentur für Arbeit

Zahlen zu sozialversicherungspflichtig und geringfügig Beschäftigten liefert die Beschäftigungsstatistik der Bundesagentur für Arbeit. Weitergehende Informationen und Daten bis auf Gemeindeebene erhalten Sie beim [Statistik-Service Ost der Bundesagentur für Arbeit](https://statistik.arbeitsagentur.de/DE/Navigation/Service/Kontakt/Kontakt-Nav.html) und im [Internetangebot der Bundesagentur für Arbeit](https://statistik.arbeitsagentur.de/DE/Navigation/Statistiken/Fachstatistiken/Beschaeftigung/Beschaeftigung-Nav.html).

###### Pendlerrechnung

Erwerbsbedingte potenzielle Pendelströme auf Gemeindeebene können interaktiv über den [Pendleratlas](https://pendleratlas.statistikportal.de) sowie aus der [Regionaldatenbank](https://www.regionalstatistik.de/genesis/online/statistic/19321) als Tabellen abgerufen werden.

Statistische BerichteZeitreihenBasisdatenRegionaldatenWeitere Datenangebote

Statistische Berichte
---------------------

#### Unsere Berichtsreihe mit aktuellen statistischen Ergebnissen.

[Erwerbstätige am Arbeitsort in Berlin und Brandenburg – Jahresergebnisse, dreimal jährlich (AVI9-hj)](/a-vi-9-hj)[Erwerbstätige am Arbeitsort in Berlin und Brandenburg – Vierteljahresergebnisse, vierteljährlich (AVI16-vj)](/a-vi-16-vj)[Erwerbstätige am Wohnort in Berlin und Brandenburg – Jahresergebnisse und Vierteljahresergebnisse, halbjährlich (AVI18-hj)](/a-vi-18-hj)[Erwerbstätige am Arbeitsort in den kreisfreien Städten und Landkreisen in Brandenburg, jährlich (AVI10-j)](/a-vi-10-j)[Geleistete Arbeitsstunden in Berlin und Brandenburg, halbjährlich (AVI17-hj)](/a-vi-17-hj)[Sozialversicherungspflichtig Beschäftigte in Berlin und Brandenburg, jährlich (AVI20-j)](/a-vi-20-j)

Zeitreihen
----------

ErwerbstätigeErwerbstätige: Veränderung zum VorjahrBeschäftigteBeschäftigte: Veränderung zum Vorjahr1 Erwerbstätige nach dem Inlandskonzept (Arbeitsort), im Jahresdurchschnitt auf der Grundlage der WZ 2008**Quelle:** Quelle: Vorläufige Ergebnisse des Arbeitskreises „Erwerbstätigenrechnung der Länder" und des Amtes für Statistik Berlin-Brandenburg (Berechnungsstand: August 2024)

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

#### Erwerbstätige

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/1ec19e33cb249283/ff83a1df4904/Erwerbstaetigkeit-Erwerbstaetige-Zeitreihe.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/79e62d588d7b0e7f/a6451e44e840/Erwerbstaetigkeit-Erwerbstaetige-Lange-Reihe.xlsx)
#### Beschäftigte

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/3159c7afa110c05a/9ea3a4f24da9/erwerbstaetigkeit-zeitreihe-2023-beschaeftigte.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/3bb8616febbc1877/9df77b59e22e/erwerbstaetigkeit-langereihe-2000-2023-beschaeftigte.xlsx)

Basisdaten
----------

ErwerbstätigeErwerbstätige: Veränderung zum VorjahrBeschäftigteBeschäftigte: AltersstrukturBeschäftigte nach Wirtschaftsabschnitt

Regionaldaten
-------------

###### Berliner Bezirke

#### Erwerbstätigkeit 2019

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte

#### Erwerbstätigkeit 2019

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

###### Brandenburger Landkreise und kreisfreie Städte

#### Sozialversicherungspflichtig Beschäftigte 2023

Chart druckenDownload JPEGDownload EXCEL

wird geladen...

Weitere Datenangebote
---------------------

#### Regionaldatenbank

![](https://download.statistik-berlin-brandenburg.de/db3ab29ca21b23e6/000f7a32f551/v/279543ff7eb2/regionaldatenbank.jpg)

In der Regionaldatenbank finden Sie tief gegliederte Ergebnisse der amtlichen Statistik auf Länder- und Kreisebene.

[Zur Regionaldatenbank](https://www.regionalstatistik.de/genesis/online?operation=statistic&levelindex=0&levelid=1714479789215&code=13312#abreadcrumb)
#### Statistikportal

![](https://download.statistik-berlin-brandenburg.de/d4b99329f45ec6c5/24bff229dd23/v/54bc944b6150/statistikportal.jpg)

Das gemeinsame Statistikportal der Statistischen Ämtern des Bundes und der Länder bietet ein umfangreiches und kostenloses Datenangebot.

[Zum Statistikportal](https://www.statistikportal.de/de/etr)

Haben Sie Fragen?
-----------------

#### Jonas Geppert

Erwerbstätigenrechnung

#### Jonas Geppert

Erwerbstätigenrechnung

* [0331 8173-3739](tel:0331 8173-3739)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Benjamin Gampfer

Erwerbstätigkeit

#### Benjamin Gampfer

Erwerbstätigkeit

* [0331 8173-3904](tel:0331 8173-3904)
* [etr@statistik-bbb.de](mailto:etr@statistik-bbb.de)
#### Jörg Feilbach

Mikrozensus

#### Jörg Feilbach

Mikrozensus

* [0331 8173-3644](tel:0331 8173-3644)
* [mikrozensus@statistik-bbb.de](mailto:mikrozensus@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock.com / hanohiki](https://download.statistik-berlin-brandenburg.de/fe20dc231151c488/8654315682c1/v/71695f4bb798/gesellschaft-verkehr-berlin-train-station-people-and-sbahn-train-picture-id686917744.jpg "iStock.com / hanohiki")](/143-2024)**Pendlerrechnung 2023 für Berlin und Brandenburg**[#### Zahl der Pendelnden erneut gestiegen](/143-2024)

Pressemitteilung Nr. 143 2023 pendelten rund 1,1 Millionen Menschen in Berlin und Brandenburg zur Arbeit in eine andere Gemeinde. Das entsprach einem Anteil von 34 % an allen erfassten Personen 3,2...

[![iStock.com / kzenon](https://download.statistik-berlin-brandenburg.de/6cd9710d4adc0784/f0c6511e7c87/v/6afc8e64d334/gesellschaft-bildung-master-discussing-a-workpiece-with-his-apprentice-or-trainee-picture-id1279669076.jpg "iStock.com / kzenon")](/091-2024)**Erwerbstätigkeit im 1. Quartal 2024 in Berlin**[#### Wachstumsdynamik nur noch durchschnittlich](/091-2024)

Im 1. Quartal 2024 waren 2.185.600 Personen in Berlin erwerbstätig. Im Vergleich zum Vorjahresquartal erhöhte sich die Erwerbstätigkeit um 9.100 Personen bzw. 0,4 %.

[![iStock.com / bernardbodo](https://download.statistik-berlin-brandenburg.de/923f7835198f8a8e/7b2b25848694/v/a9d37fad10a1/gesellschaft-arbeit-working-in-a-call-centre-picture-id1090399352.jpg "iStock.com / bernardbodo")](/090-2024)**Erwerbstätigkeit im 1. Quartal 2024 in Brandenburg**[#### Aufwärtstrend gestoppt](/090-2024)

Im 1. Quartal 2024 gingen 1.139.000 Personen in Brandenburg einer Erwerbstätigkeit nach. Das waren 400 Personen weniger als im 1. Quartal 2023.

[Zu unseren News](/news)

[* Selbstständige](/search-results?q=tag%3ASelbstständige)[* Geringverdiener](/search-results?q=tag%3AGeringverdiener)[* Pendler](/search-results?q=tag%3APendler)[* Arbeitskräfte](/search-results?q=tag%3AArbeitskräfte)[* Erwerbstätige](/search-results?q=tag%3AErwerbstätige)
