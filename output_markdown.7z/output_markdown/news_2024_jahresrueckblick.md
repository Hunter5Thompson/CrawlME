

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)
##### 17.12.2024

#### Amtlicher Jahresrückblick 2024

Das Jahr in Zahlen
------------------

![milezaway](https://download.statistik-berlin-brandenburg.de/07543797c6cb215c/c71c0aa56e0b/v/832f827867e0/feuerwerk-stock-adobe.png "milezaway")

**Bauernproteste, Geburten, Scheidungen, Zensus-Zahlen, Wahlen und wieder Wahlen in Berlin und Brandenburg... Wir werfen einen Blick auf 12 zentrale Entwicklungen in der amtlichen Statistik, die das Jahr 2024 geprägt haben.**

#### Januar: Bauernproteste und erste Ergebnisse der Agrarstrukturerhebung

Betriebe
--------

**in der Landwirtschaft gab es 2023 in Brandenburg.**

Im Januar veröffentlichten wir die ersten Ergebnisse der [Agrarstrukturerhebung 2023](/land-und-forstwirtschaft), die alle drei bis vier Jahre durchgeführt wird. Die Daten zeigten wichtige Entwicklungen in der landwirtschaftlichen Struktur, die auf großes öffentliches Interesse stießen. Zeitgleich kam es im Januar zu Bauernprotesten, die auf politische und wirtschaftliche Herausforderungen in der Landwirtschaft aufmerksam machten. Unsere Statistiken bieten in diesem Zusammenhang eine wertvolle Grundlage für Diskussionen und Entscheidungsprozesse.

#### Februar: Teilwiederholungswahl des Bundestages in Berlin

Wahlbezirke
-----------

**waren von der Wiederholung der Bundestagswahl betroffen.**

Im Februar begann das Superwahljahr mit der Teilwiederholung der Bundestagswahl in 455 Berliner Wahlbezirken. Wir waren hier maßgeblich, wie bei einem Großteil der Wahlen in Berlin und Brandenburg, an der Vorbereitung und Durchführung beteiligt. Die Wahlen hielten uns das ganze Jahr über in Bewegung – mit der Europawahl und den Brandenburger Kommunalwahlen im Mai sowie der Landtagswahl in Brandenburg im September. Und auch zum Jahresabschluss beschäftigt uns das Thema Wahlen weiterhin. Seit gestern steht fest: Die Bundestagswahl 2025 wird vorgezogen.

#### März: Equal Pay Day am 6. März

%
-

**beträgt die Verdienstungleichheit zwischen Frauen und Männern 2023 in Berlin.** 

Anlässlich des Equal Pay Days haben wir den Indikator „Gender Gap Arbeitsmarkt“ vorgestellt. Dieser lag in Berlin und Brandenburg deutlich unter dem Bundesdurchschnitt von 39 %. Er kombiniert bezahlte Arbeitszeiten, Verdienste und Erwerbsbeteiligung und macht so regionale und zeitliche Unterschiede zwischen den Geschlechtern sichtbar.

Der Equal Pay Day markiert symbolisch die Lohnlücke zwischen Männern und Frauen. Er ist der Tag im Jahr, bis zu dem Frauen umsonst arbeiten, während Männer seit dem 1. Januar für ihre Arbeit bezahlt werden.

[![Frau mit Büchern in einer Bibliothek](https://download.statistik-berlin-brandenburg.de/3d83b26860d61c9a/ca880fc309b1/v/e8a86786704e/istockphoto-1417921874-1024x1024.jpg "Frau mit Büchern in einer Bibliothek")](/news/2024/frauentag)**Internationaler Frauentag 2024**[#### Ein kurzer Blick auf den Arbeitsmarkt](/news/2024/frauentag)

Anlässlich des Internationalen Frauentags am 8. März werfen wir einen Blick auf aktuelle Arbeitsmarktzahlen und die immer noch bestehende Ungleichheit.

#### April: Trend zu weniger Geburten hält an

Kinder
------

**weniger als 2022 wurden 2023 in Berlin geboren.**

Der April lieferte uns aktuelle Zahlen aus dem Einwohnermelderegister. Demnach kamen 2023 in Berlin 33.425 Kinder zur Welt. Da sind 4.407 Kinder und 11,6 % weniger als im Vorjahr 2022. Dagegen wurden 37.455 Todesfälle gemeldet – ein Rückgang um 1.548 bzw. 4,0 %. Somit sind 4.030 mehr Berliner gestorben als geboren wurden. Im Vorjahr lag dieses Defizit bei 1.171 Personen. Aufgrund des Wanderungsgewinns von 33.874 Personen zum Stichtag 31.12.2023 verzeichnet Berlin jedoch immer noch ein Bevölkerungswachstum. Mehr Zahlen für alle Berliner Bezirke und Ortsteile finden Sie in unserer [Berlin-Statistik](/kommunalstatistik).

#### Mai: Wir feiern das Grundgesetz

Jahre
-----

**Grundgesetz**

Im Mai feierte das Grundgesetz sein 75-jähriges Bestehen, dessen Werte das Fundament unserer Demokratie bilden. Als amtliche Statistik leisten wir einen zentralen Beitrag zur Demokratie, indem wir unabhängige und faktenbasierte Daten für Staat, Wirtschaft und Gesellschaft bereitstellen. Damit unterstützen wir Entscheidungen, Gesetzgebungsprozesse und die politische Willensbildung und schützen zugleich die Werte des Grundgesetzes vor Fake News und Manipulation.

![](https://download.statistik-berlin-brandenburg.de/eedcfd6c5a9eb8c7/ec441e000afd/v/21e00bd46102/grundgesetz-statistik-fidorra.jfif)
#### Juni: Ergebnisse des Zensus 2022 veröffentlicht

EUR/m² Wohnfläche
-----------------

**muss man in Berlin im Schnitt mehr im Vergleich zu Brandenburg zahlen.**

Dieses Jahr stand der Juni ganz im Zeichen des [Zensus 2022](/zensus22). Wir veröffentlichten die ersten Ergebnisse und lieferten damit detaillierte Einblicke in Bevölkerung, Wohnsituation und soziale Strukturen der Region. So sind die Menschen in Brandenburg zum Beispiel im Schnitt vier Jahre älter als jene in Berlin, leben auf 15 m² mehr Wohnfläche, zahlen jedoch weniger Nettokaltmiete. Erstmals wurden auch Daten wie Leerstandsdauer und Heizungsenergieträger erfasst.

[Zu unseren Zensus-Dahboards](/zensus22)[![](https://download.statistik-berlin-brandenburg.de/f5ba007a5ba3be71/bf2f04febdd8/v/b06aeb82d708/zensus-nettokaltmiete.png)](/news/2024/zensus-miete)**Zensus 2022 in Berlin und Brandenburg**[#### Altbau- und Neubauwohnungen am teuersten](/news/2024/zensus-miete)

Der Zensus 2022 zeigt: Sowohl in Berlin als auch in Brandenburg sind Altbau- und Neubauwohnungen die teuersten Mietobjekte.

#### Juli: Brandenburg ist unter den Bundesländern Zuzugsmeister

Personen
--------

**hat Brandenburg durch Wanderung in 2023 dazugewonnen.**

Gemeinsam mit der Staatskanzlei Brandenburg haben wir im Juli Zahlen im innerdeutschen Vergleich veröffentlicht, die die Beliebtheit des Bundeslands unterstreichen. Die Ergebnisse lassen sich sehen: Brandenburg erzielte in 2023 den drittgrößten Wanderungsgewinn seit 1995. Hiervon stammen 50 % aus internationalen Zu- und Fortzügen. Wichtigster Wanderungspartner bleibt weiterhin Berlin. Besonders Kinder unter 18 Jahren und Erwachsene zwischen 30 und 45 Jahren prägen den Zuzug. Alle Zahlen können Sie [hier](/100-2024) nachlesen.

[![](https://download.statistik-berlin-brandenburg.de/5806030fcf894149/b352f1790b4a/v/0af2999b9b37/brandenburg-zuzugsmeister.jfif)](/100-2024)
#### August: Historisch schlechte Apfelernte erwartet

Tonnen Äpfel
------------

**Äpfel wurden 2024 in Brandenburg geerntet.**

Die vorläufige [Ernteberichterstattung](/land-und-forstwirtschaft) 2024 für Brandenburg zeigt massive Ertragsausfälle bei Äpfeln und anderen Obstsorten. Mit nur 41 Dezitonnen je Hektar liegt der Apfelertrag so niedrig wie seit 1991 nicht mehr, weit unter dem sechsjährigen Durchschnitt von 261 Dezitonnen je Hektar. Ursache sind Frostschäden durch eine Kälteperiode Ende April, die über 80 % der Apfelernte vernichtete. Die Erntemenge wird auf 3.200 Tonnen geschätzt, im Vergleich zu 18.200 Tonnen im Vorjahr. Auch bei Kirschen und Pflaumen werden historische Tiefstwerte erwartet.

#### September: Landtagswahl in Brandenburg

%
-

**der Wahlberechtigten haben bei der Landtagswahl in Brandenburg gewählt.**

Bei der Landtagswahl in Brandenburg haben mehr als 50 Kolleginnen und Kollegen aus unserem Amt bis spät in die Nacht hinein maßgeblich zu einer reibungslosen Durchführung und Transparenz der Wahl beigetragen. Zu unseren Aufgaben zählten die Sammlung, Aufbereitung, Prüfung und Plausibilisierung der Ergebnisse sowie die Veröffentlichung der Zwischenergebnisse und des vorläufigen amtlichen Wahlergebnisses. Um 23:09 Uhr waren 100 % aller Wahlbezirke ausgezählt. Die Wahlbeteiligung war übrigens die höchste seit der Wiedervereinigung.   


[Zu den Wahlergebnissen](/landtagswahlen-brandenburg)![](https://download.statistik-berlin-brandenburg.de/83b02c67ef6faeea/4bfe08bdca49/v/0f5af23a8b2e/wahlen-brandenburg.jfif)
#### Oktober: Rückläufige Zahlen beim Ehebündnis

Scheidungen
-----------

**gab es 2023 in Berlin und Brandenburg**

Insgesamt wurden 2023 in Berlin und Brandenburg 23.324 Ehen geschlossen und 9.190 geschieden, wobei ein deutlicher Abwärtstrend erkennbar ist. In Berlin wurden 11.429 Ehen geschlossen, ein historischer Tiefstand, und 5.388 geschieden, der niedrigste Wert der letzten fünf Jahre. Auch in Brandenburg sanken die Zahlen mit 11.895 Eheschließungen und 3.802 Scheidungen auf historische Tiefstände. 93 % der Eheschließungen in Berlin und 97 % in Brandenburg fanden zwischen Frau und Mann statt. Bei etwa einem Viertel der Berliner und einem Drittel der Brandenburger Eheschließungen hatten die Paare bereits gemeinsame Kinder, während bei knapp der Hälfte der Scheidungen minderjährige Kinder betroffen waren.

#### November: Migrationshintergrund in der Berliner Verwaltung

%
-

**des Personals im öffentlichen Dienst in Berlin haben einen Migrationshintergrund.**

Erstmalig wurden die 143.700 Beschäftigten des öffentlichen Dienstes in Berlin freiwillig und anonym zu ihrem Migrationshintergrund befragt. Das Projekt wurde von der [Senatsverwaltung für Arbeit, Soziales, Gleichstellung, Integration, Vielfalt und Antidiskriminierung](https://www.berlin.de/sen/asgiva/) ins Leben gerufen. Wir haben die Befragung durchgeführt und die Ergebnisse im November veröffentlicht: 22 % der Mitarbeitenden nahmen teil, davon gaben 21,7 % an, einen Migrationshintergrund zu haben – deutlich weniger als der Anteil von 39,4 % in der Berliner Bevölkerung. Die Ergebnisse basieren auf dem Berliner Partizipationsgesetz und sollen dazu beitragen, Chancengleichheit zu fördern und Reformbedarfe in der Verwaltung zu identifizieren.

#### **Dezember:****Der erste Amtventskalender ist da!**

Statistikhäppchen
-----------------

**befinden sich in unserem Amtventskalender.**

Wie viele Stollen passen auf die Fläche Brandenburgs? Zieht Berlin im Vergleich zu anderen europäischen Städten viele Gäste im Dezember an? Ist Plätzchenbacken in diesem Jahr teurer geworden? Diese und weitere Fragen beantwortet unser Amtventskalender. Öffnen Sie jeden Tag bis Weihnachten ein Türchen und entdecken Sie interessante Zahlen, Fakten und Geschichten aus Berlin und Brandenburg.

[Öffnen Sie das nächste Türchen.](/adventskalender)[![](https://download.statistik-berlin-brandenburg.de/c5a25f97f7590e73/0fd16eed48f1/v/7a75e63d0da7/amtventskalender.png)](/adventskalender)
### Kontakte

#### Redaktion

Content Management

#### Redaktion

Content Management

* [0331 8173-3654, -3083](tel:0331 8173-3654, -3083)
* [redaktion@statistik-bbb.de](mailto:redaktion@statistik-bbb.de)
### Weitere Artikel

[![iStock.com / rclassenlayouts](https://download.statistik-berlin-brandenburg.de/2110e8c08057d191/c7391f961747/v/9677d2347018/bevoelkerung-gesellschaft-crowd-of-people-picture-id1141706621.jpg "iStock.com / rclassenlayouts")](/news/2024/einwohner-oder-bevoelkerung)**Unterschiede in der amtlichen Datenaufbereitung**[#### Wie viele Menschen leben in Berlin? Welche Quelle ist die richtige?](/news/2024/einwohner-oder-bevoelkerung)

Ein Anliegen, aber mehrere Zahlen in der amtlichen Statistik. Kann das sein? Ja. Und alle Zahlen sind korrekt. Wir klären auf....

[![Schaubild Zensus 2022 zum Thema Melderegister](https://download.statistik-berlin-brandenburg.de/04748aa59bd4970e/9408a1fd8add/v/ed9326ac9540/Zensus-2022-Melderegister.png "Schaubild Zensus 2022 zum Thema Melderegister")](/news/2024/zensus-melderegister)**Unterschiede in der amtlichen Datenaufbereitung**[#### Melderegister, Zensus, Fortschreibung](/news/2024/zensus-melderegister)

Der Zensus 2022 bedeutet für fast alle Kommunen eine neue amtliche Einwohnerzahl. Wir erklären.

[![](https://download.statistik-berlin-brandenburg.de/16e459f656e2457a/adbebafceda5/v/046b794f38cc/zensus-generation-alpha.png)](/news/2024/zensus-generation-alpha)**Zensus 2022 in Berlin und Brandenburg**[#### So wächst die Generation Alpha auf](/news/2024/zensus-generation-alpha)

Der Zensus 2022 gibt Einblicke in die Einwanderungsgeschichte der Generation Alpha in Berlin und Brandenburg.

Mehr anzeigen


