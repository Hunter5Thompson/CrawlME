

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Umwelt](/wirtschaft/umwelt)
* [Umweltausgaben](/umweltausgaben)

Umwelt­schutz­ausgaben und -produkte
====================================

Die Erhebungen im Bereich Umweltökonomie umfassen die Investitionen für den Umweltschutz im Produzierenden Gewerbe und der Güter und Leistungen für den Umweltschutz bei Betrieben.

ZeitreihenBasisdaten

Zeitreihen
----------

BetriebeInvestitionen1 Betriebe im Bergbau, Gewinnung von Steinen und Erden und Verarbeitendes Gewerbe**Quelle:** Amt für Statistik Berlin-Brandenburg

**Zeitreihen** geben die Entwicklung wichtiger Kennzahlen über einen Zeitraum von etwa zehn Jahren wieder. **Lange Reihen** dokumentieren die wirtschaftliche und gesellschaftliche Entwicklung in Berlin und Brandenburg über einen Zeitraum von meist mehr als 20 Jahren.

[Zeitreihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/1ed3929d1aa76272/d4c31b902230/umweltausgaben-zeitreihe-2017-umweltschutzausgaben.xlsx)[Lange Reihe (.XLSX)](https://download.statistik-berlin-brandenburg.de/c53beb6ce15cd8a6/f2fd9ffc9803/umweltausgaben-lange-reihe-2017-umweltschutzausgaben.xlsx)

Basisdaten
----------

Haben Sie Fragen?
-----------------

#### Stephan Opitz

Umwelt, Umweltökonomische Gesamtrechnungen

#### Stephan Opitz

Umwelt, Umweltökonomische Gesamtrechnungen

* [0331 8173-1240](tel:0331 8173-1240)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Dr. Anne-Katrin Stephan

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

#### Dr. Anne-Katrin Stephan

Umwelt, UMWELTÖKONOMISCHE GESAMTRECHNUNGEN

* [0331 8173-1247](tel:0331 8173-1247)
* [umwelt@statistik-bbb.de](mailto:umwelt@statistik-bbb.de)
#### Bleiben Sie mit unserem Newsletter auf dem Laufenden.

[Jetzt abonnieren](/newsletter)

Weitere Publikationen zum Thema
-------------------------------

[![iStock-968906216.jpg](https://download.statistik-berlin-brandenburg.de/de73473a84e6df5a/fd72727beb4c/v/9e312ba3eb79/gaspipeline.jpg "iStock-968906216.jpg")](/169-2024)**Energie- und CO₂-Bilanz 2023 Berlin**[#### Energieverbrauch und CO₂-Emissionen weiter gesunken](/169-2024)

Die vorläufigen Ergebnisse der Energie- und CO₂-Bilanz 2023 zeigen auch weiterhin einen Rückgang beim Energieverbrauch und bei den CO₂-Emissionen.

[![Ein Windrad und weiter Blick in die Landschaft](https://download.statistik-berlin-brandenburg.de/2fe0c01ea1e3b28f/36c8abef068e/v/58c54355b18c/wirtschaft-preise-wind-turbine-in-the-sunset-seen-from-an-aerial-view-picture-id864427886.jpg "Ein Windrad und weiter Blick in die Landschaft")](/news/2024/nachhaltigkeit-biodiversitaet)**10 Diagramme zu den Deutschen Aktionstagen Nachhaltigkeit**[#### Biodiversität im Fokus](/news/2024/nachhaltigkeit-biodiversitaet)

Deutsche Aktionstage Nachhaltigkeit mit Schwerpunkt Biodiversität: Mit aktuellen Zahlen unterstreichen wir die Bedeutung der biologischen Vielfalt in unserer Region.

[![iStock-489193525.jpg](https://download.statistik-berlin-brandenburg.de/82f8600a57afaea2/97abf801f9a3/v/c70b556b56c6/wirtschaft-wirtschaftsbereiche-photovoltaikanlage.jpg "iStock-489193525.jpg")](/130-2024)**Stromeinspeisung 1. Halbjahr 2024 in Berlin und Brandenburg**[#### Sommer, Sonne, Sonnenschein… Ausbau der Photovoltaikanlagen schreitet voran](/130-2024)

Pressemitteilung Nr. 130 Das erste Halbjahr 2024 zeichnete sich durch einen beachtenswerten Zuwachs der Stromeinspeisung aus Photovoltaikanlagen aus. Während in Berlin im ersten Halbjahr 2023 noch...

[Zu unseren News](/news)

[* Klimaschutz](/search-results?q=tag%3AKlimaschutz)[* Investition](/search-results?q=tag%3AInvestition)[* Umweltschutz](/search-results?q=tag%3AUmweltschutz)[* Umweltschutzprodukt](/search-results?q=tag%3AUmweltschutzprodukt)[* Umweltschutzausgaben](/search-results?q=tag%3AUmweltschutzausgaben)[* Umweltschutzinvestitionen](/search-results?q=tag%3AUmweltschutzinvestitionen)
