

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Land- und Forstwirtschaft](/land-und-forstwirtschaft)
* [Rinder in Berlin und Brandenburg](/c-iii-9-hj)

Rinder in Berlin und Brandenburg
--------------------------------

#### 3. November 2024, halbjährlich

###### Die Erhebung informiert über die Anzahl der Rinder (einschließlich Büffel/Bisons), gegliedert nach Alter, Geschlecht, Nutzungszweck und Rasse.

BerlinBrandenburgMethodik
### Berlin

#### **Zum aktuellen Statistischen Bericht – 3. November 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/bd84334e7ff10a1b/8ab07014e8d6/SB_C03-09-00_2024h02_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/d68d0e91b0ae5b0f/757eefcf4e89/SB_C03-09-00_2024h02_BE.pdf)

**Büffel häufigste Rasse in Berlin**

Zum 3. November 2024 wurden in Berlin 848 Rinder gehalten. Das waren 17,5 % mehr als am 3. Mai des Jahres. Die häufigsten Rassen waren Büffel mit knapp 170 Tieren und Highlander mit 150 Tieren sowie Holstein-Schwarzbunt mit gut 110 Tieren.

Knapp 100 Rinder waren Milchkühe und weitere 320 zählten zu den sonstigen Kühen. Damit machten die Kühe fast die Hälfte des Berliner Rinderbestandes aus.

### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Zahl der Rinder auf historischem Tiefststand**

Am 3. November 2024 gab es in Brandenburg 417.500 Rinder.  Das waren 14.600 Tiere bzw. 3,4 % weniger als im Mai dieses Jahres. Gleichzeitig ist dies der geringste Bestand an Rindern in Brandenburg seit der Neugründung des Landes 1990.

Vom Rückgang des Rinderbestandes waren alle Altersgruppen und Nutzungsrichtungen betroffen. So verringerte sich der Bestand an Milchkühen um 3.500 auf 118.200 Tiere bzw. um 2,9 %. Auch die Zahl der Ammen- und Mutterkühe nahm um 2.400 auf 75.800 Tiere bzw. um 3,1 % ab. Bei den Kälbern war ein Rückgang um 3.400 auf 86.800 Tiere bzw. um 3,7 % und bei den Jungrindern um 900 auf 31.400 Tiere bzw. um 2,9 % zu verzeichnen.

Noch größer war der Rückgang bei den 1 bis unter 2-jährigen Rindern. Hier war eine Bestandsverringerung um 4.400 auf 81.500 Tiere bzw. um 5,1 % zu verzeichnen.

**Quelle:** Amt für Statistik-Berlin-Brandenburg
#### Z**um aktuellen Statistischen Bericht – 3. November 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/e91bde7655ce0da2/36627754086d/SB_C03-09-00_2024h02_BB.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/af1ff7923632d453/ea95726722ed/SB_C03-09-00_2024h02_BB.pdf)
### Kontakt

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

#### Birger Schmidt

Tierische Produkte und Flächenstatistik

* [0331 8173-3050](tel:0331 8173-3050)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

#### Heike Büttner

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3048](tel:0331 8173-3048)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

#### Dr. Thomas Troegel

Land- und Forstwirtschaft, Fischerei

* [0331 8173-3060](tel:0331 8173-3060)
* [agrar@statistik-bbb.de](mailto:agrar@statistik-bbb.de)
* [0331 817330-3041](fax:0331 817330-3041)
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Viehbestandserhebung Rinder ist eine Sekundärstatistik. Die Ergebnisse werden aus dem Herkunftssicherungs- und Informationssystem für Tiere (HIT) gewonnen. Erhebungsstichtage sind der 3. Mai und der 3. November eines jeden Jahres.

Seit Mai 2008 erfolgt die Erfassung der Merkmale allgemein. Vor dem Jahr 2008 wurden die Rinderbestände im Rahmen der Viehbestandserhebung durch Befragung der Landwirte primärstatistisch erfasst. Zur Erhebungsgesamtheit gehören seit 2008 landwirtschaftliche Haltungen im Sinne der Viehverkehrsverordnung, die in der HIT-Rinderdatenbank registriert sind.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Viehbestand und tierische Erzeugung (****Viehbestandserhebung Rinder)**  
Metadaten 2016

[Download PDF](https://download.statistik-berlin-brandenburg.de/0b4563164cbc8523/290259252185/MD_41312_2016.pdf)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/c-iii-9-hj)
