

* [Über uns](/ueber-uns)
* [Presse](/presse)
* [Service](/service)
* [Publikationen](/publikationen)
* [Karriere](/karriere)
* [Kontakt](/kontakt)
* [Daten melden](/daten-melden)

* [Wirtschaft](/wirtschaft)
* [Wirtschaftsbereiche](/wirtschaft/wirtschaftbereiche)
* [Tourismus und Gastgewerbe](/tourismus-und-gastgewerbe)
* [Gäste, Übernachtungen und Beherbergungskapazität in Berlin und Brandenburg](/g-iv-1-m)

Gäste, Übernachtungen undBeherbergungskapazität
-----------------------------------------------

#### Oktober 2024, monatlich

###### Die Monatserhebung im Tourismus liefert verlässliche Aussagen über den Stand und vor allem die kurzfristige Entwicklung des Inlandstourismus.

BerlinBrandenburgMethodik
### Berlin

**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – September**2024

[Download XLSX](https://download.statistik-berlin-brandenburg.de/c729c63be0f263a0/5b6794e785ac/SB_G04-01-00_2024m09_BE.xlsx)[Download PDF](https://download.statistik-berlin-brandenburg.de/2d334142f7f618c8/60ec71535be6/SB_G04-01-00_2024m09_BE.pdf)

**Tourismuserholung setzt sich fort**

Für die ersten neun Monate des Jahres 2024 meldeten die Berliner Beherbergungsbetriebe rund 9,5 Millionen Gäste mit 23 Millionen Übernachtungen. Das sind 5,1 % mehr Gäste und 2,8 % mehr Übernachtungen als im gleichen Zeitraum des Vorjahres, teilt das Amt für Statistik Berlin-Brandenburg mit.

Im September wurden 1.128.358 neu angekommene Gäste mit 2.748.183 Übernachtungen gezählt.

Ende des Monats waren in Berlin 738 geöffnete Beherbergungsstätten mit mindestens zehn Betten erfasst. Diese boten zusammen 147.973 Betten an. Die durchschnittliche Auslastung der Gästebetten von Januar bis September betrug 56,8 %. Zudem standen 11 Urlaubscampingplätze für einen Berlin-Aufenthalt zur Verfügung.

### Kontakt

#### Stefanie Chlebusch

Tourismus

#### Stefanie Chlebusch

Tourismus

* [0331 8173-3586](tel:0331 8173-3586)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de )
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Brandenburg

**Reiseland Brandenburg bleibt beliebt**

Rund 4,8 Millionen Gäste mit 12,8 Millionen Übernachtungen meldeten die Brandenburger Beherbergungsbetriebe dem Amt für Statistik Berlin-Brandenburg für die ersten zehn Monate des Jahres 2024. Das sind 4,5 % mehr Gäste und 1,1 % mehr Übernachtungen als im gleichen Zeitraum des Vorjahres.

Für den Oktober wurden 482.966 neu angekommene Gäste mit 1.284.167 Übernachtungen gemeldet.

Ende des Monats waren in Brandenburg 1.513 geöffnete Beherbergungsstätten mit mindestens zehn Betten erfasst. Diese boten zusammen 89.713 Betten an. Die durchschnittliche Auslastung der Gästebetten von Januar bis Oktober betrug 42,0 %. Zudem standen 149 Urlaubscampingplätze für einen Aufenthalt im Land Brandenburg zur Verfügung.

  


**Quelle:** Amt für Statistik Berlin-Brandenburg
#### **Zum aktuellen Statistischen Bericht – Oktober 2024**

[Download XLSX](https://download.statistik-berlin-brandenburg.de/768555806884df90/5ca167ef9b71/SB_G04-01-00_2024m10_BB.xlsx) [Download PDF](https://download.statistik-berlin-brandenburg.de/63e42afb2481d85f/d3b1be085f18/SB_G04-01-00_2024m10_BB.pdf)
### Kontakt

#### Stefanie Chlebusch

Tourismus

#### Stefanie Chlebusch

Tourismus

* [0331 8173-3586](tel:0331 8173-3586)
* [tourismus@statistik-bbb.de](mailto:tourismus@statistik-bbb.de )
#### Pressestelle

#### Pressestelle

* [0331 8173-1002, -1004](tel:0331 8173-1002, -1004)
* [presse@statistik-bbb.de](mailto:presse@statistik-bbb.de)
### Methodik und weitere Informationen

Die Monatserhebung im Tourismus beschreibt die konjunkturelle Entwicklung im Beherbergungsgewerbe. Sie liefert Informationen u.a. zu den Betriebstypen und -größen und der räumlichen Verteilung der Zahl der Ankünfte und der Übernachtungen von Gästen. Bei Gästen, deren Wohnsitz oder gewöhnlicher Aufenthaltsort außerhalb Deutschlands liegt, wird auch das jeweilige Herkunftsland erfasst.

Erhoben werden bei Betriebsstätten ab 10 Betten die Zahl der angebotenen Schlafgelegenheiten, bei Campingplätzen ab 10 Stellplätze die Anzahl der Stellplätze und bei Betrieben der Hotellerie zusätzlich die Zahl der Gästezimmer zum Stichtag 31.07. Für Hotelleriebetriebe mit 25 und mehr Zimmern wird außerdem monatlich die Auslastung der Gästezimmer erfragt.

#### Metadaten zu diesem Bericht

Wie kommen die Daten für den Statistischen Bericht zustande? Die Metadaten geben Aufschluss über die erhobenen Daten, enthalten den Erhebungsbogen sowie ggf. auch eine Datensatzbeschreibung.

**Monatserhebung im Tourismus**  
Metadaten ab 2024

[Download PDF](https://download.statistik-berlin-brandenburg.de/55944d847fb1b217/29a451146908/MD_45412_2024.pdf)[Archiv](/search-results?q=MD_45412&searchMethodik=true&pageNumber=1&sortBy=date-desc&searchByButton=true)[### Alle Berichtszeiträume finden Sie im Archiv.](/archiv/g-iv-1-m)
